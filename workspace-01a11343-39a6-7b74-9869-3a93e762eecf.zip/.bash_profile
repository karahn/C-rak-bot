# Arena: Çırak bot bekçisi (otomatik süpervizör kurtarma)
[ -f "$HOME/cirak/bekci.sh" ] && . "$HOME/cirak/bekci.sh"
