#!/bin/bash
# Mac / Linux / Termux: giriş yap, botları arka planda başlat
cd "$(dirname "$0")"
python3 giris.py || exit 1
nohup python3 -u supervizor.py > supervizor_out.txt 2>&1 &
echo "Botlar arka planda başladı (pid $!)"
echo "Durum: tail -f supervizor_log.txt   |   Tek satır: python3 hizli.py"
