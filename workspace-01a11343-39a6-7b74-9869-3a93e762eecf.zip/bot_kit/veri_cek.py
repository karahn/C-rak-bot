"""Kayıtlı çerezle Çırak API'sinden veri çeker."""
import json, time, http.cookiejar, urllib.request, urllib.error, sys

def oturum():
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124'),
                     ('Referer','https://oyunsitem.com/cirak/'), ('Accept','application/json')]
    return op, cj

def cek(op, yol, veri=None, kaydet=None):
    url = 'https://oyunsitem.com/cirak/api/' + yol
    data = json.dumps(veri).encode() if veri is not None else None
    req = urllib.request.Request(url, data=data,
                                 headers={'Content-Type':'application/json'} if data else {})
    try:
        with op.open(req, timeout=25) as r:
            govde = json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try: govde = json.loads(e.read().decode())
        except Exception: govde = {'hata': f'HTTP {e.code}'}
    except Exception as e:
        govde = {'hata': str(e)}
    if kaydet:
        json.dump(govde, open(kaydet,'w'), ensure_ascii=False, indent=1)
    return govde

if __name__ == '__main__':
    op, cj = oturum()
    for yol in sys.argv[1:]:
        kaydet = None
        if ':' in yol and yol.split(':', 1)[1].endswith('.json'):
            yol, kaydet = yol.split(':',1)
        print('===', yol, '===')
        r = cek(op, yol, kaydet=kaydet)
        s = json.dumps(r, ensure_ascii=False)
        print(s[:2000] + ('...' if len(s) > 2000 else ''))
        time.sleep(1.2)
