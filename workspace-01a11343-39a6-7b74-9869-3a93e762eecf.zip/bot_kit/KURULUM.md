# 🤖 Çırak Botları — Kurulum Kılavuzu

Benim hesabımda çalışan **aynı bot ailesi** — senin hesabına (Karahan) kurmak için hazır paket.
Süpervizör + 7 bot: tezgâh işleri, sokak olayları, keyif, rapor+mesaj, günlük ödüller ve mini oyun şampiyonu.

---

## 0) Pakette ne var?

| Dosya | İş |
|---|---|
| `giris.py` | Kullanıcı adı/şifre ile giriş yapar, captcha'yı **otomatik çözer**, çerezleri kaydeder |
| `supervizor.py` | Tüm botları tek süreçte çalıştırır; düşeni 3 sn'de yeniden başlatır |
| `grind4.py` | Tezgâhlarını işler, hasadı toplar |
| `sokak_bot.py` | Mahalle olaylarını yakalar + günlük görev ödülünü alır |
| `musteri_logger.py` | Bir dükkânın müşteri/ciro verisini kaydeder (dükkân no: `ISLETME`) |
| `keyif_bot.py` | Keyfi >80'de tutar (3 saatte bir 3x yürüyüş), uygun davetleri kabul eder |
| `rapor_bot.py` | 4 saatte bir DM raporu + mesaj izleme (alıcı: `RAPOR_ALICI`) |
| `gunluk_bot.py` | Günlük bonus, sezon, şans oyunları, oyun davetleri, oda eğitimi |
| `sampiyon.py` | Haftalık mini oyun sıralaması koşusu |
| `hizli.py` | Tek satır durum: kasa, vergi, TP, botlar |

---

## 1) Ne gerekiyor?

- **Python 3.10+** çalışan bir cihaz (Windows / Mac / Linux; Android'de Termux ile olur)
- Botların **çalışmaya devam etmesi** için cihazın açık kalması (uyuyan laptop = duran bot)
- Oyun hesabın **kullanıcı adı + şifresi**
- `numpy` (captcha çözücü kullanıyor — tek komutla kurulur)

---

## 2) Windows (PC) — 6 adım

1. https://python.org/downloads → Python 3.12 indir; kurarken **"Add python.exe to PATH"** kutusunu İŞARETLE.
2. `bot_kit` klasörünü örn. `C:\bot_kit` içine çıkart (zip'i sağ tık → Tümünü ayıkla).
3. Başlat → `cmd` yaz, aç. Şu komutu yaz:
   ```
   cd C:\bot_kit
   pip install -r requirements.txt
   ```
4. `AYARLAR.json` dosyasını Not Defteri ile aç, kullanıcı adı ve şifreni yaz:
   ```json
   { "kullanici": "Karahan", "sifre": "SIFREN" }
   ```
   *(Dosyayı kaydet; bu dosya şifreni içerir — kimseyle paylaşma!)*
5. `basla.bat` dosyasına çift tıkla. "OK Giriş başarılı" yazısını görürsen giriş tamam.
6. Botlar çalışmaya başlar; **pencereyi kapatma** (küçültebilirsin). Durumu görmek için başka bir cmd'de:
   ```
   cd C:\bot_kit
   python hizli.py
   ```

## 3) Mac / Linux — 4 adım

1. Klasörü çıkart, terminal aç, içine gir: `cd ~/bot_kit`
2. `python3 -m pip install -r requirements.txt`
3. `AYARLAR.json`'u düzenle (TextEdit/nano)
4. `bash basla.sh` → botlar arka planda başlar. Durum: `tail -f supervizor_log.txt`

## 4) Android telefon (Termux) — çalışır ama sabır ister

1. **F-Droid**'den Termux kur (Play Store'daki sürüm eski).
2. Termux'ta:
   ```
   pkg update && pkg install python -y
   pip install numpy
   ```
3. `bot_kit` dosyalarını telefona kopyala (zip'i indir, Termux'ta: `termux-setup-storage`, sonra `cd storage/downloads && unzip bot_kit.zip`).
4. `cd bot_kit && nano AYARLAR.json` → bilgileri yaz (Ctrl+O kaydet, Ctrl+X çık).
5. `termux-wake-lock` (ekran kapansa da uyumasın) → `bash basla.sh`
6. **Önemli:** Telefon şarjda kalsın; Ayarlar → Pil → Termux için "kısıtlama yok".

⚠️ **iPhone'da olmaz** — iOS arka planda Python çalıştırmaz. Alternatif: PC'de çalıştır, iPhone'dan sadece sonuçlara bak.

## 5) 7/24 kesintisiz istersen

| Seçenek | Not |
|---|---|
| Evdeki eski laptop / mini PC | Priz + uyku modunu kapat → en kolay |
| Raspberry Pi | Çok uygun (~elektrik masrafı yok gibi) |
| Ucuz VPS (≈4-5 $/ay) | İnternetteki sanal makine; benim sistemim de böyle bir bulutta çalışıyor |


---


---

## ⚠️ 0.56 UYARISI — GİRİŞ İÇİN ÇEREZ KULLAN (zorunlu)

Oyunun 0.56 sürümünde **captcha tamamen değişti**: artık içinde rakam yok
(sadece gürültü çizgileri ve noktalar = görsel bulmaca). Bu yüzden
`giris.py`'deki otomatik captcha çözücü **çalışmaz**.

**Kullanıcı adı + şifre ile otomatik giriş YAPILAMIYOR.**

### ✅ Çözüm: çerezle giriş (cerez_aktar.py)
1. Bilgisayarda/telefonda tarayıcıdan oyuna gir
2. `F12 → Application → Cookies → oyunsitem.com → tezgah_oturum` değerini kopyala
3. Klasörde: `python3 cerez_aktar.py YAPISTIR`
4. "✅ BAĞLANTI BAŞARILI" yazarsa tamam → `bash basla.sh`

Bu yöntem **kullanıcı adı/şifre gerektirmez** ve 0.56'da sorunsuz çalışır.
Çerez ~30 gün geçerli; ölünce 2-4. adımları tekrarla.

## 📱➡️🖥️ Google (veya Facebook) ile üye olduysan — 2 yol var

Bot sorun değil, çözümü kolay! Sırayla dene:

### Yol 1 — Oyunda şifre belirle (ÖNERİLEN, en kalıcı)
Oyun bunu destekliyor: **Hesabım → 🔑 Şifre belirle** → yeni şifreni yaz (eski şifre sorulmaz).
Artık kullanıcı adın + bu şifre ile de girebilirsin — bot da bunu kullanır:
```json
{ "kullanici": "Karahan", "sifre": "yeni_belirledigin_sifre" }
```
Google bağlantın da aynen kalır, bir şey bozulmaz.

### Yol 2 — Çerez taşıma (şifre hiç istemezsen)
1. Bilgisayarda oyunu aç, **Google ile giriş yap**.
2. `F12` → **Application** (Uygulama) → **Cookies** → `https://oyunsitem.com`
3. **tezgah_oturum** satırındaki **Value**'yu kopyala (uzun harf-dizi)
4. Klasörde şunu çalıştır:
   ```
   python3 cerez_aktar.py YAPISTIR
   ```
   Script `oturum_cerez.txt` dosyasını oluşturur ve bağlantıyı **doğrular** ("BAĞLANTI BAŞARILI: Karahan" yazar).
5. Sonra normal şekilde `basla.sh` / `basla.bat` ile botları başlat.

> ⏳ Çerez ~30 gün geçerlidir; süresi dolunca 2-4. adımları tekrarla. (Yol 1'i seçersen bu dert de olmaz.)

## 6) Ayarlar (isteğe bağlı)

Botlar ortam değişkeniyle ayarlanır (Windows: `set AD=deger` · Mac/Linux: `export AD=deger`):

| Değişken | Ne işe yarar | Varsayılan |
|---|---|---|
| `RAPOR_ALICI` | DM raporlarının gideceği kişi | `Karahan` |
| `BEN` | keyif_bot davet filtresi | `arastirmaci42` → **kendine göre değiştir** |
| `ISLETME` | musteri_logger'ın takip ettiği dükkân no | `5522` |

## 7) Sorun giderme

- **"captcha belirsiz"** satırları → normal, birkaç denemede çözer (skor eşiği geçilince girer).
- **"başka süpervizör zaten çalışıyor"** → zaten çalışıyor demektir, dokunma.
- **Botlar durdu mu?** Windows: Görev Yöneticisi → python. Mac/Linux: `ps aux | grep supervizor`.
- **Çerezler süresi dolduysa** → `python3 giris.py` tekrar çalıştır, yeniden giriş yapar.

## 8) Güvenlik & sorumluluk (kısa)

- `AYARLAR.json` şifreni içerir: kimseyle paylaşma, buluta koyma.
- Otomasyon, oyun hesabın için risk taşır (oyunlar botları sevmez 😄) — kararı ve riski sana ait. Benim hesapta aylardır çalışıyor, senin hesapta da benzer şekilde çalışacaktır ama garanti veremem.
- Şifre sadece giriş anında kullanılır; botlar sonrasında çerezlerle çalışır.

---

**Kurarken takılırsan söyle, o adımı birlikte çözeriz.** Hangi cihazda çalıştıracağını söylemen yeterli. 🔧
