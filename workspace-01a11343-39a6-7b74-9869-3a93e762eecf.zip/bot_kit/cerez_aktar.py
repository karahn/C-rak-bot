"""Çerez Aktar — Google/Facebook ile giriş yapanlar için ŞİFRESİZ kurulum.

Tarayıcıda oyuna gir (Google ile), sonra çerezi bota taşı:
  1) Chrome/Edge: oyun açıkken F12 → Application (Uygulama) → Cookies → https://oyunsitem.com
     → "tezgah_oturum" satırındaki **Value**'yu kopyala (uzun harf-dizi)
  2) Bu scripti çalıştır:  python3 cerez_aktar.py YAPISTIR
     (Windows: python cerez_aktar.py YAPISTIR)
  3) Script oturum_cerez.txt dosyasını oluşturur ve bağlantıyı DOĞRULAR.

Not: Çerez ~30 gün geçerlidir; süresi dolunca aynı adımı tekrarla.
Alternatif: Oyunda Hesabım → 🔑 Şifre belirle → AYARLAR.json'a yaz (daha kalıcı).
"""
import json, sys, time, http.cookiejar, urllib.request
from pathlib import Path


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        print('Kullanım: python3 cerez_aktar.py <tezgah_oturum değeri>')
        return
    ham = sys.argv[1].strip()
    # "tezgah_oturum=xxx; baska=yyy" biçiminde de yapıştırılabilir
    if 'tezgah_oturum=' in ham:
        ham = ham.split('tezgah_oturum=', 1)[1].split(';')[0].strip()
    ham = ham.strip('"\'')
    if not ham or len(ham) < 20:
        print('! Çerez değeri çok kısa görünüyor — doğru kopyaladığından emin ol.')
        return
    satirlar = [
        '# Netscape HTTP Cookie File',
        '# http://curl.haxx.se/rfc/cookie_spec.html',
        '# cerez_aktar.py oluşturdu',
        '',
        'oyunsitem.com\tFALSE\t/\tTRUE\t%d\ttezgah_oturum\t%s' % (int(time.time()) + 30 * 24 * 3600, ham),
        '',
    ]
    Path('oturum_cerez.txt').write_text('\n'.join(satirlar))
    print('oturum_cerez.txt yazıldı ✓ — bağlantı deneniyor...')
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent', 'Mozilla/5.0 Chrome/124'),
                     ('Referer', 'https://oyunsitem.com/cirak/'), ('Accept', 'application/json')]
    try:
        with op.open('https://oyunsitem.com/cirak/api/durum', timeout=25) as r:
            d = json.loads(r.read().decode())
        o = (d.get('oyuncu') or {})
        if o.get('kullaniciAdi'):
            print('✅ BAĞLANTI BAŞARILI: %s (seviye %s, TP %s)' % (o.get('kullaniciAdi'), o.get('seviye'), o.get('tecrube')))
            print('Şimdi botları başlat:  bash basla.sh   (Windows: basla.bat)')
        else:
            print('! Yanıt geldi ama oyuncu okunamadı — çerez eski olabilir; tarayıcıdan yenisini kopyala.')
            print(json.dumps(d, ensure_ascii=False)[:200])
    except Exception as ex:
        print('! Bağlantı kurulamadı: %s' % repr(ex)[:120])
        print('  İpucu: tezgah_oturum DEĞERİNİ kopyaladığından emin ol (adını değil).')


if __name__ == '__main__':
    main()
