@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === GIRIS ===
python giris.py
if errorlevel 1 (
  echo.
  echo Giris yapilamadi - AYARLAR.json dosyasini kontrol et.
  pause
  exit /b 1
)
echo.
echo === BOTLAR BASLIYOR (bu pencereyi KAPATMA, kucultebilirsin) ===
python -u supervizor.py
pause
