"""Giriş — kullanıcı adı + şifre ile oturum açar ve çerezleri oturum_cerez.txt'e kaydeder.

Captcha otomatik çözülür (4 rakam).
Kullanım:
  python3 giris.py                 (AYARLAR.json'dan okur)
  python3 giris.py kullanici sifre (komut satırından)
Sonra:  python3 -u supervizor.py   (botları başlatır)
"""
import importlib.util, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)


def yukle_cozucu():
    spec = importlib.util.spec_from_file_location('cozucu', os.path.join(HERE, 'cozucu.py'))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def main():
    cozucu = yukle_cozucu()
    kullanici = sifre = None
    if len(sys.argv) >= 3:
        kullanici, sifre = sys.argv[1], sys.argv[2]
    else:
        try:
            a = json.load(open('AYARLAR.json', encoding='utf-8'))
            kullanici = (a.get('kullanici') or '').strip()
            sifre = (a.get('sifre') or '').strip()
        except Exception as ex:
            print('AYARLAR.json okunamadı:', ex)
    if not kullanici or not sifre or kullanici == 'KULLANICI_ADIN':
        print('! Kullanıcı adı/şifre yok. AYARLAR.json dosyasını doldur (ya da: python3 giris.py kullanici sifre)')
        sys.exit(1)
    o = cozucu.Oturum()
    for deneme in range(1, 9):
        anahtar, cevap, skor = o.coz_ve_bilgi()
        if skor and max(skor) > 0.35:
            print('captcha belirsiz (skor %s), yenisi deneniyor...' % max(skor))
            continue
        r = o.json('giris', {'kullaniciAdi': kullanici, 'sifre': sifre,
                             'dogrulamaKod': cevap, 'dogrulamaAnahtar': anahtar})
        if 'hata' not in r:
            o.cj.save('oturum_cerez.txt', ignore_discard=True, ignore_expires=True)
            ad = kullanici
            try:
                ad = (r.get('oyuncu') or {}).get('kullaniciAdi') or kullanici
            except Exception:
                pass
            print('OK Giriş başarılı: %s — çerezler oturum_cerez.txt dosyasına kaydedildi.' % ad)
            return
        print('deneme %d: %s' % (deneme, str(r.get('hata'))[:120]))
    print('X Giriş yapılamadı. Bilgileri ve interneti kontrol et.')
    sys.exit(1)


if __name__ == '__main__':
    main()
