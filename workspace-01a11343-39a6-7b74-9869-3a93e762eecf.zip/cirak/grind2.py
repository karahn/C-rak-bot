"""Seyyar kazanç botu v2 — dükkân sermayesi biriktirir (araştırma hesabı).

Strateji:
 1) Pazar tezgâhını KENDİ çalıştır (en yüksek ₺/dk) → müşterilere bizzat servis yap (bahşiş).
 2) Boştaysa simit tezgâhını ÇIRAK ile çalıştır (ek gelir akışı).
 3) Biten işleri topla; günlük görev ödülünü al; yetenek puanlarını 'satis'e ver.
 4) Bakiye HEDEF'e ulaşınca dur.
"""
import json, os, time, http.cookiejar, urllib.request, urllib.error

TABAN = 'https://oyunsitem.com/cirak/api/'
HEDEF = float(os.environ.get('HEDEF_BAL', 115000))
MAKS_DK = float(os.environ.get('MAKS_DK', 90))
LOG = os.environ.get('GRIND_LOG', 'grind2_log.jsonl')
DUR = os.environ.get('GRIND_DUR', 'grind2_durum.json')

def oturum():
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124'),
                     ('Referer','https://oyunsitem.com/cirak/'), ('Accept','application/json')]
    return op

def cek(op, yol, veri=None):
    data = json.dumps(veri).encode() if veri is not None else None
    req = urllib.request.Request(TABAN + yol, data=data, headers={'Content-Type':'application/json'} if data else {})
    for _ in range(4):
        try:
            with op.open(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            try: g = json.loads(e.read().decode())
            except Exception: g = {'hata': f'HTTP {e.code}'}
            if e.code == 429:
                time.sleep(35); continue
            return g
        except Exception:
            time.sleep(5)
    return {'hata': 'istek başarısız'}

def logla(k):
    with open(LOG, 'a') as f:
        f.write(json.dumps(k, ensure_ascii=False) + '\n')

def durum_yaz(o):
    json.dump(o, open(DUR, 'w'), ensure_ascii=False, indent=1)

class Bot:
    def __init__(self):
        self.op = oturum()
        self.t0 = time.time()
        self.tur = 0
        self.toplam_servis = 0.0
        self.servis_adet = 0
        self.bahsis_adet = 0

    def durum(self):
        d = cek(self.op, 'durum') or {}
        o = d.get('oyuncu') or {}
        return (o.get('bakiye') or 0)/100, (o.get('seviye') or 1)

    def seyyar(self):
        return cek(self.op, 'seyyar') or {}

    def yetenek_dagit(self):
        y = cek(self.op, 'yetenekler') or {}
        for _ in range(y.get('bos') or 0):
            r = cek(self.op, 'yetenekler/yukselt', {'kod': 'satis'})
            logla({'olay': 'yetenek', 'sonuc': r})
            if 'hata' in r: break
        return y

    def topla(self):
        r = cek(self.op, 'seyyar/topla-hepsi', {})
        if isinstance(r, list) and r:
            for p in r:
                logla({'olay': 'topladi', 'kod': p.get('isKodu'), 'ciro': (p.get('ciro') or 0)/100,
                       'malzeme': (p.get('malzeme') or 0)/100, 'cirakUcreti': (p.get('cirakUcreti') or 0)/100,
                       'bonus': (p.get('bonus') or 0)/100, 'net': (p.get('net') or 0)/100,
                       'calisan': p.get('calisan'), 'olaylar': p.get('olaylar')})
            return r
        return None

    def gorev_odul(self):
        g = cek(self.op, 'gorevler') or {}
        if g.get('gorevler') and all(x.get('tamam') for x in g['gorevler']) and not g.get('alindi'):
            r = cek(self.op, 'gorevler/odul', {})
            logla({'olay': 'gorev_odul', 'sonuc': r})

    def servis_vur(self, is_id):
        """Bizzat servis: müşteri varsa bahşiş/hizmet kazancı."""
        r = cek(self.op, 'seyyar/servis', {'id': is_id})
        if r.get('reddedildi') or r.get('hata'):
            return None
        if isinstance(r.get('tutar'), (int, float)) and r['tutar'] > 0:
            self.toplam_servis += r['tutar']/100
            self.servis_adet += 1
            if r.get('bahsis'): self.bahsis_adet += 1
        # toplu sipariş teklifi geldiyse kabul et
        if r.get('teklif'):
            t = r['teklif']
            k = cek(self.op, 'seyyar/siparis', {'id': is_id, 'kabul': True})
            logla({'olay': 'siparis_kabul', 'teklif': t, 'sonuc': k})
            self.siparis_sur(k.get('id') or is_id)
        return r

    def siparis_sur(self, is_id):
        for _ in range(60):
            r = cek(self.op, 'seyyar/servis', {'id': is_id, 'parca': 5})
            sp = r.get('siparis') or {}
            if r.get('tutar') and sp.get('durum') == 'tamam':
                self.toplam_servis += r['tutar']/100
                logla({'olay': 'siparis_tamam', 'tutar': r['tutar']/100})
                break
            if sp.get('durum') in ('kacti', None) and not sp.get('durum'):
                break
            if sp.get('durum') == 'kacti':
                logla({'olay': 'siparis_kacti'}); break
            time.sleep(0.35)

    def calistir(self):
        self.yetenek_dagit()
        bakiye, seviye = self.durum()
        s = self.seyyar()
        if not (s.get('izin') or {}).get('var'):
            cek(self.op, 'seyyar/izin', {})
        self.topla()
        logla({'olay': 'baslangic', 'bakiye': bakiye, 'seviye': seviye})
        while bakiye < HEDEF and (time.time()-self.t0) < MAKS_DK*60:
            self.tur += 1
            s = self.seyyar()
            aktifler = s.get('aktifler') or []
            biten = [x for x in aktifler if x.get('bitti')]
            if biten:
                self.topla()
            self.gorev_odul()
            bakiye, seviye = self.durum()
            if bakiye >= HEDEF: break
            s = self.seyyar()
            aktifler = s.get('aktifler') or []
            kendi = next((x for x in aktifler if x.get('calisan') == 'ben' and not x.get('bitti')), None)
            if not kendi:
                r = cek(self.op, 'seyyar/basla', {'isKodu': 'pazar', 'sure': 'tam'})
                logla({'olay': 'basla', 'kod': 'pazar', 'sonuc': r, 'bakiye': bakiye})
                if 'hata' in r or 'id' not in r:
                    time.sleep(15); continue
                kendi = {'id': r['id'], 'isKodu': 'pazar', 'bitis': None}
                # ikinci tezgâhı çırağa ver
                r2 = cek(self.op, 'seyyar/basla', {'isKodu': 'simit', 'sure': 'tam'})
                logla({'olay': 'basla', 'kod': 'simit', 'sonuc': r2})
            # vardiya boyunca bizzat servis yap
            is_id = kendi['id']
            son_kontrol = time.time()
            while True:
                r = self.servis_vur(is_id)
                if r is None:
                    time.sleep(2.5)
                else:
                    time.sleep(1.2)
                if time.time() - son_kontrol > 20:
                    son_kontrol = time.time()
                    s2 = self.seyyar()
                    a = [x for x in (s2.get('aktifler') or []) if x.get('id') == is_id]
                    if not a or a[0].get('bitti'):
                        break
                    bakiye, _ = self.durum()
                durum_yaz({'tur': self.tur, 'bakiye': bakiye, 'seviye': seviye,
                           'servis_kazanc': round(self.toplam_servis, 2), 'servis_adet': self.servis_adet,
                           'bahsis_adet': self.bahsis_adet, 'sure_dk': round((time.time()-self.t0)/60, 1)})
            r = self.topla()
            bakiye, seviye = self.durum()
            durum_yaz({'tur': self.tur, 'bakiye': bakiye, 'seviye': seviye,
                       'servis_kazanc': round(self.toplam_servis, 2), 'servis_adet': self.servis_adet,
                       'bahsis_adet': self.bahsis_adet, 'sure_dk': round((time.time()-self.t0)/60, 1)})
        logla({'olay': 'bitti', 'bakiye': bakiye, 'seviye': seviye,
               'sure_dk': round((time.time()-self.t0)/60, 1), 'servis_kazanc': round(self.toplam_servis, 2)})

if __name__ == '__main__':
    Bot().calistir()
