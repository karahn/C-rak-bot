"""Uyku raporu — olcum_kalp.txt'teki 20 sn'lik damgaları okur, >40 sn boşlukları raporlar.
Kullanım: python3 olcum_rapor.py   (tek komut)
"""
import datetime, os, sys
from zoneinfo import ZoneInfo

TRT = ZoneInfo('Europe/Istanbul')

HERE = os.path.dirname(os.path.abspath(__file__))
yol = os.path.join(HERE, 'olcum_kalp.txt')
if not os.path.exists(yol):
    print('olcum_kalp.txt yok — kalp henüz başlamamış.'); sys.exit(0)

satirlar = [l.strip() for l in open(yol) if l.strip()]
if not satirlar:
    print('kalp boş.'); sys.exit(0)

def oku(l):
    p = l.split()
    return int(p[0]), p[1]

ilk, son = oku(satirlar[0]), oku(satirlar[-1])
print(f"toplam damga: {len(satirlar)} | ilk: {ilk[1]} | son: {son[1]}")
print()
print("=== uyku/takılma pencereleri (>40 sn boşluk; saatler TRT) ===")
onceki = ilk
bulundu = 0
for l in satirlar[1:]:
    s, t = oku(l)
    fark = s - onceki[0]
    if fark > 40:
        bulundu += 1
        uyanma = f"{datetime.datetime.fromtimestamp(s, TRT):%H:%M:%S}"
        print(f"  {onceki[1]} → {uyanma}  |  {fark//60} dk {fark%60} sn uyku")
    onceki = (s, t)
if not bulundu:
    print("  (henüz yok — sandbox kesintisiz koşuyor)")
