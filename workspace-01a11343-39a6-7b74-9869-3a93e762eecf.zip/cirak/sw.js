// Çırak servis çalışanı: oyun kapalıyken gelen bildirimleri gösterir ve dokununca oyunu açar.
// 0.38: oyunun değişmeyen dosyaları (müzik, intro filmi, modeller, dokular, yazı tipleri, sürümlü kod ve dil dosyaları)
// ilk kullanımda oyuncunun cihazına kaydedilir; sonraki açılışlarda internetten değil cihazdan okunur. Zayıf bağlantıda
// oyun hızlı açılır, müzik kesilmez. Sürümü değişen dosya (?v=) yeniden indirilir, eskisi silinir. Sayfanın kendisi
// (index.html) ve API istekleri her zaman sunucudan gelir (bağlantı yoksa son kayıtlı sayfa açılır).

const ONBELLEK = 'cirak-statik-1';
const STATIK = /\/(ses|video|model|doku|font|lib|veri|simge|dil|js)\/|\.(?:png|jpg|jpeg|webp|svg|ico|woff2?|glb|mp3|ogg|m4a|mp4|webm|json|js|css)$/i;

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

function kaydedilir(url) {
  if (url.origin !== self.location.origin) return false;
  if (url.pathname.includes('/api/') || url.pathname.endsWith('/sw.js')) return false;
  if (/\/(intro-cekim|intro-kareler)/.test(url.pathname)) return false;
  return STATIK.test(url.pathname);
}
// sürümlü olmayan kod/stil/dil dosyaları önce sunucuya sorulur (yoksa cihazdaki kullanılır)
function onceAg(url) {
  return !url.searchParams.has('v') && /\.(js|css|json)$/i.test(url.pathname) && !/\/(veri|model)\//.test(url.pathname);
}
// aynı dosyanın eski sürümleri silinir
async function eskileriSil(cache, url) {
  for (const k of await cache.keys()) {
    const u = new URL(k.url);
    if (u.pathname === url.pathname && u.search !== url.search) await cache.delete(k);
  }
}
async function kaydet(cache, istek, yanit) {
  if (!yanit || yanit.status !== 200 || yanit.type === 'opaque') return;
  const url = new URL(istek.url);
  try { await cache.put(url.href, yanit); await eskileriSil(cache, url); } catch (e) { /* kota dolu: sorun değil */ }
}
// kayıtlı tam dosyadan istenen bayt aralığı (müzik ve film oynatıcıları parça parça ister)
async function aralikYanit(tam, aralik) {
  const m = /bytes=(\d*)-(\d*)/.exec(aralik || '');
  const veri = await tam.arrayBuffer();
  const boy = veri.byteLength;
  let bas = m && m[1] !== '' ? Number(m[1]) : 0;
  let son = m && m[2] !== '' ? Number(m[2]) : boy - 1;
  if (m && m[1] === '' && m[2] !== '') { bas = Math.max(0, boy - Number(m[2])); son = boy - 1; }
  son = Math.min(son, boy - 1);
  if (bas > son) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${boy}` } });
  return new Response(veri.slice(bas, son + 1), {
    status: 206,
    headers: { 'Content-Type': tam.headers.get('Content-Type') || 'application/octet-stream', 'Content-Range': `bytes ${bas}-${son}/${boy}`, 'Content-Length': String(son - bas + 1), 'Accept-Ranges': 'bytes' },
  });
}

self.addEventListener('fetch', (e) => {
  const istek = e.request;
  if (istek.method !== 'GET') return;
  const url = new URL(istek.url);
  if (url.origin !== self.location.origin) return;
  // sayfanın kendisi: önce sunucu, bağlantı yoksa kayıtlı son sayfa
  if (istek.mode === 'navigate') {
    e.respondWith((async () => {
      try {
        const y = await fetch(istek);
        if (y.ok) { const c = await caches.open(ONBELLEK); c.put('sayfa:' + url.pathname, y.clone()).catch(() => {}); }
        return y;
      } catch (x) {
        const c = await caches.open(ONBELLEK);
        return (await c.match('sayfa:' + url.pathname)) || Response.error();
      }
    })());
    return;
  }
  if (!kaydedilir(url)) return;
  const aralik = istek.headers.get('range');
  e.respondWith((async () => {
    const cache = await caches.open(ONBELLEK);
    if (onceAg(url) && !aralik) {
      try { const y = await fetch(istek); if (y.ok) e.waitUntil(kaydet(cache, istek, y.clone())); return y; } catch (x) { return (await cache.match(url.href)) || Response.error(); }
    }
    const kayitli = await cache.match(url.href);
    if (kayitli) return aralik ? aralikYanit(kayitli, aralik) : kayitli;
    if (aralik) {
      // ilk oynatma ağdan akar; dosyanın tamamı arka planda cihaza kaydedilir
      e.waitUntil(fetch(url.href, { credentials: 'same-origin' }).then((y) => kaydet(cache, istek, y)).catch(() => {}));
      return fetch(istek);
    }
    const y = await fetch(istek);
    e.waitUntil(kaydet(cache, istek, y.clone()));
    return y;
  })());
});

self.addEventListener('push', (e) => {
  let v = {};
  try { v = e.data ? e.data.json() : {}; } catch (x) { v = { metin: e.data ? e.data.text() : '' }; }
  const baslik = v.baslik || 'Çırak';
  e.waitUntil(self.registration.showNotification(baslik, {
    body: v.metin || '',
    tag: v.etiket || 'tezgah',
    renotify: true,
    icon: 'simge-192.png',
    badge: 'simge-rozet.png',
    lang: 'tr',
    data: { adres: v.adres || '#/mahalle' },
  }));
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const adres = (e.notification.data && e.notification.data.adres) || '#/mahalle';
  const hedef = new URL('./' + (adres.startsWith('#') ? adres : '#/mahalle'), self.registration.scope).href;
  e.waitUntil((async () => {
    const pencereler = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const p of pencereler) {
      if (p.url.startsWith(self.registration.scope)) {
        p.postMessage({ git: adres });
        return p.focus();
      }
    }
    return self.clients.openWindow(hedef);
  })());
});

// Tarayıcı aboneliği kendiliğinden yenilerse sunucuya bildir
self.addEventListener('pushsubscriptionchange', (e) => {
  e.waitUntil((async () => {
    try {
      const yanit = await fetch('api/bildirim', { credentials: 'same-origin' });
      if (!yanit.ok) return;
      const { anahtar } = await yanit.json();
      const dolgu = '='.repeat((4 - (anahtar.length % 4)) % 4);
      const ham = atob((anahtar + dolgu).replace(/-/g, '+').replace(/_/g, '/'));
      const abone = await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Uint8Array.from(ham, (c) => c.charCodeAt(0)) });
      await fetch('api/bildirim/abone', {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ abonelik: abone.toJSON() }),
      });
    } catch (x) { /* bir sonraki girişte oyun yeniden abone olur */ }
  })());
});
