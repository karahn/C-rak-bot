# 🏪 Karahan — Yeni Dükkân Analiz Raporu

**Tarih:** 2 Ekim 2026 · **Hazırlayan:** asistanın `arastirmaci42` (oyun içi)
**Veri:** 70 ilçe canlı taraması (Ankara 25 + İstanbul 39 + İzmir 6) · 71 dükkân türü kataloğu · kendi Şarküteri'mden 1. gün ölçümü
**Senin durumun:** sv6 · Keçiören · 6 dükkân + 8 tezgâh · rayiç: Güçlükaya/Zileliler Cad.

---

## ⚡ 30 Saniyede Özet

| # | Dükkân | Neden | Açılış (küçük parsel) |
|---|---|---|---|
| 🥇 | **Çay ocağı** | 16 saat açık + **Keçiören'de SIFIR rakip** + en ucuz kurulum | **83.200 ₺** |
| 🥈 | **Seyahat acentesi** | Hizmet dükkânı (stok yok) + **70 ilçede hiç yok** + 1 çalışan | 158.200 ₺ |
| 🥉 | **Kebapçı** | sv6 rozet dükkânı + **70 ilçede hiç yok** (tam monopol) | 248.200 ₺ |
| 👏 | Büfe'yi zaten kaptın | 18 saat = oyunun en uzun mesaisi | — |

**Uzak dur:** Dönerci, Kafe, Pideci, Tatlıcı, Kasap, Kuruyemişçi, Telefoncu, Eczane — hepsinde Keçiören'de 2 rakip var ve müşteriler bölünüyor.

---

## 📏 Yöntem: Ölçüm Çıpası (benim Şarküteri, 1. gün)

| Ölçüm | Değer |
|---|---|
| Ciro (13 saat, 37 müşteri) | 21.540 ₺ |
| Kayıtlı gider | 15.073 ₺ (sabit ~8.298 + malzeme ~6.776) |
| **Net** | **+6.467 ₺** |
| Kaçan satış | 25 (raf %37 doluydu — stok şart!) |

**Türetilen model** (tüm tahminler bununla):
- Ciro ≈ **1.657 ₺/saat** (küçük dükkân, rakipsiz)
- Sabit gider ≈ **8.300 ₺/gün** (kira + 1 çalışan + elektrik/su)
- Malzeme ≈ cironun **%31,5'i** → brüt marj %68,5
- Kontrol: 13 saat × 1.657 = 21.541 ₺ ciro → net +6.456 ₺ ✓ (gerçekleşen +6.467)

> ⚠️ Bu model gıda/perakende dükkânlar için geçerli; tür farkları ±%50 sapma yaratabilir.

---

## 🕐 Oyunun Dükkân Mesaileri (70 ilçeden ölçüldü)

| Saat | Dükkânlar |
|---|---|
| **18 sa (06–24)** | **Büfe** (sende! 🎉) |
| **16 sa** | Çay ocağı (06–22) · Bakkal (07–23) · Kafe (08–24) |
| 15 sa | Fırın (06–21) · Market (08–23) |
| 14 sa | Dönerci (10–24) |
| 13 sa | Manav · Kuruyemişçi · Şarküteri · Elektrikçi · Su tesisatçısı (08–21) + Tatlıcı (10–23) |
| 12 sa | Berber · Kuaför · Bebek mağazası · Kasap · Nalbur · Züccaciye · Kırtasiye · Çiçekçi (09–21) |
| 11 sa | Ziraat bayisi (08–19) · Lokanta (11–22) · Telefoncu · Giyim · Ayakkabıcı (10–21) |
| 10 sa | Terzi · Kargo · Emlakçı (09–19) · Eczane (09–19) |

**Gerçek 24 saat açık dükkân YOK** — en uzunu senin Büfe'n (18 saat).

---

## 🏆 Fırsat Tablosu (sv ≤ 6 + Keçiören rakip durumu)

Küçük parsel açılışı = 63.200 (depozito) + 5.000 (ruhsat) + kurulum. Günlük ciro = saat × 1.657 ₺ (tahmin).

| Dükkân | Sv | Kurulum | Saat | Çalışan | Rakip | Açılış (küçük) | Ciro/gün (tah.) | Net/gün (tah.) |
|---|---|---|---|---|---|---|---|---|
| **Çay ocağı** ⭐ | 1 | 15.000 | 16 | 1 | **0** | **83.200 ₺** | ~26.500 ₺ | **~+9.900 ₺** |
| **Seyahat acentesi** | 6 | 90.000 | ?* | 1 | **0** | 158.200 ₺ | ? | hizmet (stok yok) |
| **Kebapçı** | 6 | 180.000 | ?* | 3 | **0** | 248.200 ₺ | yüksek potansiyel | sabit gider ↑↑ |
| Berber | 1 | 50.000 | 12 | 1 | **0** | 118.200 ₺ | ~19.900 ₺ | hizmet |
| Su tesisatçısı | 3 | 60.000 | 13 | 1 | **0** | 128.200 ₺ | ~21.500 ₺ | hizmet |
| Elektrikçi | 3 | 50.000 | 13 | 1 | **0** | 118.200 ₺ | ~21.500 ₺ | hizmet |
| Kuaför | 2 | 80.000 | 12 | 2 | **0** | 148.200 ₺ | ~19.900 ₺ | hizmet |
| Bebek mağazası | 2 | 85.000 | 12 | 1 | **0** | 153.200 ₺ | ~19.900 ₺ | ~+5.300 ₺ |
| Oyuncakçı | 2 | 80.000 | 11 | 1 | **0** | 148.200 ₺ | ~18.200 ₺ | ~+4.200 ₺ |
| Ayakkabıcı | 3 | 90.000 | 11 | 1 | **0** | 158.200 ₺ | ~18.200 ₺ | ~+4.200 ₺ |
| Pastane | 3 | 90.000 | ?* | 2 | **0** | 158.200 ₺ | ? | sabit ↑ |
| Fırın | 2 | 80.000 | 15 | 2 | 1 | 148.200 ₺ | ~24.900 ₺ | sabit ↑ |
| Kırtasiye | 1 | 40.000 | 12 | 1 | 1 | 108.200 ₺ | ~19.900 ₺ | ~+5.300 ₺ |
| Çiçekçi | 1 | 40.000 | 12 | 1 | 1 | 108.200 ₺ | ~19.900 ₺ | ~+5.300 ₺ |
| Temizlik ürünleri | 2 | 55.000 | 12 | 1 | 1 | 123.200 ₺ | ~19.900 ₺ | ~+5.300 ₺ |

\* Saati oyun verisinde hiç görülmedi (tahmini: acente 09–19, kebapçı 11–23, pastane 08–21 civarı).

### 🎯 "Hayalet" Dükkânlar — 70 ilçede HİÇ yok (tam monopol!)
Oyunun NPC esnafı bu türleri hiç açmamış. Sen açarsan ilçede (ve şu an tüm örneklemde) rakipsizsin:

**Kebapçı · Pastane · Balıkçı · Börekçi · Tavukçu · Çiğ köfteci · Kitapçı · Pet shop · Saatçi · Perdeci · Çantacı · İç giyim · Aktar · Çilingir · Hırdavatçı · Boya satıcısı · Halıcı · Bilgisayarcı · Oto yedek parça · Matbaa · Sürücü kursu · Mali müşavir · Hukuk bürosu · Gümrük müşaviri ...**

En ucuzları: Aktar 30k · Çilingir 30k · Çiğ köfteci 40k · Tavukçu 50k · Balıkçı/Börekçi 60k.
Hizmet olanlar (stok derdi yok): Çilingir 30k · Fotoğrafçı 70k · Seyahat acentesi 90k · Kuru temizleme 150k · Matbaa 160k.

---

## 🧮 Neden Çay Ocağı #1?

1. **16 saat mesai** — Büfe'den sonra en uzun; akşam 22'ye kadar müşteri
2. **Keçiören'de sıfır rakip** — müşteri bölünmesi yok, tanıtım gerekmez
3. **En düşük giriş:** 83.200 ₺ toplam (Keçiören'de açılabilecek en ucuz dükkân)
4. **Tek çalışan** → sabit gider düşük, risk küçük
5. Tahmini geri ödeme: açılışın ~8-9 günde çıkması (kaba model)

**Parsel durumu (Keçiören boş):** küçük **No 17, 21** (31.600 ₺/ay) · orta No 15, 24, 29, 35 (71.100 ₺/ay)
→ Küçük parsel yalnızca 2 tane kaldı, acele et. Orta parsel daha çok müşteri çeker ama depozito 2 katı (142.200 ₺).

---

## 💡 Operasyon Kuralları (ölçümden çıkan dersler)

1. **Açılışta rafı %40+ doldur** — benim ilk gün 25 satış stok yüzünden kaçtı (~5-8k ₺ kayıp)
2. **Oto-tedarik açık tut** — yetmezse hesabından çeker, satış kaçmaz
3. **Fiyatları piyasa bandında tut (%30 altı – 3 kat üstü arası serbest)** — ucuz + dolu raf daha çok satar
4. **Günde bir kez kasayı topla** — kasa boşsa oto-tedarik hesabına yüklenir
5. Krediyi (İşletme) büyüme için kullan ama 3 günlük gider tamponu (~25k) kasta dursun

---

## 📬 Sıradaki adım
Dükkânı açtıktan sonra bana yaz ("açtım") → **3 ekonomi günü** veri toplayıp senin dükkânının ciro/müşteri/net raporunu çıkarırım (tıpkı kendi Şarküteri ölçümüm gibi).

---
### 📎 Ek: Tezgâh notu
Uzaktan servis testi: senin tezgâhlar açıkken (tam gün vardiya, +6,7 dk kala) denedim → sunucu **"Bu tezgâhta iş sürmüyor"** dedi. Sonuç: **servis yalnızca tezgâh sahibine açık**, uzaktan yapılamıyor. Yani tezgâh cironu artırmanın tek yolu başında durup müşteriye servis yapmak (ciro 1,5–2 katına çıkıyor). Gözleme + kokoreç hamlen çok iyi — kokoreç tam gün tahmini neti oyunun kendi hesabıyla **~9.000 ₺**.
