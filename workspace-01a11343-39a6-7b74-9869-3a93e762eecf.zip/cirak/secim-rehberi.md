# 🗳️ Çırak — Seçim ve Adaylık Rehberi
*(4 Ekim 2026 · kaynaktan birebir çözüldü)*

---

## 1) Meslek Odası Başkanlığı 🧰

**Takvim (her ay aynı):**
| Gün | Ne oluyor |
|---|---|
| **1–7** | Açık adaylık dönemi (vaadinizi yazıp aday olursunuz) |
| **8–14** | Oylama dönemi (üyeler oy verir) |
| 15+ | Sonuç; kazanan **ayın 1'inde göreve başlar**, görev **1 ay** |

**Şartlar:**
- **Aday olmak için:** o odanın **üyesi** olmak + **en az 10. seviye**
- Üyelik işletme türünden kendiliğinden doğar (Esnaf: dükkân/tezgâh · Ticaret: şirket ya da 3+ dükkân · Sanayi: fabrika/maden/enerji/teknoloji/savunma tesisi)
- **Oy vermek için:** o ildeki oda üyesi olmak (seviye şartı yok)
- Aidat ödenmemişse (borç) avantajlar kapanır — oy/adaylık için de önce aidat gerekir

**Kurallar:**
- Aynı anda **yalnızca bir seçimde** aday olunabilir
- Kimse en az 3 oy alamazsa **sistem ağırlıklı kurayla** başkanı belirler
- Adaylar **afiş (sertifika) paylaşır** — afişten gelen herkes oy verebilir → **destekçi ağı önemli!**

**Ankara durumu (4 Ekim):**
- 🧰 Esnaf Odası: 20 üye · kasa 5.000₺ · **adaylık açık, henüz aday YOK**
- 🏛️ Ticaret Odası: 3 üye · kasa 4.500₺ · **aday YOK** (en kolay kazanılacak oda!)
- 🏭 Sanayi Odası: 0 üye (fabrika şartı)

> ⚠️ Biz sv5'iz — **sv10 olunca** oda başkanlığına aday olabiliriz.

---

## 2) Devlet Seçimleri 🏛️

| Makam | Seviye şartı | Adaylık ücreti | Takvim | Ödül / not |
|---|---|---|---|---|
| 🏘️ **İlçe Belediye Başkanı** | sv10 | 5.000₺ | Her ay (3 gün adaylık + 3 gün oylama) | Yalnızca ilçe sakinleri oy verir/kazanır |
| 🏙️ **İl Belediye Başkanı** | sv12 | 7.500₺ | Aynı takvim | **Dönem sonunda kasanın %20'si ödeneğiniz olur!** |
| 🏛️ **Milletvekili** | sv10 | 7.500₺ | Her ay (ayın 16'sında göreve başlar) | 81 ilde 600 sandalye; ilinizdekiler oy verir |
| 🇹🇷 **Cumhurbaşkanı** | sv15 | 50.000₺ | İki ayda bir (Ocak, Mart, Mayıs, Tem, Eyl, Kas) | En çok oy alan CB, sonraki 5 aday yardımcısı |

**Kurallar:**
- Aynı anda tek seçimde adaylık · Bağlantı başına 1 oy · Oy değiştirilemez
- Aday yoksa/yetersizse sistem aday ekler; 3 oy altı kalırsa kura
- Aday afişleri sosyal ağda paylaşılabilir (destek toplama)

---

## 3) Nasıl okunur/görülür? 👀

| Ne | Nerede |
|---|---|
| Odalar paneli | Oyun içi **Devlet binası → Meslek Odaları** (yeni binalar: 4 Ekim güncellemesiyle her ilçede *valilik, kaymakamlık, belediye*) |
| Seçim paneli | **Devlet → Seçimler** sekmesi (belediye / il belediye / milletvekilliği / cumhurbaşkanlığı) |
| Kendi durumun | Panelde "aday mısın / oyun mu kullandın / kalan süre" göstergeleri görünür |
| Adaylık koymak | Paneldeki **"Adaylığımı koy (ücret)"** düğmesi + kısa vaat yazısı |
| Oy kullanmak | Oylama günlerinde (8–14) aday listesindeki **"Oy ver"** düğmesi |

---

## 4) Bizim plan 🎯

1. **Şimdi → sv6 (emlakçı):** TP 339/400 — çok yakın!
2. **sv10'a kadar büyüme:** dükkânlar + şampiyon ödülleri + günlük görevler
3. **sv10'da:** Ticaret Odası (3 üye — kolay zafer!) ve İlçe Belediye adaylığı
4. **sv12:** İl Belediye (kasası büyük → %20 ödenek ciddi para)
5. **sv15:** Cumhurbaşkanlığı (uzun vade)

**Not:** Aday olursak Karahan ve arkadaşları afişten desteğe çağırabiliriz — oy sayısı bağlantı başına 1 olduğundan ne kadar çok kişi o kadar iyi. 😄
