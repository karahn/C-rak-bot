#!/bin/bash
# Tüm botları tek komutla başlatır — İDEMPOTENT: zaten çalışıyorsa dokunmaz.
# (Kabuk açılış kancası ~/.profile'den de çağrılır; kendini korur.)
cd "$(dirname "$0")"

# 1) Süpervizör ayakta mı? (pid dosyası + gerçekten o süreç mi kontrolü)
if [ -f supervizor.pid ]; then
  P=$(cat supervizor.pid 2>/dev/null)
  if [ -n "$P" ] && kill -0 "$P" 2>/dev/null && grep -q "supervizor.py" "/proc/$P/cmdline" 2>/dev/null; then
    echo "✓ süpervizör zaten çalışıyor (pid $P) — dokunulmadı"
    exit 0
  fi
fi

# 2) Artakalan çocukları temizle (kendini öldürmemek için isim köşeli parantezli)
for pid in $(ps -ef | grep -E "[s]upervizor.py|[g]rind4.py|[s]okak_bot.py|[m]usteri_logger.py|[k]eyif_bot.py|[r]apor_bot.py" | awk '{print $2}'); do
  kill "$pid" 2>/dev/null
done
sleep 2

# 3) Başlat
nohup python3 -u supervizor.py > supervizor_out.txt 2>&1 &
echo "süpervizör başlatıldı: pid $!"
