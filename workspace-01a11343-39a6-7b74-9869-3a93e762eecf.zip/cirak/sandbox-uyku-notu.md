# ⏸️ Sandbox uyku mekaniği — ölçümler ve çözüm (3 Ekim gecesi)

## Ortam
- Altyapı: **E2B** (`E2B_SANDBOX=true`, `E2B_SANDBOX_ID=iem0ny1717t6wd3lji5f2`)
- E2B varsayılan sandbox ömrü: **300 saniye (5 dakika)** — son etkinlikten sonra uyku/pause.
- Uyku = pause: **dosyalar korunur, süreçler ölür.** Uyanma = taze konteyner; bizim gözlem: her mesajda `uptime` 0–2 dk.

## Ölçülen ömürler (bu gece)
| Gözlem | Değer |
|---|---|
| Süpervizör doğuşları | 20:33, 21:26, 21:58, 22:06, 22:12, 22:20, 22:28, 22:31 (test) |
| Yeniden başlama aralıkları | 5,8 – 8,4 dk (gece geç saatler) |
| En sıkı kanıt | keyif botu 22:20:44'te vurdu, 2. vuruşu (22:24:44) hiç gelmedi → uyku 22:22–22:24:44 arası |
| Konteyner ömrü | ~2:40 – 6:30 dk aralığında gözlendi |

## Ölçüm cihazı (kalıcı)
- **olcum_kalp.sh** — 20 sn'de bir `olcum_kalp.txt`'ye zaman damgası (`epoch saat`).
- **olcum_rapor.py** — dosyadaki >40 sn boşlukları "uyku penceresi" olarak listeler.
- Bekçi, kalbi de diriltir (her kabuk açılışında kontrol).

## ⚠️ Bulunan ve düzeltilen hata: flock sızıntısı
- Belirti: `bekci_log.txt`: **"kilit dolu — atlandı"** satırları; kalp hiç başlamıyordu.
- Kök neden: bekçi `flock -n 9` ile kilidi alıyor, sonra `nohup ... &` çocukları **fd 9'u miras alıyordu** → süpervizör yaşadıkça kilit hiç bırakılmıyordu (flock kilidi açık dosya tanımına bağlıdır).
- Çözüm: çocuk başlatmalarda `9>&-` (kilit fd'si kapatılır). Kanıt: temiz-slate testi — hepsi öldürüldü, **tek kabukta kalp(1609)+süpervizör(1617)+5 bot otomatik dirildi**, ardışık 3 kabuk kilidi sorunsuz aldı.

## Pratik özet (Karahan'a)
- Botlar mesaj aralarında **en fazla birkaç dakika** daha yaşar; E2B ömrü dolunca uyku başlar.
- **Kalıcı 7/24 çalıştırma bu platformda mümkün değil** — ama Karahan her yazdığında ilk komut bekçiyi tetikler: ~10 saniyede her şey geri gelir.
- Oyunda "Durum ne" yazsa bile botlar ayaktaysa rapor botu yanıtlar; değilse mesaj bir sonraki uyanışta yakalanır.


## ⏰ Saat düzeltmesi (Karahan bildirdi)
Oyun saati = gerçek Türkiye saati (UTC+3); sandbox sunucu saati UTC (ör. 08:07 UTC = 11:07 TRT = oyun 11:07).
Yukarıdaki tablodaki ham damgalar UTC'dir — TRT = +3 (uyku penceresi TRT: 01:32 → 10:55).
Artık tüm botlar Europe/Istanbul (TRT) damgası basıyor.
