#!/bin/bash
# Botları güvenle yenile (inline kill kendi kabuğunu öldürür - bu dosyadan çalıştır)
cd /home/user/cirak
for p in $(pgrep -f "supervizor.py"); do kill $p 2>/dev/null; done
sleep 3
rm -f supervizor.pid
bash basla.sh
