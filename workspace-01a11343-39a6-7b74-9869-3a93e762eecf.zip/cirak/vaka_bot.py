"""Vaka Botu — v0.55 yenilikleri (8. bot)

0.55.0 ile gelen olayları otomatik yönetir:
  🔥 Yangın   → 110 İtfaiye
  🦹 Hırsız   → 155 Polis
  🚑 Kriz     → 112 Ambulans
  ❤️  İlk yardım (ritim oyunu) → denenir
  📦 Toplu sipariş → kabul et + zamanında teslim et (piyasa %35 üstü + prim!)
  🏅 Mahalle itibarı ve durum değişimleri loglanır.

Günde en çok 3 olay olur. Her olayda ödül + itibar kazanılır.
İtibar: dükkân müşterisi %, tezgâh cirosu %, kredi notu — hepsini etkiler.

Uçlar: vaka · vaka/{id}/ara {numara} · vaka/{id}/ilkyardim · vaka/{id}/siparis · vaka/{id}/teslim
Log: vaka_log.jsonl · kalp: vaka_kalp.txt
"""
import json, os, time, datetime, importlib.util

TABAN = 'https://oyunsitem.com/cirak/api/'
LOG = os.environ.get('VAKA_LOG', 'vaka_log.jsonl')
KALP = 'vaka_kalp.txt'
ARALIK = int(os.environ.get('VAKA_ARALIK', 90))   # 90 sn

# Olay türü → doğru numara
NUMARA = {'yangin': '110', 'hirsiz': '155', 'kriz': '112'}

spec = importlib.util.spec_from_file_location('vc', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'veri_cek.py'))
vc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vc)


def logla(a):
    a['t'] = int(time.time())
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write(json.dumps(a, ensure_ascii=False) + '\n')


def kalp():
    with open(KALP, 'w') as f:
        f.write(str(int(time.time())))


def main():
    op, cj = vc.oturum()
    logla({'olay': 'basladi'})
    print('vaka_bot başladı', flush=True)
    onceki_itibar = None
    while True:
        try:
            v = vc.cek(op, 'vaka') or {}
            kalp()

            # --- İtibar takibi ---
            it = v.get('itibar') or {}
            if it and it.get('puan') is not None:
                if onceki_itibar is not None and it['puan'] != onceki_itibar:
                    logla({'olay': 'itibar', 'puan': it['puan'], 'fark': it['puan'] - onceki_itibar,
                           'musteri': it.get('musteri'), 'tezgah': it.get('tezgah'), 'kredi': it.get('kredi')})
                    print('İtibar %s → %s (%+d) | müşteri %s%% tezgâh %s%% kredi %s'
                          % (onceki_itibar, it['puan'], it['puan'] - onceki_itibar,
                             it.get('musteri'), it.get('tezgah'), it.get('kredi')), flush=True)
                onceki_itibar = it['puan']

            # --- Olaylar ---
            for x in (v.get('acik') or v.get('olaylar') or v.get('vakalar') or []):
                durum, tur, vid = x.get('durum'), x.get('tur'), x.get('id')
                if not vid:
                    continue

                # Acil durum: telefonla doğru numarayı ara
                if durum == 'acik' and tur in NUMARA:
                    num = NUMARA[tur]
                    r = vc.cek(op, 'vaka/%s/ara' % vid, {'numara': num})
                    logla({'olay': 'ara', 'tur': tur, 'numara': num, 'id': vid, 'sonuc': r})
                    print('📞 %s → %s arandı: %s' % (tur, num, json.dumps(r, ensure_ascii=False)[:120]), flush=True)
                    time.sleep(3)

                # İlk yardım (ritim oyunu)
                elif durum == 'yardim':
                    r = vc.cek(op, 'vaka/%s/ilkyardim' % vid, {})
                    logla({'olay': 'ilkyardim', 'id': vid, 'sonuc': r})
                    print('❤️ İlk yardım: %s' % json.dumps(r, ensure_ascii=False)[:120], flush=True)
                    time.sleep(3)

                # Toplu sipariş: kabul et (piyasa %35 üstü + teslim primi)
                elif durum == 'acik' and tur == 'siparis':
                    r = vc.cek(op, 'vaka/%s/siparis' % vid, {'kabul': True})
                    logla({'olay': 'siparis_kabul', 'id': vid, 'sonuc': r})
                    print('📦 Sipariş kabul edildi: %s' % json.dumps(r, ensure_ascii=False)[:120], flush=True)
                    time.sleep(3)

                # Kabul edilmiş sipariş: teslim et (zamanında!)
                elif durum == 'kabul':
                    r = vc.cek(op, 'vaka/%s/teslim' % vid, {})
                    logla({'olay': 'teslim', 'id': vid, 'sonuc': r})
                    print('🚚 Sipariş teslim: %s' % json.dumps(r, ensure_ascii=False)[:120], flush=True)
                    time.sleep(3)

        except Exception as ex:
            logla({'olay': 'hata', 'hata': repr(ex)[:200]})
            print('hata:', repr(ex)[:120], flush=True)
            try:
                op, cj = vc.oturum()
            except Exception:
                pass
        time.sleep(ARALIK)


if __name__ == '__main__':
    main()
