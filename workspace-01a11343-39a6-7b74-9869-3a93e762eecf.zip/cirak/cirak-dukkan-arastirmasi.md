# Çırak (oyunsitem.com/cirak) — "En Çok Hangi Dükkân Kazandırır?" Araştırması

**Tarih:** 2 Ekim 2026 · **Yöntem:** Oyunun canlı API'si + açık kaynak JS kodu + test hesabıyla
canlı oynanış ölçümleri + Türkiye genelinde 55 ilçenin sokak taraması (oyuncuların gerçek dükkânları).

Test hesabı: `arastirmaci42` (sv2, Ankara/Yenimahalle) — canlı ölçümler bu hesapta yapıldı.

---

## 1) Kısa cevap

- **Erken oyunda (sv1–2) en çok kazandıran sınıf: GIDA PERAKENDESİ → Bakkal (30.000 ₺) ve Manav (25.000 ₺).**
  Oyuncuların gerçek portföyünde 27 dükkânın 8'i tam olarak bu ikisi; en zengin oyuncular da gıdaya yatırıyor.
- **Orta seviyede (sv3–6):** Kafe / Şarküteri / Kasap / Balıkçı (taze gıda marjı) ve büyük formatta Pastane;
  hizmet tarafında Kuaför (stok yok, nakit akışı basit).
- **Üst seviyede (sv6+):** Kebapçı (180.000 ₺, 3 çalışan) ve Lokanta; en yüksek kilitler:
  **Kuyumcu (sv10), Hukuk bürosu (sv11), Diş kliniği (sv11), Eczane (sv12)**.
- **Asıl büyük para dükkânda değil, seviye 15+ tesislerde** (fabrika/tarla/maden). Aşağıda ₺/saat tablosu var.
- **Dükkân açana kadarki en iyi nakit motoru tezgâh (seyyar):** Pazar tezgâhı + kendin çalışıp müşterilere
  bizzat servis = ölçülen en iyi 5 dakikada **5.983 ₺ net** (bonuslar hariç). Seyyar tezgâhlar **vergi ödemez** (esnaf muafiyeti),
  dükkânlar kârdan **%15 vergi** öder.

---

## 2) Oyuncu portföyü taraması (kanıt: halk neyi açıyor?)

55 ilçedeki 42'şer parsellik caddeler tarandı → oyunda **13 oyuncunun 27 dükkânı** var:

| Dükkân türü | Adet | | Dükkân türü | Adet |
|---|---|---|---|---|
| Bakkal | 4 | | Balıkçı, Bilgisayarcı, Pastane, Market, Oyuncakçı | 1'er |
| Manav | 4 | | Ziraat bayisi, Kargo şubesi, Kasap, Çiçekçi | 1'er |
| Kuaför / Kafe / Şarküteri / Çay ocağı | 2'şer | | Çiğ köfteci, Büfe | 1'er |

En zengin oyuncuların portföyleri (servetler ₺):

| Oyuncu | Seviye | Servet | Dükkânları |
|---|---|---|---|
| **tefon** | 8 | ~1,26 M ₺ | Bakkal (küçük), Balıkçı (küçük), Kafe (orta), Bilgisayarcı (orta) |
| **ZanY** | 6 | ~0,90 M ₺ | Kuaför (küçük) + 3 tezgâhı **çırağa** bırakmış (simit, ayakkabı, pamuk) |
| **Karahan** | 5 | ~0,50 M ₺ | Manav, Bakkal, Ziraat bayisi (hepsi küçük) |
| **ybey** | 5 | ~0,38 M ₺ | Manav, Oyuncakçı (küçük) |
| **Neji** | 6 | ~0,38 M ₺ | **Pastane** — oyundaki tek "büyük" (180 m²) dükkân |
| **Erhan** | 6 | ~0,14 M ₺ | Bakkal + Market + Manav (üçü de orta 90 m²) — saf gıda portföyü |
| **Mertcan09** | 5 | ~0,06 M ₺ | Büfe + Bakkal + Manav (üçü küçük, kirası **10.900 ₺/ay** olan ucuz ilçede) |

Yorum: Oyuncu tabanı "**küçük–çok sayıda dükkân**" ve "**gıda perakendesi**"nde yoğunlaşmış.
Ucuz ilçede çoklu küçük dükkân modeli (Mertcan09) ile geniş formatlı tek dükkân modeli (Neji – Pastane) iki ayrı yol.

Tezgâh tarafında toplam **39 oyuncu tezgâhı** var; 29'u **çırakla** çalışıyor (pasif gelir):
simit 8, ayakkabı 7, pamuk şeker 5, pazar 5, midye 4, şemsiye 4, kestane 3, mısır 2, gözleme 1.

---

## 3) Tezgâh (seyyar) — canlı ölçümler [NAKİT MOTORU]

Süre: "Tam gün" = 300 sn gerçek zaman (kural: 1 saat 37,5 sn; 2 saat/yarım/tam 60 sn + tahmin; 3 gün 45 dk; 1 hafta 105 dk).

| İş | Ekipman ₺ | Tam gün tahmini net ₺ | 1 hafta net ₺ | Kilit |
|---|---|---|---|---|
| Kokoreççi | 80.000 | **7.782** | 62.142 | sv6 |
| Gözlemeci | 35.000 | 4.047 | 32.860 | sv5 |
| Kestaneci | 25.000 | 3.804 | 28.818 | sv3 |
| **Pazar tezgâhı** | 8.000 | 2.147 | 19.014 | **açık** |
| Dondurmacı | 45.000 | 2.039 | 18.149 | sv4 |
| Mısırcı | 25.000 | 1.939 | 15.228 | sv3 |
| Midyeci | 15.000 | 1.624 | 14.180 | sv4 |
| Simitçi | 3.000 | 652 | 3.833 | açık |
| Ayakkabı boyacısı | 1.500 | 256 | 1.230 | açık |
| Pamuk şeker | 4.000 | 243 | 3.347 | açık |
| Şemsiyeci | 500 | −147 | −1.029 | açık (kış/hava işi) |
| Su-mendil | 800 | −166 | −703 | açık (yaz işi) |

**Ölçülen gerçek değerler (Pazar tezgâhı, Yenimahalle, sv2):**

| Senaryo | Net (5 dk vardiya) |
|---|---|
| Çırak bakıyor | ~2.096 ₺ |
| Kendim çalışıyorum | ~3.021 ₺ |
| Kendim + müşterilere bizzat servis (balonlara dokunma) | **5.983 ₺ (en iyi ölçüm)**; tip geliri ek olarak ~330–420 ₺/dk |
| Toplu sipariş bonusu | 360–725 ₺/sipariş |

Kurallar: izin 1.500 ₺/hafta (zabıta çevirirse "izinliysen iyi olay"); çırak yevmiyesi 1.000 ₺/gün;
servis balonları **%30'a kadar** ek kazanç; her seviye müşteriyi **+%2**; hava/mevsim/olay kazancı değiştirir
(ör. yağmurda şemsiyeci, yazın dondurmacı); seyyar tezgâhlar **vergi ödemez**.

---

## 4) Dükkân kataloğu — maliyet ve kilitler

Küçük (40 m²) dükkân için tipik açılış: **depozito = 2×aylık kira** + **ruhsat ~5.000 ₺** + **kurulum**.
Yenimahalle'de küçük kira 30.100 ₺/ay → açılış ≈ 60.200 (depozito) + 5.000 (ruhsat) + kurulum.

**sv1–2'de açık 31 tür (kurulum ₺):** Çay ocağı 15.000 · Büfe 20.000 · Manav 25.000 · **Bakkal 30.000** ·
Aktar 30.000 · Terzi 30.000 (hizmet) · Çilingir 30.000 (hizmet) · Kuruyemişçi 40.000 · Çiğ köfteci 40.000 ·
Kırtasiye 40.000 · Çiçekçi 40.000 · Tavukçu 50.000 · İç giyim 50.000 · Berber 50.000 (hizmet) ·
Temizlik ürünleri 55.000 · Balıkçı 60.000 · Şarküteri 60.000 · Börekçi 60.000 (2 çalışan) · Çantacı 60.000 ·
Perdeci 60.000 · Kargo şubesi 60.000 (hizmet) · Kasap 70.000 · Nalbur 70.000 · Züccaciye 70.000 ·
Fotoğrafçı 70.000 (hizmet) · Kitapçı 70.000 · Pet shop 70.000 · Fırın 80.000 (2) · **Kuaför 80.000 (2, hizmet)** ·
Oyuncakçı 80.000 · Bebek mağazası 85.000

**Kilitli — seviye atlayınca açılanlar:** Elektrikçi/tesisatçı/saatçı/boya (sv3), Dönerci/Pastane/Ayakkabıcı/
Hırdavatçı/Giyim mağazası/Kuru temizleme/Kafe (sv3) · Tatlıcı/Bilgisayarcı/Bisikletçi/Pideci/Oto yedek parça/
**Lokanta (sv4)** · Ziraat bayisi/Halıcı/Telefoncu (sv5) · Emlakçı/Matbaa/**Kebapçı (sv6)**/Seyahat acentesi (sv6) ·
Sigorta (sv7)/Özel kurs (sv7)/Güzellik salonu (sv7) · Döviz bürosu/Optik/Bar (sv8) · Mali müşavir/Sürücü kursu/
Veteriner/Araç kiralama (sv9) · **Kuyumcu/Reklam ajansı (sv10)** · **Hukuk bürosu/Diş kliniği (sv11)** ·
**Eczane/Gümrük müşaviri (sv12)**

**Hizmet dükkânları (`hizmet:true`) stok tutmaz** — her işte malzeme otomatik alınır: terzi, çilingir, berber,
elektrikçi, tesisatçı, kargo, kuaför, emlakçı, sigorta, kuru temizleme, özel kurs, güzellik, veteriner,
araç kiralama, diş kliniği, mali/gümrük/hukuk, matbaa, sürücü kursu.

### Kira bölgeye göre değişir (küçük 40 m², ₺/ay)
| İlçe | Kira | Günlük kira |
|---|---|---|
| Çamlıdere/Ankara (10 bin nüfus) | 4.900 | ~163 |
| Köşk/Aydın | 10.900 | ~363 |
| Tepebaşı/Eskişehir | 26.600 | ~887 |
| Yenimahalle/Ankara (bizim cadde) | 30.100 | ~1.003 |
| Çankaya/Ankara | 31.700 | ~1.057 |
Orta 90 m² ≈ 54.000–70.000 ₺/ay, Büyük 180 m² ≈ 119.000–135.000 ₺/ay.

---

## 5) Dükkân ekonomisinin kuralları (oyunun kendi metinlerinden)

- Ciro = **müşteri akışı × sepet**; müşteri akışını **mahalle nüfusu, dükkân boyutu ("büyük dükkân daha çok
  müşteri çeker"), fiyat uygunluğu, reklam ve rakipler** belirler.
- **Fiyat aralığı:** piyasa fiyatının **%30'u ile 3 katı** arası. Ucuz ve dolu raflı olan daha çok satar.
- **Aynı tür dükkân açarsan müşteriler paylaşılır** (mahalle esnafı ya da başka oyuncu).
- **Dükkânlar yalnızca çalışma saatlerinde** satış yapar ve gider yazar (ör. bakkal 07–23, kafe 08–24).
- **Günlük sabit gider:** kira/30 + elektrik + su + çalışan maaşı. **Kârdan %15 vergi**;
  kapatınca depozito geri döner, stok yarı fiyatına iade, kasa sana döner.
- Raflar boşalırsa **satış kaçar** ("bugün şu kadar satış kaçtı") → otomatik tedarik açılabilir.
- **Tapu** = {ay sayısı}×kira; kira gideri biter (satarken %80 geri alınır).
- **Şube** (başka ilçede dükkân) sv10'da açılır; taşıma, adın/malın/kasan/müşterilerinle birlikte olur.
- Hizmet dükkânları: "fiyatların" per-işlem; malzeme otomatik alınır.

---

## 6) Tesisler (sv15+) — asıl büyük para (hesaplama: piyasa fiyatlarıyla)

| Tesis | sv | Kurulum | Kâr/saat (hesap) |
|---|---|---|---|
| Uzay ve uydu şirketi | 50 | 2,0 mlr ₺ | ~28,7 M ₺ |
| Tersane | 50 | 1,2 mlr ₺ | ~21,7 M ₺ |
| Yapay zekâ laboratuvarı | 50 | 300 M ₺ | ~13,0 M ₺ |
| İHA / Yarı iletken / Havacılık | 48 | 350–400 M ₺ | ~5,3–6,2 M ₺ |
| Otomotiv fabrikası | 50 | 250 M ₺ | ~4,0–4,2 M ₺ |
| Rafineri | 48 | 150 M ₺ | ~2,3 M ₺ |
| Veri merkezi | 38 | 80 M ₺ | ~1,5 M ₺ |
| Demir çelik | 43 | 60 M ₺ | ~0,9 M ₺ |
| Çimento | 35 | 25 M ₺ | ~0,5 M ₺ |
| Tarla (buğday) | 15 | 12.000 ₺ | ~700 ₺/saat |

---

## 7) Aksiyon planı (sırayla)

1. **Sermaye:** en ucuz tezgâhla başla; hemen **Pazar tezgâhı** (8.000 ₺) al; "Tam gün"de kendin çalış ve
   **sipariş balonlarına dokun** (+%30'a kadar). İzin al (1.500 ₺/hafta). Seviye 3'te Kestaneci,
   sv5'te Gözlemeci, sv6'da Kokoreççi (seyyarın en kazançlısı: haftada ~62 bin ₺).
2. **Çırağı boşta tutma:** ikinci tezgâhı çırağa bırak (ör. pazar/simit) — pasif gelir.
3. **İlk dükkân (sv1–2):** ucuz ilçe + küçük parsel + **Bakkal/Manav**. Kirayı düşük tutan ilçe seçersen
   (10–26 bin ₺/ay) geri dönüş hızlanır. Hizmet istersen **Terzi/Çilingir (30.000 ₺)** stoksuz başlangıç.
4. **İşletme:** fiyatı piyasanın hemen altı–piyasa seviyesinde tut, rafı dolu tut, otomatik tedariki aç,
   aynı tür dükkân açma (müşteri paylaşılır), açılış saatlerine denk getir.
5. **Büyüme:** kârı yeniden yatır → aynı bölgede 2.–3. dükkân (Karahan/Erhan modeli) veya boyut büyüt
   (orta→büyük). sv10'da şube, sv15'te tesisler.
6. **Vergi:** kârdan %15 kesilir; KDV %20 fiyata dahildir. Beyanname ödenmezse %5/ay gecikme, 6 ay → icra.

> Not: Bu araştırma açık API'den alınan gerçek oyun verileri + canlı ölçümlerle yapıldı.
> Dükkânların "bugünkü ciro / müşteri" sayıları sunucu tarafında tutulur ve ancak sahibi görür;
> kesin ₺/gün karşılaştırması için test hesabıyla dükkân açıp günlük ciro ölçümü sürüyor.
