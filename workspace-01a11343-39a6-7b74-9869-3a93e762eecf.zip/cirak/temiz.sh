#!/bin/bash
cd /home/user/cirak
for p in $(pgrep -f "bekci.sh"); do kill $p 2>/dev/null; done
for p in $(pgrep -f "supervizor.py"); do kill $p 2>/dev/null; done
sleep 4
nohup python3 -u supervizor.py >> supervizor_log.txt 2>&1 &
echo "tek süpervizör: $!"
sleep 18
ps -eo args | grep -c "[s]upervizor.py"
