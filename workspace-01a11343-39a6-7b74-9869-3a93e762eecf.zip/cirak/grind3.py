"""Seyyar kazanç botu v3 — dükkân sermayesi biriktirir (araştırma hesabı).

Politika:
 * "ben" işi: en iyi kazançlı tezgâhı kendim çalıştırırım (kestaneci açılınca o, yoksa pazar),
   vardiya boyunca müşterilere bizzat servis yaparım (sipariş balonları: +%30'a kadar kazanç, bahşiş).
 * "çırak" işi: ikinci en iyi tezgâha çırak bakar (pazar, yoksa simit).
 * Biten işleri toplar, günlük görev ödülünü alır, yetenek puanlarını satış/yönetim'e dağıtır.
 * Bakiye HEDEF'e ulaşınca durur (dükkân kiralamak için).
"""
import json, os, time, http.cookiejar, urllib.request, urllib.error

TABAN = 'https://oyunsitem.com/cirak/api/'
HEDEF = float(os.environ.get('HEDEF_BAL', 97000))
MAKS_DK = float(os.environ.get('MAKS_DK', 110))
LOG = os.environ.get('GRIND_LOG', 'grind3_log.jsonl')
DUR = os.environ.get('GRIND_DUR', 'grind3_durum.json')

BEN_ONCELIK = ['kestane', 'pazar', 'simit']       # kendim çalışacağım sıra
CIRAK_ONCELIK = ['pazar', 'simit', 'ayakkabi']    # çırağa vereceğim sıra

def oturum():
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124'),
                     ('Referer','https://oyunsitem.com/cirak/'), ('Accept','application/json')]
    return op

def cek(op, yol, veri=None):
    data = json.dumps(veri).encode() if veri is not None else None
    req = urllib.request.Request(TABAN + yol, data=data, headers={'Content-Type':'application/json'} if data else {})
    for _ in range(4):
        try:
            with op.open(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            try: g = json.loads(e.read().decode())
            except Exception: g = {'hata': f'HTTP {e.code}'}
            if e.code == 429:
                time.sleep(35); continue
            return g
        except Exception:
            time.sleep(5)
    return {'hata': 'istek başarısız'}

def logla(k):
    with open(LOG, 'a') as f:
        f.write(json.dumps(k, ensure_ascii=False) + '\n')

def durum_yaz(o):
    json.dump(o, open(DUR, 'w'), ensure_ascii=False, indent=1)

class Bot:
    def __init__(self):
        self.op = oturum()
        self.t0 = time.time()
        self.tur = 0
        self.servis_kazanc = 0.0
        self.servis_adet = 0
        self.bahsis_adet = 0

    def durum(self):
        d = cek(self.op, 'durum') or {}
        o = d.get('oyuncu') or {}
        return (o.get('bakiye') or 0)/100, (o.get('seviye') or 1)

    def topla(self):
        r = cek(self.op, 'seyyar/topla-hepsi', {})
        if isinstance(r, list) and r:
            for p in r:
                logla({'olay': 'topladi', 'kod': p.get('isKodu'), 'ciro': (p.get('ciro') or 0)/100,
                       'malzeme': (p.get('malzeme') or 0)/100, 'cirakUcreti': (p.get('cirakUcreti') or 0)/100,
                       'net': (p.get('net') or 0)/100, 'calisan': p.get('calisan'), 'olaylar': p.get('olaylar')})
            return r
        return None

    def gorev_odul(self):
        g = cek(self.op, 'gorevler') or {}
        gs = g.get('gorevler') or []
        if gs and all(x.get('tamam') for x in gs) and not g.get('alindi'):
            r = cek(self.op, 'gorevler/odul', {})
            logla({'olay': 'gorev_odul', 'sonuc': r})

    def yetenek(self):
        y = cek(self.op, 'yetenekler') or {}
        for _ in range(y.get('bos') or 0):
            # satis: tezgâh satışı +%3; doluysa yonetim (çırak yevmiyesi -%4)
            sat = next((x for x in y['liste'] if x['kod'] == 'satis'), {})
            kod = 'satis' if (sat.get('derece') or 0) < 5 else 'yonetim'
            r = cek(self.op, 'yetenekler/yukselt', {'kod': kod})
            logla({'olay': 'yetenek', 'kod': kod, 'sonuc': r})
            if 'hata' in r: break

    def seyyar(self):
        return cek(self.op, 'seyyar') or {}

    def basla(self, kod):
        r = cek(self.op, 'seyyar/basla', {'isKodu': kod, 'sure': 'tam'})
        logla({'olay': 'basla', 'kod': kod, 'sonuc': r})
        return r

    def servis_vur(self, is_id):
        r = cek(self.op, 'seyyar/servis', {'id': is_id})
        if r.get('reddedildi') or r.get('hata'):
            return False
        if isinstance(r.get('tutar'), (int, float)) and r['tutar'] > 0:
            self.servis_kazanc += r['tutar']/100
            self.servis_adet += 1
            if r.get('bahsis'): self.bahsis_adet += 1
        if r.get('teklif'):
            k = cek(self.op, 'seyyar/siparis', {'id': is_id, 'kabul': True})
            logla({'olay': 'siparis_kabul', 'sonuc': k})
            self.siparis_sur(is_id)
        return True

    def siparis_sur(self, is_id):
        for _ in range(80):
            r = cek(self.op, 'seyyar/servis', {'id': is_id, 'parca': 5})
            sp = r.get('siparis') or {}
            if sp.get('durum') == 'tamam':
                self.servis_kazanc += (r.get('tutar') or 0)/100
                logla({'olay': 'siparis_tamam', 'tutar': (r.get('tutar') or 0)/100}); break
            if sp.get('durum') == 'kacti':
                logla({'olay': 'siparis_kacti'}); break
            time.sleep(0.35)

    def iyi_ben(self, isler, sahip):
        """Kendim çalışacağım tezgâh: önce sahip olduğum işler arasından öncelik sırası."""
        for kod in BEN_ONCELIK:
            if kod in sahip: return kod
        return None

    def calistir(self):
        self.yetenek()
        bakiye, seviye = self.durum()
        s = self.seyyar()
        if not (s.get('izin') or {}).get('var'):
            cek(self.op, 'seyyar/izin', {})
        self.topla()
        self.gorev_odul()
        logla({'olay': 'baslangic', 'bakiye': bakiye, 'seviye': seviye})
        while bakiye < HEDEF and (time.time()-self.t0) < MAKS_DK*60:
            self.tur += 1
            s = self.seyyar()
            aktif = s.get('aktifler') or []
            if any(x.get('bitti') for x in aktif):
                self.topla()
            self.gorev_odul()
            self.yetenek()
            bakiye, seviye = self.durum()
            if bakiye >= HEDEF: break
            s = self.seyyar()
            isler = {j['kod']: j for j in (s.get('isler') or [])}
            aktif = s.get('aktifler') or []
            sahip = {x['isKodu'] for x in aktif if not x.get('bitti')}
            sahip |= {j['kod'] for j in (s.get('isler') or []) if j.get('sahip')}
            # kestaneci açıldıysa ve alınabiliyorsa al
            kes = isler.get('kestane') or {}
            if seviye >= 3 and not kes.get('sahip') and not kes.get('kilitli') and bakiye > (kes.get('ekipman') or 0)/100 + 3000:
                r = cek(self.op, 'seyyar/ekipman-al', {'isKodu': 'kestane'})
                logla({'olay': 'ekipman_al', 'kod': 'kestane', 'sonuc': r})
                sahip.add('kestane')
            benim = None
            for kod in BEN_ONCELIK:
                if kod in sahip and kod in isler:
                    benim = kod; break
            if not benim:
                # hiç tezgâhım yok: pazar kur, olmazsa simit
                for kod in BEN_ONCELIK:
                    if isler.get(kod) and not isler[kod].get('kilitli'):
                        r = self.basla(kod)
                        if 'id' in r: benim = kod; break
                if not benim:
                    time.sleep(20); continue
            # benim işim aktif mi? değilse başlat
            aktif_kendi = next((x for x in aktif if x['isKodu'] == benim and not x.get('bitti')), None)
            if not aktif_kendi:
                r = self.basla(benim)
                if 'id' not in r:
                    time.sleep(10); continue
                aktif_kendi = {'id': r['id'], 'isKodu': benim}
            # çırağa ikinci tezgâhı ver
            if len([x for x in aktif if not x.get('bitti')]) < 2:
                for kod in CIRAK_ONCELIK:
                    if kod == benim: continue
                    j = isler.get(kod)
                    if j and j.get('sahip') and not j.get('kilitli'):
                        self.basla(kod); break
            # vardiya boyunca servis
            is_id = aktif_kendi['id']
            son = time.time()
            while True:
                ok = self.servis_vur(is_id)
                time.sleep(1.1 if ok else 2.5)
                if time.time() - son > 25:
                    son = time.time()
                    s2 = self.seyyar()
                    a = [x for x in (s2.get('aktifler') or []) if x.get('id') == is_id]
                    if not a or a[0].get('bitti'):
                        break
                    bakiye, _ = self.durum()
                durum_yaz({'tur': self.tur, 'bakiye': bakiye, 'seviye': seviye, 'ben': benim,
                           'servis_kazanc': round(self.servis_kazanc, 2), 'servis_adet': self.servis_adet,
                           'bahsis_adet': self.bahsis_adet, 'sure_dk': round((time.time()-self.t0)/60, 1)})
            self.topla()
            bakiye, seviye = self.durum()
            durum_yaz({'tur': self.tur, 'bakiye': bakiye, 'seviye': seviye, 'ben': benim,
                       'servis_kazanc': round(self.servis_kazanc, 2), 'servis_adet': self.servis_adet,
                       'bahsis_adet': self.bahsis_adet, 'sure_dk': round((time.time()-self.t0)/60, 1)})
        logla({'olay': 'bitti', 'bakiye': bakiye, 'seviye': seviye,
               'sure_dk': round((time.time()-self.t0)/60, 1), 'servis_kazanc': round(self.servis_kazanc, 2)})

if __name__ == '__main__':
    Bot().calistir()
