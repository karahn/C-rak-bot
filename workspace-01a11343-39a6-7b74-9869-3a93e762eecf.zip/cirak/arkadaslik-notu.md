# 🤝 Arkadaşlık Sistemi — keşif notları (3 Ekim gecesi)

> **Neden geç bulundu:** Yerel js kopyalarım **v0.38**'di; arkadaşlık sistemi **v0.41** ile gelmiş.
> Karahan "arkadaşlık isteği" deyince önce etkinlik daveti sandım — **yanlışmış**, ayrı sistem varmış.
> Ders: oyun güncelleniyor → ara ara `js/ana.js`'i sürüm damgasıyla yeniden indir (`js/ana-v041.js` kayıtlı).

## Endpoint'ler (canlı doğrulandı)
| Amaç | Çağrı | Parametre | Yanıt |
|---|---|---|---|
| Liste | `arkadaslar` | — | `{arkadaslar:[{id,ad,foto,seviye,yer,cevrimici}], gelen:[…], giden:[…]}` |
| Kabul | `arkadas/kabul` | `{id}` | `{durum:'arkadas'}` |
| Reddet / çıkar | `arkadas/sil` | `{id}` | `{durum:'yok'}` |
| İstek gönder | `arkadas/istek` | `{id}` | `{durum:'gonderildi'}` |
| Oyuncu ara | `oyuncu-ara?q=<ad>` | — | oyuncu listesi |

- `durum` yanıtında: **`arkadasIstek`** (bekleyen gelen istek sayısı), `okunmamis`, `okunmamisBildirim`
- bildirim türü: `davet`, `mesaj`, `seyyar`, `ruhsat`… (`bildirimler` ucu; #2153/#2155 = kamp davetleri)
- Kabul edince karşı taraf "🤝 artık arkadaşsınız" bildirimi alır (istemci toast'u)
- Arkadaş listesi **çevrimiçi durumu** gösterir (Karahan: çevrimiçi ✓)

## Benim durumum
- **Karahan (id 14) ile arkadaşız** ✅ (istek onda bekliyordu: `gelen` → kabul 3 Ekim gecesi)
- Davet 84 (kamp) + **89 + 90 (2 kamp daha)** kabul → keyif **67 → 89 → 100** 😄 DİNÇ ×1,08
- Davet 89'a **Mertcan09** (Aydın, sv5) da katılmış — Karahan'ın tanıdığı, not edildi
