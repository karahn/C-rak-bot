"""Seyyar tezgâhları otomatik çalıştırıp dükkân sermayesi biriktirir (araştırma hesabı).
- Aynı anda tek iş (kendisi çalışırsa daha kârlı) tutar.
- Ölçülen ₺/dakika en yüksek tezgâhı seçer; seviye açıldıkça daha iyisini alır.
"""
import json, time, os, http.cookiejar, urllib.request, urllib.error

TABAN = 'https://oyunsitem.com/cirak/api/'
HEDEF = float(os.environ.get('HEDEF_BAL', 115000))   # ₺
MAKS_DK = float(os.environ.get('MAKS_DK', 80))
LOG = 'grind_log.jsonl'
DUR = 'grind_durum.json'

# kod -> (seviye, ekipman kuruş)
ADAY = [
    ('kokorec', 6, 80000_00), ('gozleme', 5, 35000_00), ('kestane', 3, 25000_00),
    ('misir', 3, 25000_00), ('pazar', 2, 8000_00), ('simit', 1, 3000_00),
]

def oturum():
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124'),
                     ('Referer','https://oyunsitem.com/cirak/'), ('Accept','application/json')]
    return op, cj

def cek(op, yol, veri=None):
    data = json.dumps(veri).encode() if veri is not None else None
    req = urllib.request.Request(TABAN + yol, data=data, headers={'Content-Type':'application/json'} if data else {})
    for _ in range(5):
        try:
            with op.open(req, timeout=30) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            try: g = json.loads(e.read().decode())
            except Exception: g = {'hata': f'HTTP {e.code}'}
            if e.code == 429: time.sleep(45); continue
            return g
        except Exception:
            time.sleep(6)
    return {'hata': 'istek başarısız'}

def logla(k):
    with open(LOG, 'a') as f:
        f.write(json.dumps(k, ensure_ascii=False) + '\n')

def durum_yaz(o):
    json.dump(o, open(DUR, 'w'), ensure_ascii=False, indent=1)

def main():
    op, cj = oturum()
    t0 = time.time()
    logla({'olay': 'baslangic'})
    cek(op, 'bonus/al', {})
    d = cek(op, 'durum'); oy = d.get('oyuncu') or {}
    bakiye = (oy.get('bakiye') or 0)/100; seviye = oy.get('seviye') or 1
    s = cek(op, 'seyyar') or {}
    if not (s.get('izin') or {}).get('var'):
        cek(op, 'seyyar/izin', {})
    olcum = {}          # kod -> ₺/dk
    tur = 0
    while bakiye < HEDEF and (time.time()-t0) < MAKS_DK*60:
        tur += 1
        # 1) aktifleri topla
        r = cek(op, 'seyyar/topla-hepsi', {})
        if isinstance(r, list):
            for p in r:
                net = (p.get('net') or 0)/100
                sure = max(60, ((p.get('_sure') or 300)))
                logla({'olay': 'topladi', 'id': p.get('id'), 'kod': p.get('isKodu'), 'ciro': (p.get('ciro') or 0)/100,
                       'net': net, 'malzeme': (p.get('malzeme') or 0)/100, 'cirakUcreti': (p.get('cirakUcreti') or 0)/100})
        time.sleep(2)
        s = cek(op, 'seyyar') or {}
        isler = {j['kod']: j for j in (s.get('isler') or [])}
        d = cek(op, 'durum'); oy = d.get('oyuncu') or {}
        bakiye = (oy.get('bakiye') or 0)/100; seviye = oy.get('seviye') or 1
        # 2) ölçüme göre en iyi tezgâhı seç
        sec = None
        for kod, sv, ek in ADAY:
            j = isler.get(kod)
            if not j: continue
            if j.get('sahip'):
                sec = kod; break
            if seviye >= sv and ek/100 + 3000 <= bakiye and j.get('kilitli') is False:
                # satın al (yalnız daha iyisiyse)
                mevcut = olcum.get(sec, 0) if sec else 0
                if olcum.get(kod, 0) if kod in olcum else True:
                    cek(op, 'seyyar/ekipman-al', {'isKodu': kod})
                    logla({'olay': 'ekipman_al', 'kod': kod, 'fiyat': ek/100})
                    sec = kod; break
        if not sec:
            logla({'olay': 'uygun_tezgah_yok'}); time.sleep(15); continue
        j = isler[sec]
        r = cek(op, 'seyyar/basla', {'isKodu': sec, 'sure': 'tam'})
        logla({'olay': 'basla', 'kod': sec, 'calisan': r.get('calisan'), 'bakiye': bakiye, 'seviye': seviye})
        if 'hata' in r:
            time.sleep(10); continue
        isid = r.get('id')
        # 3) bitişi bekle
        bitis = None
        for _ in range(45):
            time.sleep(12)
            s2 = cek(op, 'seyyar') or {}
            a = [x for x in (s2.get('aktifler') or []) if x.get('id') == isid]
            if not a:
                break
            if a[0].get('bitti'):
                bitis = a[0]; break
        r2 = cek(op, 'seyyar/topla-hepsi', {})
        net = 0
        if isinstance(r2, list):
            for p in r2:
                if p.get('id') == isid: net = (p.get('net') or 0)/100
        logla({'olay': 'kazanc', 'kod': sec, 'net': net, 'sonuc': r2})
        # 4) ölçüm güncelle
        gecen = (time.time()-t0)
        if net:
            olcum[sec] = net  # 5 dk'lık tur → ₺/5dk
        d = cek(op, 'durum'); oy = d.get('oyuncu') or {}
        bakiye = (oy.get('bakiye') or 0)/100; seviye = oy.get('seviye') or 1
        durum_yaz({'tur': tur, 'bakiye': bakiye, 'seviye': seviye, 'tezgah': sec,
                   'son_net': net, 'olcum': olcum, 'sure_dk': round((time.time()-t0)/60, 1)})
        time.sleep(2)
    logla({'olay': 'bitti', 'bakiye': bakiye, 'seviye': seviye, 'sure_dk': round((time.time()-t0)/60,1)})

if __name__ == '__main__':
    main()
