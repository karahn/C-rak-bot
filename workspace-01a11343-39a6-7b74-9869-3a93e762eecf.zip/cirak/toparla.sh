#!/bin/bash
# HER TUR BAŞI: botları ayakta tut + hasadı topla + kısa durum. (tek komut)
cd "$(dirname "$0")"
bash basla.sh
sleep 4
python3 toparla.py
