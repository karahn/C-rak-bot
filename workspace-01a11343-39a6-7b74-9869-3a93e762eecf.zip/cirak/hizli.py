"""Hızlı durum — TEK SATIRDA her şey (1-3 saniye).

0.56 uyumlu: varlık vergisi eşiği, itibar, açık olay, yarış sırası dahil.
Kullanım:  python3 hizli.py
"""
import json, os, subprocess, sys, importlib.util, time

spec = importlib.util.spec_from_file_location('vc', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'veri_cek.py'))
vc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vc)

VARLIK_MUAFIYET = 5_000_000_00   # kuruş: 0.56 varlık vergisi muafiyeti


def main():
    op, cj = vc.oturum()

    # --- banka + vergi ---
    b = vc.cek(op, 'banka') or {}
    nakit = (b.get('nakit') or 0) / 100
    vadesiz = (b.get('vadesiz') or 0) / 100
    kasa = nakit + vadesiz

    v = vc.cek(op, 'vergi') or {}
    kalan = sum((x.get('kalan') or 0) for x in v.get('beyanlar', []) if x.get('durum') in ('bekliyor', 'gecikti')) / 100
    eksik = kalan - nakit

    # --- oyuncu ---
    d = vc.cek(op, 'durum') or {}
    o = d.get('oyuncu') or {}
    tp, sv = o.get('tecrube') or 0, o.get('seviye')

    # --- 0.55: itibar + açık olay ---
    vk = vc.cek(op, 'vaka') or {}
    it = vk.get('itibar') or {}
    acik = len(vk.get('acik') or [])

    # --- mini oyun sırası ---
    sira = '-'
    try:
        s = vc.cek(op, 'mini-oyun/sira?kod=genel') or {}
        for x in (s.get('liste') or []):
            if x.get('kullaniciAdi') == (o.get('kullaniciAdi') or ''):
                sira = '#%s/%s' % (x.get('sira'), x.get('puan'))
    except Exception:
        pass

    # --- botlar ---
    try:
        out = subprocess.run(['ps', '-eo', 'args'], capture_output=True, text=True).stdout
        adlar = [a for a in ('grind4', 'sokak_bot', 'musteri_logger', 'keyif_bot', 'rapor_bot', 'gunluk_bot', 'sampiyon', 'vaka_bot') if a + '.py' in out]
    except Exception:
        adlar = []
    oto = ''
    if len(adlar) < 8 and 'supervizor.py' not in (out if 'out' in dir() else ''):
        subprocess.run(['bash', 'basla.sh'], capture_output=True, text=True)
        oto = ' → botlar kaldırıldı!'

    # --- uyarılar ---
    uyari = []
    if eksik > 0:
        uyari.append('VERGİ EKSİK %.0f₺' % eksik)
    if acik:
        uyari.append('%d AÇIK OLAY' % acik)
    if kasa > VARLIK_MUAFIYET / 100:
        uyari.append('VARLIK VERGİSİ!!')
    elif kasa > 0.8 * VARLIK_MUAFIYET / 100:
        uyari.append('varlık eşiğine yakın')
    if it.get('puan', 0) < 500:
        uyari.append('itibar düşük')

    print('SV%s · TP %s · KASA %.0f₺ · VERGİ %.0f₺ (%s) · İTİBAR %s · YARIŞ %s · BOT %d/8%s' % (
        sv, tp, kasa, kalan, 'HAZIR +%.0f' % -eksik if eksik <= 0 else 'EKSİK %.0f' % eksik,
        it.get('puan', '-'), sira, len(adlar), oto))
    if uyari:
        print('⚠️  ' + ' | '.join(uyari))


if __name__ == '__main__':
    main()
