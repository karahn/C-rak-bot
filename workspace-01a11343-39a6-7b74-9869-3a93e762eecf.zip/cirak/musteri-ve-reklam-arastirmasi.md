# 👥 Müşteri Akışı + 📣 Reklam Sistemi Araştırması

**Tarih:** 2 Ekim 2026 · **Ölçüm:** canlı Şarküteri (id 5522, Yenimahalle No 4, küçük, rakipsiz)
**Yöntem:** 2 saatlik canlı kayıt (40 sn aralıkla 28+ örnek) + reklam kampanyası testi + kod analizi

---

## 👥 BÖLÜM 1: Müşteriler Nasıl ve Ne Zaman Geliyor?

### 💥 ANA BULGU: Müşteriler SAAT BAŞI TOPLU DALGA halinde geliyor!

Kanıt (canlı kayıt):
| Zaman | Müşteri | Ciro | Kaçan | Doluluk | Kasa |
|---|---|---|---|---|---|
| 13:42–13:59 | 37 (sabit) | 21.540 ₺ | 25 | 149 | 0 ₺ |
| **14:00:00** | **74 (+37!)** | **50.510 ₺ (+28.970)** | 26 | 111 (−38) | 28.332 ₺ |

- Geçiş **tam saat başında** oldu: 13:59 örnekte 37 → 14:00 örnekte 74
- Yani müşteriler gün boyu damla damla değil, **her oyun saatinde bir "parti"** halinde geliyor
- Parti, saniyeler içinde alışverişini yapıp çıkıyor (bekleme yok)

### 📅 Günde Kaç Kez Geliyor?
- Dükkân **08:00–21:00** arası açık → **günde 13 dalga** (her saat başı 1 kez)
- Ölçülen parti büyüklüğü: **~37 müşteri/saat** (13:00 ve 14:00 partileri ikisi de 37)
- Kaba günlük projeksiyon: 13 × ~37 ≈ **480 müşteri/gün potansiyeli**
- ⚠️ Parti büyüklüğü saatlere göre değişebilir (öğle/akşam yoğunluğu); 15:00–17:00 partileri şu an kayıtta, doğrulanacak

### 💰 Müşteri Başına Harcama
- 74 müşteri / 50.510 ₺ → **ortalama 683 ₺/müşteri**
- (1. parti 582 ₺, 2. parti 783 ₺ — sepet ortalaması yükseliyor)

### 🚨 KRİTİK DERS: Boş raf = kaçan müşteri
- Gün içinde **26 müşteri** ürün bulamadığı için **eli boş döndü** ("kaçan" sayacı)
- Kabaca kayıp: 26 × 683 ₺ ≈ **17.750 ₺ ciro** (~12.000 ₺ brüt kâr!)
- 1 saatlik partide 38 birim satıldı (149 → 111) → **saatte ~38 birim, günde ~500 birim** stok akışı gerekir
- Kapasite 400 → günde en az 1-2 kez otomatik/manuel takviye şart

---

## 📣 BÖLÜM 2: Reklam Sistemi — Çalışıyor mu?

### Sistem: "Dükkânına reklam ver" (İş Dünyası → Reklam)
| | Değer |
|---|---|
| Sistem ajansı | **Çırak Medya** — +%10 müşteri |
| Fiyat (küçük dükkân) | **2.500 ₺/gün** |
| Fiyat (orta ×1,6) | 4.000 ₺/gün |
| Fiyat (büyük ×2,5) | 6.250 ₺/gün |
| Süre | 1–30 gün seçilir, **peşin** ödenir |
| "1 gün" ne demek? | **24 gerçek saat** (test ettim: 13:47 → ertesi gün 13:47) |

### ✅ Çalıştığını kanıtladım (canlı test)
1. Şarküteri için kampanya başlattım: `{"ucret": 250000, "bitis": +24 saat, "etki": 0.1}` — kasadan 2.500 ₺ kesildi ✓
2. **Pano çalışıyor:** Mahalle caddesindeki reklam panosunda dükkânım görünüyor → `cadde.reklamlar: [{"ad": "Araştırma Şarküter", ...}]` ✓
3. Etki "+%10 daha çok müşteri" olarak panele düştü ✓
4. İlk reklamlı parti (14:00) 37 müşteri getirdi — henüz **ölçülebilir artış görülmedi** (tek parti verisiyle net değil; 15:00-17:00 partileri kayıtta)

### 🧮 Değer hesabı (ölçülen sayılarla)
Reklam: +%10 müşteri. Müşteri başı 683 ₺. Malzeme gideri cironun ~%31,5'i (brüt marj %68,5).

| Günlük müşteri | +%10 = ek müşteri | Ek ciro | Ek brüt kâr | Reklam bedeli | **Net** |
|---|---|---|---|---|---|
| 200 | +20 | +13.651 ₺ | +9.351 ₺ | −2.500 ₺ | **+6.851 ₺** |
| 400 | +40 | +27.303 ₺ | +18.702 ₺ | −2.500 ₺ | **+16.202 ₺** |
| 480 | +48 | +32.763 ₺ | +22.443 ₺ | −2.500 ₺ | **+19.943 ₺** |

**Sonuç: Günde ~55+ müşteri çeken her dükkân için reklam kârlı.** (Bizimki 2 saatte 74 müşteri getirdi — barajın çok üstünde.)

### 🎬 Bonus: Kendi Reklam Ajansını Kurma (oyuncu işi!)
| | Değer |
|---|---|
| Şart | **sv20** + 500.000 ₺ kuruluş harcı |
| Etki kademeleri | %12 (ücretsiz) → %16 (1.000.000 ₺) → %20 (3.000.000 ₺) |
| Kazanç | Her kampanyanın **%75'i ajansa**, %10 vergi (hazine), %15 medya gideri |
| Günlük fiyat | **Kendin belirlersin** (panele yaz) — oyuncular senin ajansını seçerse her gün sana öderler |

Ajansta toplam gelir ve kampanya sayısı panelde görünüyor → karşı-oyuncuya hizmet eden pasif gelir kapısı.

---

## 🎯 Karahan için Aksiyon Planı

1. **Raf yönetimi her şeyden önemli:** kaçan müşteri = yanan para. Benim dükkânımda 26 müşteri (~12.000 ₺ brüt) boşa gitti. Senin dükkânlarında da "kaybedilen" sayısı varsa raflar boş kalıyor demektir → **oto-tedarik açık + kasa tamponu dolu tut**
2. **Reklamı sırayla dene:** Büfe (18 saat × müşteri) en çok müşteriyi çeker → oraya 1 günlük (2.500 ₺) kampanya al, "bugün müşteri"yi ertesi gün kıyasla. Ben 3 gün veri toplayıp sana tabloyu vereceğim
3. **Şarküteri (senin) sabah 08:00 partisini kaçırma:** dükkân açılışında raflar DOLU olsun — açılış partisi en büyük kayıp riski
4. **sv20 hedefi:** 500.000 ₺ + sv20 → kendi ajansın; oyunculara reklam satışı = tamamen pasif gelir
5. Orta dükkâna geçersen (taşın): hem müşteri tabanı hem reklam etkisi büyür (maliyet de 1,6×)

**Not:** Reklamın +%10 etkisinin partilere yansıması 15:00–17:00 partileriyle ölçülüyor; sonuç netleşince ayrıca yazarım.
