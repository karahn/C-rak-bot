"""Canlı servis testi: kendi tezgâhım + çırak tezgâhlarını servis edebiliyor muyum?
Çalıştır: python3 -u test_servis.py   (gerçek 6-7 dk sürer)
Çıktı: test_servis_sonuc.json  + ekrana özet
"""
import json, time, http.cookiejar, urllib.request, urllib.error, os

TABAN = 'https://oyunsitem.com/cirak/api/'

def oturum():
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent','Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124'),
                     ('Referer','https://oyunsitem.com/cirak/'), ('Accept','application/json')]
    return op

def cek(op, yol, veri=None):
    data = json.dumps(veri).encode() if veri is not None else None
    req = urllib.request.Request(TABAN + yol, data=data, headers={'Content-Type':'application/json'} if data else {})
    for i in range(3):
        try:
            with op.open(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(35); continue
            try: return json.loads(e.read().decode())
            except Exception: return {'hata': f'HTTP {e.code}'}
        except Exception:
            time.sleep(3)
    return {'hata': 'istek başarısız'}

op = oturum()
LOG = []
RAW = {}          # ilk yanıtlar
RED = {}          # red sebep sayacı

def servis(is_id, etiket):
    r = cek(op, 'seyyar/servis', {'id': is_id})
    RAW.setdefault(etiket, [])
    if len(RAW[etiket]) < 3:
        RAW[etiket].append(r)
    if r.get('reddedildi') or r.get('hata'):
        sebep = r.get('hata') or 'reddedildi'
        RED[sebep] = RED.get(sebep, 0) + 1
        return r, 0.0
    tutar = (r.get('tutar') or 0)/100
    # sipariş teklifi geldiyse tamamla
    if r.get('teklif'):
        cek(op, 'seyyar/siparis', {'id': is_id, 'kabul': True})
        for _ in range(80):
            rr = cek(op, 'seyyar/servis', {'id': is_id, 'parca': 5})
            sp = rr.get('siparis') or {}
            if sp.get('durum') == 'tamam':
                tutar += (rr.get('tutar') or 0)/100
                break
            if sp.get('durum') == 'kacti':
                break
            time.sleep(0.3)
    return r, tutar

# önce temiz başlangıç
s = cek(op, 'seyyar')
if any(not x.get('bitti') for x in (s.get('aktifler') or [])):
    print('UYARI: hâlâ aktif iş var:', [(x['id'], x['isKodu']) for x in s['aktifler']])
    r = cek(op, 'seyyar/topla-hepsi', {}); print('topla-hepsi:', r)

bas = {}
for kod, kim in [('pazar','ben'), ('simit','cirak'), ('pamuk','cirak'), ('semsiye','cirak')]:
    r = cek(op, 'seyyar/basla', {'isKodu': kod, 'sure': 'tam'})
    bas[kod] = r
    print('başla', kod, '→', r)
    time.sleep(1.2)

kimlik = {kod: r['id'] for kod, r in bas.items() if isinstance(r, dict) and 'id' in r}
print('kimlikler:', kimlik)

kazanc = {k: 0.0 for k in kimlik}
adet = {k: 0 for k in kimlik}
sira = []
for k in kimlik:                       # pazar'a daha sık vur
    sira.append(k)
    if k == 'pazar':
        sira.append(k)

t0 = time.time()
i = 0
while time.time() - t0 < 380:
    kod = sira[i % len(sira)]; i += 1
    if kod in kimlik:
        r, t = servis(kimlik[kod], kod)
        kazanc[kod] += t; adet[kod] += 1
    time.sleep(0.55)
    if i % 40 == 0:
        s2 = cek(op, 'seyyar')
        hala = [x['isKodu'] for x in (s2.get('aktifler') or []) if not x.get('bitti')]
        print(f't={int(time.time()-t0)}s aktif={hala} kazanç={ {k: round(v,1) for k,v in kazanc.items()} }')
        if not hala:
            break

print('\n=== ilk ham yanıtlar ===')
for k, v in RAW.items():
    print(k, '→', json.dumps(v, ensure_ascii=False))
print('=== red sebepleri ===', RED)
print('=== servis turları ===', adet)

r = cek(op, 'seyyar/topla-hepsi', {})
sonuc = {'baslangic': bas, 'kazanc': {k: round(v,2) for k, v in kazanc.items()},
         'adet': adet, 'red': RED, 'ham': RAW, 'topla': r}
json.dump(sonuc, open('test_servis_sonuc.json','w'), ensure_ascii=False, indent=1)
if isinstance(r, list):
    print('\n=== HASAT ===')
    for q in r:
        print(f"{q['isAdi']:22s} çalışan:{q['calisan']:6s} ciro {q['ciro']/100:>9,.2f}₺ malz {q['malzeme']/100:>8,.2f}₺ çırak {q['cirakUcreti']/100:>7,.2f}₺ NET {q['net']/100:>9,.2f}₺")
else:
    print('topla:', r)
d = cek(op, 'durum'); print('bakiye:', round(d['oyuncu']['bakiye']/100,2), '₺')
