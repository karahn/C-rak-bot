"""Toparlama özeti — hasat + kısa durum. Her tur başında toparla.sh çağırır."""
import importlib.util, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
_spec = importlib.util.spec_from_file_location('vc', os.path.join(HERE, 'veri_cek.py'))
vc = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(vc)

op = vc.oturum()[0]

r = vc.cek(op, 'seyyar/topla-hepsi', {})
if isinstance(r, list) and r:
    print('hasat: +%.2f ₺ (%d iş)' % (sum(q['net'] for q in r) / 100, len(r)))
else:
    print('hasat: yok')

d = vc.cek(op, 'durum') or {}
o = d.get('oyuncu') or {}
y = vc.cek(op, 'yasam') or {}
i = vc.cek(op, 'isletme/5522') or {}
dun = i.get('dun') or {}
k = vc.cek(op, 'isletme/7820') or {}
kb = k.get('bugun') or {}
a = vc.cek(op, 'arkadaslar') or {}

print(f"kasa {o.get('bakiye',0)/100:,.2f} ₺ | keyif {y.get('keyif')}{y.get('simge','')} "
      f"(×{y.get('carpan')}) | sv{o.get('seviye')} TP {o.get('tecrube')}/{o.get('seviyeUst')}")
print(f"Şarküteri dün: ciro {dun.get('ciro',0)/100:,.0f} / net {(dun.get('ciro',0)-dun.get('gider',0))/100:,.0f} ₺"
      f" | Kargo bugün: {kb.get('ciro',0)/100:,.0f} ₺ / {kb.get('musteri',0)} müşteri")
print('arkadaşlar:', [x['ad'] for x in (a.get('arkadaslar') or [])])
print('okunmamış:', d.get('okunmamis'), '| arkadaş isteği:', d.get('arkadasIstek'))

# TP/kasa anlık görüntü — sv6 hedef takibi
import time as _t
try:
    with open('tp_gecmis.jsonl', 'a') as _f:
        _f.write(json.dumps({'ts': int(_t.time()), 'tp': o.get('tecrube'), 'sv': o.get('seviye'),
                             'ust': o.get('seviyeUst'), 'kasa': o.get('bakiye')}, ensure_ascii=False) + '\n')
except Exception:
    pass
