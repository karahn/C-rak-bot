"""Tavan ölçek testi: servis tavanı vardiya uzunluğuna göre ölçekleniyor mu?
ayakkabi 'saat1' (75 s) ve 'tam' (600 s) vardiyalarında ilk servisin 'tavan' değerini kıyaslar.
Sonuç: tavan_test.json  —  oran = tavan_saat1 / tavan_tam (süre oranı 75/600 = 0.125)
"""
import json, time, http.cookiejar, urllib.request, urllib.error

TABAN = 'https://oyunsitem.com/cirak/api/'
SONUC = {}

def oturum():
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent', 'Mozilla/5.0 Chrome/124'), ('Referer', 'https://oyunsitem.com/cirak/'),
                     ('Accept', 'application/json')]
    return op

def cek(op, yol, veri=None):
    data = json.dumps(veri).encode() if veri is not None else None
    req = urllib.request.Request(TABAN + yol, data=data,
                                 headers={'Content-Type': 'application/json'} if data else {})
    for _ in range(3):
        try:
            with op.open(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(30); continue
            try: return json.loads(e.read().decode())
            except Exception: return {'hata': f'HTTP {e.code}'}
        except Exception:
            time.sleep(3)
    return {'hata': 'istek'}

def bekle_topla(op, kid, sure_s):
    t0 = time.time()
    while time.time() - t0 < sure_s + 60:
        time.sleep(10)
        s = cek(op, 'seyyar')
        a = [x for x in (s.get('aktifler') or []) if x.get('id') == kid]
        if not a or a[0].get('bitti'):
            break
    tr = cek(op, 'seyyar/topla-hepsi', {})
    return tr

op = oturum()
for sure in ['saat1', 'tam']:
    r = cek(op, 'seyyar/basla', {'isKodu': 'ayakkabi', 'sure': sure})
    print(sure, 'başla →', r, flush=True)
    if 'id' not in r:
        SONUC[sure] = {'hata': r}
        continue
    time.sleep(2)
    k = cek(op, 'seyyar/servis', {'id': r['id']})
    tavan = k.get('tavan')
    print(sure, 'servis →', json.dumps(k, ensure_ascii=False), flush=True)
    tr = bekle_topla(op, r['id'], 600 if sure == 'tam' else 75)
    net = None
    if isinstance(tr, list):
        for q in tr:
            if q.get('isKodu') == 'ayakkabi':
                net = q
    SONUC[sure] = {'tavan': tavan, 'servis_ornek': k, 'topla': net}
    print(sure, 'topla →', json.dumps(net, ensure_ascii=False), flush=True)
    time.sleep(3)

if SONUC.get('saat1', {}).get('tavan') and SONUC.get('tam', {}).get('tavan'):
    oran = SONUC['saat1']['tavan'] / SONUC['tam']['tavan']
    SONUC['oran_saat1_tam'] = round(oran, 4)
    SONUC['sure_orani_75_600'] = 0.125
    print(f"\n>>> ORAN = {oran:.4f} (süre oranı 0.125)", flush=True)
json.dump(SONUC, open('tavan_test.json', 'w'), ensure_ascii=False, indent=1)
print('bitti', flush=True)
