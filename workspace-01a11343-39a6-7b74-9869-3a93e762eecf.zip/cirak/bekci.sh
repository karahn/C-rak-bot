# Çırak süpervizör bekçisi — ~/.bash_profile / ~/.bashrc / ~/.profile içinden çağrılır.
# Her kabuk açılışında: (1) uyku ölçüm kalbi (2) süpervizör — ölüyse arka planda yeniden başlatır.
# ÖNEMLİ: başlatılan çocuklara 9>&- ile kilit fd'si GEÇİRİLMEZ (yoksa çocuk yaşadıkça kilit hiç bırakılmaz).
if [ -f "$HOME/cirak/supervizor.py" ]; then
  (
    flock -n 9 || { echo "$(TZ='Europe/Istanbul' date '+%F %T') kilit dolu — atlandı" >> "$HOME/cirak/bekci_log.txt"; exit 0; }
    cd "$HOME/cirak" || exit 0

    # --- 1) uyku ölçüm kalbi ---
    __kalp_ok=0
    __kp=""
    if [ -f olcum.pid ]; then
      __kp=$(cat olcum.pid 2>/dev/null)
      if [ -n "$__kp" ] && kill -0 "$__kp" 2>/dev/null && grep -q "olcum_kalp" "/proc/$__kp/cmdline" 2>/dev/null; then
        __kalp_ok=1
      fi
    fi
    if [ "$__kalp_ok" = "0" ]; then
      nohup sh olcum_kalp.sh >> olcum_out.txt 2>&1 9>&- &
    fi

    # --- 2) süpervizör ---
    __sup_ok=0
    __p=""
    if [ -f supervizor.pid ]; then
      __p=$(cat supervizor.pid 2>/dev/null)
      if [ -n "$__p" ] && kill -0 "$__p" 2>/dev/null && grep -q supervizor.py "/proc/$__p/cmdline" 2>/dev/null; then
        __sup_ok=1
      fi
    fi
    if [ "$__sup_ok" = "0" ]; then
      __now=$(date +%s); __last=$(cat .son_baslat 2>/dev/null || echo 0)
      if [ $((__now - __last)) -ge 90 ]; then
        echo "$__now" > .son_baslat
        nohup python3 -u supervizor.py >> supervizor_out.txt 2>&1 9>&- &
        __sup_ok=2
      fi
    fi

    echo "$(TZ='Europe/Istanbul' date '+%F %T') kabuk: kalp_ok=$__kalp_ok sup=$__sup_ok (kalp pid: ${__kp:-yok} · sup pid: ${__p:-yok})" >> bekci_log.txt
    exit 0
  ) 9>"$HOME/cirak/.supervizor.lock"
fi
