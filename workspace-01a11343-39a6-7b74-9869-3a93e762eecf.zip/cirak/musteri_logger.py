"""Müşteri akışı kaydedici: Şarküteri'nin müşteri/ciro/doluluk verisini düzenli örnekler.
Çıktı: musteri_log.jsonl  (her satır: ts, saat, dakika, musteri, ciro, gider, kaybedilen, doluluk, kasa)
Kullanım: python3 -u musteri_logger.py [dakika] [saniye_aralik]
"""
import json, sys, time, http.cookiejar, urllib.request, urllib.error

DAKIKA = float(sys.argv[1]) if len(sys.argv) > 1 else 45
ARALIK = float(sys.argv[2]) if len(sys.argv) > 2 else 45
TABAN = 'https://oyunsitem.com/cirak/api/'
ISLETME = 5522

def oturum():
    cj = http.cookiejar.MozillaCookieJar('oturum_cerez.txt')
    cj.load(ignore_discard=True, ignore_expires=True)
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    op.addheaders = [('User-Agent', 'Mozilla/5.0 Chrome/124'), ('Referer', 'https://oyunsitem.com/cirak/'),
                     ('Accept', 'application/json')]
    return op

def cek(op, yol, veri=None):
    data = json.dumps(veri).encode() if veri is not None else None
    req = urllib.request.Request(TABAN + yol, data=data,
                                 headers={'Content-Type': 'application/json'} if data else {})
    for _ in range(3):
        try:
            with op.open(req, timeout=25) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(20); continue
            try: return json.loads(e.read().decode())
            except Exception: return {'hata': f'HTTP {e.code}'}
        except Exception:
            time.sleep(3)
    return {'hata': 'istek'}

op = oturum()
t0 = time.time()
n = 0
while time.time() - t0 < DAKIKA * 60:
    d = cek(op, f'isletme/{ISLETME}') or {}
    t = cek(op, 'seyyar') or {}
    tk = (t.get('takvim') or {})
    b = d.get('bugun') or {}
    satir = {
        'ts': int(time.time() * 1000), 'gercek_dk': round((time.time() - t0) / 60, 2),
        'saat': tk.get('saat'), 'dakika': tk.get('dakika'),
        'musteri': b.get('musteri', 0), 'ciro': b.get('ciro', 0) / 100,
        'gider': b.get('gider', 0) / 100, 'kaybedilen': b.get('kaybedilen', 0),
        'doluluk': d.get('doluluk'), 'kasa': (d.get('kasa') or 0) / 100,
        'durum': d.get('durum'),
    }
    with open('musteri_log.jsonl', 'a') as f:
        f.write(json.dumps(satir, ensure_ascii=False) + '\n')
    n += 1
    if n % 5 == 0:
        print(f"[{satir['gercek_dk']}dk] saat {satir['saat']}:{satir['dakika']:02d} | müşteri {satir['musteri']} | ciro {satir['ciro']:,.0f}₺ | kaçan {satir['kaybedilen']} | doluluk {satir['doluluk']}", flush=True)
    time.sleep(ARALIK)
print('logger bitti', flush=True)
