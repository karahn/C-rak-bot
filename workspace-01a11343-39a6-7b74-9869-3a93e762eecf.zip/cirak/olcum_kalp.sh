#!/bin/sh
# Sandbox uyku ölçüm kalbi — 20 sn'de bir zaman damgası bırakır.
# Damgalar arasındaki >40 sn boşluk = sandbox o aralıkta uyudu/takıldı.
# bekci.sh her kabuk açılışında bu kalbin yaşadığını kontrol eder, ölüyse yeniden başlatır.
echo $$ > "$HOME/cirak/olcum.pid"
sayac=0
while true; do
  TZ='Europe/Istanbul' date '+%s %H:%M:%S' >> "$HOME/cirak/olcum_kalp.txt"
  sayac=$((sayac + 1))
  # ara sıra dosyayı kırp (sonsuz büyümesin)
  if [ $((sayac % 300)) -eq 0 ]; then
    tail -n 5000 "$HOME/cirak/olcum_kalp.txt" > "$HOME/cirak/olcum_kalp.tmp" 2>/dev/null \
      && mv "$HOME/cirak/olcum_kalp.tmp" "$HOME/cirak/olcum_kalp.txt"
  fi
  sleep 20
done
