import { BAYRAKLAR } from './bayraklar.js?v=0.38.0';
const kurulanlar = new Set();
let sira = 0, acik = null;
const globe = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/></svg>';
export const aramaMetni = s => String(s).normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase('tr').replace(/ı/g,'i');
export function secimKutusuKur(select, { tur='dil', ara='Ara…', bos='Sonuç bulunamadı.' }={}) {
  for (const eski of kurulanlar) if (!eski.select.isConnected) eski.sil();
  const old = [...kurulanlar].find(x=>x.select===select); if(old)return old;
  const signal=new AbortController(), events={signal:signal.signal}, id='secim-'+(++sira);
  let popup=null, input=null, list=null, rows=[], index=-1;
  const box=document.createElement('div');box.className='secim-kontrol';
  const button=document.createElement('button');button.type='button';button.className='secim-dugme';button.setAttribute('role','combobox');button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-expanded','false');button.setAttribute('aria-controls',id);
  const label=select.closest('label')?.querySelector('span')?.textContent.trim() || select.getAttribute('aria-label') || '';
  button.setAttribute('aria-label',label);box.append(button);select.before(box);select.classList.add('secim-native');select.tabIndex=-1;select.setAttribute('aria-hidden','true');
  const icon=value=>{
    const node=document.createElement('span');node.className='secim-simge';node.setAttribute('aria-hidden','true');
    const flag=tur==='ulke'&&BAYRAKLAR[value];
    if(flag){node.classList.add('secim-bayrak');node.style.backgroundImage=`url("${new URL('../doku/bayraklar.webp',import.meta.url).href}")`;node.style.backgroundPosition=`${-flag[0]}px ${-flag[1]}px`;}
    else node.innerHTML=globe;
    return node;
  };
  const name=o=>o?.dataset.ad || o?.label || '';
  const yenile=()=>{
    const option=select.selectedOptions[0];button.replaceChildren(icon(select.value));const text=document.createElement('span');text.className='secim-deger';text.textContent=name(option);button.append(text);
    const arrow=document.createElement('span');arrow.className='secim-ok';arrow.setAttribute('aria-hidden','true');arrow.textContent='⌄';button.append(arrow);button.disabled=select.disabled;
    if(popup)filter();
  };
  const kapat=(odak=false)=>{
    popup?.remove();popup=input=list=null;rows=[];index=-1;button.setAttribute('aria-expanded','false');if(acik===api)acik=null;
    if(odak&&button.isConnected)button.focus({preventScroll:true});
  };
  const konumla=()=>{
    if(!popup)return;if(!button.isConnected)return kapat();
    const r=button.getBoundingClientRect(),v=window.visualViewport,left=v?.offsetLeft||0,top=v?.offsetTop||0,w=v?.width||innerWidth,h=v?.height||innerHeight;
    const width=Math.min(Math.max(r.width,300),w-24);popup.style.width=width+'px';popup.style.left=Math.max(left+12,Math.min(r.left,left+w-width-12))+'px';
    const below=top+h-r.bottom-12,above=r.top-top-12,down=below>=Math.min(260,above);
    const height=Math.max(110,Math.min(370,down?below:above));popup.style.maxHeight=height+'px';list.style.maxHeight=Math.max(48,height-74)+'px';
    popup.style.top=(down?r.bottom+8:Math.max(top+12,r.top-Math.min(height,popup.scrollHeight)-8))+'px';
  };
  const highlight=i=>{
    if(!rows.length)return;index=Math.max(0,Math.min(rows.length-1,i));
    rows.forEach((r,n)=>r.classList.toggle('secim-aktif',n===index));input.setAttribute('aria-activedescendant',rows[index].id);rows[index].scrollIntoView({block:'nearest'});
  };
  const sec=row=>{
    const option=select.options[Number(row.dataset.index)];if(!option||option.disabled)return;
    select.value=option.value;kapat(true);yenile();select.dispatchEvent(new Event('change',{bubbles:true}));
  };
  const filter=()=>{
    const q=aramaMetni(input.value);list.replaceChildren();rows=[];index=-1;input.removeAttribute('aria-activedescendant');
    let english;try{english=tur==='ulke'?new Intl.DisplayNames(['en'],{type:'region'}):null;}catch(_){}
    [...select.options].forEach((option,n)=>{
      const alias=tur==='ulke'?english?.of(option.value):'';
      if(q&&!aramaMetni([name(option),option.value,option.dataset.arama,alias].join(' ')).includes(q))return;
      const row=document.createElement('button');row.type='button';row.className='secim-satir';row.id=id+'-o-'+n;row.dataset.index=n;row.setAttribute('role','option');row.setAttribute('aria-selected',String(option.selected));row.setAttribute('aria-disabled',String(option.disabled));row.tabIndex=-1;row.append(icon(option.value));
      const text=document.createElement('span');text.className='secim-satir-metin';const main=document.createElement('b');main.textContent=name(option);text.append(main);
      if(option.dataset.meta){const meta=document.createElement('small');meta.textContent=option.dataset.meta;text.append(meta);}row.append(text);
      if(option.selected){const tick=document.createElement('span');tick.className='secim-tik';tick.textContent='✓';row.append(tick);}list.append(row);if(!option.disabled)rows.push(row);
      row.addEventListener('click',()=>sec(row),{once:false});row.addEventListener('pointerdown',e=>e.preventDefault());
    });
    if(!list.children.length){const empty=document.createElement('p');empty.className='secim-bos';empty.setAttribute('role','status');empty.textContent=bos;list.append(empty);}
    konumla();
  };
  const open=()=>{
    if(select.disabled)return;if(popup)return kapat(true);acik?.kapat();acik=api;
    popup=document.createElement('div');popup.id=id;popup.className='secim-acilir';popup.setAttribute('role','dialog');popup.setAttribute('aria-label',label);popup.dir=select.closest('[dir]')?.dir || 'ltr';
    const search=document.createElement('div');search.className='secim-arama';const symbol=document.createElement('span');symbol.innerHTML=globe;
    input=document.createElement('input');input.type='search';input.placeholder=ara;input.setAttribute('aria-label',ara);input.setAttribute('role','combobox');input.setAttribute('aria-autocomplete','list');input.setAttribute('aria-expanded','true');input.autocomplete='off';input.spellcheck=false;
    list=document.createElement('div');list.id=id+'-liste';list.className='secim-liste';list.setAttribute('role','listbox');list.setAttribute('aria-label',label);input.setAttribute('aria-controls',list.id);search.append(symbol,input);popup.append(search,list);document.body.append(popup);button.setAttribute('aria-expanded','true');filter();input.focus({preventScroll:true});
    input.addEventListener('input',filter);input.addEventListener('keydown',e=>{
      if(e.isComposing)return;
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();highlight(index+(e.key==='ArrowDown'?1:-1));}
      else if(e.key==='Enter'){e.preventDefault();if(index<0&&rows.length)highlight(0);if(rows[index])sec(rows[index]);}
      else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();kapat(true);}
      else if(e.key==='Tab')kapat(false);
    });
  };
  const api={select,yenile,kapat,sil(){kapat();signal.abort();box.remove();select.classList.remove('secim-native');select.removeAttribute('aria-hidden');select.removeAttribute('tabindex');kurulanlar.delete(api);}};
  kurulanlar.add(api);button.addEventListener('click',e=>{e.preventDefault();open();},events);
  button.addEventListener('keydown',e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();if(!popup)open();highlight(0);}},events);
  select.addEventListener('change',yenile,events);select.addEventListener('invalid',e=>{e.preventDefault();button.focus();},events);
  document.addEventListener('pointerdown',e=>{if(popup&&!popup.contains(e.target)&&!box.contains(e.target))kapat();},events);
  document.addEventListener('focusin',e=>{if(popup&&!popup.contains(e.target)&&!box.contains(e.target))kapat();},events);
  window.addEventListener('resize',konumla,events);window.addEventListener('scroll',konumla,{...events,capture:true});window.visualViewport?.addEventListener('resize',konumla,events);window.visualViewport?.addEventListener('scroll',konumla,events);
  yenile();return api;
}
