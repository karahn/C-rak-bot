import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.38.0';
import { urunAdi as _urunAdi, birimAdi as _birimAdi, aktifDil, t as _oyunMetni, htmlDil as _oyunHtml } from './dil.js?v=0.38.0';
// Çırak – sektörler: tesislerim, yeni yatırım, ambar, toptan pazar ve şirket
import { api, tl, tamTl, esc, sureMetni, simdi, bildir, onayla } from './yardimci.js?v=0.38.0';
import { tesisEkHtml, tesisEkBagla } from './devlet.js?v=0.38.0';

let h = null; // ana.js'den gelen yardımcılar (panelAc, eylem, ses, aktifRota, durumYenile, zamanlayici)
let sekme = 'tesis';
let katalogOnbellek = null;
let pazarGrup = 'tarim';

export function uretimKur(yardimcilar) { h = yardimcilar; }

const SEKMELER = [['tesis', '🏭', 'production.tab.tesis'], ['yatirim', '➕', 'production.tab.yatirim'], ['ambar', '📦', 'production.tab.ambar'], ['pazar', '📈', 'production.tab.pazar'], ['tedarik', '🤝', 'production.tab.tedarik'], ['sirket', '🏛️', 'production.tab.sirket']];
const GRUPLAR = [['tarim', '🌾', 'production.group.tarim'], ['hayvan', '🐄', 'production.group.hayvan'], ['orman', '🌲', 'production.group.orman'], ['maden', '⛏️', 'production.group.maden'], ['sanayi', '🏭', 'production.group.sanayi'], ['teknoloji', '🤖', 'production.group.teknoloji'], ['savunma', '🛡️', 'production.group.savunma'], ['enerji', '⚡', 'production.group.enerji']];
const AYLAR = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

const sayi = (x) => Number(x).toLocaleString(aktifDil(), { maximumFractionDigits: x >= 100 ? 0 : 2 });
function urunMetni(nesne, urunler) {
  return Object.entries(nesne).map(([k, m]) => `${sayi(m)} ${esc(_birimAdi(urunler[k] ? urunler[k].birim : ''))} ${esc(_urunAdi(urunler[k] ? urunler[k].ad : k))}`).join(', ');
}
async function katalog() {
  if (!katalogOnbellek) katalogOnbellek = await api('uretim/katalog');
  return katalogOnbellek;
}

export async function uretimPaneli(yeniSekme) {
  if (yeniSekme) sekme = yeniSekme;
  const p = h.panelAc({
    ikon: '🏭', baslik: _oyunMetni("ui.0bc00e76c6a1"), rota: 'uretim', alt: _oyunMetni("production.subtitle"),
    govde: `<div class="sekmeler kaydirmali" role="tablist">${SEKMELER.map(([k, i, a]) => `<button role="tab" data-sekme="${k}" aria-selected="${sekme === k}">${i} ${_oyunHtml(a)}</button>`).join('')}</div>
      <div id="uretim-icerik"><p class="soluk">${_oyunHtml("auth.loading")}</p></div>`,
  });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); uretimPaneli(b.dataset.sekme); }));
  const kutu = p.querySelector('#uretim-icerik');
  try {
    if (sekme === 'tesis') await tesislerCiz(kutu);
    else if (sekme === 'yatirim') await yatirimCiz(kutu);
    else if (sekme === 'ambar') await ambarCiz(kutu);
    else if (sekme === 'pazar') await pazarCiz(kutu);
    else if (sekme === 'tedarik') await tedarikCiz(kutu);
    else await sirketCiz(kutu);
  } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; }
}

const hala = (kutu) => kutu.isConnected && h.aktifRota() === 'uretim';
let sigortaListesi = [];

// ---------- Tesislerim ----------
async function tesislerCiz(kutu) {
  const [{ tesisler }, k, sg] = await Promise.all([api('uretim'), katalog(), api('sigorta').catch(() => ({ liste: [] }))]);
  sigortaListesi = sg.liste || [];
  if (!hala(kutu)) return;
  const U = k.urunler;
  if (!tesisler.length) {
    kutu.innerHTML = `<div class="kart"><h3>${_oyunHtml("production.first")}</h3>
      <p class="kucuk">${_autoHtml("Tarla kirala, kümes kur, fabrika aç ya da maden ara. Ürünlerin ambarına girer; ister toptan pazarda sat, ister kendi dükkânına mal yap.")}</p>
      <button class="dugme yesil" data-git-sekme="yatirim">➕ ${_oyunHtml("production.options")}</button></div>
      <div class="kart"><h3>${_oyunHtml("production.how")}</h3><ul class="kural-listesi">
        <li>${_autoSablon`🌾 <b>${_autoHtml("Tarım")}</b> ürünü bölgene ve ekim ayına göre verir. Konya'da buğday, Rize'de çay, Antalya'da narenciye.`}</li>
        <li>${_autoMetin("🏭 <b>Fabrikalar</b> hammaddeyi işler: buğday → un → ekmek, süt → peynir, pamuk → iplik → kumaş → tişört.")}</li>
        <li>${_autoMetin("⛏️ <b>Madenler</b> gerçek yataklarında: Zonguldak kömür, Batman petrol, Eskişehir bor.")}</li>
        <li>${_autoMetin("⚡ <b>Santraller</b> gerçek havaya göre üretir: bulutlu günde güneş, rüzgârlı günde türbin kazandırır.")}</li>
        <li>${_autoMetin("🏛️ İşin büyüdükçe <b>limited, anonim şirket</b> ve sonunda <b>holding</b> kur.")}</li></ul></div>`;
    kutu.querySelector('[data-git-sekme]').addEventListener('click', () => uretimPaneli('yatirim'));
    return;
  }
  const biten = tesisler.filter((t) => (t.uretim && t.uretim.bitti) || (t.enerji && t.enerji.birikmis > 0)).length;
  kutu.innerHTML = `${biten ? `<button class="dugme yesil" data-eylem="hepsi">${_autoSablon`💰 ${biten} tesiste topla`}</button>` : ''}
    <div class="tesis-listesi">${tesisler.map((t) => tesisKarti(t, U)).join('')}</div>`;
  const hepsi = kutu.querySelector('[data-eylem=hepsi]');
  if (hepsi) hepsi.addEventListener('click', async () => {
    const r = await h.eylem(hepsi, () => api('uretim/topla-hepsi', {}));
    if (r === undefined) return;
    sonucBildir(r, U);
    uretimPaneli();
  });
  kutu.querySelectorAll('[data-baslat]').forEach((b) => b.addEventListener('click', async () => {
    const [id, recete] = b.dataset.baslat.split(':');
    const t = tesisler.find((x) => String(x.id) === id);
    const r = t.receteler.find((x) => x.kod === recete);
    const girdiVar = Object.keys(r.girdi).length > 0;
    if (!(await onayla(_autoSablon`${r.ad}\n\nGider: ${tamTl(r.gider)}${girdiVar ? _autoSablon`\nGirdi: ${urunMetni(r.girdi, U).replace(/&[a-z#0-9]+;/g, '')}\n(Ambarında eksik olan toptan pazardan alınır.)` : ''}\nSüre: ${sureMetni(r.sureMs)}`, { baslik: _oyunMetni("ui.9c3f476c9549"), evet: _autoMetin('Başlat'), ikon: t.simge }))) return;
    const s = await h.eylem(b, () => api('uretim/baslat', { id: Number(id), recete }));
    if (s === undefined) return;
    h.ses.satinAl();
    bildir(s.alinan ? _oyunMetni("production.startedCost", {amount:tl(s.alinan)}) : _oyunMetni("production.started"));
    uretimPaneli();
  }));
  kutu.querySelectorAll('[data-topla]').forEach((b) => b.addEventListener('click', async () => {
    const r = await h.eylem(b, () => api('uretim/topla', { id: Number(b.dataset.topla) }));
    if (r === undefined) return;
    sonucBildir([r], U);
    h.durumYenile().catch(() => {});
    uretimPaneli();
  }));
  kutu.querySelectorAll('[data-buyut]').forEach((b) => b.addEventListener('click', async () => {
    const t = tesisler.find((x) => String(x.id) === b.dataset.buyut);
    if (!(await onayla(_autoSablon`${t.ad}: ${t.sonrakiKademe.ad} kapasiteye büyütülsün mü?\nBedel: ${tamTl(t.sonrakiKademe.ucret)}`, { baslik: _oyunMetni("ui.32586da790c4"), evet: _oyunMetni("ui.32586da790c4"), ikon: '⬆️' }))) return;
    if ((await h.eylem(b, () => api('uretim/buyut', { id: t.id }))) === undefined) return;
    h.ses.satinAl();
    uretimPaneli();
  }));
  tesisEkBagla(kutu, tesisler, () => uretimPaneli());
  kutu.querySelectorAll('[data-sat]').forEach((b) => b.addEventListener('click', async () => {
    const t = tesisler.find((x) => String(x.id) === b.dataset.sat);
    if (!(await onayla(_autoSablon`${t.ad} (${t.il}) satılsın mı? Eline yaklaşık ${tl(t.satisDegeri)} geçer.`, { baslik: _autoMetin('Tesisi sat'), evet: _oyunMetni("ui.fdeb71b569e0"), tehlike: true, ikon: '🏷️' }))) return;
    const r = await h.eylem(b, () => api('uretim/sat', { id: t.id }));
    if (r === undefined) return;
    bildir(_oyunMetni("production.sold", {amount:tl(r.tutar)}));
    uretimPaneli();
  }));
  // geri sayımlar
  h.zamanlayici(() => {
    if (!hala(kutu)) return;
    kutu.querySelectorAll('[data-bitis]').forEach((el) => {
      const kalan = Number(el.dataset.bitis) - simdi();
      const top = Number(el.dataset.bitis) - Number(el.dataset.bas);
      if (kalan <= 0) { uretimPaneli(); return; }
      el.querySelector('.kalan').textContent = sureMetni(kalan);
      el.querySelector('.cubuk > div').style.width = `${Math.min(100, 100 * (1 - kalan / top))}%`;
    });
  }, 1000);
}

function tesisKarti(t, U) {
  const ust = `<div class="tesis-ust"><span class="tesis-simge">${t.simge}</span>
    <div class="tesis-baslik"><b>${esc(t.ad)}</b><span class="kucuk soluk">${esc(t.il)} · ${esc(t.kademeAdi)}${t.cesit ? ' · ' + esc((t.receteler && t.receteler[0] && t.receteler[0].ad) || '') : ''}${t.rezerv !== null ? _autoSablon` · rezerv: ${t.rezerv} dönem` : ''}</span></div></div>`;
  let govde = '';
  if (t.enerji) {
    const e = t.enerji;
    govde = `<div class="bilgi-izgara"><div><small>${_autoHtml("Anlık kapasite")}</small><b>%${e.anlik}</b></div><div><small>${_autoHtml("Birikmiş satış")}</small><b class="arti">${tl(e.birikmis)}</b></div></div>
      <p class="kucuk soluk">${_autoSablon`Kurulu güç ${sayi(e.guc)} MW. ${e.gercekHava ? _autoHtml('Üretim ilin şu anki havasına göre hesaplanıyor.') : _autoHtml('Hava bilgisi gelince üretim gerçek havaya göre hesaplanır.')} Elektrik şebekeye kendiliğinden satılır.`}</p>
      ${e.birikmis > 0 ? `<button class="dugme yesil kucuk" data-topla="${t.id}">${_autoSablon`⚡ ${tl(e.birikmis)} tahsil et`}</button>` : ''}`;
  } else if (t.uretim && t.uretim.bitti) {
    govde = `<p class="kucuk">${_autoSablon`<b>${esc(t.uretim.ad || '')}</b> bitti: ${urunMetni(t.uretim.cikti, U) || tl(t.uretim.para)}`}</p>
      <button class="dugme yesil" data-topla="${t.id}">📥 ${_oyunHtml("finance.collect")}</button>`;
  } else if (t.uretim) {
    const top = t.uretim.bitis - t.uretim.baslangic;
    govde = `<div data-bitis="${t.uretim.bitis}" data-bas="${t.uretim.baslangic}">
      <p class="kucuk" style="margin:0">${_autoSablon`<b>${esc(t.uretim.ad || '')}</b> sürüyor ·`} <span class="kalan">${sureMetni(t.uretim.bitis - simdi())}</span></p>
      <div class="cubuk"><div style="width:${Math.min(100, 100 * (1 - (t.uretim.bitis - simdi()) / top))}%"></div></div>
      <p class="kucuk soluk" style="margin:0">${_autoSablon`Beklenen: ${urunMetni(t.uretim.cikti, U) || tl(t.uretim.para)}`}</p></div>`;
  } else if (t.durum === 'tukendi') {
    govde = `<p class="kucuk">${_autoHtml("⛏️ Rezerv tükendi. Tesisi kapatıp (arazi düzenleme masrafı düşülür) başka yerde yeni ruhsat alabilirsin.")}</p>`;
  } else {
    govde = `<div class="recete-listesi">${(t.receteler || []).map((r) => `<div class="recete${r.uygun ? '' : ' kapali'}">
        <div class="recete-bilgi"><b>${esc(r.ad)}</b> <span class="kucuk soluk">· ${sureMetni(r.sureMs)}${r.verim !== 100 ? ` · verim %${r.verim}` : ''}</span>
          <div class="kucuk">${Object.keys(r.girdi).length ? `${urunMetni(r.girdi, U)} → ` : ''}${urunMetni(r.cikti, U)}${r.para ? `${Object.keys(r.cikti).length ? ' + ' : ''}${tl(r.para)} gelir` : ''}${r.arama ? _autoHtml('Rezerv bulunursa işletmeye geçilir.') : ''}</div>
          <div class="kucuk soluk">${_autoSablon`Gider ${tl(r.gider)}${r.kisIsitma ? _autoHtml(' (kış ısıtması dahil)') : ''}`}${r.aylar ? ` · ${r.uygun ? _autoHtml('mevsimi') : _autoHtml('yalnızca')}: ${r.aylar.map((a) => (aktifDil()==='tr' ? AYLAR[a] : new Intl.DateTimeFormat(aktifDil(), {month:'short',timeZone:'UTC'}).format(new Date(Date.UTC(2024,a,1))))).join(', ')}` : ''}${r.turizm ? _autoHtml(' · gelir doluluğa göre değişir') : ''}</div></div>
        <button class="dugme kucuk${r.arama ? ' mavi' : ''}" data-baslat="${t.id}:${r.kod}" ${r.uygun ? '' : 'disabled'}>${r.arama ? _oyunMetni("finance.search") : _oyunMetni("finance.start")}</button></div>`).join('')}</div>`;
  }
  const alt = `<div class="tesis-alt">
    ${t.sonrakiKademe && !t.uretim ? `<button class="metin-dugme" data-buyut="${t.id}">${_autoSablon`⬆️ Büyüt: ${esc(t.sonrakiKademe.ad)} (${tl(t.sonrakiKademe.ucret)})`}</button>` : ''}
    ${tesisEkHtml(t, sigortaListesi)}
    ${!t.uretim ? `<button class="metin-dugme tehlike" data-sat="${t.id}">${_oyunHtml("ui.fdeb71b569e0")}</button>` : ''}</div>`;
  return `<div class="kart tesis-karti">${ust}${govde}${alt}</div>`;
}

function sonucBildir(liste, U) {
  let para = 0;
  const urunler = {};
  const olaylar = [];
  for (const r of liste) {
    if (r.enerji) { para += r.gelir || 0; continue; }
    para += r.para || 0;
    if (r.olay && r.olay.arama) { olaylar.push(r.olay.bulundu ? _autoSablon`⛏️ Rezerv bulundu! ${r.olay.rezerv} dönemlik üretim.` : _autoMetin('⛏️ Sondaj boş çıktı. Tekrar arayabilirsin.')); continue; }
    if (r.olay && r.olay.ad) olaylar.push(`${r.olay.etki > 0 ? '🍀' : '⚠️'} ${r.olay.ad} (%${Math.round(r.olay.etki * 100)})${r.olay.tazminat ? _autoSablon`, sigorta ${tl(r.olay.tazminat)} ödedi` : ''}`);
    for (const [k, m] of Object.entries(r.cikti || {})) urunler[k] = (urunler[k] || 0) + m;
  }
  h.ses.kasa();
  const metin = [Object.keys(urunler).length ? `Ambara girdi: ${urunMetni(urunler, U).replace(/&[a-z#0-9]+;/g, '')}` : '', para ? _autoSablon`Kazanç: ${tl(para)}` : '', ...olaylar].filter(Boolean).join('\n');
  bildir(metin || _oyunMetni("production.collected"));
}

// ---------- Yatırım ----------
async function yatirimCiz(kutu) {
  const k = await katalog();
  if (!hala(kutu)) return;
  const U = k.urunler;
  kutu.innerHTML = `<p class="kucuk soluk">${_autoSablon`İlin: <b>${esc(k.benimIlim.ad)}</b> (${esc(k.benimIlim.bolge)}${k.benimIlim.kiyi ? _autoHtml(', kıyı') : ''}). Verim yüzdesi bu ile göredir; tesisi başka ilde de kurabilirsin.`}</p>
    ${k.sektorler.map((s) => `<details class="kart sektor-karti"><summary><span class="tesis-simge">${s.simge}</span><div style="flex:1;min-width:0"><b>${esc(s.ad)}</b>${s.tesisler.every((t) => t.kilitli) ? ` <span class="kilit-rozet">${Math.min(...s.tesisler.map((t) => t.seviye))}${_autoHtml(". seviye")}</span>` : ''}<div class="kucuk soluk">${esc(s.aciklama)}</div></div></summary>
      ${s.tesisler.map((t) => `<div class="yatirim ${t.kilitli ? 'kilitli' : ''}">
        <div class="yatirim-ust"><span class="tesis-simge">${t.simge}</span><div style="flex:1;min-width:0"><b>${esc(t.ad)}</b>
          <div class="kucuk soluk">${t.kilitli ? `<span class="kilit-rozet">${_autoSablon`${t.seviye}. seviye`}</span>` : _autoSablon`${t.seviye}. seviye`} ${_autoSablon`· ${esc(t.kademeler[0])} · kurulum <b>${tl(t.kurulum)}</b>`}</div></div></div>
        <p class="kucuk" style="margin:6px 0">${esc(t.aciklama || '')}</p>
        ${t.tur === 'surekli' ? `<p class="kucuk soluk">${_autoSablon`Bu ilde verim: %${t.verim}`}</p>` : `<ul class="kucuk recete-ozet">${t.receteler.map((r) => `<li>${esc(r.ad)}: ${Object.keys(r.girdi).length ? urunMetni(r.girdi, U) + ' → ' : ''}${urunMetni(r.cikti, U)}${r.para ? tl(r.para) + ' gelir' : ''}
            <span class="soluk">· ${sureMetni(r.sureSaat * 3600000)}${r.aylar ? ' · ' + r.aylar.map((a) => (aktifDil()==='tr' ? AYLAR[a] : new Intl.DateTimeFormat(aktifDil(), {month:'short',timeZone:'UTC'}).format(new Date(Date.UTC(2024,a,1))))).join(', ') : ''}${r.verim !== 100 ? ` · verim %${r.verim}` : ''}</span></li>`).join('')}</ul>`}
        ${t.kilitli ? '' : `<div class="yatirim-form" data-tur="${t.kod}">
          ${t.cesitli ? `<select name="cesit">${t.receteler.map((r) => `<option value="${r.kod}">${_autoSablon`${esc(r.ad.replace(' hasadı', ''))} (verim %${r.verim})`}</option>`).join('')}</select>` : ''}
          <select name="ilId">${ilSecenekleri(t, k)}</select>
          <button class="dugme yesil kucuk" data-kur="${t.kod}">${_autoSablon`Kur: ${tl(t.kurulum)}`}</button></div>`}
      </div>`).join('')}</details>`).join('')}`;
  kutu.querySelectorAll('[data-kur]').forEach((b) => b.addEventListener('click', async () => {
    const f = b.closest('.yatirim-form');
    const veri = { tur: b.dataset.kur, ilId: Number(f.querySelector('[name=ilId]').value) };
    const cs = f.querySelector('[name=cesit]');
    if (cs) veri.cesit = cs.value;
    const t = k.sektorler.flatMap((s) => s.tesisler).find((x) => x.kod === veri.tur);
    const ilAd = (k.iller.find((i) => i.id === veri.ilId) || {}).ad;
    if (!(await onayla(`${t.ad} ${ilAd}'da kurulsun mu?\nKurulum: ${tamTl(t.kurulum)}`, { baslik: _oyunMetni("ui.866f575d55db"), evet: _autoMetin('Kur'), ikon: t.simge }))) return;
    const r = await h.eylem(b, () => api('uretim/kur', veri));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(`${t.ad} kuruldu! ${t.maden ? _autoHtml('Şimdi ruhsat alıp arama sondajı yap.') : _autoHtml('Tesislerim sekmesinden üretime başla.')}`);
    uretimPaneli('tesis');
  }));
}

function ilSecenekleri(t, k) {
  let iller = k.iller;
  if (t.iller) iller = iller.filter((i) => t.iller.includes(i.id));
  else if (t.bolgeZorunlu) iller = iller.filter((i) => t.bolgeZorunlu.includes(i.bolge));
  else if (t.kiyi && t.receteler.every((r) => r.kiyi)) iller = iller.filter((i) => i.kiyi);
  const benim = iller.find((i) => i.id === k.benimIlim.id);
  const sirali = benim ? [benim, ...iller.filter((i) => i !== benim)] : iller;
  return sirali.map((i) => `<option value="${i.id}">${esc(i.ad)}${i === benim ? ' (ilin)' : ''}</option>`).join('');
}

// ---------- Ambar ----------
async function ambarCiz(kutu) {
  const a = await api('ambar');
  if (!hala(kutu)) return;
  const toplam = a.urunler.reduce((t, x) => t + x.deger, 0);
  kutu.innerHTML = `<div class="bilgi-izgara"><div><small>${_autoHtml("Ambarın değeri")}</small><b>${tl(toplam)}</b></div><div><small>${_autoHtml("Soğuk depo")}</small><b>${a.koruma ? `%${Math.round(a.koruma * 100)} koruma` : _autoHtml('Yok')}</b></div></div>
    ${a.urunler.length ? `<ul class="satirlar ambar-listesi">${a.urunler.map((u) => `<li data-urun="${u.kod}">
        <div class="ambar-satir"><span><b>${esc(_urunAdi(u.ad))}</b><br><span class="kucuk soluk">${_autoSablon`${sayi(u.miktar)} ${esc(_birimAdi(u.birim))} · piyasa ${tl(u.fiyat)}/${esc(_birimAdi(u.birim))}${u.bozulma ? ' · bozulur' : ''}`}</span></span>
          <span class="sag">${tl(u.deger)}<br><button class="metin-dugme" data-ac="${u.kod}">${_oyunHtml("finance.sell")} ▾</button></span></div>
        <form class="gizli-form ambar-form" hidden>
          <label class="alan"><span>${_autoSablon`Miktar (${esc(_birimAdi(u.birim))})`}</span><input name="miktar" type="number" min="0" step="any" value="${u.miktar}" max="${u.miktar}"></label>
          <div class="bilgi-izgara"><button type="button" class="dugme kucuk" data-sistem>${_autoSablon`Hemen sat: ${tl(u.sistemAlir)}/${esc(_birimAdi(u.birim))}`}</button>
            <button type="button" class="dugme mavi kucuk" data-ilan style="margin-top:0">${_oyunHtml("production.list")}</button></div>
          <label class="alan"><span>${_autoHtml("İlan birim fiyatı (₺)")}</span><input name="fiyat" type="number" min="0" step="any" value="${Math.round(u.fiyat) / 100}"></label>
          <p class="kucuk soluk">${_autoHtml("İlanda sistemden %12 daha iyi fiyata satarsın; alan oyuncu nakliyeyi öder, %2 komisyon kesilir. İlan 3 gün açık kalır.")}</p>
        </form></li>`).join('')}</ul>` : `<div class="kart"><p class="soluk">${_autoHtml("Ambarın boş. Tesislerinden ürün topladıkça burada birikir.")}</p></div>`}
    ${a.ilanlar.length ? `<div class="kart"><h3>${_autoHtml("Açık ilanların")}</h3><ul class="satirlar">${a.ilanlar.map((i) => `<li><span>${sayi(i.miktar)} ${esc(_birimAdi(i.birim))} ${esc(_urunAdi(i.ad))}<br><span class="kucuk soluk">${_autoSablon`${tl(i.fiyat)}/${esc(_birimAdi(i.birim))} · ${sureMetni(i.bitis - simdi())} kaldı`}</span></span>
        <button class="dugme gri kucuk" style="width:auto" data-iptal="${i.id}">${_oyunHtml("production.retract")}</button></li>`).join('')}</ul></div>` : ''}`;
  kutu.querySelectorAll('[data-ac]').forEach((b) => b.addEventListener('click', () => {
    const f = b.closest('li').querySelector('form');
    f.hidden = !f.hidden;
  }));
  kutu.querySelectorAll('.ambar-form').forEach((f) => {
    const kod = f.closest('li').dataset.urun;
    f.querySelector('[data-sistem]').addEventListener('click', async (e) => {
      const r = await h.eylem(e.currentTarget, () => api('pazar/sat', { urun: kod, miktar: Number(f.elements.miktar.value) }));
      if (r === undefined) return;
      h.ses.kasa();
      bildir(_oyunMetni("production.sale", {amount:tl(r.tutar)}));
      uretimPaneli();
    });
    f.querySelector('[data-ilan]').addEventListener('click', async (e) => {
      const r = await h.eylem(e.currentTarget, () => api('pazar/ilan', { urun: kod, miktar: Number(f.elements.miktar.value), fiyat: Math.round(Number(String(f.elements.fiyat.value).replace(',', '.')) * 100) }));
      if (r === undefined) return;
      bildir(_oyunMetni("production.listed"));
      uretimPaneli();
    });
  });
  kutu.querySelectorAll('[data-iptal]').forEach((b) => b.addEventListener('click', async () => {
    if ((await h.eylem(b, () => api('pazar/ilan-iptal', { id: Number(b.dataset.iptal) }))) === undefined) return;
    uretimPaneli();
  }));
}

// ---------- Pazar ----------
async function pazarCiz(kutu) {
  const l = await api('pazar?grup=' + pazarGrup);
  if (!hala(kutu)) return;
  kutu.innerHTML = `<div class="cipler">${GRUPLAR.map(([k, icon, key]) => `<button class="cip ${k === pazarGrup ? 'secili' : ''}" data-grup="${k}">${icon} ${_oyunHtml(key)}</button>`).join('')}</div>
    <p class="kucuk soluk">${_autoHtml("Piyasa fiyatı alım satımla oynar, zamanla dengeye döner. Sistem piyasanın %8 üstüne satar, %12 altına alır; ilanlarda oyuncular arası daha iyi fiyat bulunur.")}</p>
    <ul class="satirlar pazar-listesi">${l.map((u) => `<li data-urun="${u.kod}"><button class="pazar-satir" data-detay="${u.kod}">
      <span><b>${esc(_urunAdi(u.ad))}</b>${u.ithal ? ` <span class="rozetcik">${_autoHtml("ithal")}</span>` : ''}<br><span class="kucuk soluk">${u.ilanSayisi ? _autoSablon`${u.ilanSayisi} ilan · en ucuz ${tl(u.enUcuzIlan)}` : _autoHtml('ilan yok')}</span></span>
      <span class="sag">${tl(u.fiyat)}<small class="soluk">/${esc(_birimAdi(u.birim))}</small><br><span class="kucuk ${u.degisim > 0 ? 'arti' : u.degisim < 0 ? 'eksi' : 'soluk'}">${u.degisim > 0 ? '▲' : u.degisim < 0 ? '▼' : '•'} %${Math.abs(u.degisim).toLocaleString(aktifDil())}</span></span></button>
      <div class="pazar-detay" hidden></div></li>`).join('')}</ul>`;
  kutu.querySelectorAll('[data-grup]').forEach((b) => b.addEventListener('click', () => { pazarGrup = b.dataset.grup; h.ses.tik(); uretimPaneli(); }));
  kutu.querySelectorAll('[data-detay]').forEach((b) => b.addEventListener('click', () => pazarDetay(b.closest('li'), l.find((x) => x.kod === b.dataset.detay))));
}

async function pazarDetay(li, u) {
  const d = li.querySelector('.pazar-detay');
  if (!d.hidden) { d.hidden = true; return; }
  d.hidden = false;
  d.innerHTML = `<p class="soluk kucuk">${_oyunHtml("auth.loading")}</p>`;
  const ilanlar = await api('pazar/' + u.kod);
  d.innerHTML = `${u.kod === 'elektrik' ? `<p class="kucuk soluk">${_autoHtml("Elektrik santrallerden şebekeye kendiliğinden satılır.")}</p>` : `
    <div class="pazar-al"><input type="number" min="0" step="any" placeholder="${_autoSablon`Miktar (${esc(_birimAdi(u.birim))})`}" name="miktar">
      <button class="dugme kucuk" data-al>${_autoSablon`Sistemden al: ${tl(u.sistemSatar)}/${esc(_birimAdi(u.birim))}`}</button></div>`}
    ${ilanlar.length ? `<ul class="satirlar">${ilanlar.map((i) => `<li><span>${sayi(i.miktar)} ${esc(_birimAdi(u.birim))} · <b>${tl(i.fiyat)}</b>/${esc(_birimAdi(u.birim))}<br>
        <span class="kucuk soluk">${esc(i.satici)} · ${esc(i.il)}${i.nakliye ? ` · nakliye %${(i.nakliye * 100).toLocaleString(aktifDil())}` : ''}</span></span>
        ${i.benim ? `<span class="kucuk soluk">${_autoHtml("senin")}</span>` : `<button class="dugme mavi kucuk" style="width:auto" data-ilan-al="${i.id}" data-en="${i.miktar}">${_oyunHtml("finance.buy")}</button>`}</li>`).join('')}</ul>` : `<p class="kucuk soluk">${_autoHtml("Bu ürün için oyuncu ilanı yok.")}</p>`}`;
  const al = d.querySelector('[data-al]');
  if (al) al.addEventListener('click', async () => {
    const m = Number(d.querySelector('[name=miktar]').value);
    const r = await h.eylem(al, () => api('pazar/al', { urun: u.kod, miktar: m }));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(_autoSablon`${sayi(m)} ${_birimAdi(u.birim)} ${_urunAdi(u.ad)} ambarına girdi (${tl(r.tutar)}).`);
    al.disabled = false;
  });
  d.querySelectorAll('[data-ilan-al]').forEach((b) => b.addEventListener('click', async () => {
    const girilen = Number(d.querySelector('[name=miktar]') ? d.querySelector('[name=miktar]').value : 0);
    const m = girilen > 0 ? Math.min(girilen, Number(b.dataset.en)) : Number(b.dataset.en);
    const r = await h.eylem(b, () => api('pazar/ilan-al', { id: Number(b.dataset.ilanAl), miktar: m }));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(_autoSablon`Satın alındı: ${tl(r.tutar + r.nakliye)}${r.nakliye ? ' (nakliye dahil)' : ''}`);
    d.hidden = true;
    pazarDetay(li, u);
  }));
}

// ---------- Şirket ----------
async function sirketCiz(kutu) {
  const s = await api('sirket');
  if (!hala(kutu)) return;
  const m = s.mevcut;
  const n = s.sonraki;
  const yuzde = (x) => `%${(x * 100).toLocaleString(aktifDil(), { maximumFractionDigits: 1 })}`;
  kutu.innerHTML = `<div class="kart sirket-karti"><div class="sirket-unvan">${m.unvan ? esc(m.unvan) : _autoHtml('Henüz şirketin yok')}</div>
      <div class="kucuk soluk">${esc(m.ad)}</div>
      <div class="bilgi-izgara" style="margin-top:10px"><div><small>${_autoHtml("Servet")}</small><b>${tl(s.servet)}</b></div><div><small>${_autoHtml("İşletme / sektör")}</small><b>${s.isletme} / ${s.sektor}</b></div></div>
      <p class="kucuk">${_autoSablon`Avantajların: gider indirimi ${yuzde(m.indirim)}, pazar komisyonu ${yuzde(m.komisyon)}${m.verim ? `, verim +${yuzde(m.verim)}` : ''}.`}</p></div>
    <div class="basamaklar">${s.turler.map((t, i) => `<div class="basamak ${t.kod === m.kod ? 'simdi' : s.turler.findIndex((x) => x.kod === m.kod) > i ? 'gecti' : ''}"><span>${['🧑‍🔧', '🏢', '🏦', '🏛️'][i]}</span><small>${esc(t.ad)}</small></div>`).join('')}</div>
    ${n ? `<div class="kart"><h3>${_autoSablon`Sıradaki: ${esc(n.ad)}`}</h3>
      <ul class="sart-listesi">${n.sartlar.map((x) => `<li class="${x.tamam ? 'tamam' : ''}">${x.tamam ? '✅' : '⬜'} ${esc(x.ad)}${x.durum ? ` <span class="soluk">(${esc(x.durum)})</span>` : ''}</li>`).join('')}
        <li>${_autoSablon`💼 Kuruluş bedeli: <b>${tl(n.ucret)}</b>`}</li></ul>
      <p class="kucuk">${_autoSablon`Kazanacağın: gider indirimi ${yuzde(n.indirim)}, komisyon ${yuzde(n.komisyon)}${n.verim ? _autoSablon`, tüm üretimde +${yuzde(n.verim)} verim` : ''}.`}</p>
      ${m.unvan ? '' : `<label class="alan"><span>${_autoHtml("Şirketinin adı")}</span><input name="ad" maxlength="40" placeholder="ör. Yılmaz Gıda"></label>`}
      <button class="dugme yesil" data-kur ${n.sartlar.every((x) => x.tamam) ? '' : 'disabled'}>${_autoSablon`${esc(n.ad)} kur`}</button></div>`
    : `<div class="kart basari"><h3>${_autoHtml("🏛️ Holding patronusun!")}</h3><p>${_autoHtml("Çıraklıktan patronluğa giden yolu tamamladın. Şimdi sıralamada zirveye oyna.")}</p></div>`}`;
  const b = kutu.querySelector('[data-kur]');
  if (b) b.addEventListener('click', async () => {
    const ad = kutu.querySelector('[name=ad]') ? kutu.querySelector('[name=ad]').value : '';
    const r = await h.eylem(b, () => api('sirket/kur', { ad }));
    if (r === undefined) return;
    h.ses.seviye();
    bildir(_autoSablon`Tebrikler! ${r.unvan} artık bir ${n.ad.toLocaleLowerCase('tr')}.`);
    uretimPaneli();
  });
}

// ---------- Tedarik sözleşmeleri ----------
const DURUM_ADI = { teklif: 'Teklif (satıcı bekleniyor)', suruyor: 'Sürüyor', bitti: 'Tamamlandı', feshedildi: 'Feshedildi', iptal: 'Geri çekildi' };
async function tedarikCiz(kutu) {
  const [t, piyasa] = await Promise.all([api('tedarik'), api('pazar')]);
  if (!hala(kutu)) return;
  const fiyatlar = Object.fromEntries(piyasa.map((u) => [u.kod, u]));
  const satir = (x) => `<li class="tedarik-satir">
      <div style="flex:1;min-width:0">${_autoSablon`<b>${sayi(x.miktar)} ${esc(x.birim)} ${esc(x.urunAdi)}</b> × ${x.teslimSayisi} teslim`}
        <div class="kucuk soluk">${_autoSablon`${tl(x.birimFiyat)}/${esc(x.birim)} · her ${x.aralikGun} ekonomi gününde · toplam ${tl(x.toplam)}`}</div>
        <div class="kucuk">${x.benimAlici ? _autoSablon`Satıcı: ${x.satici ? esc(x.satici) : '—'}` : _autoSablon`Alıcı: ${esc(x.alici)}`} · ${esc(_autoMetin(DURUM_ADI[x.durum] || x.durum))}${x.durum === 'suruyor' ? _autoSablon` · ${x.yapilan}/${x.teslimSayisi} teslim${x.kacirilan ? `${_autoSablon`, <b class="kirmizi">${x.kacirilan} kaçtı</b>`}` : ''} · sonraki ${sureMetni(Math.max(0, x.sonraki - simdi()))} sonra` : ''}</div></div>
      ${x.benimAlici && x.durum === 'teklif' ? `<button class="dugme kucuk gri" data-geri="${x.id}">${_oyunHtml("production.retract")}</button>` : ''}</li>`;
  kutu.innerHTML = `
    <div class="kart"><h3>${_autoHtml("🤝 Tedarik sözleşmesi nedir?")}</h3>
      <p class="kucuk">${_autoSablon`Fabrikanın hammaddesini düzenli almak ya da ürününü garanti bir alıcıya satmak için oyuncularla sözleşme yap. Alıcı toplam bedeli emanete yatırır; satıcı %${t.teminatOrani} teminat koyar. Her teslim gününde mal satıcının ambarından alıcınınkine kendiliğinden geçer. Mal yoksa satıcı teminatından ceza öder; üst üste iki teslim kaçarsa sözleşme feshedilir.`}</p></div>
    ${t.benim.length ? `<div class="kart"><h3>${_autoHtml("Sözleşmelerim")}</h3><ul class="satirlar">${t.benim.map(satir).join('')}</ul></div>` : ''}
    <div class="kart"><h3>${_autoHtml("Açık teklifler (satıcı aranıyor)")}</h3>
      ${t.teklifler.length ? `<ul class="satirlar">${t.teklifler.map((x) => `<li class="tedarik-satir">
        <div style="flex:1;min-width:0"><b>${sayi(x.miktar)} ${esc(x.birim)} ${esc(x.urunAdi)}</b> × ${x.teslimSayisi}
          <div class="kucuk soluk">${_autoSablon`${tl(x.birimFiyat)}/${esc(x.birim)}${fiyatlar[x.urun] ? ` (piyasa ${tl(fiyatlar[x.urun].fiyat)})` : ''} · her ${x.aralikGun} ekonomi günü · ${esc(x.alici)}, ${esc(x.il || '')}`}</div>
          <div class="kucuk">${_autoSablon`Toplam ${tl(x.toplam)} · teminat ${tl(Math.round(x.toplam * t.teminatOrani / 100))} · ambarında ${sayi(x.ambarimda)} ${esc(x.birim)}`}</div></div>
        <button class="dugme kucuk mavi" data-kabul="${x.id}">${_oyunHtml("production.accept")}</button></li>`).join('')}</ul>` : `<p class="soluk kucuk">${_autoHtml("Şu an açık teklif yok. İlk teklifi sen aç!")}</p>`}
    </div>
    <div class="kart"><h3>${_autoHtml("Yeni teklif aç (alıcı olarak)")}</h3>
      <label class="alan"><span>${_autoHtml("Ürün")}</span><select name="urun">${piyasa.filter((u) => u.kod !== 'elektrik').map((u) => `<option value="${u.kod}">${esc(_urunAdi(u.ad))} (${tl(u.fiyat)}/${esc(_birimAdi(u.birim))})</option>`).join('')}</select></label>
      <div class="iki-alan"><label class="alan"><span>${_autoHtml("Her teslimde miktar")}</span><input name="miktar" type="number" min="1" step="any" value="1000"></label>
        <label class="alan"><span>${_autoHtml("Birim fiyat (₺)")}</span><input name="fiyat" type="number" min="0" step="0.01"></label></div>
      <div class="iki-alan"><label class="alan"><span>${_autoHtml("Teslim sayısı")}</span><select name="teslim">${Array.from({ length: t.enCokTeslim }, (_, i) => `<option ${i === 3 ? 'selected' : ''}>${i + 1}</option>`).join('')}</select></label>
        <label class="alan"><span>${_autoHtml("Aralık")}</span><select name="aralik">${t.aralikGunleri.map((g) => `<option value="${g}" ${g === 3 ? 'selected' : ''}>${_autoSablon`${g} ekonomi günü (${sureMetni(g * t.ekonomiGunuMs)})`}</option>`).join('')}</select></label></div>
      <p class="kucuk" data-ozet></p>
      <button class="dugme yesil" data-teklif>🤝 ${_oyunHtml("production.offer")}</button>
      <p class="kucuk soluk">${_autoHtml("Birim fiyat piyasanın yarısı ile iki katı arasında olmalı. 7 ekonomi gününde kabul edilmeyen teklif geri çekilir, paran iade edilir.")}</p>
    </div>`;
  const f = (n) => kutu.querySelector(`[name=${n}]`);
  const fiyatYaz = () => { const u = fiyatlar[f('urun').value]; if (u) f('fiyat').value = (u.fiyat / 100).toFixed(2); ozet(); };
  const ozet = () => {
    const m = Number(f('miktar').value), bf = Math.round(Number(f('fiyat').value) * 100), n = Number(f('teslim').value);
    kutu.querySelector('[data-ozet]').innerHTML = m > 0 && bf > 0 ? `${_autoSablon`Emanete alınacak toplam: <b>${tamTl(Math.round(m * bf * n))}</b>`}` : '';
  };
  f('urun').addEventListener('change', fiyatYaz);
  for (const n of ['miktar', 'fiyat', 'teslim']) f(n).addEventListener('input', ozet);
  fiyatYaz();
  kutu.querySelector('[data-teklif]').addEventListener('click', async (e) => {
    const veri = { urun: f('urun').value, miktar: Number(f('miktar').value), birimFiyat: Math.round(Number(f('fiyat').value) * 100), teslimSayisi: Number(f('teslim').value), aralikGun: Number(f('aralik').value) };
    const r = await h.eylem(e.currentTarget, () => api('tedarik', veri));
    if (r === undefined) return;
    bildir(_autoSablon`Teklifin yayında. ${tamTl(r.toplam)} emanete alındı.`);
    await h.durumYenile();
    uretimPaneli();
  });
  kutu.querySelectorAll('[data-kabul]').forEach((b) => b.addEventListener('click', async () => {
    const x = t.teklifler.find((y) => y.id === Number(b.dataset.kabul));
    const teminat = Math.round(x.toplam * t.teminatOrani / 100);
    if (!(await onayla(_autoSablon`${sayi(x.miktar)} ${x.birim} ${x.urunAdi}, ${x.teslimSayisi} teslim, her ${x.aralikGun} ekonomi gününde.\nTeminat: ${tamTl(teminat)}\nHer teslimde ambarında yeterli mal olmalı, yoksa teminattan ceza kesilir.`, { baslik: _oyunMetni("ui.5d7d4474242d"), evet: _autoMetin('Kabul ediyorum'), ikon: '🤝' }))) return;
    if ((await h.eylem(b, () => api(`tedarik/${x.id}/kabul`, {}))) === undefined) return;
    bildir(_oyunMetni("production.contractStarted"));
    await h.durumYenile();
    uretimPaneli();
  }));
  kutu.querySelectorAll('[data-geri]').forEach((b) => b.addEventListener('click', async () => {
    if ((await h.eylem(b, () => api(`tedarik/${b.dataset.geri}/iptal`, {}))) === undefined) return;
    await h.durumYenile();
    uretimPaneli();
  }));
}
