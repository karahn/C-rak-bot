import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.49.2';
import { t as _oyunMetni, htmlDil as _oyunHtml, urunAdi as _urunAdi, birimAdi as _birimAdi } from './dil.js?v=0.49.2';
// Çırak – devlet ve piyasalar: seçimler (belediye, meclis, cumhurbaşkanlığı), meclis ve kanunlar,
// kamu ihaleleri, borsa, sigorta şirketleri, reklam ajansları, tesis ortaklıkları
import { api, tl, tamTl, esc, sayiDili, sayiCoz, sureMetni, gercekSureAdi, simdi, bildir, onayla, sor, kart } from './yardimci.js?v=0.49.2';
import { avatarHtml, isimHtml } from './sosyal.js?v=0.49.2';

const avatarHarf = (ad) => String(ad || '?').trim().split(/\s+/).slice(0, 2).map((p) => p[0]).join('').toLocaleUpperCase('tr');

let h = null; // ana.js'den gelen yardımcılar
export function devletKur(y) { h = y; }

const tarih = (ms) => new Date(ms + 3 * 3600000).toISOString().slice(0, 10).split('-').reverse().join('.');
const tarihSaat = (ms) => `${tarih(ms)} ${new Date(ms + 3 * 3600000).toISOString().slice(11, 16)}`;
function tutarOku(s) {
  const t = sayiCoz(s);
  return Number.isFinite(t) && t > 0 ? Math.round(t * 100) : 0;
}
const kurusYaz = (k) => (Math.round(k) / 100).toLocaleString(sayiDili(), { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const hala = (kutu, rota) => kutu.isConnected && h.aktifRota() === rota;
const yukleniyor = () => `<p class="soluk">${_autoHtml("Yükleniyor…")}</p>`;
const avatar = (ad, foto, sistem) => foto ? `<img class="aday-foto" src="${esc(foto)}" alt="">` : `<span class="aday-foto harf${sistem ? ' sistem' : ''}">${esc(avatarHarf(ad))}</span>`;
function sekmeler(liste, secili, veri = 'sekme') {
  return `<div class="sekmeler kaydir" role="tablist">${liste.map(([k, i, a]) => `<button role="tab" data-${veri}="${k}" aria-selected="${secili === k}">${i} ${_autoMetin(a)}</button>`).join('')}</div>`;
}

// ====================================================================== Seçimler
let secimSekme = 'belediye';
const TUR_BILGI = {
  belediye: {
    kural: 'Her ay seçim yapılır. Adaylık 3 gün, oylama 3 gün sürer; kazanan ayın 1\'inde göreve başlar, görev 1 ay. Yalnızca ilçende yaşayanlar aday olur ve oy verir. Adaylık ücreti ilçe belediyesi kasasına gider.',
    gorev: 'Başkan ilçedeki ruhsat ve izin başvurularını onaylar ya da gerekçesini yazarak reddeder; 12 saatte bakmazsa bot karar verir. Dönem sonunda belediye kasasının %20\'si ödenek olarak başkana ödenir.',
  },
  ilbelediye: {
    kural: 'İlçe belediye seçimiyle aynı takvimde, her ay yapılır. Adaylık 3 gün, oylama 3 gün; kazanan ayın 1\'inde göreve başlar, görev 1 ay. İlinde yaşayan herkes aday olabilir ve oy verir. Adaylık ücreti il belediyesi kasasına gider.',
    gorev: 'İl belediye başkanı ilin belediye kasasını yönetir: ildeki işletmelerin vergisinin %20\'si ve ildeki mülklerin tapu harcının %30\'u bu kasaya akar. Dönem sonunda kasanın %20\'si ödenek olarak başkana ödenir. İl ve ilçe başkanları mahallede konvoyla geçer.',
  },
  mv: {
    kural: 'Her ay seçim yapılır; adaylık 3 gün, oylama 3 gün. Vekiller oylamanın bittiği günün ertesinde (ayın 16\'sında) göreve başlar, görev 1 ay. 81 ilde toplam 600 sandalye vardır; seçmen yalnızca kendi ilinin adaylarına oy verir.',
    gorev: 'Milletvekilleri mecliste vergi, ruhsat harcı, pazar vergisi, seyyar izni ve zabıta cezası için kanun teklifi verir ve oylar. Dönem sonunda ülke kasasının %10\'u 600 vekil arasında paylaştırılır.',
  },
  cb: {
    kural: 'Yılda 6 seçim yapılır (iki ayda bir). Adaylık 3 gün, oylama 3 gün; kazanan Ocak, Mart, Mayıs, Temmuz, Eylül ve Kasım\'ın 1\'inde göreve başlar, görev 2 ay. En çok oy alan cumhurbaşkanı, sonraki 5 aday yardımcısı olur. Tüm Türkiye oy verir.',
    gorev: 'Cumhurbaşkanı meclisten geçen kanunları ve kamu ihalelerini onaylar ya da veto eder; 3 saatte bakmazsa bot karar verir. Dönem sonunda ülke kasasının %5\'i ödenek olarak ödenir.',
  },
};

export async function secimPaneli(sekme) {
  if (sekme && TUR_BILGI[sekme]) secimSekme = sekme;
  const p = h.panelAc({
    ikon: '🗳️', baslik: _oyunMetni("ui.439e54384792"), rota: 'secim', alt: _autoMetin('Belediye, meclis ve cumhurbaşkanlığı'),
    govde: `${sekmeler([['belediye', '🏛️', _autoMetin('İlçe Belediye')], ['ilbelediye', '🏙️', _autoMetin('İl Belediye')], ['mv', '🏢', _autoMetin('Meclis')], ['cb', '🇹🇷', _autoMetin('Cumhur&shy;başkanlığı')]], secimSekme)}<div id="secim-icerik">${yukleniyor()}</div>`,
  });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); history.replaceState(null, '', '#/secim/' + b.dataset.sekme); secimPaneli(b.dataset.sekme); }));
  const kutu = p.querySelector('#secim-icerik');
  let x;
  try { x = await api('secim'); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'secim')) return;
  p.querySelector('.alt-baslik').innerHTML = `${_autoSablon`Ülke kasası (hazine): <b>${tl(x.hazine)}</b>`}`;
  const s = x.secimler[secimSekme];
  const benimMakamlarim = x.makamlarim.filter((m) => (secimSekme === 'cb' ? ['cb', 'cby'].includes(m.tur) : m.tur === secimSekme));
  let html = '';
  // görev masası
  if (secimSekme === 'belediye' && x.belediye.baskanMiyim) html += belediyeMasasi(x.belediye);
  if (secimSekme === 'ilbelediye' && x.ilBelediye) html += `<div class="kart${x.ilBelediye.baskanMiyim ? ' basari' : ''}"><h3>🏙️ ${esc(x.ilBelediye.ad)}</h3>
    <div class="bilgi-izgara"><div><small>${_autoHtml("Belediye kasası")}</small><b>${tl(x.ilBelediye.kasa)}</b></div><div><small>${_autoHtml("Başkan")}</small><b>${esc(x.ilBelediye.baskan.ad)}</b></div></div>
    ${x.ilBelediye.baskanMiyim ? `<p class="kucuk" style="margin:8px 0 0">${_autoHtml("⭐ İlin belediye başkanı sensin. Dönem sonunda kasanın %20'si ödeneğin olarak hesabına yatar.")}</p>` : ''}</div>`;
  if (secimSekme === 'mv' && x.meclis.milletvekiliyim) html += meclisHtml(x.meclis);
  if (secimSekme === 'cb' && x.meclis.cumhurbaskaniyim) html += cbMasasi(x);
  html += takvimHtml(s);
  if (s.evre === 'adaylik') html += adayOlHtml(s, x);
  if (s.evre !== 'bekliyor') html += adaylarHtml(s);
  html += gorevdekilerHtml(s, benimMakamlarim);
  if (secimSekme === 'mv' && !x.meclis.milletvekiliyim) html += meclisHtml(x.meclis);
  if (x.mazbatalar.length) html += mazbataHtml(x.mazbatalar.filter((m) => (secimSekme === 'cb' ? ['cb', 'cby'].includes(m.tur) : m.tur === secimSekme)));
  html += `<div class="kart"><h3>${_autoHtml("ℹ️ Nasıl işler?")}</h3><p class="kucuk" style="margin:0 0 6px">${_autoMetin(TUR_BILGI[secimSekme].kural)}</p><p class="kucuk soluk" style="margin:0">${_autoSablon`${_autoMetin(TUR_BILGI[secimSekme].gorev)} Aday yoksa ya da yetersizse sistem adayları eklenir; kimse en az 3 oy alamazsa sistem, oylara göre ağırlıklı kurayla seçer. Bir kişi aynı anda yalnızca bir seçimde aday olabilir; her internet bağlantısından bir oy sayılır.`}</p></div>`;
  kutu.innerHTML = html;
  secimBagla(kutu, x, s);
  // geri sayım
  h.zamanlayici(() => {
    if (!hala(kutu, 'secim')) return;
    kutu.querySelectorAll('[data-geri]').forEach((el) => { el.textContent = sureMetni(Math.max(0, Number(el.dataset.geri) - simdi())); });
    kutu.querySelectorAll('[data-sefer-bas]').forEach((el) => { const a = Number(el.dataset.seferBas), b = Number(el.dataset.seferBit); el.style.width = Math.min(100, Math.round(((simdi() - a) / (b - a)) * 100)) + '%'; });
  }, 1000);
}

function takvimHtml(s) {
  const adim = (ad, bas, bit, etkin, bitti) => `<li class="${etkin ? 'etkin' : bitti ? 'bitti' : ''}"><b>${ad}</b><small>${tarih(bas)}${bit ? ' – ' + tarih(bit - 1) : ''}</small></li>`;
  const t = simdi();
  const kalanHedef = s.evre === 'bekliyor' ? s.adaylikBas : s.evre === 'adaylik' ? s.oylamaBas : s.gorevBas;
  const kalanAd = s.evre === 'bekliyor' ? _autoMetin('Adaylığın açılmasına') : s.evre === 'adaylik' ? _autoMetin('Oylamanın başlamasına') : _autoMetin('Oylamanın bitmesine');
  return `<div class="kart"><h3>${s.simge} ${esc(s.ad)} · ${esc(s.bolge)}${s.tur === 'mv' ? ` <span class="rozetcik bilgi">${_autoSablon`${s.sandalye} sandalye`}</span>` : ''}</h3>
    <ol class="secim-takvim">
      ${adim(_autoMetin('Adaylık'), s.adaylikBas, s.oylamaBas, s.evre === 'adaylik', t >= s.oylamaBas)}
      ${adim('Oylama', s.oylamaBas, s.gorevBas, s.evre === 'oylama', t >= s.gorevBas)}
      ${adim(_autoMetin('Göreve başlama'), s.gorevBas, s.gorevBitis, false, false)}
    </ol>
    <p class="kucuk" style="margin:6px 0 0">${_autoSablon`${kalanAd} <b data-geri="${kalanHedef}">${sureMetni(kalanHedef - t)}</b> kaldı.`}</p></div>`;
}

function adaylarHtml(s) {
  const oylama = s.evre === 'oylama';
  const yetki = !s.secmenMi ? `<p class="kucuk soluk">${_autoHtml("Oy vermek için en az 3. seviye ve 3 günlük hesap gerekir.")}</p>`
    : s.baglantiKullandi ? `<p class="kucuk soluk">${_autoSablon`Bu internet bağlantısından bu seçimde ${s.baglantiSiniri || 1} oy verildi. Bir bağlantıdan en çok ${s.baglantiSiniri || 1} oy sayılır.`}</p>` : '';
  return `<div class="kart"><h3>${oylama ? _autoHtml('🗳️ Oy ver') : '🎤 Adaylar'} <span class="kucuk soluk">(${s.adaylar.length})</span></h3>
    ${oylama ? yetki : `<p class="kucuk soluk" style="margin:0 0 6px">${_autoHtml("Oylama başlayınca adaylar tüm seçmenlere mesajla duyurulur.")}</p>`}
    ${s.adaylar.length ? `<ul class="aday-listesi">${s.adaylar.map((a) => `<li${a.oyuncuId && s.oyum === a.id ? ' class="secili"' : ''}>
      ${avatar(a.ad, a.foto, a.sistem)}
      <div class="aday-yazi"><b>${esc(a.ad)}</b> ${a.sistem ? `<span class="rozetcik">${_autoHtml("Sistem adayı")}</span>` : `<span class="kucuk soluk">${_autoSablon`${a.seviye}. seviye`}</span>`}<br><span class="kucuk">“${esc(a.vaat || '')}”</span></div>
      <div class="aday-oy">${a.oy !== null ? `<b>${a.oy}</b><small>${_autoHtml("oy")}</small>` : ''}
        ${a.oyuncuId && a.oyuncuId === h.oyuncu().id ? `<span class="rozetcik bilgi">${_autoHtml("Sen")}</span>`
          : s.oyum === a.id ? `<span class="rozetcik iyi">${_autoHtml("Oyun")}</span>`
          : oylama && !s.oyum && s.secmenMi && !s.baglantiKullandi ? `<button class="dugme mavi kucuk" data-oy="${a.id}">${_autoHtml("Oy ver")}</button>` : ''}</div></li>`).join('')}</ul>`
      : `<p class="kucuk soluk">${_autoHtml("Henüz aday yok. İlk aday sen ol!")}</p>`}</div>`;
}

function adayOlHtml(s, x) {
  if (s.adayim) return `<div class="kart basari aday-kart"><b>${_autoHtml("🎤 Adaysın.")}</b> <span class="kucuk">${_autoHtml("Adaylık afişini paylaş, arkadaşlarından destek iste: afişten gelip üye olan herkes oy verebilir.")}</span>
    ${s.adaySertifika ? `<button class="aday-afis" data-afis="${s.adaySertifika}"><img src="api/sertifika/${s.adaySertifika}.jpg" alt="${_autoHtml("Adaylık afişin")}" loading="lazy"><span>${_autoHtml("📣 Afişini paylaş, destek iste")}</span></button>` : ''}</div>`;
  if (s.baskaAdaylik) return `<div class="kart"><p class="kucuk" style="margin:0">${_autoSablon`Şu an ${esc(x.secimler[s.baskaAdaylik].ad.toLocaleLowerCase('tr'))} seçiminde adaysın. Bir kişi aynı anda yalnızca bir seçimde aday olabilir.`}</p></div>`;
  if (!s.adayOlabilir) return `<div class="kart"><p class="kucuk soluk" style="margin:0">${_autoSablon`${s.makam} adayı olmak için`} <span class="kilit-rozet">${_autoSablon`${s.adaySeviye}. seviye`}</span> ${_autoSablon`gerekir. Adaylık ücreti ${tl(s.adayUcreti)}.`}</p></div>`;
  return `<div class="kart vurgu"><h3>${_autoSablon`🎤 ${esc(s.makam)} adayı ol`}</h3>
    <label class="alan"><span>${_autoHtml("Seçmenlere vaadin")}</span><input name="vaat" maxlength="200" placeholder="${s.tur === 'belediye' || s.tur === 'ilbelediye' ? _autoHtml('ör. Ruhsatları aynı gün onaylayacağım') : s.tur === 'mv' ? _autoHtml('ör. Esnafın vergisini düşüreceğim') : _autoHtml('ör. İhaleler şeffaf olacak')}"></label>
    <button class="dugme yesil" data-aday="${s.tur}">${_autoSablon`Adaylığımı koy (${tl(s.adayUcreti)})`}</button>
    <p class="kucuk soluk">${_autoSablon`Ücret ${s.tur === 'belediye' ? _autoHtml('ilçe belediyesi kasasına') : s.tur === 'ilbelediye' ? _autoHtml('il belediyesi kasasına') : _autoHtml('ülke kasasına')} gider, iade edilmez. Adaylık afişin hazırlanır; paylaşıp destek isteyebilirsin.`}</p></div>`;
}

function gorevdekilerHtml(s, benim) {
  const l = s.gorevde;
  const bas = benim.length ? `<p class="kucuk basari-yazi">${_autoHtml("⭐ Görevdesin:")} ${esc(benim.map((m) => m.makam).join(', '))} ${_autoSablon`(bitiş ${tarih(benim[0].bitis - 1)})`}</p>` : '';
  if (!l.length) return `<div class="kart"><h3>${_autoHtml("🏅 Görevdekiler")}</h3>${bas}<p class="kucuk soluk" style="margin:0">${s.tur === 'belediye' || s.tur === 'ilbelediye' ? _autoHtml('Belediyeyi şimdilik bot yönetiyor.') : _autoHtml('Henüz seçilmiş kimse yok; ilk seçimden sonra görevliler burada görünür.')}</p></div>`;
  const gercek = l.filter((m) => m.oyuncuId).length;
  return `<div class="kart"><h3>${_autoSablon`🏅 Görevdekiler${s.tur === 'mv' ? ` · ${esc(s.bolge)} vekilleri` : ''}`}</h3>${bas}
    ${s.tur === 'mv' ? `<p class="kucuk soluk" style="margin:0 0 6px">${_autoSablon`${l.length} vekilden ${gercek} oyuncu. Oyuncu olmayan vekiller oylamaya katılmaz.`}</p>` : ''}
    <ul class="makam-listesi">${l.slice(0, 40).map((m) => `<li>${avatar(m.ad, m.foto, !m.oyuncuId)}<span><b>${esc(m.ad)}</b><br><small>${_autoSablon`${esc(m.makam)} · ${m.oy} oy`}</small></span>${m.oyuncuId ? '' : `<span class="rozetcik">${_autoHtml("Sistem")}</span>`}</li>`).join('')}</ul>
    ${l.length > 40 ? `<p class="kucuk soluk">${_autoSablon`ve ${l.length - 40} vekil daha`}</p>` : ''}</div>`;
}

function mazbataHtml(l) {
  return `<div class="kart"><h3>${_autoHtml("📜 Mazbatalarım")}</h3><div class="mazbata-listesi">${l.map((m) => `<a class="mazbata" href="s/${m.kod}" target="_blank" rel="noopener">
    <img src="api/sertifika/${m.kod}.jpg" alt="${esc(m.makam)} mazbatası" loading="lazy"><span><b>${esc(m.makam)}</b><small>${tarih(m.baslangic)} – ${tarih(m.bitis - 1)}</small></span></a>`).join('')}</div>
    <p class="kucuk soluk">${_autoHtml("Mazbatana dokun: paylaşım sayfası açılır, arkadaşlarınla paylaş.")}</p></div>`;
}

function belediyeMasasi(b) {
  return `<div class="kart basari"><h3>${_autoSablon`🏛️ Başkanlık masası: bekleyen başvurular (${b.bekleyenler.length})`}</h3>
    ${b.bekleyenler.length ? `<ul class="satirlar">${b.bekleyenler.map((x) => `<li class="basvuru-karar"><span><b>${esc(x.oyuncu)}</b>: ${esc(x.ad)}${x.isletme ? ` · “${esc(x.isletme)}”` : ''}<br><span class="kucuk soluk">${tarihSaat(x.olusturma)}</span></span>
      <span class="dugme-satiri"><button class="dugme yesil kucuk" data-karar="onay" data-id="${x.id}">${_autoHtml("Onayla")}</button><button class="dugme kirmizi kucuk" data-karar="red" data-id="${x.id}">${_autoHtml("Reddet")}</button></span></li>`).join('')}</ul>`
      : `<p class="kucuk soluk" style="margin:0">${_autoHtml("Şu an bekleyen başvuru yok.")}</p>`}
    <p class="kucuk soluk">${_autoSablon`${_autoHtml("Belediye kasası")}: <b>${tl(b.kasa)}</b>. 12 saat içinde karar vermediğin başvurulara bot bakar.`}</p></div>`;
}

const KANUN_DURUM = { oylama: ['Oylamada', 'bilgi'], onay: ['Cumhurbaşkanı onayında', 'altin'], yururlukte: ['Yürürlükte', 'iyi'], ret: ['Mecliste reddedildi', 'kotu'], veto: ['Veto edildi', 'kotu'], karar: ['Karar veriliyor', 'bilgi'], sayim: ['Sayılıyor', 'bilgi'] };
function meclisHtml(m) {
  const teklif = m.milletvekiliyim ? `<details class="kart vurgu"><summary><b>${_autoHtml("📝 Kanun teklifi ver")}</b></summary>
      <label class="alan"><span>${_autoHtml("Konu")}</span><select name="kanun">${m.kanunlar.map((k) => `<option value="${k.anahtar}" data-birim="${k.birim}" data-deger="${k.deger}">${_autoSablon`${esc(k.ad)} (şu an ${k.birim === 'TL' ? tamTl(k.deger) : '%' + k.deger})`}</option>`).join('')}</select></label>
      <label class="alan"><span>${_autoHtml("Yeni değer")} <small class="soluk" data-kanun-ipucu></small></span><input name="deger" inputmode="decimal" autocomplete="off"></label>
      <label class="alan"><span>${_autoHtml("Gerekçe")}</span><input name="gerekce" maxlength="300" placeholder="${_autoHtml("ör. Esnafın yükü hafiflesin, kayıt dışı azalsın")}"></label>
      <button class="dugme yesil" data-teklif>${_autoHtml("Meclise sun")}</button>
      <p class="kucuk soluk">${_autoSablon`Bir teklif ayarı en çok %${Math.round(m.enCokDegisim * 100)} değiştirebilir. Oylama 24 saat sürer; kabul edilirse cumhurbaşkanının onayına gider.`}</p></details>` : '';
  const liste = m.teklifler.length ? `<ul class="kanun-listesi">${m.teklifler.map((k) => {
    const [dAd, dTur] = KANUN_DURUM[k.durum] || [k.durum, ''];
    const oyVer = m.milletvekiliyim && k.durum === 'oylama' && k.oyum === null;
    return `<li><div><b>${esc(k.ad)}</b>: ${esc(k.eski)} → <b>${esc(k.yeni)}</b> <span class="rozetcik ${dTur}">${_autoHtml(dAd)}</span>
      <br><span class="kucuk">“${esc(k.gerekce || '')}”</span><br><span class="kucuk soluk">${_autoSablon`${esc(k.oneren || '')} · ${tarihSaat(k.olusturma)} · ${k.evet} evet, ${k.hayir} hayır`}${k.durum === 'oylama' ? ` ${_autoHtml("· kalan")} <span data-geri="${k.oylamaBitis}">${sureMetni(k.oylamaBitis - simdi())}</span>` : ''}${k.kararGerekce ? ` · ${esc(k.kararGerekce)}` : ''}</span></div>
      ${oyVer ? `<div class="dugme-satiri"><button class="dugme yesil kucuk" data-kanun-oy="evet" data-id="${k.id}">${_autoHtml("Evet")}</button><button class="dugme kirmizi kucuk" data-kanun-oy="hayir" data-id="${k.id}">${_autoHtml("Hayır")}</button><button class="dugme kucuk" data-kanun-oy="cekimser" data-id="${k.id}">${_autoHtml("Çekimser")}</button></div>`
        : k.oyum !== null ? `<span class="rozetcik">${k.oyum === 1 ? _autoHtml('Evet dedin') : k.oyum === -1 ? _autoHtml('Hayır dedin') : _autoMetin("Çekimser")}</span>` : ''}</li>`;
  }).join('')}</ul>` : `<p class="kucuk soluk" style="margin:0">${_autoHtml("Mecliste henüz kanun teklifi yok.")}</p>`;
  return `${teklif}<div class="kart"><h3>${_autoHtml("📜 Meclis gündemi ve Resmî Gazete")}</h3>${liste}</div>
    <div class="kart"><h3>${_autoHtml("⚖️ Yürürlükteki oranlar")}</h3><ul class="satirlar">${m.kanunlar.map((k) => `<li><span>${esc(k.ad)}<br><span class="kucuk soluk">${esc(k.aciklama)}</span></span><span class="sag">${k.birim === 'TL' ? tamTl(k.deger) : '%' + k.deger}</span></li>`).join('')}</ul></div>`;
}

function cbMasasi(x) {
  const kanunlar = x.meclis.teklifler.filter((k) => k.durum === 'onay');
  const ihaleler = x.ihaleOnay || [];
  return `<div class="kart basari"><h3>${_autoHtml("🇹🇷 Cumhurbaşkanlığı masası")}</h3>
    <p class="kucuk soluk" style="margin:0 0 6px">${_autoHtml("3 saat içinde karar vermediğin işlere bot karar verir.")}</p>
    <h4>${_autoSablon`Onay bekleyen kanunlar (${kanunlar.length})`}</h4>
    ${kanunlar.length ? `<ul class="satirlar">${kanunlar.map((k) => `<li><span><b>${esc(k.ad)}</b>: ${esc(k.eski)} → ${esc(k.yeni)}<br><span class="kucuk soluk">${_autoSablon`${k.evet} evet, ${k.hayir} hayır · “${esc(k.gerekce || '')}”`}</span></span>
      <span class="dugme-satiri"><button class="dugme yesil kucuk" data-cb-kanun="1" data-id="${k.id}">${_autoHtml("Onayla")}</button><button class="dugme kirmizi kucuk" data-cb-kanun="0" data-id="${k.id}">${_autoHtml("Veto")}</button></span></li>`).join('')}</ul>` : `<p class="kucuk soluk">${_autoHtml("Yok.")}</p>`}
    <h4>${_autoSablon`Onay bekleyen ihaleler (${ihaleler.length})`}</h4>
    ${ihaleler.length ? `<ul class="satirlar">${ihaleler.map((i) => `<li><span><b>${esc(i.baslik)}</b><br><span class="kucuk soluk">${esc(i.kurum)} · ${i.miktar.toLocaleString(sayiDili())} ${esc(i.birim)} × ${tamTl(i.kazananFiyat)} = ${tl(i.miktar * i.kazananFiyat)}</span></span>
      <span class="dugme-satiri"><button class="dugme yesil kucuk" data-cb-ihale="1" data-id="${i.id}">${_autoHtml("Onayla")}</button><button class="dugme kirmizi kucuk" data-cb-ihale="0" data-id="${i.id}">${_autoHtml("İptal")}</button></span></li>`).join('')}</ul>` : `<p class="kucuk soluk">${_autoHtml("Yok.")}</p>`}</div>`;
}

function secimBagla(kutu, x, s) {
  const yenile = () => secimPaneli();
  kutu.querySelectorAll('[data-oy]').forEach((b) => b.addEventListener('click', async () => {
    const a = s.adaylar.find((y) => String(y.id) === b.dataset.oy);
    if (!(await onayla(_autoSablon`${a.ad} adayına oy verilsin mi? Oy değiştirilemez.`, { baslik: _autoMetin('Oyunu kullan'), evet: _autoMetin('Oy ver'), ikon: '🗳️' }))) return;
    if ((await h.eylem(b, () => api('secim/oy', { tur: s.tur, aday: a.id }))) === undefined) return;
    h.ses.satinAl();
    bildir(_autoMetin('Oyun kaydedildi. Sonuçlar göreve başlama günü açıklanır.'));
    yenile();
  }));
  const af = kutu.querySelector('[data-afis]');
  if (af) af.addEventListener('click', () => h.sertifikaGoster({ kod: af.dataset.afis, baslik: _autoSablon`${s.makam} adaylığı`, seviye: h.oyuncu().seviye, kutlama: _autoMetin('📣 Afişini paylaş, destek iste!') }));
  const ad = kutu.querySelector('[data-aday]');
  if (ad) ad.addEventListener('click', async () => {
    const vaat = kutu.querySelector('[name=vaat]').value;
    if (!(await onayla(_autoSablon`${s.makam} adaylığı için ${tamTl(s.adayUcreti)} ödenecek. Onaylıyor musun?`, { baslik: _autoMetin('Aday ol'), evet: _autoMetin('Aday ol'), ikon: '🎤' }))) return;
    const r = await h.eylem(ad, () => api('secim/aday', { tur: s.tur, vaat }));
    if (r === undefined) return;
    h.ses.seviye();
    await h.durumYenile();
    bildir(_autoMetin('Adaylığın açıklandı! Oylama başlayınca adaylar herkese duyurulacak.'));
    yenile();
    if (r.sertifika) h.sertifikaGoster({ kod: r.sertifika, baslik: _autoSablon`${r.makam} adaylığı`, seviye: h.oyuncu().seviye, kutlama: _autoMetin('📣 Adaylık afişin hazır! Paylaş, arkadaşlarından destek iste.') });
  });
  kutu.querySelectorAll('[data-karar]').forEach((b) => b.addEventListener('click', async () => {
    let neden = '';
    if (b.dataset.karar === 'red') {
      neden = await sor(_autoMetin('Ret gerekçen nedir? Başvuru sahibi görecek.'), { baslik: _oyunMetni("ui.76b6d0c35e54"), ipucu: _autoMetin('ör. Tabela adı uygunsuz'), ikon: '❌', uzunluk: 200 });
      if (!neden) return;
    }
    if ((await h.eylem(b, () => api('belediye/karar', { id: Number(b.dataset.id), karar: b.dataset.karar, neden }))) === undefined) return;
    bildir(b.dataset.karar === 'onay' ? _autoMetin('Başvuru onaylandı.') : _autoMetin('Başvuru reddedildi.'));
    yenile();
  }));
  // meclis
  const sec = kutu.querySelector('[name=kanun]');
  if (sec) {
    const ipucu = () => {
      const o = sec.selectedOptions[0];
      const deger = Number(o.dataset.deger);
      const tlMi = o.dataset.birim === 'TL';
      const pay = Math.max(tlMi ? 0 : 1, deger * x.meclis.enCokDegisim);
      kutu.querySelector('[data-kanun-ipucu]').textContent = tlMi ? `(${tamTl(deger - pay)} – ${tamTl(deger + pay)})` : `(%${Math.ceil(deger - pay)} – %${Math.floor(deger + pay)})`;
      kutu.querySelector('[name=deger]').placeholder = tlMi ? _autoSablon`ör. ${Math.round(deger / 100).toLocaleString(sayiDili())}` : _autoSablon`ör. ${deger}`;
    };
    sec.addEventListener('change', ipucu);
    ipucu();
    kutu.querySelector('[data-teklif]').addEventListener('click', async (e) => {
      const o = sec.selectedOptions[0];
      const ham = kutu.querySelector('[name=deger]').value;
      const deger = o.dataset.birim === 'TL' ? tutarOku(ham) : Number(String(ham).replace(',', '.'));
      const gerekce = kutu.querySelector('[name=gerekce]').value;
      if ((await h.eylem(e.currentTarget, () => api('meclis/teklif', { anahtar: sec.value, deger, gerekce }))) === undefined) return;
      bildir(_autoMetin('Teklifin meclis gündemine alındı. Oylama 24 saat sürer.'));
      yenile();
    });
  }
  kutu.querySelectorAll('[data-kanun-oy]').forEach((b) => b.addEventListener('click', async () => {
    if ((await h.eylem(b, () => api('meclis/oy', { id: Number(b.dataset.id), oy: b.dataset.kanunOy }))) === undefined) return;
    bildir(_autoMetin('Oyun kaydedildi.'));
    yenile();
  }));
  kutu.querySelectorAll('[data-cb-kanun]').forEach((b) => b.addEventListener('click', async () => {
    const onay = b.dataset.cbKanun === '1';
    let gerekce = '';
    if (!onay) { gerekce = await sor(_autoMetin('Veto gerekçen nedir? Meclis görecek.'), { baslik: _autoMetin('Kanunu veto et'), ikon: '⛔', uzunluk: 300 }); if (!gerekce) return; }
    if ((await h.eylem(b, () => api('meclis/karar', { id: Number(b.dataset.id), onay, gerekce }))) === undefined) return;
    bildir(onay ? _autoMetin('Kanun onaylandı, yürürlüğe girdi.') : _autoMetin('Kanun veto edildi.'));
    yenile();
  }));
  kutu.querySelectorAll('[data-cb-ihale]').forEach((b) => b.addEventListener('click', async () => {
    const onay = b.dataset.cbIhale === '1';
    if (!onay && !(await onayla(_autoMetin('İhale iptal edilsin mi? Kazananın teminatı iade edilir.'), { baslik: _oyunMetni("ui.876b5db3fe0a"), evet: _autoMetin('İptal et'), tehlike: true, ikon: '📑' }))) return;
    if ((await h.eylem(b, () => api(`ihale/${b.dataset.id}/karar`, { onay }))) === undefined) return;
    bildir(onay ? _autoMetin('İhale onaylandı.') : _autoMetin('İhale iptal edildi.'));
    yenile();
  }));
}

// ====================================================================== Kamu ihaleleri
const IHALE_TUR = { mal: ['📦', 'Mal alımı'], makine: ['🚜', 'İş makinesi'], yapim: ['🚧', 'Yapım işi'], sevkiyat: ['🚛', 'Sevkiyat (tır)'] };
let ihaleFiltre = 'hepsi';
const IHALE_DURUM = { acik: ['Teklif alınıyor', 'bilgi'], onay: ['Onay bekliyor', 'altin'], teslim: ['Teslimat', 'bilgi'], tamam: ['Tamamlandı', 'iyi'], fesih: ['Feshedildi', 'kotu'], iptal: ['İptal', 'kotu'] };
export async function ihalePaneli() {
  const p = h.panelAc({ ikon: '📑', baslik: _oyunMetni("ui.2351832c9db4"), rota: 'ihale', alt: _autoMetin('Devlete mal, iş makinesi, yapım işi ve tır sevkiyatı: kapalı zarf, en düşük teklif kazanır'), govde: yukleniyor() });
  const kutu = p.querySelector('.panel-govde');
  let x;
  try { x = await api('ihale'); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'ihale')) return;
  const benim = x.ihaleler.filter((i) => i.benimMi && ['teslim', 'onay'].includes(i.durum));
  const acikHepsi = x.ihaleler.filter((i) => i.durum === 'acik');
  const acik = acikHepsi.filter((i) => ihaleFiltre === 'hepsi' || i.tur === ihaleFiltre);
  const diger = x.ihaleler.filter((i) => !benim.includes(i) && i.durum !== 'acik');
  for (const i of x.ihaleler) { i.urunAd = _urunAdi(i.urunAd); i.birim = _birimAdi(i.birim); }
  const kart = (i) => {
    const [dAd, dTur] = IHALE_DURUM[i.durum] || [i.durum, ''];
    const toplam = i.miktar * (i.kazananFiyat || i.tavan);
    let alt = '';
    if (i.durum === 'acik') {
      alt = i.teklifim ? `<p class="kucuk">${_autoSablon`Teklifin: <b>${tamTl(i.teklifim.fiyat)}</b> / ${esc(i.birim)} · teminat ${tl(i.teklifim.teminat)} (kapalı zarf)`}</p>`
        : `<div class="ihale-teklif"><label class="alan"><span>${_autoSablon`Birim fiyatın (₺ / ${esc(i.birim)})`}</span><input name="fiyat-${i.id}" inputmode="decimal" placeholder="${_autoSablon`en çok ${kurusYaz(i.tavan)}`}"></label>
          <button class="dugme mavi kucuk" data-ihale-teklif="${i.id}">${_autoHtml("Teklif ver")}</button></div><p class="kucuk soluk" data-teminat="${i.id}">${_autoSablon`Teklifle birlikte toplam tutarın %${Math.round(x.teminatOrani * 100)}'u geçici teminat alınır.`}</p>`;
    } else if (i.benimMi && i.durum === 'teslim' && i.tur === 'sevkiyat') {
      // 0.49: tır seferleri
      const yolda = (i.seferler || []).filter((x) => x.durum === 'yolda');
      const yoldaTon = yolda.reduce((t, x) => t + x.ton, 0);
      const kalan = i.miktar - i.teslimEdilen - yoldaTon;
      const oran = i.teslimEdilen / i.miktar;
      alt = `<div class="cubuk"><div style="width:${Math.round(oran * 100)}%"></div><div class="yolda" style="width:${Math.round((yoldaTon / i.miktar) * 100)}%"></div></div>
        <p class="kucuk">${_autoSablon`${i.teslimEdilen.toLocaleString(sayiDili())} / ${i.miktar.toLocaleString(sayiDili())} ton teslim edildi · ${yoldaTon.toLocaleString(sayiDili())} ton yolda · son gün <b>${tarihSaat(i.teslimBitis)}</b>`}</p>
        ${yolda.length ? `<ul class="sefer-listesi">${yolda.map((x) => `<li><span class="sefer-tir">${'🚛'.repeat(Math.min(6, x.tir))}${x.tir > 6 ? `×${x.tir}` : ''}</span><span>${_autoSablon`${x.ton.toLocaleString(sayiDili())} ton`}</span><span class="sefer-yol"><i style="--bas:${x.basla};--bit:${x.bitis};width:${Math.min(100, Math.round(((simdi() - x.basla) / (x.bitis - x.basla)) * 100))}%" data-sefer-bas="${x.basla}" data-sefer-bit="${x.bitis}"></i></span><b data-geri="${x.bitis}">${sureMetni(x.bitis - simdi())}</b></li>`).join('')}</ul>` : ''}
        ${kalan > 0 ? `<button class="dugme yesil kucuk" data-ihale-teslim="${i.id}" ${x.filo && x.filo.bos > 0 ? '' : 'disabled'}>🚛 ${_autoSablon`Sefer başlat (${Math.min(x.filo ? x.filo.bos : 0, Math.ceil(kalan / x.tirTon))} tır)`}</button>
          <p class="kucuk soluk">${x.filo && x.filo.bos > 0 ? _autoSablon`Boşta ${x.filo.bos} tırın var · tır başına ${x.tirTon} ton · yakıt tır başına ~${i.yakitLt.toLocaleString(sayiDili())} L (önce ambardan)` : _autoHtml('Bütün tırların yolda. Biri dönünce yeni sefer başlatabilirsin.')}</p>` : ''}`;
    } else if (i.benimMi && i.durum === 'teslim') {
      const oran = i.teslimEdilen / i.miktar;
      alt = `<div class="cubuk"><div style="width:${Math.round(oran * 100)}%"></div></div>
        <p class="kucuk">${_autoSablon`${i.teslimEdilen.toLocaleString(sayiDili())} / ${i.miktar.toLocaleString(sayiDili())} ${esc(i.birim)} teslim edildi · son gün <b>${tarihSaat(i.teslimBitis)}</b> (`}<span data-geri="${i.teslimBitis}">${sureMetni(i.teslimBitis - simdi())}</span>)</p>
        <button class="dugme yesil kucuk" data-ihale-teslim="${i.id}">📦 ${_autoHtml("Ambardan teslim et")}</button>`;
    } else if (i.benimMi && i.durum === 'onay') alt = `<p class="kucuk">${_autoHtml("🏆 En düşük teklif senin! Cumhurbaşkanı onayı bekleniyor.")}</p>`;
    const [tSimge, tAd] = IHALE_TUR[i.tur] || IHALE_TUR.mal;
    const yapimNotu = i.tur === 'yapim' && i.durum === 'acik' ? `<p class="kucuk soluk" style="margin:0 0 6px">${i.urun === 'okul' || i.urun === 'konut' ? _autoHtml('🏗️ İnşaat şirketi tesisinde yapılır (okul için ambarında mobil vinç olmalı).') : _autoHtml('🚧 Yol ve altyapı müteahhitliği tesisinde yapılır; iş makineleri ambarında olmalı.')}</p>` : '';
    return `<li class="kart ihale-kart"><div class="ihale-ust"><div><b>${esc(i.baslik)}</b><br><span class="kucuk soluk">${tSimge} ${_autoHtml(tAd)} · ${esc(i.kurum)}</span></div><span class="rozetcik ${dTur}">${_autoHtml(dAd)}</span></div>
      ${i.tur === 'sevkiyat' ? `<div class="sevkiyat-rota"><b>${esc(i.cikisIl || '')}</b><span class="rota-cizgi">🚛</span><b>${esc(i.varisIl || '')}</b><small>${_autoSablon`${i.mesafe.toLocaleString(sayiDili())} km · sefer ~${gercekSureAdi(i.seferSure)}`}</small></div>` : ''}
      <div class="bilgi-izgara"><div><small>${i.tur === 'sevkiyat' ? _autoHtml('Yük') : _autoHtml("Ürün")}</small><b>${i.miktar.toLocaleString(sayiDili())} ${esc(i.birim)} ${esc(i.urunAd)}</b></div><div><small>${i.kazananFiyat ? _autoHtml('Kazanan fiyat') : _autoHtml('Yaklaşık maliyet (tavan)')}</small><b>${tamTl(i.kazananFiyat || i.tavan)} <small>/ ${esc(i.birim)}</small></b></div>
        <div><small>${_autoHtml("Toplam")}</small><b>${tl(toplam)}</b></div><div><small>${i.durum === 'acik' ? _autoHtml('Kapanışa') : _autoHtml('Teslim süresi')}</small><b>${i.durum === 'acik' ? `<span data-geri="${i.kapanis}">${sureMetni(i.kapanis - simdi())}</span>` : i.teslimGun + _autoHtml(' gün')}</b></div></div>
      ${i.durum === 'acik' ? `<p class="kucuk soluk" style="margin:0 0 6px">${_autoSablon`${i.teklifSayisi} teklif verildi · teslim süresi ${i.teslimGun} gün`}</p>` : ''}${yapimNotu}${i.belediye && ['acik', 'onay', 'teslim'].includes(i.durum) ? `<p class="kucuk soluk" style="margin:0 0 6px">${_autoHtml('🏛️ Bedeli il belediyesinin kasasından ödenir.')}</p>` : ''}${alt}</li>`;
  };
  kutu.innerHTML = `
    ${x.filo && x.filo.firma ? `<div class="kart filo-ozet"><span>🚛</span><div><b>${_autoSablon`Filon: ${x.filo.toplam} tır`}</b><small>${_autoSablon`${x.filo.bos} boşta · ${x.filo.yolda} yolda`}</small></div></div>` : ''}
    ${benim.length ? `<h3>${_autoHtml("🏆 Kazandığın ihaleler")}</h3><ul class="ihale-listesi">${benim.map(kart).join('')}</ul>` : ''}
    <h3>${_autoSablon`📂 Teklif alınan ihaleler (${acikHepsi.length})`}</h3>
    <div class="cipler">${[['hepsi', '📑', 'Tümü'], ...Object.entries(IHALE_TUR).map(([k, [sm, ad]]) => [k, sm, ad])].map(([k, sm, ad]) => `<button class="cip ${k === ihaleFiltre ? 'secili' : ''}" data-ihale-filtre="${k}">${sm} ${_autoHtml(ad)}${k !== 'hepsi' ? ` (${acikHepsi.filter((i) => i.tur === k).length})` : ''}</button>`).join('')}</div>
    ${acik.length ? `<ul class="ihale-listesi">${acik.map(kart).join('')}</ul>` : `<div class="kart"><p class="kucuk soluk" style="margin:0">${_autoHtml("Şu an açık ihale yok. Devlet birkaç saatte bir yeni ihaleye çıkar.")}</p></div>`}
    ${diger.length ? `<details class="kart"><summary><b>${_autoHtml("Geçmiş ve sonuçlanan ihaleler")}</b></summary><ul class="ihale-listesi">${diger.map(kart).join('')}</ul></details>` : ''}
    <div class="kart"><h3>${_autoHtml("ℹ️ Kurallar")}</h3><ul class="kural-listesi">
      <li>${_autoSablon`📑 En az ${x.seviye}. seviye oyuncular teklif verebilir. Teklifler kapalı zarftır, değiştirilemez.`}</li>
      <li>${_autoSablon`💰 Teklifle birlikte toplam tutarın %${Math.round(x.teminatOrani * 100)}'u geçici teminat alınır; kaybedenlere hemen iade edilir.`}</li>
      <li>${_autoHtml("🏆 En düşük birim fiyat kazanır. Sonuç cumhurbaşkanının onayına gider; 3 saatte bakmazsa bot onaylar.")}</li>
      <li>${_autoHtml("📦 Kazanan malı süresi içinde ambarından (parça parça da olur) teslim eder, her teslimde bedelini alır. İş bitince teminat iade edilir.")}</li>
      <li>${_autoHtml("⛔ Süresinde teslim edilmezse sözleşme feshedilir, teminat hazineye gelir kaydedilir.")}</li>
      <li>${_autoHtml("🚜 Belediyeler, Karayolları, DSİ ve AFAD iş makinesi ve araç alır: İş makinesi fabrikası kurup üretebilirsin.")}</li>
      <li>${_autoHtml("🏛️ Belediye ihalelerinin bedeli il belediyesinin kasasından ödenir. Kasa yetmezse ihale iptal edilir ve teminat iade edilir; teslim edilmeyen işin teminatı belediye kasasına geçer.")}</li>
      <li>${_autoHtml("🚧 Yol, kaldırım, sulama kanalı ve okul gibi yapım işlerini müteahhitler yapar. Bu işler pazarda alınıp satılmaz; yalnızca devlete teslim edilir.")}</li>
      <li>${_autoSablon`🚛 Sevkiyat ihalelerinde devlet kendi yükünü bir ilden başka bir ile taşıtır; fiyat ton başınadır. Teklif için nakliye firman olmalı. Tır başına ${x.tirTon} ton taşınır, her sefer varınca ödenir; yakıt önce ambardan kullanılır.`}</li></ul></div>`;
  kutu.querySelectorAll('[data-ihale-filtre]').forEach((b) => b.addEventListener('click', () => { ihaleFiltre = b.dataset.ihaleFiltre; h.ses.tik(); ihalePaneli(); }));
  kutu.querySelectorAll('[data-ihale-teklif]').forEach((b) => b.addEventListener('click', async () => {
    const i = x.ihaleler.find((y) => String(y.id) === b.dataset.ihaleTeklif);
    const fiyat = tutarOku(kutu.querySelector(`[name=fiyat-${i.id}]`).value);
    if (!fiyat) return bildir(_autoMetin('Birim fiyatını yaz.'), true);
    const teminat = Math.round(fiyat * i.miktar * x.teminatOrani);
    if (!(await onayla(_autoSablon`${i.baslik}\n\nBirim fiyat: ${tamTl(fiyat)}\nToplam: ${tamTl(fiyat * i.miktar)}\nGeçici teminat: ${tamTl(teminat)}\n\nTeklif kapalı zarftır, değiştirilemez.`, { baslik: _oyunMetni("ui.250959a43e02"), evet: _autoMetin('Teklifi ver'), ikon: '📑' }))) return;
    if ((await h.eylem(b, () => api(`ihale/${i.id}/teklif`, { fiyat }))) === undefined) return;
    h.ses.satinAl();
    bildir(_autoMetin('Teklifin zarfa kondu. İhale kapanınca sonuç bildirilir.'));
    await h.durumYenile();
    ihalePaneli();
  }));
  kutu.querySelectorAll('[data-ihale-teslim]').forEach((b) => b.addEventListener('click', async () => {
    const r = await h.eylem(b, () => api(`ihale/${b.dataset.ihaleTeslim}/teslim`, {}));
    if (r === undefined) return;
    h.ses.kasa();
    if (r.sefer) bildir(_autoSablon`${r.sefer.tir} tır ${r.sefer.ton.toLocaleString(sayiDili())} ton yükle yola çıktı. Varış: ${gercekSureAdi(r.sefer.bitis - simdi())}`);
    else bildir(r.bitti ? _autoSablon`Teslimat tamamlandı! ${tl(r.tutar)} ödendi, teminatın iade edildi.` : _autoSablon`${r.verilen.toLocaleString(sayiDili())} birim teslim edildi, ${tl(r.tutar)} ödendi.`);
    await h.durumYenile();
    ihalePaneli();
  }));
  h.zamanlayici(() => {
    if (!hala(kutu, 'ihale')) return;
    kutu.querySelectorAll('[data-geri]').forEach((el) => { el.textContent = sureMetni(Math.max(0, Number(el.dataset.geri) - simdi())); });
    kutu.querySelectorAll('[data-sefer-bas]').forEach((el) => { const a = Number(el.dataset.seferBas), b = Number(el.dataset.seferBit); el.style.width = Math.min(100, Math.round(((simdi() - a) / (b - a)) * 100)) + '%'; });
  }, 1000);
}

// ====================================================================== Borsa
let borsaSekme = 'piyasa';
let borsaHisse = null;
export async function borsaPaneli(sekme, hisse) {
  if (sekme) borsaSekme = sekme;
  if (hisse !== undefined) borsaHisse = hisse;
  const p = h.panelAc({
    ikon: '📈', baslik: _oyunMetni("ui.7dac429c2c59"), rota: 'borsa', alt: _autoMetin('Şirketlerin hisselerini al, sat, halka arz ol'),
    govde: `${sekmeler([['piyasa', '📊', 'Piyasa'], ['portfoy', '💼', _autoMetin('Portföyüm')], ['sirket', '🏢', _autoMetin('Şirketim')]], borsaSekme)}<div id="borsa-icerik">${yukleniyor()}</div>`,
  });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); borsaPaneli(b.dataset.sekme, null); }));
  const kutu = p.querySelector('#borsa-icerik');
  try {
    if (borsaSekme === 'piyasa' && borsaHisse) return hisseCiz(kutu, await api('borsa/hisse/' + encodeURIComponent(borsaHisse)));
    const x = await api('borsa');
    if (!hala(kutu, 'borsa')) return;
    if (borsaSekme === 'piyasa') piyasaCiz(kutu, x);
    else if (borsaSekme === 'portfoy') portfoyCiz(kutu, x);
    else sirketCiz(kutu, x);
  } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; }
}
const degisim = (x) => `<span class="${x > 0 ? 'arti' : x < 0 ? 'eksi' : 'soluk'}">${x > 0 ? '▲' : x < 0 ? '▼' : '•'} %${Math.abs(x * 100).toLocaleString(sayiDili(), { maximumFractionDigits: 2 })}</span>`;
function piyasaCiz(kutu, x) {
  kutu.innerHTML = x.hisseler.length ? `<ul class="hisse-listesi">${x.hisseler.map((s) => `<li><button data-hisse="${s.kod}">
      <span class="hisse-kod">${esc(s.kod)}</span><span class="hisse-ad"><b>${esc(s.ad)}</b><small>${_autoSablon`${esc(s.sahip)} · piyasa değeri ${tl(s.piyasaDegeri)}`}</small></span>
      <span class="hisse-fiyat"><b>${kurusYaz(s.fiyat)} ₺</b>${degisim(s.degisim)}</span></button></li>`).join('')}</ul>
      <p class="kucuk soluk">${_autoHtml("Fiyatlar lot başınadır. Günlük fiyat sınırı önceki kapanışın ±%20'si.")}</p>`
    : `<div class="kart"><h3>${_autoHtml("Borsa henüz boş")}</h3><p class="kucuk">${_autoSablon`Anonim şirketler ve holdingler halka arz olabilir. İlk halka arzı sen yap: <b>${_autoHtml("Şirketim")}</b> sekmesine bak.`}</p></div>`;
  kutu.querySelectorAll('[data-hisse]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); borsaPaneli('piyasa', b.dataset.hisse); }));
}
function cizgiGrafik(nokta, gen = 320, yuk = 90) {
  if (nokta.length < 2) return `<p class="kucuk soluk">${_autoHtml("Grafik için birkaç günlük işlem gerekiyor.")}</p>`;
  const min = Math.min(...nokta), max = Math.max(...nokta);
  const y = (v) => yuk - 6 - ((v - min) / Math.max(1, max - min)) * (yuk - 12);
  const d = nokta.map((v, i) => `${i ? 'L' : 'M'}${((i / (nokta.length - 1)) * gen).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const renk = nokta[nokta.length - 1] >= nokta[0] ? '#1FA25A' : '#D64545';
  return `<svg class="hisse-grafik" viewBox="0 0 ${gen} ${yuk}" preserveAspectRatio="none"><path d="${d} L${gen},${yuk} L0,${yuk} Z" fill="${renk}" opacity=".12"/><path d="${d}" fill="none" stroke="${renk}" stroke-width="2.2" vector-effect="non-scaling-stroke"/></svg>`;
}
function hisseCiz(kutu, s) {
  if (!hala(kutu, 'borsa')) return;
  const derinlik = (l, yon) => l.length ? l.map((o) => `<li class="${yon}"><span>${kurusYaz(o.fiyat)} ₺</span><span>${_autoSablon`${o.lot.toLocaleString(sayiDili())} lot`}</span></li>`).join('') : `<li class="soluk">${_autoHtml("Emir yok")}</li>`;
  kutu.innerHTML = `<button class="metin-dugme" data-geri-don>← ${_autoHtml("Tüm hisseler")}</button>
    <div class="kart"><div class="hisse-baslik"><span class="hisse-kod buyuk">${esc(s.kod)}</span><div><b>${esc(s.ad)}</b><br><small class="soluk">${esc(s.tur)} · ${esc(s.sahip)}</small></div>
      <div class="sag"><b class="buyuk-sayi">${kurusYaz(s.fiyat)} ₺</b><br>${degisim(s.onceki ? (s.fiyat - s.onceki) / s.onceki : 0)}</div></div>
      ${cizgiGrafik(s.gunluk.map((g) => g.kapanis))}
      <div class="bilgi-izgara"><div><small>${_autoHtml("Defter değeri")}</small><b>${kurusYaz(s.defterDegeri)} ₺</b></div><div><small>${_autoHtml("Piyasa değeri")}</small><b>${tl(s.fiyat * s.lot)}</b></div>
        <div><small>${_autoHtml("Taban / tavan")}</small><b>${kurusYaz(s.taban)} / ${kurusYaz(s.tavan)}</b></div><div><small>${_autoHtml("Dağıtılan temettü")}</small><b>${tl(s.temettu)}</b></div></div></div>
    <div class="kart"><h3>${_autoHtml("Emir ver")}</h3>
      <div class="sekmeler kucuk-sekme"><button data-yon="al" aria-selected="true">🟢 ${_autoHtml("Al")}</button><button data-yon="sat" aria-selected="false">🔴 ${_oyunHtml("ui.fdeb71b569e0")}</button></div>
      <div class="iki-alan"><label class="alan"><span>${_autoHtml("Lot")}</span><input name="lot" inputmode="numeric" value="100"></label>
        <label class="alan"><span>${_autoHtml("Fiyat (₺)")}</span><input name="fiyat" inputmode="decimal" value="${kurusYaz(s.fiyat)}"></label></div>
      <p class="kucuk" data-emir-ozet></p>
      <button class="dugme yesil" data-emir>${_autoHtml("Alış emri ver")}</button></div>
    <div class="kart"><h3>${_autoHtml("Emir defteri")}</h3><div class="emir-defteri"><ul><li class="baslik"><span>${_autoHtml("Alış")}</span><span></span></li>${derinlik(s.alis, 'al')}</ul><ul><li class="baslik"><span>${_autoHtml("Satış")}</span><span></span></li>${derinlik(s.satis, 'sat')}</ul></div></div>
    <div class="kart"><h3>${_autoHtml("Son işlemler")}</h3>${s.islemler.length ? `<ul class="satirlar">${s.islemler.map((i) => `<li><span class="kucuk soluk">${tarihSaat(i.zaman)}</span><span>${_autoSablon`${i.lot.toLocaleString(sayiDili())} lot`}</span><span class="sag">${kurusYaz(i.fiyat)} ₺</span></li>`).join('')}</ul>` : `<p class="kucuk soluk" style="margin:0">${_autoHtml("Henüz işlem yok.")}</p>`}</div>`;
  kutu.querySelector('[data-geri-don]').addEventListener('click', () => borsaPaneli('piyasa', null));
  let yon = 'al';
  const ozet = () => {
    const lot = Math.floor(Number(kutu.querySelector('[name=lot]').value) || 0);
    const fiyat = tutarOku(kutu.querySelector('[name=fiyat]').value);
    const t = lot * fiyat;
    kutu.querySelector('[data-emir-ozet]').textContent = t ? `Tutar ${tamTl(t)} · komisyon ${tamTl(Math.round(t * 0.002))}` : '';
  };
  kutu.querySelectorAll('[data-yon]').forEach((b) => b.addEventListener('click', () => {
    yon = b.dataset.yon;
    kutu.querySelectorAll('[data-yon]').forEach((c) => c.setAttribute('aria-selected', String(c === b)));
    const e = kutu.querySelector('[data-emir]');
    e.textContent = yon === 'al' ? _autoMetin('Alış emri ver') : _autoMetin('Satış emri ver');
    e.classList.toggle('yesil', yon === 'al'); e.classList.toggle('kirmizi', yon === 'sat');
  }));
  kutu.querySelectorAll('[name=lot], [name=fiyat]').forEach((i) => i.addEventListener('input', ozet));
  ozet();
  kutu.querySelector('[data-emir]').addEventListener('click', async (e) => {
    const lot = Math.floor(Number(kutu.querySelector('[name=lot]').value) || 0);
    const fiyat = tutarOku(kutu.querySelector('[name=fiyat]').value);
    const r = await h.eylem(e.currentTarget, () => api('borsa/emir', { kod: s.kod, yon, lot, fiyat }));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(r.islemler ? _autoSablon`Emrin ${r.islemler} işlemle (kısmen ya da tamamen) gerçekleşti.` : _autoMetin('Emrin tahtaya kondu; karşı emir gelince gerçekleşir.'));
    await h.durumYenile();
    hisseCiz(kutu, await api('borsa/hisse/' + encodeURIComponent(s.kod)));
  });
}
function portfoyCiz(kutu, x) {
  const toplam = x.portfoy.reduce((t, p) => t + p.deger, 0);
  const maliyet = x.portfoy.reduce((t, p) => t + p.maliyet, 0);
  kutu.innerHTML = `<div class="bilgi-izgara"><div><small>${_autoHtml("Portföy değeri")}</small><b>${tl(toplam)}</b></div><div><small>${_autoHtml("Kâr / zarar")}</small><b class="${toplam - maliyet >= 0 ? 'arti' : 'eksi'}">${tl(toplam - maliyet)}</b></div></div>
    <div class="kart"><h3>${_autoHtml("Hisselerim")}</h3>${x.portfoy.length ? `<ul class="satirlar">${x.portfoy.map((p) => `<li><span>${_autoSablon`<b>${esc(p.kod)}</b> · ${p.lot.toLocaleString(sayiDili())} lot<br>`}<span class="kucuk soluk">${_autoSablon`maliyet ${tl(p.maliyet)}`}</span></span><span class="sag">${tl(p.deger)}<br><button class="metin-dugme" data-hisse="${esc(p.kod)}">${_autoHtml("Al / sat")}</button></span></li>`).join('')}</ul>` : `<p class="kucuk soluk" style="margin:0">${_autoHtml("Henüz hissen yok.")}</p>`}</div>
    <div class="kart"><h3>${_autoHtml("Açık emirlerim")}</h3>${x.emirler.length ? `<ul class="satirlar">${x.emirler.map((e) => `<li><span><b>${esc(e.kod)}</b> ${e.yon === 'al' ? _autoHtml('🟢 Alış') : _autoHtml('🔴 Satış')}<br><span class="kucuk soluk">${_autoSablon`${e.kalan.toLocaleString(sayiDili())} / ${e.lot.toLocaleString(sayiDili())} lot × ${kurusYaz(e.fiyat)} ₺`}</span></span><button class="dugme kucuk" data-iptal="${e.id}">${_autoHtml("İptal")}</button></li>`).join('')}</ul>` : `<p class="kucuk soluk" style="margin:0">${_autoHtml("Açık emrin yok. Bir haftadan eski emirler kendiliğinden iptal edilir.")}</p>`}</div>`;
  kutu.querySelectorAll('[data-hisse]').forEach((b) => b.addEventListener('click', () => borsaPaneli('piyasa', b.dataset.hisse)));
  kutu.querySelectorAll('[data-iptal]').forEach((b) => b.addEventListener('click', async () => {
    if ((await h.eylem(b, () => api(`borsa/emir/${b.dataset.iptal}/iptal`, {}))) === undefined) return;
    bildir(_autoMetin('Emir iptal edildi, emanet iade edildi.'));
    await h.durumYenile();
    borsaPaneli('portfoy');
  }));
}
function sirketCiz(kutu, x) {
  if (x.sirketim) {
    kutu.innerHTML = `<div class="kart basari"><h3>${_autoSablon`🏢 Şirketin borsada: ${esc(x.sirketim)}`}</h3>
      <button class="dugme" data-hisse="${esc(x.sirketim)}">📊 ${_autoHtml("Hisse sayfasını aç")}</button></div>
      <div class="kart"><h3>💸 ${_autoHtml("Temettü dağıt")}</h3><p class="kucuk">${_autoHtml("Belirlediğin tutar tüm hissedarlara lotları oranında paylaştırılır (senin payın sende kalır). Temettü, hisseye olan güveni artırır.")}</p>
        <label class="alan"><span>${_autoHtml("Toplam temettü (₺)")}</span><input name="temettu" inputmode="decimal" placeholder="${_autoHtml("ör. 100.000")}"></label>
        <button class="dugme yesil" data-temettu>${_autoHtml("Temettü dağıt")}</button></div>`;
    kutu.querySelector('[data-hisse]').addEventListener('click', () => borsaPaneli('piyasa', x.sirketim));
    kutu.querySelector('[data-temettu]').addEventListener('click', async (e) => {
      const tutar = tutarOku(kutu.querySelector('[name=temettu]').value);
      if (!(await onayla(_autoSablon`${tamTl(tutar)} temettü dağıtılsın mı? (Dışarıdaki hissedarların payı hesabından çıkar.)`, { baslik: _oyunMetni("ui.cfb2ac1ae58c"), evet: _autoMetin('Dağıt'), ikon: '💸' }))) return;
      const r = await h.eylem(e.currentTarget, () => api('borsa/temettu', { tutar }));
      if (r === undefined) return;
      bildir(_autoSablon`Hissedarlara ${tl(r.dagitilan)} temettü ödendi.`);
      await h.durumYenile();
    });
    return;
  }
  if (!x.arzEdebilir) {
    kutu.innerHTML = `<div class="kart"><h3>${_autoHtml("Halka arz")}</h3><p class="kucuk">${_autoSablon`Şirketini borsaya açmak için <b>anonim şirket</b> ${_autoHtml("ya da")} <b>holding</b> olmalısın. Şirketleşme için Hesabım &gt; Şirket bölümüne bak.`}</p>
      <ul class="kural-listesi"><li>${_autoSablon`📈 Halka arzda şirketinin %${x.arzAraligi[0]}–%${x.arzAraligi[1]}'ini satışa çıkarır, parayı hemen alırsın.`}</li><li>${_autoHtml("🏢 Yönetim her zaman sende kalır (en az %51).")}</li><li>${_autoHtml("💸 İstersen temettü dağıtıp hissedarlarını ödüllendirirsin.")}</li></ul></div>`;
    return;
  }
  kutu.innerHTML = `<div class="kart vurgu"><h3>🔔 ${_autoHtml("Halka arz ol")}</h3>
    <p class="kucuk">${_autoSablon`Şirketinin toplam ${x.lot.toLocaleString(sayiDili())} lotu var. Defter değeri lot başına <b>${kurusYaz(x.defterDegeri)} ₺</b> (servetin / lot sayısı).`}</p>
    <label class="alan"><span>${_autoHtml("Hisse kodu (3–5 harf)")}</span><input name="kod" maxlength="5" placeholder="${_autoHtml("ör. CIRAK")}" style="text-transform:uppercase"></label>
    <label class="alan"><span>${_autoMetin("Halka arz oranı: <b data-oran-yaz>%20</b>")}</span><input type="range" name="oran" min="${x.arzAraligi[0]}" max="${x.arzAraligi[1]}" value="20"></label>
    <label class="alan"><span>${_autoHtml("Arz fiyatı (₺ / lot)")}</span><input name="fiyat" inputmode="decimal" value="${kurusYaz(x.defterDegeri)}"></label>
    <p class="kucuk" data-arz-ozet></p>
    <button class="dugme yesil" data-arz>${_autoHtml("Halka arz et")}</button>
    <p class="kucuk soluk">${_autoHtml("Arz fiyatı defter değerinin yarısı ile iki katı arasında olmalı. Arz tutarının %1'i kurul ücretidir (hazineye). Satılmayan lotlar tahtada kalır, istediğin zaman geri çekebilirsin.")}</p></div>`;
  const ozet = () => {
    const oran = Number(kutu.querySelector('[name=oran]').value);
    kutu.querySelector('[data-oran-yaz]').textContent = '%' + oran;
    const fiyat = tutarOku(kutu.querySelector('[name=fiyat]').value);
    const lot = Math.round((x.lot * oran) / 100);
    kutu.querySelector('[data-arz-ozet]').innerHTML = `${_autoSablon`${lot.toLocaleString(sayiDili())} lot satışa çıkar · tamamı satılırsa <b>${tamTl(lot * fiyat)}</b>`}`;
  };
  kutu.querySelectorAll('[name=oran], [name=fiyat]').forEach((i) => i.addEventListener('input', ozet));
  ozet();
  kutu.querySelector('[data-arz]').addEventListener('click', async (e) => {
    const veri = { kod: kutu.querySelector('[name=kod]').value, oran: Number(kutu.querySelector('[name=oran]').value), fiyat: tutarOku(kutu.querySelector('[name=fiyat]').value) };
    if (!(await onayla(_autoSablon`${veri.kod.toUpperCase()} kodla şirketinin %${veri.oran}'i halka arz edilsin mi?`, { baslik: _autoMetin('Halka arz'), evet: _autoMetin('Halka arz et'), ikon: '🔔' }))) return;
    const r = await h.eylem(e.currentTarget, () => api('borsa/arz', veri));
    if (r === undefined) return;
    h.ses.seviye();
    bildir(_autoSablon`${r.kod} borsada! ${r.arzLot.toLocaleString(sayiDili())} lot satışta.`);
    await h.durumYenile();
    borsaPaneli('piyasa', r.kod);
  });
}

// ====================================================================== Sigorta, reklam, ortaklık (Şirketler)
let isSekme = 'reklam';
export async function isDunyasiPaneli(sekme) {
  if (sekme) isSekme = sekme;
  const rota = h.aktifRota();
  const p = h.panelAc({
    ikon: '🤝', baslik: _oyunMetni("ui.6d33f6a5aafa"), rota, alt: _autoMetin('Reklam, sigorta ve ortaklıklar'),
    govde: `${sekmeler([['reklam', '📣', _autoMetin('Reklam')], ['sigorta', '🛡️', _autoMetin('Sigorta')], ['ortaklik', '🤝', _autoMetin('Ortaklık')]], isSekme)}<div id="is-icerik">${yukleniyor()}</div>`,
  });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); isDunyasiPaneli(b.dataset.sekme); }));
  const kutu = p.querySelector('#is-icerik');
  try {
    if (isSekme === 'reklam') reklamCiz(kutu, await api('reklam'), rota);
    else if (isSekme === 'sigorta') sigortaCiz(kutu, await api('sigorta'), rota);
    else ortaklikCiz(kutu, await api('ortaklik'), rota);
  } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; }
}

function reklamCiz(kutu, x, rota) {
  if (!hala(kutu, rota)) return;
  const kat = { kucuk: 1, orta: 1.6, buyuk: 2.5 };
  kutu.innerHTML = `
    <div class="kart"><h3>${_autoHtml("📣 Dükkânına reklam ver")}</h3>
      ${x.dukkanlarim.length ? `
      <label class="alan"><span>${_autoHtml("Dükkân")}</span><select name="dukkan">${x.dukkanlarim.map((d) => `<option value="${d.id}" data-kat="${d.kat}">${esc(d.ad)} (${d.boyut === 'kucuk' ? _autoHtml('küçük') : d.boyut === 'orta' ? 'orta' : _autoHtml('büyük')})</option>`).join('')}</select></label>
      <label class="alan"><span>${_autoHtml("Ajans")}</span><select name="ajans">${x.ajanslar.map((a) => `<option value="${a.id}" data-fiyat="${a.gunlukFiyat}">${_autoSablon`${esc(a.ad)} · %${Math.round(a.etki * 100)} daha çok müşteri · ${tl(a.gunlukFiyat)}/gün${a.sistem ? '' : ` (${esc(a.sahip)})`}`}</option>`).join('')}</select></label>
      <label class="alan"><span>${_autoMetin("Süre: <b data-gun-yaz>3 gün</b>")}</span><input type="range" name="gun" min="1" max="30" value="3"></label>
      <p class="kucuk" data-reklam-ozet></p>
      <button class="dugme yesil" data-kampanya>${_autoHtml("Kampanyayı başlat")}</button>
      <p class="kucuk soluk">${_autoHtml("Kampanya süresince dükkânına daha çok müşteri gelir ve mahalledeki reklam panosunda dükkânının adı döner. Fiyat küçük dükkân içindir; orta dükkânda 1,6, büyükte 2,5 katı.")}</p>`
      : `<p class="kucuk soluk" style="margin:0">${_autoHtml("Reklam vermek için önce bir dükkân aç.")}</p>`}</div>
    ${x.kampanyalarim.length ? `<div class="kart"><h3>${_autoHtml("Süren kampanyalarım")}</h3><ul class="satirlar">${x.kampanyalarim.map((k) => `<li><span><b>${esc(k.dukkan)}</b><br><span class="kucuk soluk">${_autoSablon`+%${Math.round(k.etki * 100)} müşteri`}</span></span><span class="sag kucuk">${_autoSablon`${sureMetni(k.bitis - simdi())} kaldı`}</span></li>`).join('')}</ul></div>` : ''}
    ${x.ajansim ? `<div class="kart basari"><h3>${_autoSablon`🎬 Ajansım: ${esc(x.ajansim.ad)}`}</h3>
        <div class="bilgi-izgara"><div><small>${_autoHtml("Toplam gelir")}</small><b>${tl(x.ajansim.gelir)}</b></div><div><small>${_autoHtml("Kampanya")}</small><b>${x.ajansim.kampanya}</b></div><div><small>${_autoHtml("Etki")}</small><b>%${Math.round(x.ajansim.etki * 100)}</b></div><div><small>${_autoHtml("Günlük fiyat")}</small><b>${tl(x.ajansim.gunlukFiyat)}</b></div></div>
        <div class="iki-alan"><label class="alan"><span>${_autoHtml("Yeni günlük fiyat (₺)")}</span><input name="afiyat" inputmode="decimal" placeholder="${Math.round(x.ajansim.gunlukFiyat / 100).toLocaleString(sayiDili())}"></label><button class="dugme kucuk" data-afiyat>${_autoHtml("Kaydet")}</button></div>
        ${x.ajansim.sonraki ? `<button class="dugme mavi kucuk" data-buyut>${_autoSablon`⬆️ Büyüt: etki %${Math.round(x.ajansim.sonraki.etki * 100)} (${tl(x.ajansim.sonraki.ucret)})`}</button>` : `<p class="kucuk">${_autoHtml("En büyük kademedesin.")}</p>`}
        <p class="kucuk soluk">${_autoHtml("Her kampanyanın %75'i sana, %10'u vergi (hazine), %15'i medya gideri.")}</p></div>`
      : x.kurabilir ? `<details class="kart"><summary><b>🎬 ${_autoHtml("Reklam ajansı kur")}</b> <span class="kucuk soluk">${_autoSablon`(${tl(x.kurulus.harc)} kuruluş harcı)`}</span></summary>
        <label class="alan"><span>${_autoHtml("Ajansın adı")}</span><input name="aad" maxlength="30" placeholder="${_autoHtml("ör. Işık Reklam")}"></label>
        <label class="alan"><span>${_autoHtml("Günlük fiyat (₺, küçük dükkân için)")}</span><input name="akur-fiyat" inputmode="decimal" value="${Math.round(x.kurulus.sistemFiyati / 100)}"></label>
        <button class="dugme yesil" data-ajans-kur>${_autoHtml("Ajansı kur")}</button>
        <p class="kucuk soluk">${_autoHtml("Fiyatın sistem ajansının yarısı ile iki katı arasında olmalı. Dükkân sahipleri ajansını listede görür.")}</p></details>`
      : `<div class="kart"><p class="kucuk soluk" style="margin:0">${_autoHtml("Reklam ajansı kurmak için")} <span class="kilit-rozet">${_autoSablon`${x.kurulus.seviye}. seviye`}</span> ${_autoHtml("gerekir.")}</p></div>`}`;
  const ozet = () => {
    const d = kutu.querySelector('[name=dukkan]');
    if (!d) return;
    const a = kutu.querySelector('[name=ajans]').selectedOptions[0];
    const gun = Number(kutu.querySelector('[name=gun]').value);
    kutu.querySelector('[data-gun-yaz]').textContent = gun + _autoMetin(' gün');
    kutu.querySelector('[data-reklam-ozet]').innerHTML = `${_autoSablon`Toplam: <b>${tamTl(Number(a.dataset.fiyat) * Number(d.selectedOptions[0].dataset.kat) * gun)}</b>`}`;
  };
  kutu.querySelectorAll('[name=dukkan], [name=ajans], [name=gun]').forEach((i) => i.addEventListener('input', ozet));
  ozet();
  const k = kutu.querySelector('[data-kampanya]');
  if (k) k.addEventListener('click', async () => {
    const veri = { isletmeId: Number(kutu.querySelector('[name=dukkan]').value), ajansId: Number(kutu.querySelector('[name=ajans]').value), gun: Number(kutu.querySelector('[name=gun]').value) };
    const r = await h.eylem(k, () => api('reklam/kampanya', veri));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(_autoSablon`Kampanya başladı: ${tl(r.ucret)}. Müşteriler %${Math.round(r.etki * 100)} artacak.`);
    await h.durumYenile();
    h.caddeYenile();
    isDunyasiPaneli('reklam');
  });
  const kur = kutu.querySelector('[data-ajans-kur]');
  if (kur) kur.addEventListener('click', async () => {
    const veri = { ad: kutu.querySelector('[name=aad]').value, fiyat: tutarOku(kutu.querySelector('[name=akur-fiyat]').value) };
    if (!(await onayla(_autoSablon`Reklam ajansı kurulsun mu? Kuruluş harcı ${tamTl(x.kurulus.harc)}.`, { baslik: _autoMetin('Ajans kur'), evet: _autoMetin('Kur'), ikon: '🎬' }))) return;
    if ((await h.eylem(kur, () => api('reklam/ajans', veri))) === undefined) return;
    h.ses.seviye();
    await h.durumYenile();
    isDunyasiPaneli('reklam');
  });
  const af = kutu.querySelector('[data-afiyat]');
  if (af) af.addEventListener('click', async () => {
    if ((await h.eylem(af, () => api('reklam/ayar', { fiyat: tutarOku(kutu.querySelector('[name=afiyat]').value) }))) === undefined) return;
    bildir(_autoMetin('Fiyat güncellendi.'));
    isDunyasiPaneli('reklam');
  });
  const by = kutu.querySelector('[data-buyut]');
  if (by) by.addEventListener('click', async () => {
    if ((await h.eylem(by, () => api('reklam/buyut', {}))) === undefined) return;
    h.ses.satinAl();
    await h.durumYenile();
    isDunyasiPaneli('reklam');
  });
}

function sigortaCiz(kutu, x, rota) {
  if (!hala(kutu, rota)) return;
  const k = x.kurulus;
  const s = x.sirketim;
  kutu.innerHTML = `
    ${s ? `<div class="kart ${s.durum === 'acik' ? 'basari' : 'uyari'}"><h3>🛡️ ${esc(s.ad)}${s.durum !== 'acik' ? ` <span class="rozetcik kotu">${_autoHtml("İflas")}</span>` : ''}</h3>
      <div class="bilgi-izgara"><div><small>${_autoHtml("Kasa (karşılık)")}</small><b>${tl(s.kasa)}</b></div><div><small>${_autoHtml("Poliçe")}</small><b>${s.police}</b></div><div><small>${_autoHtml("Toplam prim")}</small><b class="arti">${tl(s.prim)}</b></div><div><small>${_autoHtml("Ödenen tazminat")}</small><b class="eksi">${tl(s.tazminat)}</b></div></div>
      ${s.durum === 'acik' ? `<label class="alan"><span>${_autoSablon`Prim oranı: <b data-oran-yaz>%${s.oran}</b>`} <small class="soluk">${_autoHtml("(devlet oranının yüzdesi)")}</small></span><input type="range" name="soran" min="${k.oranAraligi[0]}" max="${k.oranAraligi[1]}" value="${s.oran}"></label>
        <button class="dugme kucuk" data-soran>${_autoHtml("Oranı kaydet")}</button>
        <div class="iki-alan"><label class="alan"><span>${_autoHtml("Tutar (₺)")}</span><input name="skasa" inputmode="decimal" placeholder="${_autoHtml("ör. 500.000")}"></label>
          <div class="dugme-satiri"><button class="dugme yesil kucuk" data-skasa="yatir">${_autoHtml("Kasaya koy")}</button><button class="dugme kucuk" data-skasa="cek">${_autoSablon`Çek (en çok ${tl(s.cekilebilir)})`}</button></div></div>
        <p class="kucuk soluk">${_autoSablon`Kasada en az ${tl(k.karsilik)} karşılık kalmalı. Hasarda tazminat önce kasadan, yetmezse hesabından ödenir; o da yetmezse şirket iflas eder.`}</p>` : ''}</div>`
      : x.kurabilir ? `<details class="kart vurgu"><summary><b>🛡️ ${_autoHtml("Sigorta şirketi kur")}</b></summary>
        <label class="alan"><span>${_autoHtml("Şirketin adı")}</span><input name="sad" maxlength="30" placeholder="${_autoHtml("ör. Güven")}"></label>
        <label class="alan"><span>${_autoSablon`Sermaye (₺, en az ${tamTl(k.enAzSermaye)})`}</span><input name="ssermaye" inputmode="decimal" value="${Math.round(k.enAzSermaye / 100)}"></label>
        <label class="alan"><span>${_autoMetin("Prim oranı: <b data-oran-yaz>%90</b>")}</span><input type="range" name="soran" min="${k.oranAraligi[0]}" max="${k.oranAraligi[1]}" value="90"></label>
        <button class="dugme yesil" data-skur>${_autoSablon`Şirketi kur (${tl(k.harc)} harç)`}</button>
        <p class="kucuk soluk">${_autoSablon`Tarım ve hayvancılık tesislerinin sahipleri seni sigortacı olarak seçebilir. Primin %${Math.round(k.vergi * 100)}'u vergidir.`}</p></details>`
      : `<div class="kart"><p class="kucuk soluk" style="margin:0">${_autoHtml("Sigorta şirketi kurmak için")} <span class="kilit-rozet">${_autoSablon`${k.seviye}. seviye`}</span> ${_autoHtml("gerekir.")}</p></div>`}
    <div class="kart"><h3>${_autoHtml("Sigorta şirketleri")}</h3>
      <ul class="satirlar"><li><span>${_autoMetin("<b>🏛️ Devlet (TARSİM)</b><br>")}<span class="kucuk soluk">${_autoHtml("Standart oran: ürün değerinin %4'ü · zararın %80'i")}</span></span><span class="sag">%100</span></li>
      ${x.liste.map((c) => `<li><span><b>🛡️ ${esc(c.ad)}</b><br><span class="kucuk soluk">${_autoSablon`${esc(c.sahip)} · ${c.police} poliçe · güvence ${c.guvence === 'guclu' ? _autoHtml('💪 güçlü') : _autoHtml('⚠️ zayıf')}`}</span></span><span class="sag">%${c.oran}</span></li>`).join('')}</ul>
      <p class="kucuk soluk">${_autoHtml("Sigortacını Sektörler &gt; Tesislerim'de her tesisin altından seçersin. Oran, devlet primine göre yüzdedir (%90 = %10 daha ucuz).")}</p></div>`;
  kutu.querySelectorAll('[name=soran]').forEach((i) => i.addEventListener('input', () => { kutu.querySelector('[data-oran-yaz]').textContent = '%' + i.value; }));
  const kur = kutu.querySelector('[data-skur]');
  if (kur) kur.addEventListener('click', async () => {
    const veri = { ad: kutu.querySelector('[name=sad]').value, sermaye: tutarOku(kutu.querySelector('[name=ssermaye]').value), oran: Number(kutu.querySelector('[name=soran]').value) };
    if (!(await onayla(_autoSablon`Sigorta şirketi kurulsun mu?\nHarç: ${tamTl(k.harc)}\nSermaye (şirket kasasına): ${tamTl(veri.sermaye)}`, { baslik: _oyunMetni("ui.ccb0d2555c3b"), evet: _autoMetin('Kur'), ikon: '🛡️' }))) return;
    if ((await h.eylem(kur, () => api('sigorta/kur', veri))) === undefined) return;
    h.ses.seviye();
    await h.durumYenile();
    isDunyasiPaneli('sigorta');
  });
  const or = kutu.querySelector('[data-soran]');
  if (or) or.addEventListener('click', async () => {
    if ((await h.eylem(or, () => api('sigorta/ayar', { oran: Number(kutu.querySelector('[name=soran]').value) }))) === undefined) return;
    bildir(_autoMetin('Prim oranı güncellendi.'));
    isDunyasiPaneli('sigorta');
  });
  kutu.querySelectorAll('[data-skasa]').forEach((b) => b.addEventListener('click', async () => {
    if ((await h.eylem(b, () => api('sigorta/kasa', { tutar: tutarOku(kutu.querySelector('[name=skasa]').value), yon: b.dataset.skasa }))) === undefined) return;
    await h.durumYenile();
    isDunyasiPaneli('sigorta');
  }));
}

function ortaklikCiz(kutu, x, rota) {
  if (!hala(kutu, rota)) return;
  kutu.innerHTML = `
    ${x.gelen.length ? `<div class="kart vurgu"><h3>${_autoHtml("📨 Sana gelen ortaklık teklifleri")}</h3><ul class="satirlar">${x.gelen.map((k) => `<li><span><b>${esc(k.sahip)}</b>: ${esc(k.tesis)}<br><span class="kucuk">${_autoSablon`%${k.pay} pay için <b>${tamTl(k.bedel)}</b>`}</span></span>
      <span class="dugme-satiri"><button class="dugme yesil kucuk" data-cevap="1" data-id="${k.id}">${_autoHtml("Kabul")}</button><button class="dugme kucuk" data-cevap="0" data-id="${k.id}">${_autoHtml("Reddet")}</button></span></li>`).join('')}</ul></div>` : ''}
    <div class="kart"><h3>${_autoHtml("🤝 Ortak olduğum tesisler")}</h3>${x.paylarim.length ? `<ul class="satirlar">${x.paylarim.map((p) => `<li><span><b>${esc(p.tesis)}</b> · ${esc(p.il)}<br><span class="kucuk soluk">${_autoSablon`sahibi ${esc(p.sahip)}`}</span></span><span class="sag">%${p.pay}</span></li>`).join('')}</ul>` : `<p class="kucuk soluk" style="margin:0">${_autoHtml("Henüz bir tesiste ortaklığın yok.")}</p>`}</div>
    ${x.giden.length ? `<div class="kart"><h3>${_autoHtml("Gönderdiğim teklifler")}</h3><ul class="satirlar">${x.giden.map((k) => `<li><span><b>${esc(k.alici)}</b>: ${esc(k.tesis)}<br><span class="kucuk soluk">%${k.pay} · ${tamTl(k.bedel)}</span></span><button class="dugme kucuk" data-cevap="0" data-id="${k.id}">${_autoHtml("Geri çek")}</button></li>`).join('')}</ul></div>` : ''}
    <div class="kart"><h3>${_autoHtml("ℹ️ Nasıl işler?")}</h3><ul class="kural-listesi">
      <li>${_autoSablon`🏭 Tesis sahibi, Sektörler &gt; Tesislerim'de tesisin altındaki <b>${_autoHtml("Ortak al")}</b> ile bir oyuncuya %5–%49 pay önerir.`}</li>
      <li>${_autoHtml("💰 Ortak bedeli öder; o günden sonra her toplamada ürünün ve gelirin payı kadarı ortağın ambarına ve hesabına gider.")}</li>
      <li>${_autoHtml("🏷️ Tesis satılırsa satış bedelinden payını alır. Sahip, ortağın payını ödediği bedelle geri alabilir.")}</li></ul></div>`;
  kutu.querySelectorAll('[data-cevap]').forEach((b) => b.addEventListener('click', async () => {
    const kabul = b.dataset.cevap === '1';
    if (kabul) {
      const k = x.gelen.find((y) => String(y.id) === b.dataset.id);
      if (!(await onayla(_autoSablon`${k.tesis}: %${k.pay} pay için ${tamTl(k.bedel)} ödenecek. Kabul ediyor musun?`, { baslik: _autoMetin('Ortak ol'), evet: _autoMetin('Kabul et'), ikon: '🤝' }))) return;
    }
    if ((await h.eylem(b, () => api(`ortaklik/${b.dataset.id}/cevap`, { kabul }))) === undefined) return;
    if (kabul) { h.ses.satinAl(); bildir(_autoMetin('Artık bu tesisin ortağısın!')); }
    await h.durumYenile();
    isDunyasiPaneli('ortaklik');
  }));
}

// Tesis kartına: sigortacı seçimi ve ortaklık (uretim.js çağırır)
export function tesisEkHtml(t, sigortalar) {
  const sig = t.sigortalanabilir ? `<label class="kucuk sigorta-sec">🛡️ <select data-sigortaci="${t.id}">
      <option value="yok" ${!t.sigorta ? 'selected' : ''}>${_autoHtml("Sigortasız")}</option>
      <option value="0" ${t.sigorta && !t.sigortaci ? 'selected' : ''}>${_autoHtml("Devlet (TARSİM) %4")}</option>
      ${(sigortalar || []).map((s) => `<option value="${s.id}" ${t.sigorta && t.sigortaci === s.id ? 'selected' : ''}>${esc(s.ad)} %${(4 * s.oran / 100).toLocaleString(sayiDili(), { maximumFractionDigits: 2 })}</option>`).join('')}
    </select></label>` : '';
  const ortak = `<div class="ortaklar">${t.ortaklar && t.ortaklar.length ? `<span class="kucuk">${_autoHtml("🤝 Ortaklar:")} ${t.ortaklar.map((o) => `${esc(o.ad)} %${o.pay} <button class="metin-dugme" data-ortak-geri="${t.id}:${o.oyuncuId}" title="Payı bedeliyle geri al">↩</button>`).join(', ')}</span>` : ''}
    <button class="metin-dugme" data-ortak-al="${t.id}">🤝 ${_autoHtml("Ortak al")}</button></div>`;
  return sig + ortak;
}
export function tesisEkBagla(kutu, tesisler, yenile) {
  kutu.querySelectorAll('[data-sigortaci]').forEach((s) => s.addEventListener('change', async () => {
    const id = Number(s.dataset.sigortaci);
    if (s.value === 'yok') await h.eylem(null, () => api('uretim/sigorta', { id, acik: false }));
    else await h.eylem(null, () => api('uretim/sigortaci', { id, sirket: Number(s.value) || null }));
    bildir(_autoMetin('Sigorta tercihin kaydedildi; sonraki üretimden itibaren geçerli.'));
  }));
  kutu.querySelectorAll('[data-ortak-al]').forEach((b) => b.addEventListener('click', async () => {
    const t = tesisler.find((x) => String(x.id) === b.dataset.ortakAl);
    const alici = await sor(_autoSablon`${t.ad} için ortaklık teklif edeceğin oyuncunun kullanıcı adı:`, { baslik: _autoMetin('Ortak al'), ipucu: _autoMetin('kullanıcı adı'), ikon: '🤝', uzunluk: 24 });
    if (!alici) return;
    const pay = Number(await sor(_autoMetin('Kaç yüzde pay veriyorsun? (5–49)'), { baslik: _autoMetin('Pay'), ipucu: _autoMetin('ör. 20'), ikon: '📊', uzunluk: 2 }));
    if (!pay) return;
    const bedel = tutarOku(await sor(_autoSablon`%${pay} pay için isteyeceğin bedel (₺):`, { baslik: _autoMetin('Bedel'), ipucu: _autoMetin('ör. 250.000'), ikon: '💰', uzunluk: 15 }));
    if (!bedel) return;
    if ((await h.eylem(b, () => api('ortaklik/teklif', { tesisId: t.id, alici, pay, bedel }))) === undefined) return;
    bildir(_autoSablon`${alici} adlı oyuncuya teklifin gönderildi.`);
  }));
  kutu.querySelectorAll('[data-ortak-geri]').forEach((b) => b.addEventListener('click', async () => {
    const [tesis, ortak] = b.dataset.ortakGeri.split(':').map(Number);
    if (!(await onayla(_autoMetin('Ortağın payını ödediği bedelle geri almak istiyor musun?'), { baslik: _oyunMetni("ui.4e1a454ffd5a"), evet: _autoMetin('Geri al'), ikon: '↩' }))) return;
    if ((await h.eylem(b, () => api('ortaklik/geri-al', { tesis, ortak }))) === undefined) return;
    await h.durumYenile();
    yenile();
  }));
}

// ====================================================================== Lüks yaşam: araba, yat, ev, arsa
let varlikSekme = 'araba';
const VARLIK_SEKME = [['araba', '🚗', 'Araba'], ['yat', '🛥️', 'Yat'], ['ev', '🏡', 'Ev'], ['arsa', '🌳', 'Arsa'], ['benim', '🔑', 'Varlıklarım']];
const MARKA_SIMGE = { araba: '🚘', yat: '🛥️', ev: '🏡', arsa: '🌳' };
export async function varlikPaneli(sekme) {
  if (sekme) varlikSekme = sekme;
  const p = h.panelAc({
    ikon: '💎', baslik: _oyunMetni("ui.10cfca6772b9"), rota: 'varlik', alt: _autoMetin('Araba, yat, ev ve arsa al; sertifikanı paylaş'),
    govde: `${sekmeler(VARLIK_SEKME, varlikSekme)}<div id="varlik-icerik">${yukleniyor()}</div>`,
  });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); varlikPaneli(b.dataset.sekme); }));
  const kutu = p.querySelector('#varlik-icerik');
  let x;
  try { x = await api('varlik'); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'varlik')) return;
  p.querySelector('.alt-baslik').innerHTML = x.varliklarim.length ? `${_autoSablon`Varlıklarının değeri: <b>${tl(x.toplam)}</b>`}` : _autoMetin('Araba, yat, ev ve arsa al; sertifikanı paylaş');
  const vitrin = x.sonAlimlar.length ? `<div class="kart"><h3>✨ ${_autoHtml("Son lüks alımlar")}</h3><ul class="satirlar">${x.sonAlimlar.slice(0, 6).map((a) => `<li><span>${MARKA_SIMGE[a.tur]} <b>${esc(a.oyuncu)}</b> ${a.tur === 'araba' ? `${_autoSablon`son model bir <b>${esc(a.ad)}</b> satın aldı`}` : a.tur === 'yat' ? `${_autoSablon`<b>${esc(a.ad)}</b> yatının sahibi oldu`}` : `${_autoSablon`${a.il ? esc(a.il) + '\'de ' : ''}<b>${esc(a.ad)}</b> satın aldı`}`}</span><span class="sag kucuk soluk">${tl(a.fiyat)}</span></li>`).join('')}</ul></div>` : '';
  if (varlikSekme === 'benim') {
    let mg = null;
    try { mg = await api('magaza'); } catch (e) { mg = null; }
    if (!hala(kutu, 'varlik')) return;
    const vitrinKarti = mg ? `<div class="kart magaza-vitrin"><div class="varlik-ust"><span class="varlik-simge">🏎️</span><div><b>${_autoHtml("Garaj vitrini")}</b><br><span class="kucuk soluk">${mg.vitrin ? _autoHtml("Araçların ve mülklerin profilinde sergileniyor.") : _autoHtml("Araçlarını, yatını ve mülklerini profilinde sergile. Plakan ve boyan da görünür.")}</span></div>
      <div class="sag">${mg.vitrin ? `<button class="dugme mavi kucuk" data-profilim>${_autoHtml("Profilimi gör")}</button>` : `<b>${tl(mg.fiyatlar.vitrin)}</b><br><button class="dugme yesil kucuk" data-vitrin-al>${_autoHtml("Satın al")}</button>`}</div></div></div>` : '';
    const magazaLinki = `<a class="kart magaza-link" href="#/magaza"><span>🛍️</span><div><b>${_autoHtml("Mağaza")}</b><small>${_autoHtml("Profil çerçevesi, isim rengi, altın sertifika ve araç süsleri")}</small></div><i>›</i></a>`;
    kutu.innerHTML = magazaLinki + vitrinKarti + (x.varliklarim.length ? `<ul class="varlik-listesi">${x.varliklarim.map((v) => `<li class="kart">
      <div class="varlik-ust"><span class="varlik-simge"${v.gorunum && v.gorunum.renk ? ` style="--renk:${v.gorunum.renk}"` : ''}>${MARKA_SIMGE[v.tur]}</span><div><b>${esc(v.ad)}</b>${v.isim ? ` <span class="kucuk">“${esc(v.isim)}”</span>` : ''}${v.plaka ? ` ${plakaHtml(v.plaka)}` : ''}<br><span class="kucuk soluk">${_autoSablon`${v.gorunum && v.gorunum.renkAd ? esc(_autoMetin(v.gorunum.renkAd)) + ' · ' : ''}${v.il ? esc(v.il) + ' · ' : ''}${tarih(v.alisZamani)} alındı`}</span></div></div>
      <div class="bilgi-izgara"><div><small>${_autoHtml("Bugünkü değer")}</small><b class="${v.deger >= v.alisFiyati ? 'arti' : 'eksi'}">${tl(v.deger)}</b></div><div><small>${_autoHtml("Alış")}</small><b>${tl(v.alisFiyati)}</b></div>
        <div><small>${v.tur === 'ev' ? _autoHtml('Aylık kira / vergi') : _autoHtml('Aylık gider')}</small><b>${v.tur === 'ev' ? `${v.kirada ? tl(v.aylikKira) : '—'} / ${tl(v.aylikGider)}` : tl(v.aylikGider)}</b></div><div><small>${_autoHtml("Satarsan eline geçer")}</small><b>${tl(v.satisTutari)}</b></div></div>
      <div class="dugme-satiri">${v.sertifika ? `<button class="dugme mavi kucuk" data-sertifika="${esc(v.sertifika)}" data-ad="${esc(v.ad)}">🏆 ${_autoHtml("Sertifikayı paylaş")}</button>` : ''}
        ${v.tur === 'araba' && mg ? `<button class="dugme kucuk" data-plaka="${v.id}">🔖 ${_autoHtml("Özel plaka")}</button><button class="dugme kucuk" data-boya="${v.id}">🎨 ${_autoHtml("Boya")}</button><button class="dugme kucuk" data-far="${v.id}">💡 ${_autoHtml("Far")}</button><button class="dugme kucuk" data-jant="${v.id}">🛞 ${_autoHtml("Jant")}</button>` : ''}
        ${v.tur === 'ev' ? `<button class="dugme kucuk" data-kira="${v.id}" data-acik="${v.kirada ? 0 : 1}">${v.kirada ? _autoHtml('🔑 Kiracıyı çıkar') : '🏠 Kiraya ver'}</button>` : ''}
        <button class="dugme kirmizi kucuk" data-sat="${v.id}">${_oyunHtml("ui.fdeb71b569e0")}</button></div></li>`).join('')}</ul>`
      : `<div class="kart"><p class="kucuk" style="margin:0">${_autoHtml("Henüz bir varlığın yok. Araba, yat, ev ya da arsa al; her alımda paylaşılabilir bir sertifika çıkar.")}</p></div>`) + vitrin
      + `<div class="kart"><h3>${_autoHtml("ℹ️ Nasıl işler?")}</h3><ul class="kural-listesi"><li>${_autoHtml("🚗 Arabalar yılda yaklaşık %12, yatlar %8 değer kaybeder; evler %12, arsalar %15 değer kazanır (ekonomi yılı).")}</li>
        <li>${_autoHtml("🧾 Her ay giderler çıkar: araba MTV ve kasko, yat marina ve bakım, ev emlak vergisi. Evi kiraya verirsen her ay kira gelir.")}</li>
        <li>${_autoHtml("📜 Ev ve arsada %4 tapu harcı alınır. Satışta araba %5, yat %8, ev ve arsa %3 komisyon düşülür.")}</li><li>${_autoHtml("💎 Varlıkların servetine ve sıralamana bugünkü değeriyle eklenir.")}</li></ul></div>`;
    const vb = kutu.querySelector('[data-vitrin-al]');
    if (vb) vb.addEventListener('click', async () => {
      if (!(await onayla(_autoSablon`Garaj vitrini ${hTl(mg.fiyatlar.vitrin)} karşılığında alınsın mı? Bir kez alınır, araçların profilinde sergilenir.`, { baslik: _autoMetin('Garaj vitrini'), evet: _autoMetin('Satın al'), ikon: '🏎️' }))) return;
      if ((await h.eylem(vb, () => api('magaza/vitrin', {}))) === undefined) return;
      h.ses.seviye();
      bildir(_autoMetin('🏎️ Garaj vitrinin hazır! Araçların artık profilinde görünüyor.'));
      await h.durumYenile();
      varlikPaneli('benim');
    });
    const pb = kutu.querySelector('[data-profilim]');
    if (pb) pb.addEventListener('click', () => { h.ses.tik(); h.profilAc(h.oyuncu().id); });
    formDonus = () => varlikPaneli('benim');
    kutu.querySelectorAll('[data-plaka]').forEach((b) => b.addEventListener('click', () => plakaFormu(x.varliklarim.find((v) => String(v.id) === b.dataset.plaka), mg)));
    kutu.querySelectorAll('[data-boya]').forEach((b) => b.addEventListener('click', () => boyaFormu(x.varliklarim.find((v) => String(v.id) === b.dataset.boya), mg)));
    kutu.querySelectorAll('[data-far]').forEach((b) => b.addEventListener('click', () => parcaFormu('far', x.varliklarim.find((v) => String(v.id) === b.dataset.far), mg)));
    kutu.querySelectorAll('[data-jant]').forEach((b) => b.addEventListener('click', () => parcaFormu('jant', x.varliklarim.find((v) => String(v.id) === b.dataset.jant), mg)));
    kutu.querySelectorAll('[data-sertifika]').forEach((b) => b.addEventListener('click', () => h.sertifikaGoster({ kod: b.dataset.sertifika, baslik: b.dataset.ad, seviye: h.oyuncu().seviye })));
    kutu.querySelectorAll('[data-kira]').forEach((b) => b.addEventListener('click', async () => {
      if ((await h.eylem(b, () => api(`varlik/${b.dataset.kira}/kira`, { acik: b.dataset.acik === '1' }))) === undefined) return;
      bildir(b.dataset.acik === '1' ? _autoMetin('Evin kiraya verildi; kira her ay hesabına yatar.') : _autoMetin('Ev boşaltıldı.'));
      varlikPaneli('benim');
    }));
    kutu.querySelectorAll('[data-sat]').forEach((b) => b.addEventListener('click', async () => {
      const v = x.varliklarim.find((y) => String(y.id) === b.dataset.sat);
      if (!(await onayla(_autoSablon`${v.ad} satılsın mı? Eline ${tamTl(v.satisTutari)} geçer.`, { baslik: _oyunMetni("ui.fdeb71b569e0"), evet: _oyunMetni("ui.fdeb71b569e0"), tehlike: true, ikon: '🏷️' }))) return;
      const r = await h.eylem(b, () => api(`varlik/${v.id}/sat`, {}));
      if (r === undefined) return;
      h.ses.kasa();
      bildir(_autoSablon`${v.ad} satıldı: ${tl(r.tutar)}`);
      await h.durumYenile();
      h.caddeYenile();
      varlikPaneli('benim');
    }));
    return;
  }
  const liste = x.liste.filter((k) => k.tur === varlikSekme);
  const carpan = (k) => (k.tur === 'ev' || k.tur === 'arsa') && k.sart !== 'istanbul' ? x.ilCarpani : 1;
  kutu.innerHTML = `${varlikSekme === 'ev' || varlikSekme === 'arsa' ? `<p class="kucuk soluk">${_autoSablon`Fiyatlar ${esc(x.il.ad)} için (il seçerek değişir). İstanbul en pahalı, küçük illerde daha ucuz.`}</p>` : ''}
    <ul class="vitrin-listesi">${liste.map((k) => `<li class="kart${k.kilitli ? ' kilitli' : ''}">
      <div class="varlik-ust"><span class="varlik-simge">${MARKA_SIMGE[k.tur]}</span><div><b>${esc(k.ad)}</b><br><span class="kucuk soluk">${esc(k.not || '')}${k.sart === 'kiyi' ? _autoHtml(' · kıyı illerinde') : k.sart === 'istanbul' ? _autoHtml(' · yalnızca İstanbul') : ''}</span></div>
        <div class="sag"><b>${tl(Math.round(k.fiyat * carpan(k)))}</b><br>${k.kilitli ? `<span class="kilit-rozet">${_autoSablon`${k.seviye}. seviye`}</span>` : `<button class="dugme yesil kucuk" data-al="${k.kod}">${_autoHtml("Satın al")}</button>`}</div></div></li>`).join('')}</ul>${vitrin}`;
  kutu.querySelectorAll('[data-al]').forEach((b) => b.addEventListener('click', () => varlikAlFormu(x, x.liste.find((k) => k.kod === b.dataset.al))));
}

// 0.42: Türk plakası görünümünde küçük plaka
export function plakaHtml(p) { return `<span class="plaka-tr"><i>TR</i>${esc(p)}</span>`; }
// "26tefon1" → "26 TEFON 1" (sunucudaki kuralın aynısı; son karar sunucunundur)
function plakaDuzelt(metin) {
  const s0 = String(metin || '').toLocaleUpperCase('tr').replace(/İ/g, 'I').replace(/[^0-9A-ZÇĞÖŞÜ]/g, '');
  const m = /^(\d{2})([A-ZÇĞÖŞÜ]{1,5})(\d{1,4})$/.exec(s0);
  if (!m) return null;
  const p = `${m[1]} ${m[2]} ${m[3]}`;
  return /^(0[1-9]|[1-7][0-9]|8[01]) ([A-PR-VYZ]{1,5}) ([0-9]{1,4})$/.test(p) ? p : null;
}
let formDonus = () => varlikPaneli('benim');
function plakaFormu(v, mg) {
  const il = String((h.oyuncu().il && h.oyuncu().il.id) || 34).padStart(2, '0');
  const p = h.panelAc({
    ikon: '🔖', baslik: _autoMetin('Özel plaka'), alt: esc(v.ad), rota: 'varlik',
    govde: `<div class="kart"><div class="plaka-onizleme">${plakaHtml(v.plaka || `${il} ABC 123`)}</div>
      <label class="alan"><span>${_autoHtml("Plakan")}</span><input name="plaka" maxlength="14" autocapitalize="characters" autocomplete="off" placeholder="${il} TEFON 01" value="${esc(v.plaka || '')}"></label>
      <p class="kucuk soluk" data-durum>${_autoHtml("İl kodu (01–81), 1–5 harf ve 1–4 rakam. Ç, Ğ, İ, Ö, Ş, Ü, Q, W, X kullanılmaz. Her plaka oyunda tektir.")}</p>
      <p class="kucuk">${_autoSablon`Fiyat: <b>${hTl(mg.fiyatlar.plaka)}</b>. Plaka arabanla birlikte kalır; arabayı satarsan plaka boşa çıkar.`}</p>
      <button class="dugme yesil" data-onay disabled>${_autoHtml("Plakayı tak")}</button> <button class="dugme gri" data-vazgec>${_autoHtml("Vazgeç")}</button></div>`,
  });
  const giris = p.querySelector('[name=plaka]'), onay = p.querySelector('[data-onay]'), durum = p.querySelector('[data-durum]'), on = p.querySelector('.plaka-onizleme');
  const guncelle = () => {
    const d = plakaDuzelt(giris.value);
    on.innerHTML = plakaHtml(d || giris.value.toLocaleUpperCase('tr') || `${il} ABC 123`);
    on.classList.toggle('gecersiz', !!giris.value && !d);
    onay.disabled = !d || d === v.plaka;
    durum.classList.toggle('kirmizi', !!giris.value && !d);
  };
  giris.addEventListener('input', guncelle);
  guncelle();
  p.querySelector('[data-vazgec]').addEventListener('click', () => formDonus());
  onay.addEventListener('click', async () => {
    const r = await h.eylem(onay, () => api('magaza/plaka', { id: v.id, plaka: giris.value }));
    if (r === undefined) return;
    h.ses.seviye();
    bildir(_autoSablon`🔖 Yeni plakan takıldı: ${r.plaka}`);
    await h.durumYenile();
    h.caddeYenile();
    formDonus();
  });
}
const BITIS_AD = { mat: 'Mat', metalik: 'Metalik', sedef: 'Sedef', krom: 'Krom' };
function boyaFormu(v, mg) {
  let secili = null;
  const p = h.panelAc({
    ikon: '🎨', baslik: _autoMetin('Özel boya'), alt: esc(v.ad), rota: 'varlik',
    govde: `<div class="kart"><div class="boya-izgara">${mg.boyalar.map((b) => `<button class="boya-secim${v.boya === b.kod ? ' simdiki' : ''}" data-kod="${b.kod}" ${v.boya === b.kod ? 'disabled' : ''}>
        <i class="boya-ornek ${b.bitis}" style="--renk:${b.renk}"></i><b>${esc(_autoMetin(b.ad))}</b><small>${esc(_autoMetin(BITIS_AD[b.bitis]))} · ${tl(b.fiyat)}</small></button>`).join('')}</div>
      <p class="kucuk soluk">${_autoHtml("Boya sadece görünümü değiştirir; arabanın değeri değişmez. Sokağına park ettiğin araban yeni rengiyle görünür.")}</p>
      <button class="dugme yesil" data-onay disabled>${_autoHtml("Boyat")}</button> <button class="dugme gri" data-vazgec>${_autoHtml("Vazgeç")}</button></div>`,
  });
  const onay = p.querySelector('[data-onay]');
  p.querySelectorAll('[data-kod]').forEach((b) => b.addEventListener('click', () => {
    h.ses.tik();
    secili = mg.boyalar.find((x) => x.kod === b.dataset.kod);
    p.querySelectorAll('[data-kod]').forEach((y) => y.classList.toggle('secili', y === b));
    onay.disabled = false;
    onay.textContent = _autoSablon`Boyat (${hTl(secili.fiyat, true)})`;
  }));
  p.querySelector('[data-vazgec]').addEventListener('click', () => formDonus());
  onay.addEventListener('click', async () => {
    if (!secili) return;
    const r = await h.eylem(onay, () => api('magaza/boya', { id: v.id, boya: secili.kod }));
    if (r === undefined) return;
    h.ses.seviye();
    bildir(_autoSablon`🎨 Araban boyandı: ${_autoMetin(r.ad)}`);
    await h.durumYenile();
    h.caddeYenile();
    formDonus();
  });
}

// 0.42.1: far ve jant seçimi (araba başına)
function parcaFormu(tur, v, mg) {
  const far = tur === 'far';
  const liste = far ? mg.farlar : mg.jantlar;
  const simdiki = far ? v.far : v.jant;
  const FAR_RENK = { beyaz: '#EEF4FF', sari: '#FFD27A', buz: '#BFD9FF' };
  let secili = null;
  const p = h.panelAc({
    ikon: far ? '💡' : '🛞', baslik: far ? _autoMetin('Far rengi') : _autoMetin('Jant'), alt: esc(v.ad), rota: h.aktifRota(),
    govde: `<div class="kart"><div class="boya-izgara">${liste.map((b) => `<button class="boya-secim${simdiki === b.kod ? ' simdiki' : ''}" data-kod="${b.kod}" ${simdiki === b.kod ? 'disabled' : ''}>
        ${far ? `<i class="far-ornek" style="--renk:${FAR_RENK[b.kod]}"></i>` : `<i class="jant-ornek" style="--renk:${b.renk}"></i>`}<b>${esc(_autoMetin(b.ad))}</b><small>${tl(b.fiyat)}</small></button>`).join('')}</div>
      <p class="kucuk soluk">${far ? _autoHtml("Gece sokağına park ettiğin arabanın farları bu renkte yanar.") : _autoHtml("Jant sokağındaki arabanda görünür; arabanın değeri değişmez.")}</p>
      <button class="dugme yesil" data-onay disabled>${_autoHtml("Tak")}</button> <button class="dugme gri" data-vazgec>${_autoHtml("Vazgeç")}</button></div>`,
  });
  const onay = p.querySelector('[data-onay]');
  p.querySelectorAll('[data-kod]').forEach((b) => b.addEventListener('click', () => {
    h.ses.tik();
    secili = liste.find((x) => x.kod === b.dataset.kod);
    p.querySelectorAll('[data-kod]').forEach((y) => y.classList.toggle('secili', y === b));
    onay.disabled = false;
    onay.textContent = _autoSablon`Tak (${hTl(secili.fiyat, true)})`;
  }));
  p.querySelector('[data-vazgec]').addEventListener('click', () => formDonus());
  onay.addEventListener('click', async () => {
    if (!secili) return;
    const r = await h.eylem(onay, () => api('magaza/' + tur, { id: v.id, kod: secili.kod }));
    if (r === undefined) return;
    h.ses.seviye();
    bildir(far ? _autoSablon`💡 Yeni farların takıldı: ${_autoMetin(r.ad)}` : _autoSablon`🛞 Yeni jantların takıldı: ${_autoMetin(r.ad)}`);
    await h.durumYenile();
    h.caddeYenile();
    formDonus();
  });
}

// ====================================================================== 0.42.1: Mağaza
// Profil (çerçeve, isim rengi, altın sertifika, garaj vitrini) ve araç süsleri (plaka, boya, far, jant).
let magazaSekme = 'profil';
// 0.44: görünüm hakkı (Esnaf Kartı / Sezon kartı): varsa görünüm alımında fiyat yerine "ücretsiz" yazılır
let magazaHak = 0;
const hTl = (f, kisa = false) => (magazaHak > 0 ? (kisa ? _autoMetin('ücretsiz') : _autoMetin('ücretsiz (görünüm hakkın kullanılır)')) : (kisa ? tl(f) : tamTl(f)));
const MAGAZA_SEKME = [['profil', '🙂', 'Profil'], ['tezgah', '🛒', 'Tezgâh ve dükkân'], ['arac', '🚘', 'Araç, yat ve ev'], ['kutlama', '🎆', 'Kutlama'], ['reklam', '🪧', 'Reklam Ver'], ['kartlar', '🎫', 'Esnaf ve Sezon']];
export async function magazaPaneli(sekme) {
  if (sekme && MAGAZA_SEKME.some(([k]) => k === sekme)) magazaSekme = sekme;
  const p = h.panelAc({
    ikon: '🛍️', baslik: _autoMetin('Mağaza'), rota: 'magaza', alt: _autoMetin('Görünüm ürünleri: hiçbiri servetine ya da kazancına etki etmez'),
    govde: `${sekmeler(MAGAZA_SEKME, magazaSekme)}<div id="magaza-icerik">${yukleniyor()}</div>`,
  });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); magazaPaneli(b.dataset.sekme); }));
  const kutu = p.querySelector('#magaza-icerik');
  let mg, x;
  if (magazaSekme === 'reklam') { formDonus = () => magazaPaneli('reklam'); return bilboardIcerik(kutu); }
  if (magazaSekme === 'kutlama') { formDonus = () => magazaPaneli('kutlama'); return kutlamaIcerik(kutu); }
  if (magazaSekme === 'kartlar') { formDonus = () => magazaPaneli('kartlar'); return kartlarIcerik(kutu); }
  try { [mg, x] = await Promise.all([api('magaza'), magazaSekme === 'arac' ? api('varlik') : Promise.resolve(null)]); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'magaza')) return;
  h.altinSertifika(mg.altinSertifika);
  magazaHak = mg.hak || 0;
  if (magazaHak > 0) kutu.insertAdjacentHTML('beforebegin', `<div class="kart hak-serit">🎫 ${_autoSablon`${magazaHak} görünüm hakkın var: sıradaki görünüm alımın ücretsiz.`}</div>`);
  formDonus = () => magazaPaneli(magazaSekme);
  const o = h.oyuncu();
  if (magazaSekme === 'arac') {
    const arabalar = x.varliklarim.filter((v) => v.tur === 'araba');
    const yatlar = x.varliklarim.filter((v) => v.tur === 'yat');
    const evler = x.varliklarim.filter((v) => v.tur === 'ev');
    const dl = mg.dolasma;
    kutu.innerHTML = `<div class="kart magaza-vitrin"><div class="varlik-ust"><span class="varlik-simge">🛣️</span><div><b>${_autoHtml("Mahallede dolaşma")}</b><br><span class="kucuk soluk">${_autoSablon`Seçtiğin araban ${mg.dolasmaGun} gün boyunca mahallendeki herkesin caddesinde trafikte, adınla birlikte dolaşır.`}</span>
        ${dl ? `<br><span class="rozetcik iyi">${_autoSablon`Dolaşıyor · ${sureMetni(dl.bitis - simdi())} kaldı`}</span>` : ''}</div><div class="sag"><b>${tl(mg.fiyatlar.dolasma)}</b></div></div></div>
      ${arabalar.length ? `<ul class="varlik-listesi">${arabalar.map((v) => `<li class="kart"><div class="varlik-ust"><span class="varlik-simge"${v.gorunum && v.gorunum.renk ? ` style="--renk:${v.gorunum.renk}"` : ''}>🚘</span>
        <div><b>${esc(v.ad)}</b>${v.plaka ? ` ${plakaHtml(v.plaka)}` : ''}${dl && dl.arac === v.id ? ` <span class="rozetcik iyi">🛣️ ${_autoHtml("Dolaşıyor")}</span>` : ''}<br><span class="kucuk soluk">${[v.gorunum.renkAd, v.gorunum.farAd, v.gorunum.jantAd].filter(Boolean).map((a) => esc(_autoMetin(a))).join(' · ')}</span></div></div>
        <div class="dugme-satiri"><button class="dugme kucuk" data-plaka="${v.id}">🔖 ${_autoHtml("Özel plaka")}</button><button class="dugme kucuk" data-boya="${v.id}">🎨 ${_autoHtml("Boya")}</button><button class="dugme kucuk" data-far="${v.id}">💡 ${_autoHtml("Far")}</button><button class="dugme kucuk" data-jant="${v.id}">🛞 ${_autoHtml("Jant")}</button>
          ${dl && dl.arac !== v.id ? `<button class="dugme kucuk mavi" data-dolas-arac="${v.id}">🛣️ ${_autoHtml("Bununla dolaş")}</button>` : ''}<button class="dugme kucuk yesil" data-dolas="${v.id}">🛣️ ${dl ? _autoSablon`+${mg.dolasmaGun} gün uzat` : _autoSablon`Mahallede dolaştır (${mg.dolasmaGun} gün)`}</button></div></li>`).join('')}</ul>`
      : `<div class="kart"><p class="kucuk" style="margin:0">${_autoHtml("Araç süsleri için önce bir araba al.")}</p><a class="dugme yesil kucuk" href="#/varlik/araba">🚗 ${_autoHtml("Araba al")}</a></div>`}
      <div class="kart"><h3>🛥️ ${_autoHtml("Yata isim")}</h3><p class="kucuk soluk">${_autoSablon`Yatının bordasına istediğin adı yazdır; garaj vitrininde de görünür. ${tl(mg.fiyatlar.yatAd)}`}</p>
        ${yatlar.length ? `<ul class="bb-liste">${yatlar.map((v) => `<li><span>🛥️</span><div><b>${esc(v.ad)}</b><small>${v.isim ? '“' + esc(v.isim) + '”' : _autoHtml('İsimsiz')}</small></div><span></span><button class="dugme kucuk" data-yat-ad="${v.id}">✍️ ${_autoHtml("İsim yazdır")}</button></li>`).join('')}</ul>`
          : `<a class="dugme gri kucuk" href="#/varlik/yat">🛥️ ${_autoHtml("Yat al")}</a>`}</div>
      <div class="kart"><h3>🏡 ${_autoHtml("Ev cephe rengi")}</h3><p class="kucuk soluk">${_autoSablon`Evinin ya da villanın cephesini boyat; garaj vitrininde bu renkle görünür. ${tl(mg.fiyatlar.cephe)}`}</p>
        ${evler.length ? evler.map((v) => `<div class="cephe-ev"><b>🏡 ${esc(v.ad)}</b>${v.il ? ` <small class="soluk">${esc(v.il)}</small>` : ''}<div class="boya-izgara">${mg.cepheler.map((c) => `<button class="boya-secim${v.gorunum && v.gorunum.cephe === c.kod ? ' simdiki' : ''}" data-cephe="${v.id}" data-kod="${c.kod}" ${v.gorunum && v.gorunum.cephe === c.kod ? 'disabled' : ''}><i class="boya-ornek" style="--renk:${c.renk}"></i><b>${esc(_autoMetin(c.ad))}</b><small>${v.gorunum && v.gorunum.cephe === c.kod ? _autoHtml('Kullanılıyor') : tl(c.fiyat)}</small></button>`).join('')}</div></div>`).join('')
          : `<a class="dugme gri kucuk" href="#/varlik/ev">🏡 ${_autoHtml("Ev al")}</a>`}</div>`;
    const bul = (id) => arabalar.find((v) => String(v.id) === id);
    kutu.querySelectorAll('[data-plaka]').forEach((b) => b.addEventListener('click', () => plakaFormu(bul(b.dataset.plaka), mg)));
    kutu.querySelectorAll('[data-boya]').forEach((b) => b.addEventListener('click', () => boyaFormu(bul(b.dataset.boya), mg)));
    kutu.querySelectorAll('[data-far]').forEach((b) => b.addEventListener('click', () => parcaFormu('far', bul(b.dataset.far), mg)));
    kutu.querySelectorAll('[data-jant]').forEach((b) => b.addEventListener('click', () => parcaFormu('jant', bul(b.dataset.jant), mg)));
    kutu.querySelectorAll('[data-dolas]').forEach((b) => b.addEventListener('click', async () => {
      const v = bul(b.dataset.dolas);
      if (!(await onayla(_autoSablon`${v.ad} ${mg.dolasmaGun} gün boyunca mahallende adınla dolaşsın mı? ${tamTl(mg.fiyatlar.dolasma)}`, { baslik: _autoMetin('Mahallede dolaşma'), evet: _autoMetin('Satın al'), ikon: '🛣️' }))) return;
      if ((await h.eylem(b, () => api('magaza/dolasma', { id: v.id }))) === undefined) return;
      h.ses.seviye();
      bildir(_autoMetin('🛣️ Araban mahallede dolaşmaya çıktı!'));
      await h.durumYenile(); h.caddeYenile();
      magazaPaneli('arac');
    }));
    kutu.querySelectorAll('[data-dolas-arac]').forEach((b) => b.addEventListener('click', async () => {
      if ((await h.eylem(b, () => api('magaza/dolasma-arac', { id: Number(b.dataset.dolasArac) }))) === undefined) return;
      h.ses.tik(); bildir(_autoMetin('Artık bu araban dolaşıyor.')); h.caddeYenile(); magazaPaneli('arac');
    }));
    kutu.querySelectorAll('[data-yat-ad]').forEach((b) => b.addEventListener('click', async () => {
      const ad = await sor(_autoSablon`Yatına hangi adı yazdıralım? (${hTl(mg.fiyatlar.yatAd)})`, { baslik: _autoMetin('Yata isim'), evet: _autoMetin('Yazdır'), ipucu: _autoMetin('ör. Mavi Rüya'), ikon: '🛥️', uzunluk: 24 });
      if (!ad) return;
      if ((await h.eylem(b, () => api('magaza/yat-ad', { id: Number(b.dataset.yatAd), ad }))) === undefined) return;
      h.ses.seviye(); bildir(_autoSablon`🛥️ Yatının yeni adı: ${ad}`); magazaPaneli('arac');
    }));
    kutu.querySelectorAll('[data-cephe]').forEach((b) => b.addEventListener('click', async () => {
      const c = mg.cepheler.find((x) => x.kod === b.dataset.kod);
      if (!(await onayla(_autoSablon`Evinin cephesi ${_autoMetin(c.ad)} renge boyansın mı? ${hTl(c.fiyat)}`, { baslik: _autoMetin('Ev cephe rengi'), evet: _autoMetin('Satın al'), ikon: '🏡' }))) return;
      if ((await h.eylem(b, () => api('magaza/cephe', { id: Number(b.dataset.cephe), kod: c.kod }))) === undefined) return;
      h.ses.seviye(); bildir(_autoMetin('🏡 Evinin cephesi yenilendi.')); magazaPaneli('arac');
    }));
    return;
  }
  const tabelaAdi = (o.kullaniciAdi || 'ÇIRAK').toLocaleUpperCase('tr').slice(0, 10);
  const ONIZLEME = {
    cerceve: (c) => avatarHtml(o.foto, o.kullaniciAdi, 46, '', { c: c.kod }),
    isim: (c) => `<span class="isim-onizleme">${isimHtml(o.kullaniciAdi, { r: c.kod })}</span>`,
    desen: (c) => `<i class="desen-ornek" style="--r1:${c.r1};--r2:${c.r2}"></i>`,
    neon: (c) => `<span class="neon-ornek" style="--renk:${c.renk}">${esc(tabelaAdi)}</span>`,
    yazi: (c) => `<span class="yazi-ornek y-${c.kod}">${esc(tabelaAdi)}</span>`,
  };
  const secimIzgara = (tur, liste, aktif, sahip) => `<div class="boya-izgara">${liste.map((c) => {
    const var_ = sahip.includes(c.kod);
    const onizleme = ONIZLEME[tur](c);
    return `<button class="boya-secim${aktif === c.kod ? ' simdiki' : ''}" data-tur="${tur}" data-kod="${c.kod}" data-fiyat="${var_ ? 0 : c.fiyat}" ${aktif === c.kod ? 'disabled' : ''}>
      ${onizleme}<b>${esc(_autoMetin(c.ad))}</b><small>${aktif === c.kod ? _autoHtml('Kullanılıyor') : var_ ? _autoHtml('Senin · ücretsiz seç') : tl(c.fiyat)}</small></button>`;
  }).join('')}</div>${aktif ? `<button class="dugme gri kucuk" data-tur="${tur}" data-kod="" data-fiyat="0">${_autoHtml("Kaldır")}</button>` : ''}`;
  if (magazaSekme === 'tezgah') {
    kutu.innerHTML = `<div class="kart"><h3>🎨 ${_autoHtml("Tezgâh deseni")}</h3><p class="kucuk soluk">${_autoHtml("Bütün tezgâhlarının tentesi, şemsiyesi, örtüsü ve paspası bu iki renkle çizgili olur. Komşular da görür.")}</p>
        ${secimIzgara('desen', mg.desenler, mg.desen, mg.sahipDesen)}</div>
      <div class="kart magaza-vitrin"><div class="varlik-ust"><span class="varlik-simge">💡</span><div><b>${_autoHtml("Işık zinciri")}</b><br><span class="kucuk soluk">${_autoHtml("Tezgâhlarının önünde renkli ampullerle bir ışık kemeri; tenteli tezgâhlarda tentenin altına ikinci bir zincir. Akşamları sokağı canlandırır.")}</span></div>
        <div class="sag">${mg.isikAlindi ? `<button class="dugme ${mg.isik ? 'gri' : 'yesil'} kucuk" data-isik="${mg.isik ? 0 : 1}">${mg.isik ? _autoHtml('Kapat') : _autoHtml('Aç')}</button>` : `<b>${tl(mg.fiyatlar.isik)}</b><br><button class="dugme yesil kucuk" data-isik="1">${_autoHtml("Satın al")}</button>`}</div></div></div>
      <div class="kart"><h3>🌃 ${_autoHtml("Neon tabela")}</h3><p class="kucuk soluk">${_autoHtml("Bütün dükkânlarının tabelası koyu zeminli, renkli neon ışıklı olur; gece daha da parlar.")}</p>
        ${secimIzgara('neon', mg.neonlar, mg.neon, mg.sahipNeon)}</div>
      <div class="kart"><h3>🔤 ${_autoHtml("Tabela yazı tipi")}</h3><p class="kucuk soluk">${_autoHtml("Dükkân tabelalarındaki adın bu yazı tipiyle yazılır.")}</p>
        ${secimIzgara('yazi', mg.yazilar, mg.yazi, mg.sahipYazi)}</div>`;
  } else kutu.innerHTML = `<div class="kart"><h3>🖼️ ${_autoHtml("Profil çerçevesi")}</h3><p class="kucuk soluk">${_autoHtml("Profilinde, sıralamada ve sohbette fotoğrafının çevresinde görünür. Bir kez aldığın çerçeveyi istediğin zaman yeniden seçebilirsin.")}</p>
      ${secimIzgara('cerceve', mg.cerceveler, mg.cerceve, mg.sahipCerceve)}</div>
    <div class="kart"><h3>🌈 ${_autoHtml("İsim rengi")}</h3><p class="kucuk soluk">${_autoHtml("Adın profilde, sıralamada ve sohbette bu renkte yazılır.")}</p>
      ${secimIzgara('isim', mg.isimRenkleri, mg.isimRenk, mg.sahipIsim)}</div>
    <div class="kart magaza-vitrin"><div class="varlik-ust"><span class="varlik-simge">🏆</span><div><b>${_autoHtml("Altın sertifika")}</b><br><span class="kucuk soluk">${_autoHtml("Sertifikaların altın çerçeveyle gösterilir; paylaştığın sertifika sayfasında da parlayan altın çerçeve ve ★ Altın sertifika şeridi çıkar.")}</span></div>
      <div class="sag">${mg.altinSertifika ? `<span class="rozetcik iyi">${_autoHtml("Senin")}</span>` : `<b>${tl(mg.fiyatlar.altinSertifika)}</b><br><button class="dugme yesil kucuk" data-altin>${_autoHtml("Satın al")}</button>`}</div></div></div>
    <div class="kart magaza-vitrin"><div class="varlik-ust"><span class="varlik-simge">🏎️</span><div><b>${_autoHtml("Garaj vitrini")}</b><br><span class="kucuk soluk">${_autoHtml("Araçlarını, yatını ve mülklerini profilinde sergile. Plakan ve boyan da görünür.")}</span></div>
      <div class="sag">${mg.vitrin ? `<span class="rozetcik iyi">${_autoHtml("Senin")}</span>` : `<b>${tl(mg.fiyatlar.vitrin)}</b><br><button class="dugme yesil kucuk" data-vitrin-al>${_autoHtml("Satın al")}</button>`}</div></div></div>
    <button class="dugme mavi" data-profilim>👤 ${_autoHtml("Profilimi gör")}</button>`;
  kutu.querySelectorAll('[data-tur][data-kod]').forEach((b) => b.addEventListener('click', async () => {
    const tur = b.dataset.tur, kod = b.dataset.kod || null, fiyat = Number(b.dataset.fiyat) || 0;
    const LISTE = { cerceve: mg.cerceveler, isim: mg.isimRenkleri, desen: mg.desenler, neon: mg.neonlar, yazi: mg.yazilar };
    const TUR_AD = { cerceve: 'çerçeve', isim: 'isim rengi', desen: 'tezgâh deseni', neon: 'neon tabela', yazi: 'tabela yazı tipi' };
    const ad = kod ? LISTE[tur].find((c) => c.kod === kod).ad : '';
    if (fiyat && !(await onayla(_autoSablon`${_autoMetin(ad)} ${_autoMetin(TUR_AD[tur])} ${hTl(fiyat)} karşılığında alınsın mı?`, { baslik: _autoMetin('Mağaza'), evet: _autoMetin('Satın al'), ikon: '🛍️' }))) return;
    if ((await h.eylem(b, () => api('magaza/profil', { tur, kod }))) === undefined) return;
    fiyat ? h.ses.seviye() : h.ses.tik();
    bildir(kod ? _autoMetin('✨ Yeni görünümün kullanılıyor.') : _autoMetin('Görünüm kaldırıldı.'));
    await h.durumYenile();
    if (['neon', 'yazi'].includes(tur)) h.caddeYenile();
    if (tur === 'desen') h.seyyarYenile();
    magazaPaneli(magazaSekme);
  }));
  const ib = kutu.querySelector('[data-isik]');
  if (ib) ib.addEventListener('click', async () => {
    const acik = ib.dataset.isik === '1';
    if (acik && !mg.isikAlindi && !(await onayla(_autoSablon`Işık zinciri ${hTl(mg.fiyatlar.isik)} karşılığında alınsın mı? Bir kez alınır, sonra istediğin zaman açıp kapatabilirsin.`, { baslik: _autoMetin('Işık zinciri'), evet: _autoMetin('Satın al'), ikon: '💡' }))) return;
    if ((await h.eylem(ib, () => api('magaza/isik', { acik }))) === undefined) return;
    acik && !mg.isikAlindi ? h.ses.seviye() : h.ses.tik();
    bildir(acik ? _autoMetin('💡 Tezgâhlarında ışık zinciri yanıyor.') : _autoMetin('Işık zinciri kapatıldı.'));
    await h.durumYenile();
    h.seyyarYenile();
    magazaPaneli('tezgah');
  });
  const ab = kutu.querySelector('[data-altin]');
  if (ab) ab.addEventListener('click', async () => {
    if (!(await onayla(_autoSablon`Altın sertifika ${hTl(mg.fiyatlar.altinSertifika)} karşılığında alınsın mı? Bir kez alınır, bütün sertifikaların altın çerçeveli olur.`, { baslik: _autoMetin('Altın sertifika'), evet: _autoMetin('Satın al'), ikon: '🏆' }))) return;
    if ((await h.eylem(ab, () => api('magaza/altin-sertifika', {}))) === undefined) return;
    h.ses.seviye();
    h.altinSertifika(true);
    bildir(_autoMetin('🏆 Sertifikaların artık altın çerçeveli!'));
    await h.durumYenile();
    magazaPaneli('profil');
  });
  const vb = kutu.querySelector('[data-vitrin-al]');
  if (vb) vb.addEventListener('click', async () => {
    if (!(await onayla(_autoSablon`Garaj vitrini ${hTl(mg.fiyatlar.vitrin)} karşılığında alınsın mı? Bir kez alınır, araçların profilinde sergilenir.`, { baslik: _autoMetin('Garaj vitrini'), evet: _autoMetin('Satın al'), ikon: '🏎️' }))) return;
    if ((await h.eylem(vb, () => api('magaza/vitrin', {}))) === undefined) return;
    h.ses.seviye();
    bildir(_autoMetin('🏎️ Garaj vitrinin hazır! Araçların artık profilinde görünüyor.'));
    await h.durumYenile();
    magazaPaneli('profil');
  });
  const pm = kutu.querySelector('[data-profilim]');
  if (pm) pm.addEventListener('click', () => { h.ses.tik(); h.profilAc(o.id); });
}

// ---------- 0.44: Esnaf Kartı ve Sezon kartı ----------
async function kartlarIcerik(kutu) {
  let e, s, mg;
  try { [e, s, mg] = await Promise.all([api('esnaf'), api('sezon'), api('magaza')]); } catch (x) { kutu.innerHTML = `<p class="soluk">${esc(x.message)}</p>`; return; }
  if (!hala(kutu, 'magaza')) return;
  const KART_SIMGE = { cerceve: '🖼️', isim: '🌈', desen: '🎨', neon: '🌃', hak: '🎫' };
  const yuzde = Math.min(100, Math.round((100 * s.puan) / s.esikler[s.esikler.length - 1]));
  kutu.innerHTML = `<div class="kart esnaf-kart${e.aktif ? ' aktif' : ''}">
      <div class="varlik-ust"><span class="varlik-simge">🎫</span><div><b>${_autoHtml("Esnaf Kartı")}</b>${e.aktif ? ` <span class="rozetcik iyi">${_autoSablon`Üyesin · ${sureMetni(e.bitis - simdi())} kaldı`}</span>` : ''}<br><span class="kucuk soluk">${_autoSablon`${e.gun} günlük üyelik. Güç vermez, zaman kazandırır.`}</span></div>
        <div class="sag"><b>${tl(e.fiyat)}</b></div></div>
      <ul class="esnaf-liste">
        <li>🔁 ${_autoHtml("Tek dokunuşla “topla ve yeniden başlat”: biten tezgâhlar toplanır, aynı iş aynı süreyle yeniden başlar.")}</li>
        <li>🔔 ${_autoHtml("Ek hatırlatmalar: günlük ödülünü ve görev sandığını unutma diye akşam bildirimi.")}</li>
        <li>🎁 ${_autoSablon`Her ${e.gun} günde ${e.hak} görünüm hakkı: mağazadaki görünüm ürünlerinden ikisi ücretsiz.`}</li>
        <li>🎫 ${_autoHtml("Adının yanında Esnaf rozeti (profil, sohbet, sıralama).")}</li>
      </ul>
      <button class="dugme ${e.aktif ? 'mavi' : 'yesil'}" data-esnaf>${e.aktif ? _autoSablon`🎫 ${e.gun} gün uzat` : _autoHtml("🎫 Esnaf Kartı al")}</button>
      ${mg.hak ? `<p class="kucuk">${_autoSablon`🎫 ${mg.hak} görünüm hakkın var.`}</p>` : ''}</div>
    <div class="kart sezon-kart">
      <div class="sezon-ust"><div><h3>🏅 ${_autoHtml("Sezon")}</h3><span class="kucuk soluk">${_autoSablon`Bu hafta kazandığın her TP sezon puanıdır. Sezonun bitmesine ${sureMetni(s.bitis - simdi())}.`}</span></div>
        <div class="sezon-puan"><b>${s.puan}</b><small>${_autoSablon`${s.kademe}/10 kademe`}</small></div></div>
      <div class="cubuk sezon-cubuk"><div style="width:${yuzde}%"></div></div>
      <div class="sezon-tablo" role="table">
        <div class="sezon-satir baslik" role="row"><span>${_autoHtml("Kademe")}</span><span>${_autoHtml("Ücretsiz")}</span><span>🏅 ${_autoHtml("Sezon kartı")}</span></div>
        ${s.kademeler.map((k) => `<div class="sezon-satir${k.ulasildi ? ' ulasildi' : ''}" role="row"><span><b>${k.no}</b><small>${k.esik} TP</small></span>
          <span>${k.ucretsiz ? `${k.ucretsiz.alindi ? '✅' : k.ulasildi ? '🎁' : '🔒'} ${tl(k.ucretsiz.tutar)}` : '<small class="soluk">—</small>'}</span>
          <span class="${s.kart ? '' : 'kilitli'}">${k.kart.alindi ? '✅' : k.ulasildi && s.kart ? '🎁' : '🔒'} ${KART_SIMGE[k.kart.tur] || '🎁'} ${esc(_autoMetin(k.kart.ad))}</span></div>`).join('')}
      </div>
      <div class="dugme-satiri">
        ${s.alinabilir ? `<button class="dugme yesil" data-sezon-odul>🎁 ${_autoSablon`Ödülleri al (${s.alinabilir})`}</button>` : ''}
        ${s.kart ? `<span class="rozetcik iyi">🏅 ${_autoHtml("Sezon kartın var")}</span>` : `<button class="dugme mavi" data-sezon-kart>🏅 ${_autoSablon`Sezon kartı al (${tl(s.fiyat)})`}</button>`}
      </div>
      <p class="kucuk soluk">${_autoHtml("Kart sırası yalnızca görünüm verir; sezon ürünleri mağazada satılmaz. Zaten sende olan bir ürün yerine 1 görünüm hakkı alırsın. Kartı hafta içinde ne zaman alırsan al, geçtiğin kademelerin ödülleri de açılır. Ödülleri hafta bitmeden almayı unutma.")}${s.rozet ? ' ' + _autoSablon`Şimdiye kadar ${s.rozet} sezon şampiyonluğun var.` : ''}</p></div>`;
  const eb = kutu.querySelector('[data-esnaf]');
  eb.addEventListener('click', async () => {
    if (!(await onayla(_autoSablon`Esnaf Kartı ${e.gun} gün için ${tamTl(e.fiyat)} karşılığında alınsın mı? ${e.hak} görünüm hakkı da hesabına eklenir.`, { baslik: _autoMetin('Esnaf Kartı'), evet: _autoMetin('Satın al'), ikon: '🎫' }))) return;
    if ((await h.eylem(eb, () => api('esnaf/al', {}))) === undefined) return;
    h.ses.seviye();
    bildir(_autoMetin('🎫 Esnaf Kartın hazır! Kolay gelsin.'));
    await h.durumYenile();
    magazaPaneli('kartlar');
  });
  const sk = kutu.querySelector('[data-sezon-kart]');
  if (sk) sk.addEventListener('click', async () => {
    if (!(await onayla(_autoSablon`Bu haftanın Sezon kartı ${tamTl(s.fiyat)} karşılığında alınsın mı? Kart sırasındaki görünüm ödülleri açılır.`, { baslik: _autoMetin('Sezon kartı'), evet: _autoMetin('Satın al'), ikon: '🏅' }))) return;
    if ((await h.eylem(sk, () => api('sezon/kart', {}))) === undefined) return;
    h.ses.seviye();
    bildir(_autoMetin('🏅 Sezon kartın açıldı!'));
    await h.durumYenile();
    magazaPaneli('kartlar');
  });
  const so = kutu.querySelector('[data-sezon-odul]');
  if (so) so.addEventListener('click', async () => {
    const r = await h.eylem(so, () => api('sezon/odul', {}));
    if (r === undefined) return;
    h.ses.seviye();
    const adlar = r.alinan.filter((x) => x.ad).map((x) => _autoMetin(x.ad));
    bildir(`🎁 ${[r.para ? tl(r.para) : '', ...adlar].filter(Boolean).join(' · ')}`);
    await h.durumYenile();
    magazaPaneli('kartlar');
  });
}

// ---------- 0.43: Kutlama: havai fişek ve kutlama ilanı ----------
async function kutlamaIcerik(kutu) {
  let k;
  try { k = await api('kutlama'); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'magaza')) return;
  const f = k.fisek, il = k.ilan;
  const ILAN_DURUM = { bekliyor: [_autoMetin('Onay bekliyor'), ''], onaylandi: [_autoMetin('Yayında'), 'iyi'], reddedildi: [_autoMetin('Reddedildi'), 'kotu'] };
  const ILAN_AD = { dogum: 'Doğum günü', acilis: 'Açılış', tebrik: 'Tebrik', evlilik: 'Evlilik', bayram: 'Bayram', diger: 'Diğer' };
  kutu.innerHTML = `<div class="kart"><h3>🎆 ${_autoHtml("Havai fişek gösterisi")}</h3>
      <p class="kucuk soluk">${_autoHtml("Mahallende herkesin aynı anda gördüğü bir havai fişek gösterisi başlat. Gösteri başlarken ilçedeki herkese adın ve kutlama nedenin duyurulur. Akşam karanlığında en güzel görünür.")}</p>
      <form id="fisek-form"><div class="bb-sureler">${['kucuk', 'buyuk'].map((t, i) => `<label><input type="radio" name="tur" value="${t}" ${i === 0 ? 'checked' : ''}><b>${t === 'buyuk' ? _autoHtml('Büyük gösteri') : _autoHtml('Küçük gösteri')}</b><small>${_autoSablon`${Math.round(f.sureler[t] / 1000)} sn`} · ${tl(f.fiyatlar[t])}</small></label>`).join('')}</div>
      <label class="alan"><span>${_autoHtml("Neden kutluyorsun?")}</span><select name="neden">${Object.entries(f.nedenler).map(([kod, ad]) => `<option value="${kod}">${esc(_autoMetin(ad))}</option>`).join('')}</select></label>
      ${f.sirada.length ? `<p class="kucuk">${_autoHtml("Sıradaki gösteriler:")} ${f.sirada.map((x) => `<span class="rozetcik">${esc(x.oyuncu)} · ${x.bas > simdi() ? sureMetni(x.bas - simdi()) : _autoHtml('şimdi')}</span>`).join(' ')}</p>` : ''}
      <button class="dugme yesil" type="submit">🎆 ${_autoHtml("Gösteriyi başlat")}</button></form></div>
    <div class="kart"><h3>🎉 ${_autoHtml("Kutlama ilanı")}</h3>
      <p class="kucuk soluk">${_autoSablon`Doğum günü, açılış, tebrik… Kısa mesajın yönetim onayından sonra 24 saat boyunca mahalle panolarında döner. Onaylanmazsa ${tl(il.fiyat)} iade edilir.`}</p>
      <form id="ilan-form"><div class="bb-simgeler">${Object.entries(il.turler).map(([kod, simge], i) => `<label title="${esc(_autoMetin(ILAN_AD[kod] || kod))}"><input type="radio" name="tur" value="${kod}" ${i === 0 ? 'checked' : ''}><i>${simge}</i></label>`).join('')}</div>
      <label class="alan"><span>${_autoHtml("Mesajın")}</span><input name="metin" maxlength="80" required placeholder="${_autoHtml("ör. İyi ki doğdun Ayşe! Nice yaşlara 🎂")}"></label>
      <button class="dugme yesil" type="submit">🎉 ${_autoSablon`İlanı gönder (${tl(il.fiyat)})`}</button></form>
      ${il.benim.length ? `<ul class="bb-liste" style="margin-top:12px">${il.benim.map((x) => `<li><span>${x.simge}</span><div><b>${esc(x.metin)}</b><small>${x.durum === 'onaylandi' && x.bitis > simdi() ? _autoSablon`${sureMetni(x.bitis - simdi())} daha panolarda` : x.neden ? esc(x.neden) : ''}</small></div><em class="rozetcik ${ILAN_DURUM[x.durum][1]}">${x.durum === 'onaylandi' && x.bitis <= simdi() ? _autoHtml('Bitti') : ILAN_DURUM[x.durum][0]}</em><span></span></li>`).join('')}</ul>` : ''}</div>`;
  const ff = kutu.querySelector('#fisek-form');
  ff.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = Object.fromEntries(new FormData(ff).entries());
    if (!(await onayla(_autoSablon`Havai fişek gösterisi ${tamTl(f.fiyatlar[v.tur])} karşılığında başlasın mı?`, { baslik: _autoMetin('Havai fişek'), evet: _autoMetin('Başlat'), ikon: '🎆' }))) return;
    const r = await h.eylem(ff.querySelector('[type=submit]'), () => api('kutlama/fisek', v));
    if (r === undefined) return;
    h.ses.seviye();
    bildir(_autoSablon`🎆 Gösterin ${sureMetni(Math.max(0, r.bas - simdi()))} sonra başlıyor! Mahalleye dön ve gökyüzüne bak.`);
    await h.durumYenile(); h.caddeYenile();
    magazaPaneli('kutlama');
  });
  const fi = kutu.querySelector('#ilan-form');
  fi.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = Object.fromEntries(new FormData(fi).entries());
    if (String(v.metin || '').trim().length < 5) return bildir(_autoMetin('Kutlama mesajı en az 5 harf olmalı.'), true);
    if (!(await onayla(_autoSablon`"${v.metin}" ilanı ${tamTl(il.fiyat)} karşılığında onaya gönderilsin mi?`, { baslik: _autoMetin('Kutlama ilanı'), evet: _autoMetin('Gönder'), ikon: '🎉' }))) return;
    if ((await h.eylem(fi.querySelector('[type=submit]'), () => api('kutlama/ilan', v))) === undefined) return;
    h.ses.seviye();
    bildir(_autoMetin('🎉 İlanın onaya gönderildi. Onaylanınca 24 saat panolarda!'));
    await h.durumYenile();
    magazaPaneli('kutlama');
  });
}

// ---------- 0.43: Bilboard reklamları ----------
const BILBOARD_RENK = [['#1B2F5B', '#FFC42E', '#0B1224'], ['#B03A2E', '#FFFFFF', '#3A0D08'], ['#13723E', '#FFE9A8', '#062614'], ['#6A1B9A', '#FFD1F2', '#1E0730'], ['#E65100', '#FFFFFF', '#3D1500'], ['#111111', '#FFD700', '#000000']];
let bilboardSecili = null, bilboardGosterilen = null;
// Caddedeki bilboarda dokunulunca: o bilboard seçili olarak Reklam Ver sekmesi açılır
export function bilboardAc(no, gosterilen) {
  bilboardSecili = no; bilboardGosterilen = gosterilen || null;
  if (location.hash === '#/magaza/reklam') magazaPaneli('reklam'); else location.hash = '#/magaza/reklam';
}
const bilboardOnizleme = ({ baslik, alt, simge, renk, veren }) => {
  const [z, y, k] = BILBOARD_RENK[renk] || BILBOARD_RENK[0];
  return `<div class="bilboard-onizleme" style="--z:${z};--y:${y};--k:${k}"><span class="bb-simge">${esc(simge || '📣')}</span><div><b>${esc(String(baslik || '').toLocaleUpperCase(document.documentElement.lang || 'tr'))}</b>${alt ? `<small>${esc(alt)}</small>` : ''}</div><em>${veren ? '@' + esc(veren) : _autoHtml('REKLAM')}</em></div>`;
};
async function bilboardIcerik(kutu) {
  let b;
  try { b = await api('bilboard'); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'magaza')) return;
  const o = h.oyuncu();
  const g = bilboardGosterilen;
  bilboardGosterilen = null;
  const secilebilir = b.panolar.filter((p) => !p.benim && p.ilkBos !== null);
  let pano = (secilebilir.find((p) => p.no === bilboardSecili) || secilebilir[0] || {}).no || null;
  bilboardSecili = null;
  const zamanMetni = (t) => t <= simdi() + 60000 ? _autoMetin('hemen') : _autoSablon`${sureMetni(t - simdi())} sonra`;
  const DURUM = { yayinda: _autoMetin('Yayında'), sirada: _autoMetin('Sırada'), bitti: _autoMetin('Bitti'), kaldirildi: _autoMetin('Kaldırıldı') };
  const durumu = (r) => r.durum === 'kaldirildi' ? 'kaldirildi' : r.bitis <= simdi() ? 'bitti' : r.baslangic > simdi() ? 'sirada' : 'yayinda';
  kutu.innerHTML = `${g ? `<div class="kart"><h3>🪧 ${_autoHtml("Bu bilboardda şu an")}</h3>${bilboardOnizleme({ ...g, veren: g.oyuncu })}
      <div class="dugme-satiri">${g.yerNo != null ? `<button class="dugme kucuk" data-bb-dukkan="${g.yerNo}">🏪 ${_autoHtml("Dükkâna git")}</button>` : ''}<button class="dugme gri kucuk" data-bb-profil="${g.oyuncuId}">👤 ${_autoHtml("Profili gör")}</button></div></div>` : ''}
    <div class="kart"><h3>📣 ${_autoHtml("Reklam Ver")}</h3>
      <p class="kucuk soluk">${_autoSablon`Caddendeki 3 bilboarddan birine reklamını koy. Her bilboardda en çok ${b.kapasite} reklam sırayla döner; bütün mahalle görür. Dolu bilboardda reklamın ilk boşalan yerden başlar.`}</p>
      ${b.panolar.length ? `<div class="bb-panolar">${b.panolar.map((p) => `<label class="bb-pano${p.benim || p.ilkBos === null ? ' kapali' : ''}"><input type="radio" name="pano" value="${p.no}" ${p.no === pano ? 'checked' : ''} ${p.benim || p.ilkBos === null ? 'disabled' : ''}>
        <b>${p.no}. ${esc(_autoMetin(p.ad))}</b><small>${_autoSablon`${p.yayinda}/${p.kapasite} dolu`}${p.sirada ? _autoSablon` · ${p.sirada} sırada` : ''}</small>
        <small>${p.benim ? _autoHtml('Burada reklamın var') : p.ilkBos === null ? _autoHtml('Dolu') : _autoSablon`Başlar: ${zamanMetni(p.ilkBos)}`}</small></label>`).join('')}</div>` : ''}
      <div id="bb-onizleme"></div>
      <form id="bb-form" class="bb-form">
        <label class="alan"><span>${_autoHtml("Başlık")}</span><input name="baslik" maxlength="28" required placeholder="${_autoHtml("ör. En taze simit bizde!")}"></label>
        <label class="alan"><span>${_autoHtml("Alt yazı (isteğe bağlı)")}</span><input name="alt" maxlength="40" placeholder="${_autoHtml("ör. Çarşı girişi, sabah 7'den beri")}"></label>
        <div class="alan"><span>${_autoHtml("Simge")}</span><div class="bb-simgeler">${b.simgeler.map((x, i) => `<label><input type="radio" name="simge" value="${x}" ${i === 0 ? 'checked' : ''}><i>${x}</i></label>`).join('')}</div></div>
        <div class="alan"><span>${_autoHtml("Renk")}</span><div class="bb-renkler">${BILBOARD_RENK.slice(0, b.renkSayi).map(([z, y], i) => `<label><input type="radio" name="renk" value="${i}" ${i === 0 ? 'checked' : ''}><i style="background:${z};color:${y}">A</i></label>`).join('')}</div></div>
        ${b.dukkanlar.length ? `<label class="alan"><span>${_autoHtml("Reklama dokunan nereye gitsin?")}</span><select name="hedef"><option value="profil">${_autoHtml("Profilim")}</option>${b.dukkanlar.map((d) => `<option value="dukkan:${d.id}">🏪 ${esc(d.ad)}</option>`).join('')}</select></label>` : ''}
        <div class="alan"><span>${_autoHtml("Süre")}</span><div class="bb-sureler">${Object.entries(b.fiyatlar).map(([gun, f], i) => `<label><input type="radio" name="gun" value="${gun}" ${i === 0 ? 'checked' : ''}><b>${gun === '1' ? _autoMetin('1 gün') : _autoSablon`${gun} gün`}</b><small>${tl(f)}</small></label>`).join('')}</div></div>
        <button class="dugme yesil" type="submit" ${pano ? '' : 'disabled'}>📣 ${_autoHtml("Reklam Ver")}</button>
        ${pano ? '' : `<p class="kucuk soluk">${_autoHtml("Şu an reklam verebileceğin boş bilboard yok.")}</p>`}
      </form></div>
    ${b.reklamlarim.length ? `<div class="kart"><h3>🗂️ ${_autoHtml("Reklamlarım")}</h3><ul class="bb-liste">${b.reklamlarim.map((r) => {
      const du = durumu(r);
      return `<li><span>${esc(r.simge)}</span><div><b>${esc(r.baslik)}</b><small>${_autoSablon`${r.pano}. bilboard`} · ${du === 'sirada' ? _autoSablon`başlar: ${zamanMetni(r.baslangic)}` : du === 'yayinda' ? _autoSablon`biter: ${sureMetni(r.bitis - simdi())} sonra` : ''}${r.neden ? ' · ' + esc(r.neden) : ''}</small></div><em class="rozetcik ${du === 'yayinda' ? 'iyi' : du === 'kaldirildi' ? 'kotu' : ''}">${DURUM[du]}</em><small>👆 ${r.tiklama}</small></li>`;
    }).join('')}</ul></div>` : ''}`;
  const f = kutu.querySelector('#bb-form');
  const oniz = () => {
    const v = Object.fromEntries(new FormData(f).entries());
    kutu.querySelector('#bb-onizleme').innerHTML = bilboardOnizleme({ baslik: v.baslik || _autoMetin('Reklam başlığın'), alt: v.alt, simge: v.simge, renk: Number(v.renk), veren: o.kullaniciAdi });
  };
  f.addEventListener('input', oniz);
  oniz();
  kutu.querySelectorAll('[name=pano]').forEach((r) => r.addEventListener('change', () => { pano = Number(r.value); }));
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = Object.fromEntries(new FormData(f).entries());
    if (String(v.baslik || '').trim().length < 3) return bildir(_autoMetin('Reklam başlığı en az 3 harf olmalı.'), true);
    const fiyat = b.fiyatlar[v.gun];
    const p = b.panolar.find((x) => x.no === pano);
    if (!p) return;
    if (!(await onayla(_autoSablon`"${v.baslik}" reklamı ${p.no}. bilboarda ${v.gun} gün için ${tamTl(fiyat)} karşılığında konsun mu?`, { baslik: _autoMetin('Reklam Ver'), evet: _autoMetin('Öde ve yayınla'), ikon: '📣' }))) return;
    const r = await h.eylem(f.querySelector('[type=submit]'), () => api('bilboard', { ...v, pano }));
    if (r === undefined) return;
    h.ses.seviye();
    bildir(r.sirada ? _autoSablon`📣 Reklamın sıraya alındı; ${zamanMetni(r.baslangic)} yayına girer.` : _autoMetin('📣 Reklamın bilboardda! Mahalle seni görüyor.'));
    await h.durumYenile();
    h.caddeYenile();
    magazaPaneli('reklam');
  });
  const bd = kutu.querySelector('[data-bb-dukkan]');
  if (bd) bd.addEventListener('click', () => { h.ses.tik(); h.dukkanaGit(Number(bd.dataset.bbDukkan)); });
  const bp = kutu.querySelector('[data-bb-profil]');
  if (bp) bp.addEventListener('click', () => { h.ses.tik(); h.profilAc(Number(bp.dataset.bbProfil)); });
}

function varlikAlFormu(x, k) {
  const alan = k.tur === 'araba'
    ? `<label class="alan"><span>${_autoHtml("Renk")}</span><div class="renk-secim">${Object.entries(x.renkler).map(([kod, [ad, hex]], i) => `<label title="${esc(ad)}"><input type="radio" name="renk" value="${kod}" ${i === 0 ? 'checked' : ''}><i style="background:${hex}"></i><small>${esc(ad)}</small></label>`).join('')}</div></label>`
    : k.tur === 'yat' ? `<label class="alan"><span>${_autoHtml("Yatına bir ad ver (isteğe bağlı)")}</span><input name="ad" maxlength="24" placeholder="ör. Mavi Rüya"></label>`
      : `<label class="alan"><span>${_autoHtml("İl")}</span><select name="il">${h.iller().slice().sort((a, b) => a.ad.localeCompare(b.ad, 'tr')).map((i) => `<option value="${i.id}" ${i.id === x.il.id ? 'selected' : ''} ${k.sart === 'istanbul' && i.id !== 34 ? 'disabled' : ''}>${esc(i.ad)}</option>`).join('')}</select></label>`;
  const p = h.panelAc({
    ikon: MARKA_SIMGE[k.tur], baslik: k.ad, alt: esc(k.not || ''), rota: 'varlik',
    govde: `<div class="kart">${alan}
      <p class="kucuk">${k.tur === 'ev' || k.tur === 'arsa' ? _autoHtml('Fiyat seçtiğin ile göre hesaplanır, üstüne %4 tapu harcı eklenir.') : k.tur === 'araba' ? _autoHtml('Fiyata ÖTV ve KDV dahildir. Arabayla sokağına park edersin.') : _autoHtml('Her ay marina bağlama ve bakım gideri çıkar.')}</p>
      <button class="dugme yesil" data-onay>${_autoHtml("Satın al")}</button> <button class="dugme gri" data-vazgec>${_autoHtml("Vazgeç")}</button></div>`,
  });
  p.querySelector('[data-vazgec]').addEventListener('click', () => varlikPaneli());
  p.querySelector('[data-onay]').addEventListener('click', async (e) => {
    const veri = { kod: k.kod };
    const r0 = p.querySelector('[name=renk]:checked'); if (r0) veri.renk = r0.value;
    const a0 = p.querySelector('[name=ad]'); if (a0) veri.ad = a0.value;
    const i0 = p.querySelector('[name=il]'); if (i0) veri.ilId = Number(i0.value);
    const r = await h.eylem(e.currentTarget, () => api('varlik/al', veri));
    if (r === undefined) return;
    h.ses.seviye();
    await h.durumYenile();
    h.caddeYenile();
    h.sertifikaGoster({ kod: r.sertifika, baslik: r.ad, seviye: h.oyuncu().seviye, kutlama: _autoSablon`🎉 ${r.ad} artık senin! Sertifikanı paylaş.` });
    // 0.43: lüks alımı mahallede havai fişekle kutla
    kart({ ikon: '🎆', baslik: _autoMetin('Mahallede kutla!'), metin: _autoMetin('Yeni alımını havai fişek gösterisiyle bütün mahalleye duyur.'), eylemAdi: _autoMetin('Havai fişek'), eylem: () => { location.hash = '#/magaza/kutlama'; }, sure: 12000 });
  });
}

// ====================================================================== Vergi Dairesi (0.38)
const VERGI_DURUM = { bekliyor: ['Ödeme bekliyor', 'uyari'], gecikti: ['Gecikti', 'tehlike'], odendi: ['Ödendi', 'iyi'], icra: ['İcrada', 'tehlike'] };
export async function vergiPaneli() {
  const o = h.oyuncu();
  const p = h.panelAc({ ikon: '🧾', baslik: _autoMetin('Vergi Dairesi'), rota: 'vergi', alt: _autoSablon`${(o.ilce && o.ilce.ad) || ''} Vergi Dairesi`, govde: yukleniyor() });
  const kutu = p.querySelector('.panel-govde');
  let x;
  try { x = await api('vergi'); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'vergi')) return;
  const k = x.kurallar;
  const dn = x.donem;
  const bekleyen = x.beyanlar.filter((b) => b.durum === 'bekliyor' || b.durum === 'gecikti');
  const satir = (b) => {
    const [dAd, dTur] = VERGI_DURUM[b.durum] || [b.durum, ''];
    const odenebilir = b.durum === 'bekliyor' || b.durum === 'gecikti';
    return `<li class="kart vergi-kart"><div class="ihale-ust"><div><b>${_autoSablon`${esc(b.donem)} tarihinde biten dönem`}</b><br><span class="kucuk soluk">${_autoHtml(b.turAdi)}</span></div><span class="rozetcik ${dTur}">${_autoHtml(dAd)}</span></div>
      <div class="bilgi-izgara">
        <div><small>${_autoSablon`KDV (%${k.kdv})`}</small><b>${tl(b.kdv)}</b></div>
        <div><small>${_autoHtml(b.turAdi)}</small><b>${tl(b.gelir)}</b></div>
        ${b.ceza ? `<div><small>${_autoHtml("Gecikme cezası")}</small><b class="kirmizi">${tl(b.ceza)}</b></div>` : ''}
        <div><small>${odenebilir ? _autoHtml('Kalan borç') : _autoHtml('Ödenen')}</small><b>${tl(odenebilir ? b.kalan : b.odenen)}</b></div>
        <div><small>${_autoHtml("Satış / alış")}</small><b>${tl(b.ciro)} / ${tl(b.alis)}</b></div>
        <div><small>${_autoHtml("Dönem kârı")}</small><b>${tl(b.kar)}</b></div>
      </div>
      ${odenebilir ? `<p class="kucuk ${b.durum === 'gecikti' ? 'kirmizi' : 'soluk'}" style="margin:6px 0">${b.sonOdeme > simdi() ? _autoSablon`Son ödeme: ${tarihSaat(b.sonOdeme)} (${sureMetni(b.sonOdeme - simdi())})` : _autoSablon`Son ödeme geçti: ${tarihSaat(b.sonOdeme)}`}</p>
        <button class="dugme yesil kucuk" data-vergi-ode="${b.id}">💳 ${_autoSablon`Öde (${tl(b.kalan)})`}</button>` : b.odemeZamani ? `<p class="kucuk soluk" style="margin:6px 0 0">${_autoSablon`Ödeme: ${tarihSaat(b.odemeZamani)}`}</p>` : ''}</li>`;
  };
  const dilim = k.dilimler.map((d, i) => {
    const alt = i ? k.dilimler[i - 1].ust : 0;
    return `<li>${d.ust ? _autoSablon`${tl(alt)} – ${tl(d.ust)}: %${d.oran}` : _autoSablon`${tl(alt)} üstü: %${d.oran}`}</li>`;
  }).join('');
  kutu.innerHTML = `
    <div class="kart"><div class="bilgi-izgara">
      <div><small>${_autoHtml("Vergi numarası")}</small><b>${esc(x.vergiNo)}</b></div>
      <div><small>${_autoHtml("Vergi dairesi")}</small><b>${esc(_autoSablon`${x.daire} Vergi Dairesi`)}</b></div>
      <div><small>${_autoHtml("Mükellefiyet")}</small><b>${_autoHtml(x.turAdi)} + KDV</b></div>
      <div><small>${_autoHtml("Toplam vergi borcu")}</small><b class="${x.borc ? 'kirmizi' : ''}">${tl(x.borc)}</b></div>
    </div>
    ${bekleyen.length > 1 ? `<button class="dugme yesil" data-vergi-ode="hepsi" style="margin-top:8px">💳 ${_autoSablon`Tüm vergi borcunu öde (${tl(x.borc)})`}</button>` : ''}</div>
    <div class="kart"><h3>${_autoSablon`📊 Bu dönem (${dn.ad} tarihinde biter)`}</h3>
      <div class="bilgi-izgara">
        <div><small>${_autoHtml("Satışlar (KDV dahil)")}</small><b>${tl(dn.ciro)}</b></div>
        <div><small>${_autoHtml("Alışlar (KDV dahil)")}</small><b>${tl(dn.alis)}</b></div>
        <div><small>${_autoHtml("Dönem kârı")}</small><b>${tl(dn.kar)}</b></div>
        <div><small>${_autoHtml("Tahmini KDV")}</small><b>${tl(dn.kdv)}</b></div>
        <div><small>${x.tur === 'sahis' ? _autoHtml('Tahmini gelir vergisi') : _autoHtml('Tahmini kurumlar vergisi')}</small><b>${tl(dn.gelir)}</b></div>
        <div><small>${_autoHtml("Dönem sonu")}</small><b><span data-geri="${dn.bitis}">${sureMetni(dn.bitis - simdi())}</span></b></div>
      </div>
      <p class="kucuk soluk" style="margin:6px 0 0">${_autoHtml("Dönem bitince beyannamen kendiliğinden düzenlenir ve sana ödeme talimatı gelir. Vergi otomatik kesilmez.")}</p></div>
    <h3>${_autoHtml("🧾 Beyannameler")}</h3>
    ${x.beyanlar.length ? `<ul class="ihale-listesi">${x.beyanlar.map(satir).join('')}</ul>` : `<div class="kart"><p class="kucuk soluk" style="margin:0">${_autoHtml("Henüz beyannamen yok. Dükkân, tesis ve pazar satışların dönem sonunda beyan edilir.")}</p></div>`}
    <div class="kart"><h3>${_autoHtml("ℹ️ Kurallar")}</h3><ul class="kural-listesi">
      <li>${_autoSablon`🧾 Vergi dönemi bir ekonomi ayıdır (30 ekonomi günü). KDV %${k.kdv}: fiyatlara dahildir; satışlarının KDV'sinden alışlarının KDV'si düşülür, artan KDV sonraki döneme devreder.`}</li>
      <li>${_autoHtml("📈 Şahıs işletmesi gelir vergisi, şirketler kurumlar vergisi öder. Vergi dönem kârına dilimli uygulanır:")}<ul>${dilim}</ul></li>
      <li>${_autoSablon`📅 Beyandan sonra ${k.odemeGun} ekonomi günü içinde ödersin; vergi kendiliğinden kesilmez.`}</li>
      <li>${_autoSablon`⚠️ Son ödemeden sonra ödenmeyen her ay için kalan verginin %${k.ceza}'i gecikme cezası eklenir.`}</li>
      <li>${_autoSablon`⚖️ ${k.icraAy} ay ödenmeyen vergi borcu icraya gider: banka mevduatların dondurulur, 3 ekonomi günü içinde ödenmezse mevduatından tahsil edilir.`}</li>
      <li>${_autoHtml("🛒 Seyyar tezgâhlar esnaf muafiyetindedir, vergi ödemez.")}</li>
      <li>${_autoHtml("🏛️ Gelir ve kurumlar vergisinin %20'si ilinin belediyesine, kalanı ve KDV ülke kasasına gider.")}</li>
    </ul></div>`;
  kutu.querySelectorAll('[data-vergi-ode]').forEach((b) => b.addEventListener('click', async () => {
    const id = b.dataset.vergiOde;
    const tutar = id === 'hepsi' ? x.borc : (x.beyanlar.find((y) => String(y.id) === id) || {}).kalan;
    if (!(await onayla(_autoSablon`${tl(tutar)} vergi ödensin mi? Para önce vadesiz hesabından, yetmezse nakdinden alınır.`, { baslik: _autoMetin('Vergi Dairesi'), evet: _autoMetin('Öde'), ikon: '🧾' }))) return;
    const r = await h.eylem(b, () => api('vergi/ode', { id }));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(_autoSablon`Vergi ödendi: ${tl(r.odenen)}. Teşekkürler!`);
    await h.durumYenile();
    vergiPaneli();
  }));
}

// ====================================================================== 0.46: Meslek odaları
const ODA_DURUM = {
  odendi: ['✅', 'Aidat ödendi', 'yesil'], bekliyor: ['⏳', 'Bu ayın aidatı alınacak', ''], borc: ['⚠️', 'Aidat ödenmedi: avantajlar askıda', 'kirmizi'],
};
const ODA_KOSUL = {
  esnaf: 'Seyyar tezgâhı ya da dükkânı olanlar üye olur.',
  ticaret: 'Limited, anonim şirket ya da holdingi, en az 3 dükkânı ya da hizmet şirketi olanlar üye olur.',
  sanayi: 'Fabrika, maden, enerji, teknoloji ya da savunma tesisi olanlar üye olur.',
};
export async function odalarPaneli() {
  const p = h.panelAc({ ikon: '🤝', baslik: _autoMetin('Meslek odaları'), rota: 'odalar', alt: _autoMetin('Esnaf, Ticaret ve Sanayi Odası'), govde: yukleniyor() });
  const kutu = p.querySelector('.panel-govde');
  let x;
  try { x = await api('odalar'); } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
  if (!hala(kutu, 'odalar')) return;
  const ASAMA = { adaylik: _autoMetin('Adaylık açık (ayın 1-7\'si)'), oylama: _autoMetin('Oylama sürüyor (ayın 8-14\'ü)'), sonuc: _autoMetin('Seçim sonuçlandı; yeni seçim gelecek ayın 1\'inde') };
  const odaKart = (o) => {
    const [dIk, dAd, dRenk] = ODA_DURUM[o.aidatDurum] || ['', '', ''];
    const s = o.secim;
    const adayListe = s.adaylar.length ? `<ul class="oda-adaylar">${s.adaylar.map((a) => `<li><b>${esc(a.ad)}</b>${a.vaat ? `<small>“${esc(a.vaat)}”</small>` : ''}
        <span class="sag">${a.oy != null ? _autoSablon`${a.oy} oy` : ''}${s.asama === 'oylama' && o.aktif && !s.oyum ? `<button class="dugme mavi kucuk" data-oda-oy="${o.kod}" data-aday="${a.id}">${_autoHtml('Oy ver')}</button>` : ''}${s.oyum === a.id ? ` <span class="rozet">${_autoHtml('Oy verdin')}</span>` : ''}</span></li>`).join('')}</ul>`
      : `<p class="soluk">${_autoHtml('Bu dönem henüz aday yok.')}</p>`;
    const adayForm = s.asama === 'adaylik' && o.aktif && !s.adayim ? (s.seviyeYeter
      ? `<div class="oda-aday-form"><input maxlength="140" placeholder="${esc(_autoMetin('Vaadin (isteğe bağlı)'))}" data-vaat="${o.kod}"><button class="dugme yesil kucuk" data-oda-aday="${o.kod}">${_autoHtml('Aday ol')}</button></div>`
      : `<p class="soluk">${_autoHtml('Aday olmak için en az 10. seviye olmalısın.')}</p>`) : '';
    return `<div class="kart oda-kart${o.uye ? ' uye' : ''}">
      <div class="oda-ust"><span class="oda-simge">${o.simge}</span><div><b>${_autoHtml(o.ad)}</b><small>${esc(x.il)} · ${_autoSablon`Bu ay ${o.uyeSayisi} üye`} · ${_autoSablon`Kasa ${tl(o.kasa)}`}</small></div></div>
      ${o.uye ? `<div class="oda-durum ${dRenk}">${dIk} ${_autoHtml(dAd)} · ${_autoSablon`Aylık aidat ${tl(o.aidat)}`}${o.aidatDurum === 'borc' ? ` <button class="dugme yesil kucuk" data-oda-aidat="${o.kod}">${_autoHtml('Aidatı öde')}</button>` : ''}</div>`
        : `<div class="oda-durum">${_autoHtml('Üye değilsin.')} ${_autoHtml(ODA_KOSUL[o.kod])}</div>`}
      <ul class="oda-avantaj">${o.avantajlar.map((a) => `<li>${_autoHtml(a)}</li>`).join('')}</ul>
      ${o.aktif ? (o.egitimAlindi ? `<p class="soluk">🎓 ${_autoHtml('Bu ayın eğitimine katıldın.')}</p>` : `<button class="dugme mavi kucuk" data-oda-egitim="${o.kod}">🎓 ${_autoSablon`Eğitime katıl (+${o.egitimTp} TP)`}</button>`) : ''}
      <div class="oda-secim"><b>🗳️ ${_autoHtml('Oda başkanı')}</b> ${o.baskan ? `<span>${esc(o.baskan.ad)} <small class="soluk">(${_autoSablon`${o.baskan.oy} oy`})</small></span>` : `<span class="soluk">${_autoHtml('henüz seçilmedi')}</span>`}
        <small class="soluk">${ASAMA[s.asama]}</small>${adayListe}${adayForm}</div>
    </div>`;
  };
  const r = x.rapor;
  const satir = (l, f) => l.length ? `<ul class="oda-rapor">${l.map(f).join('')}</ul>` : `<p class="soluk">${_autoHtml('Veri yok.')}</p>`;
  kutu.innerHTML = `<p class="soluk">${_autoHtml('Odalar her ilde ayrıdır. Üyelik işletme türünden kendiliğinden doğar; aidat her ay hesabından alınır. Başkan her ay üyelerin oyuyla seçilir.')}</p>
    ${x.odalar.map(odaKart).join('')}
    ${r ? `<div class="kart"><b>📊 ${_autoHtml('Ticaret Odası pazar raporu')}</b>
      <div class="oda-rapor-izgara"><div><small>${_autoHtml('En çok işlem (7 gün)')}</small>${satir(r.enCokIslem, (u) => `<li>${esc(_urunAdi(u.urun, u.ad))}<span>${tl(u.hacim)}</span></li>`)}</div>
      <div><small>${_autoHtml('Fiyatı yükselen')}</small>${satir(r.yukselen, (u) => `<li>${esc(_urunAdi(u.urun, u.ad))}<span class="arti">+${(u.degisim * 100).toFixed(1)}%</span></li>`)}</div>
      <div><small>${_autoHtml('Fiyatı düşen')}</small>${satir(r.dusen, (u) => `<li>${esc(_urunAdi(u.urun, u.ad))}<span class="eksi">${(u.degisim * 100).toFixed(1)}%</span></li>`)}</div></div></div>` : ''}`;
  const yap = async (b, yol, veri, mesaj) => {
    b.disabled = true;
    try { const sonuc = await api(yol, veri); bildir(typeof mesaj === 'function' ? mesaj(sonuc) : mesaj); h.durumYenile && h.durumYenile(); odalarPaneli(); }
    catch (e) { bildir(e.message, true); b.disabled = false; }
  };
  kutu.querySelectorAll('[data-oda-aidat]').forEach((b) => b.addEventListener('click', () => yap(b, 'oda/aidat', { oda: b.dataset.odaAidat }, _autoMetin('Aidat ödendi, avantajların açıldı.'))));
  kutu.querySelectorAll('[data-oda-egitim]').forEach((b) => b.addEventListener('click', () => yap(b, 'oda/egitim', { oda: b.dataset.odaEgitim }, (s) => _autoSablon`Eğitimi tamamladın: +${s.tp} TP`)));
  kutu.querySelectorAll('[data-oda-aday]').forEach((b) => b.addEventListener('click', () => yap(b, 'oda/aday', { oda: b.dataset.odaAday, vaat: (kutu.querySelector(`[data-vaat="${b.dataset.odaAday}"]`) || {}).value || '' }, _autoMetin('Adaylığın alındı. Oylama ayın 8\'inde başlar.'))));
  kutu.querySelectorAll('[data-oda-oy]').forEach((b) => b.addEventListener('click', async () => { if (!(await onayla(_autoMetin('Oyun bu dönem için kesinleşir. Emin misin?')))) return; yap(b, 'oda/oy', { oda: b.dataset.odaOy, adayId: Number(b.dataset.aday) }, _autoMetin('Oyun kaydedildi.')); }));
}

// ====================================================================== Menü: devlet ve piyasalar
export function devletMenusu() {
  const oge = [
    ['secim', '🗳️', _autoMetin('Seçimler'), _autoMetin('Belediye, meclis, cumhurbaşkanlığı')],
    ['ihale', '📑', 'Kamu ihaleleri', _autoMetin('Devlete mal sat')],
    ['borsa', '📈', 'Borsa', _autoMetin('Hisse al-sat, halka arz')],
    ['isdunyasi', '🤝', _autoMetin('İş dünyası'), _autoMetin('Reklam, sigorta, ortaklık')],
    ['varlik', '💎', _autoMetin('Lüks yaşam'), _autoMetin('Araba, yat, ev, arsa')],
    ['banka', '🏦', 'Tefon Bank', _autoMetin('Mevduat, kredi, döviz-altın')],
    ['vergi', '🧾', 'Vergi Dairesi', _autoMetin('KDV, gelir ve kurumlar vergisi')],
    ['belediye', '🏛️', _autoMetin('Belediye'), _autoMetin('Ruhsatlar ve başvurular')],
    ['odalar', '🤝', _autoMetin('Meslek odaları'), _autoMetin('Esnaf, Ticaret ve Sanayi Odası')],
  ];
  h.panelAc({
    ikon: '🏛️', baslik: _autoMetin('Devlet ve Piyasalar'), alt: _autoMetin('Seçimler, ihaleler, borsa ve daha fazlası'),
    govde: `<div class="menu-izgara">${oge.map(([r, i, a, s]) => `<a class="menu-oge" href="#/${r}"><span>${i}</span><b>${_autoHtml(a)}</b><small>${s}</small></a>`).join('')}</div>`,
  });
}
