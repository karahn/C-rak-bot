// Tek bir 3D çizici; mahalle ve harita sahneleri arasında geçiş yapar.
import * as THREE from 'three';
import { kalite, kaliteTercihi, fpsTercihi, fpsKaydet } from './kalite.js?v=0.38.0';

const mobil = matchMedia('(pointer: coarse)').matches;
let hedefFps = fpsTercihi();
export function fpsDegeri() { return hedefFps; }
export function fpsAyarla(deger) {
  hedefFps = fpsKaydet(deger);
  son = sonCizim = performance.now();
  olcumSure = olcumKare = olcumAgir = 0;
  return hedefFps;
}
let renderer = null;
let aktif = null;
let son = performance.now();
const raycaster = new THREE.Raycaster();
const fare = new THREE.Vector2();
let basma = null;
let calisiyor = true;
let baglamKayip = false;
let sonCizim = performance.now();
let kareIstegi = 0; // bekleyen tek kare isteği: döngünün ikinci kopyası asla başlamasın
// Tanıtım için: akıcılık kademesi kilitlenebilir (tanıtım sırasında çözünürlük değişip görüntü sarsılmasın)
let kademeKilit = false;
export function kademeKilitle(v, en = null) {
  kademeKilit = !!v;
  if (v && en !== null && renderer && kademe < en) kademeUygula(en);
  olcumSure = olcumKare = olcumAgir = 0;
}
function kareIste() {
  cancelAnimationFrame(kareIstegi);
  kareIstegi = requestAnimationFrame(dongu);
}

export function baslat(canvas) {
  if (renderer) {
    if (renderer.domElement !== canvas) throw new Error('3B çizici zaten başka bir yüzeyde çalışıyor.');
    return renderer;
  }
  const K = kalite();
  renderer = new THREE.WebGLRenderer({ canvas, antialias: K.kod !== 'dusuk', powerPreference: mobil ? 'default' : 'high-performance' });
  enFazlaPiksel = Math.min(window.devicePixelRatio || 1, K.piksel);
  piksel = enFazlaPiksel;
  renderer.setPixelRatio(piksel);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  // Nötr ton eşleme renkleri ACES gibi soldurmaz: cepheler, tenteler ve arabalar canlı görünür
  renderer.toneMapping = THREE.NeutralToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = K.golge;
  renderer.localClippingEnabled = true; // binaların kesit görünümü için
  // dokunmatik cihazlarda (tablet, telefon) yumuşak gölge yerine daha hafif gölge
  renderer.shadowMap.type = matchMedia('(pointer: coarse)').matches ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
  boyutla();
  window.addEventListener('resize', boyutla);

  // Kısa dokunuşu (sürükleme değil) sahneye tıklama olarak ilet
  canvas.addEventListener('pointerdown', (e) => {
    basma = { x: e.clientX, y: e.clientY, t: performance.now() };
  });
  // Dokunuş "click" olayında işlenir: pointerup'ta açılan panel, dokunmatik ekranın ardından gelen
  // "click" olayını kendi arka planına alıp hemen kapanıyordu (hayalet tıklama).
  // Dokunma süresi parmak kalkınca ölçülür (yavaş telefonda "click" geç gelse de dokunuş sayılır)
  canvas.addEventListener('pointerup', () => { if (basma) basma.bitis = performance.now(); });
  canvas.addEventListener('click', (e) => {
    if (!basma || !aktif || !aktif.tikla) return;
    const hareket = Math.hypot(e.clientX - basma.x, e.clientY - basma.y);
    const sure = (basma.bitis || performance.now()) - basma.t;
    basma = null;
    if (hareket > 12 || sure > 650) return;
    fare.x = (e.clientX / window.innerWidth) * 2 - 1;
    fare.y = -(e.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(fare, aktif.kamera);
    aktif.tikla(raycaster);
  });

  // Sekme gizlenince döngü durur, geri gelince yeniden başlar. Önceden bekleyen kare isteği iptal edilir;
  // yoksa her uygulama değişiminde ikinci bir döngü başlar ve oyun gittikçe yavaşlar.
  const donguyuAyarla = () => {
    calisiyor = !document.hidden && !baglamKayip;
    olcumSure = olcumKare = olcumAgir = 0;
    cancelAnimationFrame(kareIstegi); kareIstegi = 0;
    if (calisiyor && !elle) { son = sonCizim = performance.now(); kareIste(); }
  };
  document.addEventListener('visibilitychange', donguyuAyarla);
  canvas.addEventListener('webglcontextlost', e => {
    e.preventDefault(); baglamKayip = true; donguyuAyarla();
  });
  canvas.addEventListener('webglcontextrestored', () => {
    baglamKayip = false;
    try { aktif?.baglamYenilendi?.(); } catch (e) { donguHatasi('baglam', e); }
    donguyuAyarla();
  });

  donguyuAyarla();
  return renderer;
}

function boyutla() {
  if (!renderer) return;
  const w = window.innerWidth;
  const h = window.innerHeight;
  renderer.setSize(w, h, false);
  if (aktif) aktif.boyut(w, h);
}

export function sahneSec(s) {
  if (aktif === s) return;
  if (aktif && aktif.durdur) aktif.durdur();
  aktif = s;
  if (aktif) {
    aktif.boyut(window.innerWidth, window.innerHeight);
    if (aktif.basla) aktif.basla();
  }
}

export function aktifSahne() { return aktif; }

// İlk karede shader derlenmesi ve doku yüklenmesi yerine yükleme ekranında hazırlanır.
export async function onHazirla(s) {
  if (!renderer || !s?.sahne || !s?.kamera) return;
  await s.hazirla?.();
  s.boyut(window.innerWidth, window.innerHeight);
  s.guncelle(0, performance.now() / 1000);
  if (renderer.compileAsync) await renderer.compileAsync(s.sahne, s.kamera);
  else renderer.compile(s.sahne, s.kamera);
  renderer.toneMappingExposure = s.pozlama ?? 1.05;
  renderer.render(s.sahne, s.kamera);
  son = sonCizim = performance.now();
}

// Otomatik seçimde eski uyarlamalı çözünürlük geri gelir; manuel kaliteler sabittir.
let enFazlaPiksel = 1;
let piksel = 1;
let kademe = 0;           // 0: tam kalite … 3: en hafif
let olcumSure = 0, olcumKare = 0, olcumAgir = 0;
let kareNo = 0;
const KADEME_PIKSEL = [1, 0.85, 0.72, 0.6];
function kademeUygula(k) {
  kademe = Math.max(0, Math.min(3, k));
  const yeni = Math.min(enFazlaPiksel, Math.max(0.75, enFazlaPiksel * KADEME_PIKSEL[kademe]));
  if (Math.abs(yeni - piksel) > 0.01) {
    piksel = yeni;
    renderer.setPixelRatio(piksel);
    boyutla();
  }
}
function akicilikOlc(dtMs) {
  if (kademeKilit || kaliteTercihi() !== 'otomatik' || !aktif) {
    olcumSure = olcumKare = olcumAgir = 0;
    return;
  }
  olcumSure += dtMs;
  olcumKare++;
  if (dtMs > 1000 / hedefFps * 2) olcumAgir++;
  if (olcumSure < 2500) return;
  const fps = (olcumKare * 1000) / olcumSure;
  const agirOran = olcumAgir / olcumKare;
  if ((fps < hedefFps * .63 || agirOran > 0.2) && kademe < 3) kademeUygula(kademe + 1);
  else if (fps > hedefFps * .93 && agirOran < 0.03 && kademe > 0) kademeUygula(kademe - 1);
  olcumSure = olcumKare = olcumAgir = 0;
}
export function akicilikKademesi() { return kademe; }

// Döngüde bir hata çıkarsa oyun donmaz: sonraki kare önceden istenir, hata yakalanıp sunucuya bir kez bildirilir.
// (Eskiden tek bir hata döngüyü durduruyordu: görüntü donuyor, kamera kaymıyor, düğmeler ise çalışıyordu.)
const bildirilenHatalar = new Set();
function donguHatasi(yer, e) {
  const mesaj = (e && e.message) || String(e);
  const anahtar = yer + mesaj;
  if (bildirilenHatalar.has(anahtar) || bildirilenHatalar.size > 20) return;
  bildirilenHatalar.add(anahtar);
  console.error('[döngü]', yer, e);
  try {
    const surum = (/[?&]v=([\d.]+)/.exec(import.meta.url) || [])[1] || '';
    fetch(new URL('../api/istemci-hata', import.meta.url).href, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, keepalive: true,
      body: JSON.stringify({ yer, mesaj, yigin: (e && e.stack) || '', surum }),
    }).catch(() => {});
  } catch (x) { /* yok say */ }
}
// Çevrimdışı çekim (tanıtım videosunun üretimi, yalnızca ?deneme): döngü durur, kareler sabit adımla elle çizilir
let elle = false;
let elleT = 0;
export function elleMod(v) {
  elle = !!v;
  if (elle) { cancelAnimationFrame(kareIstegi); elleT = performance.now() / 1000; } else { son = sonCizim = performance.now(); if (calisiyor) kareIste(); }
}
export function elleKare(dt, ciz = true) {
  if (!aktif) return null;
  elleT += dt;
  kareNo++;
  aktif.guncelle(dt, elleT);
  if (!ciz) return null;
  renderer.toneMappingExposure = aktif.pozlama ?? 1.05;
  renderer.shadowMap.autoUpdate = true;
  renderer.render(aktif.sahne, aktif.kamera);
  return renderer.domElement;
}
export function pikselAyarla(p) { if (renderer) { renderer.setPixelRatio(p); boyutla(); } }

// 0.37.22: Ekranı tamamen örten (telefonda tam ekran açılan) bir pencere varken arkadaki 3B sahne görünmez.
// Bu sürede sahne saniyede 5 kez çizilir: şehir yaşamaya devam eder, ama telefon boşuna ısınmaz ve pil bitmez.
// Pencere kapanınca hemen seçilen kare hızına dönülür.
let ortuluKontrol = 0, ortulu = false;
function ekranOrtuluMu(t) {
  if (t - ortuluKontrol < 400) return ortulu;
  ortuluKontrol = t;
  ortulu = false;
  if (typeof document === 'undefined' || typeof document.getElementById !== 'function' || typeof getComputedStyle !== 'function') return false;
  const k = document.getElementById('panel-katman');
  if (!k || k.hidden) return false;
  const p = k.querySelector('.panel');
  if (!p) return false;
  const r = p.getBoundingClientRect();
  const w = window.innerWidth, h = window.innerHeight;
  // pencerenin görünen alanı ekranın en az %92'si olmalı ve arka planı saydam olmamalı
  const gorunen = Math.max(0, Math.min(r.right, w) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, h) - Math.max(r.top, 0));
  if (gorunen < w * h * 0.92) return false;
  const bg = getComputedStyle(p).backgroundColor;
  const m = /rgba?\(([^)]+)\)/.exec(bg || '');
  const a = m ? (m[1].split(',')[3] !== undefined ? Number(m[1].split(',')[3]) : 1) : 0;
  ortulu = a >= 0.95 || getComputedStyle(p).backgroundImage !== 'none';
  return ortulu;
}
export function ekranOrtulu() { return ortulu; }

function dongu(t) {
  if (!calisiyor || elle) return;
  kareIstegi = requestAnimationFrame(dongu);
  const hamDt = t - son;
  // 90/120/144 Hz ekranlarda aynı kaliteyle gereksiz kare üretimini önler.
  // Birikmiş zamanı kullanır; çekim için elleKare bu sınırdan etkilenmez.
  const aralikMs = ekranOrtuluMu(t) ? 200 : 1000 / hedefFps;
  const cizimDt = t - sonCizim;
  if (cizimDt < aralikMs - 0.5) return;
  sonCizim += Math.max(1, Math.floor((cizimDt + 0.5) / aralikMs)) * aralikMs;
  const dt = Math.min(0.25, Math.max(0, hamDt / 1000) || 0); // hareket sahnede küçük adımlara bölünür
  son = t;
  if (hamDt > 0 && hamDt < 1000 && !ortulu) akicilikOlc(hamDt);
  else if (ortulu) olcumSure = olcumKare = olcumAgir = 0;
  kareNo++;
  if (!aktif) return;
  try { aktif.guncelle(dt, t / 1000); } catch (e) { donguHatasi('guncelle', e); }
  try {
    renderer.toneMappingExposure = aktif.pozlama ?? 1.05;
    // gölge haritası: akıcılık kademesine ve sahnenin isteğine göre birkaç karede bir yenilenir
    if (aktif.golgeIstegi) {
      // sabit gölge: harita yalnızca sahne isteyince yenilenir
      renderer.shadowMap.autoUpdate = false;
      if (aktif.golgeIstegi()) renderer.shadowMap.needsUpdate = true;
    } else {
      const aralik = Math.max(mobil ? 2 : 1, aktif.golgeAralik || 1);
      renderer.shadowMap.autoUpdate = aralik === 1;
      if (aralik > 1 && kareNo % aralik === 0) renderer.shadowMap.needsUpdate = true;
    }
    renderer.render(aktif.sahne, aktif.kamera);
  } catch (e) { donguHatasi('cizim', e); }
  try { if (aktif.etiketleriGuncelle) aktif.etiketleriGuncelle(); } catch (e) { donguHatasi('etiket', e); }
}

// 3D noktayı ekran koordinatına çevirir; ekran dışındaysa null döner
const gecici = new THREE.Vector3();
export function ekranKonumu(nokta, kamera) {
  gecici.copy(nokta).project(kamera);
  if (gecici.z > 1 || gecici.z < -1) return null;
  return {
    x: (gecici.x * 0.5 + 0.5) * window.innerWidth,
    y: (-gecici.y * 0.5 + 0.5) * window.innerHeight,
  };
}

export function getRenderer() { return renderer; }

// Sahneyi ekranda göstermeden önce ısıtır: gölgelendiriciler derlenir, dokular ekran kartına yüklenir.
// (Sinematik tanıtımda sahne değişirken takılma ve boş kare olmasın diye.)
export async function isit(s) {
  if (!renderer || !s) return;
  try {
    if (renderer.compileAsync) await renderer.compileAsync(s.sahne, s.kamera);
    else renderer.compile(s.sahne, s.kamera);
    s.sahne.traverse((o) => {
      const m = o.material;
      if (!m) return;
      for (const x of Array.isArray(m) ? m : [m]) for (const k of ['map', 'normalMap', 'emissiveMap', 'roughnessMap']) if (x[k] && x[k].isTexture) renderer.initTexture(x[k]);
    });
  } catch (e) { /* ısıtma olmazsa da oyun sürer */ }
}
