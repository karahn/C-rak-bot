import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.38.0';
import { aktifDil, t, sistemMetni, sunucuMetinleri } from './dil.js?v=0.38.0';
// Ortak yardımcılar: para biçimi, sunucu istekleri, bildirimler

const SAYI_BICIMLERI=new Map();
function sayiBicimi(tur){const dil=aktifDil(),key=dil+':'+tur;if(!SAYI_BICIMLERI.has(key))SAYI_BICIMLERI.set(key,new Intl.NumberFormat(dil,tur==='compact'?{notation:'compact',maximumSignificantDigits:3}:{maximumFractionDigits:tur==='kisa'?2:0}));return SAYI_BICIMLERI.get(key);}
const TL_BICIM={format:n=>sayiBicimi('tam').format(n)};

// Büyük tutarlar kısaltılır: 1.250.000 → 1,25 Mn; 3.400.000.000 → 3,4 Mr; 2 trilyon → 2 Tn.
// Bir milyonun altı tam yazılır (25.000).
const KISA_BICIM={format:n=>sayiBicimi('kisa').format(n)};
const KISALTMALAR = [[1e12, 'Tn'], [1e9, 'Mr'], [1e6, 'Mn']];
export function sade(kurus) {
  const lira = Math.round(kurus / 100);
  const mutlak = Math.abs(lira);
  for (const [bolen, ek] of KISALTMALAR) {
    if (mutlak >= bolen) {
      const deger = lira / bolen;
      // 3 anlamlı basamak: 1,25 Mn · 12,5 Mn · 125 Mn
      const basamak = Math.abs(deger) >= 100 ? 0 : Math.abs(deger) >= 10 ? 1 : 2;
      const yuvarlak = Math.trunc(deger * 10 ** basamak) / 10 ** basamak;
      if(aktifDil()!=='tr')return sayiBicimi('compact').format(yuvarlak*bolen);
      return KISA_BICIM.format(yuvarlak) + ' ' + ek;
    }
  }
  return TL_BICIM.format(lira);
}
export function tl(kurus) {
  return sade(kurus) + ' ₺';
}
// Kısaltmasız tam tutar (onay pencereleri ve ipuçları için)
export function tamTl(kurus) {
  return TL_BICIM.format(Math.round(kurus / 100)) + ' ₺';
}
export function isaretliTl(kurus) {
  return (kurus < 0 ? '−' : '+') + tl(Math.abs(kurus));
}
export function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
export function sureMetni(ms) {
  const sn = Math.max(0, Math.ceil(ms / 1000));
  if (sn >= 86400) return t("notify.daysHours",{days:Math.floor(sn/86400),hours:Math.floor((sn%86400)/3600)});
  const sa = Math.floor(sn / 3600);
  const dk = Math.floor((sn % 3600) / 60);
  const s = sn % 60;
  if (sa > 0) return t("notify.hoursMinutes",{hours:sa,minutes:dk});
  if (dk > 0) return `${dk}:${String(s).padStart(2, '0')}`;
  return t("notify.seconds",{seconds:s});
}
export function gercekSureAdi(ms) {
  const dk = Math.round(ms / 60000);
  return dk >= 60 ? t("notify.hours",{hours:Math.round(dk/60)}) : t("notify.minutes",{minutes:dk});
}
export function nufusMetni(n) {
  if(aktifDil()!=='tr')return new Intl.NumberFormat(aktifDil(),{notation:"compact",compactDisplay:"long",maximumFractionDigits:1}).format(n);
  if (n >= 1e6) return (n / 1e6).toLocaleString('tr-TR', { maximumFractionDigits: 1 }) + ' milyon';
  if (n >= 1e3) return Math.round(n / 1e3).toLocaleString('tr-TR') + ' bin';
  return String(n);
}

// Sunucu saati ile tarayıcı saati arasındaki fark
let fark = 0;
export function farkAyarla(f) { fark = f; }
export function simdi() { return Date.now() + fark; }

export class OturumYok extends Error {}

export async function api(yol, veri) {
  const secenek = { credentials: 'same-origin', headers: {} };
  if (veri !== undefined) {
    secenek.method = 'POST';
    secenek.headers['Content-Type'] = 'application/json';
    secenek.body = JSON.stringify(veri);
  }
  let yanit;
  try {
    yanit = await fetch('api/' + yol, secenek);
  } catch (e) {
    throw new Error(sistemMetni('Sunucuya ulaşılamadı. İnternet bağlantını kontrol et.'));
  }
  let govde = null;
  try { govde = await yanit.json(); } catch (e) { /* boş yanıt */ }
  if (!yanit.ok) {
    const mesaj = sistemMetni((govde && govde.hata) || 'Bir sorun oluştu.');
    if (yanit.status === 503 && govde && govde.bakim) bakimEkrani(mesaj);
    if (yanit.status === 401 && yol !== 'giris') throw new OturumYok(mesaj);
    throw new Error(mesaj);
  }
  // sunucunun Türkçe sistem metinleri (katalog adları, açıklamalar, hareketler) oyuncunun dilinde; sohbetler gezilmez
  if (govde && typeof govde === 'object' && !/^(mesaj|sohbet|grup|konusma)/.test(yol)) { try { sunucuMetinleri(govde); } catch (e) { /* çeviri hatası oyunu durdurmaz */ } }
  return govde;
}

// Bakım ekranı: yönetim bakım modunu açınca oyuncular bu ekranı görür; birkaç dakikada bir yeniden dener
let bakimZamani = null;
function bakimEkrani(mesaj) {
  let e = document.getElementById('bakim-ekrani');
  if (!e) {
    e = document.createElement('div');
    e.id = 'bakim-ekrani';
    e.innerHTML = `<div class="bakim-kart"><div class="bakim-ikon">🛠️</div><h2>${_autoHtml("Kısa bir bakımdayız")}</h2><p data-mesaj></p><small>${_autoHtml("Sayfa birazdan kendiliğinden yenilenecek.")}</small><button class="dugme" data-yenile>${_autoHtml("🔄 Şimdi dene")}</button></div>`;
    document.body.appendChild(e);
    e.querySelector('[data-yenile]').addEventListener('click', () => location.reload());
  }
  e.querySelector('[data-mesaj]').textContent = mesaj;
  clearTimeout(bakimZamani);
  bakimZamani = setTimeout(() => location.reload(), 120000);
}

// ---------- Bildirimler ----------
// Tüm kısa uyarılar ve oyun bildirimleri aynı kutuda üst üste görünür.
// Her biri X ile kapatılabilir. Önemli olanlar (hata, uyarı, düğmeli, başarı kartları) 7 saniye, önemsizler 5 saniye
// ekranda kalır. Fare üzerindeyken süre durur (en çok 20 sn; dokunmatikte durmaz, yoksa kapanmadan kalıyordu).
// Aynı anda en fazla 3 tane görünür, fazlası sıraya girer.
const EN_FAZLA = 3;
const sira = [];
let kutu = null;
function bildirimKutusu() {
  if (kutu && document.body.contains(kutu)) return kutu;
  kutu = document.getElementById('oyun-bildirimleri');
  if (!kutu) {
    kutu = document.createElement('div');
    kutu.id = 'oyun-bildirimleri';
    kutu.setAttribute('aria-live', 'polite');
    document.body.appendChild(kutu);
  }
  return kutu;
}

function siradakiniGoster() {
  const k = bildirimKutusu();
  while (sira.length && k.querySelectorAll('.oyun-bildirim:not(.gidiyor)').length < EN_FAZLA) {
    const b = sira.shift();
    k.appendChild(b.el);
    b.baslat();
  }
}

// Kart biçiminde bildirim: { ikon, baslik, metin, eylemAdi, eylem, sure, tur: 'bilgi' | 'hata' | 'basari' }
export function kart({ ikon = 'ℹ️', baslik = '', metin = '', eylemAdi = null, eylem = null, sure = null, tur = 'bilgi', onemli = null } = {}) {
  // sistem metinleri (birebir eşleşen) oyuncunun dilinde gösterilir; oyuncu adları ve mesajları değişmez
  baslik = sistemMetni(baslik); metin = sistemMetni(metin); if (eylemAdi) eylemAdi = sistemMetni(eylemAdi);
  const el = document.createElement('div');
  el.className = 'oyun-bildirim ' + tur;
  el.setAttribute('role', tur === 'hata' ? 'alert' : 'status');
  el.innerHTML = `<span class="ob-ikon" aria-hidden="true">${ikon}</span>
    <span class="ob-yazi">${baslik ? `<b>${esc(baslik)}</b>` : ''}${baslik && metin ? '<br>' : ''}${esc(metin)}</span>
    ${eylemAdi ? `<button class="dugme kucuk ob-eylem">${esc(eylemAdi)}</button>` : ''}
    <button class="ob-kapat" aria-label="${esc(t('common.close'))}">✕</button>
    <span class="ob-sure" aria-hidden="true"></span>`;
  const agir = onemli !== null ? onemli : !!eylemAdi || ['hata', 'uyari', 'basari'].includes(tur);
  // düğmeli bildirim (ör. sipariş teklifi) kendi süresini isteyebilir; diğerleri 5 / 3,5 sn
  let kalan = eylemAdi && sure ? Math.max(5000, sure) : agir ? 5000 : 3500;
  let durmaToplam = 0;
  let zaman = null;
  let bas = 0;
  let bitti = false;
  const kapat = () => {
    if (bitti) return;
    bitti = true;
    clearTimeout(zaman);
    el.classList.add('gidiyor');
    setTimeout(() => { el.remove(); siradakiniGoster(); }, 350);
  };
  const devam = () => {
    if (bitti) return;
    bas = Date.now();
    clearTimeout(zaman);
    zaman = setTimeout(kapat, kalan);
    el.style.setProperty('--sure', kalan + 'ms');
    el.classList.remove('duraklat');
  };
  let durBas = 0;
  const dur = (e) => {
    if (bitti || (e && e.pointerType !== 'mouse') || durmaToplam > 20000) return;
    clearTimeout(zaman);
    kalan = Math.max(1500, kalan - (Date.now() - bas));
    durBas = Date.now();
    el.classList.add('duraklat');
  };
  const surdur = (e) => {
    if (bitti || (e && e.pointerType !== 'mouse')) return;
    if (durBas) { durmaToplam += Date.now() - durBas; durBas = 0; }
    devam();
  };
  el.querySelector('.ob-kapat').addEventListener('click', (e) => { e.stopPropagation(); kapat(); });
  if (eylemAdi) el.querySelector('.ob-eylem').addEventListener('click', (e) => { e.stopPropagation(); kapat(); if (eylem) eylem(); });
  el.addEventListener('pointerenter', dur);
  el.addEventListener('pointerleave', surdur);
  // güvenlik: ekrana geldikten sonra ne olursa olsun en geç 30 sn içinde kapanır
  sira.push({ el, baslat: () => { devam(); setTimeout(kapat, Math.max(30000, kalan + 25000)); } });
  siradakiniGoster();
  return { kapat };
}

// Kısa uyarı (eski kullanım korunur): bildir('metin') ya da bildir('hata metni', true)
export function bildir(metin, hata) {
  // kısa onay mesajları önemsizdir (3,5 sn), hatalar önemlidir (5 sn)
  return kart({ ikon: hata ? '⚠️' : '✅', metin, tur: hata ? 'hata' : 'basari', onemli: !!hata });
}

// ---------- Onay ve soru pencereleri (tarayıcının kendi pencereleri yerine) ----------
function pencere({ ikon, baslik, metin, evet, hayir, tehlike, girdi }) {
  baslik = sistemMetni(baslik); metin = sistemMetni(metin); evet = sistemMetni(evet); hayir = sistemMetni(hayir);
  if (girdi && girdi.ipucu) girdi = { ...girdi, ipucu: sistemMetni(girdi.ipucu) };
  return new Promise((coz) => {
    const perde = document.createElement('div');
    perde.className = 'onay-perde';
    perde.innerHTML = `<div class="onay-kutu" role="dialog" aria-modal="true">
        <div class="onay-ikon" aria-hidden="true">${ikon}</div>
        ${baslik ? `<h3>${esc(baslik)}</h3>` : ''}
        <p>${esc(metin)}</p>
        ${girdi ? `<input class="onay-girdi" maxlength="${girdi.uzunluk || 120}" placeholder="${esc(girdi.ipucu || '')}">` : ''}
        <div class="onay-dugmeler">
          <button class="dugme gri" data-c="hayir">${esc(hayir)}</button>
          <button class="dugme ${tehlike ? 'kirmizi' : 'yesil'}" data-c="evet">${esc(evet)}</button>
        </div></div>`;
    document.body.appendChild(perde);
    requestAnimationFrame(() => perde.classList.add('acik'));
    const inp = perde.querySelector('.onay-girdi');
    const bitir = (sonuc) => {
      perde.classList.remove('acik');
      document.removeEventListener('keydown', tus);
      setTimeout(() => perde.remove(), 200);
      coz(sonuc);
    };
    const evetDe = () => {
      if (inp) { const v = inp.value.trim(); if (!v) { inp.focus(); return; } bitir(v); } else bitir(true);
    };
    const tus = (e) => { if (e.key === 'Escape') bitir(inp ? null : false); if (e.key === 'Enter') evetDe(); };
    document.addEventListener('keydown', tus);
    perde.querySelector('[data-c=hayir]').addEventListener('click', () => bitir(inp ? null : false));
    perde.querySelector('[data-c=evet]').addEventListener('click', evetDe);
    perde.addEventListener('click', (e) => { if (e.target === perde) bitir(inp ? null : false); });
    setTimeout(() => (inp || perde.querySelector('[data-c=evet]')).focus(), 50);
  });
}

// Evet/hayır sorusu. Dönüş: true | false
export function onayla(metin, { baslik = '', evet = t('notify.yes'), hayir = t('notify.cancel'), tehlike = false, ikon = '❓' } = {}) {
  return pencere({ ikon, baslik, metin, evet, hayir, tehlike });
}

// Metin isteyen soru. Dönüş: yazılan metin ya da null
export function sor(metin, { baslik = '', evet = t('notify.send'), hayir = t('notify.cancel'), ipucu = '', ikon = '✍️', uzunluk = 120 } = {}) {
  return pencere({ ikon, baslik, metin, evet, hayir, girdi: { ipucu, uzunluk } });
}

// SVG ilerleme halkası
export function halkaSvg(oran, boyut, kalinlik, renk, zemin) {
  const r = (boyut - kalinlik) / 2;
  const c = 2 * Math.PI * r;
  return `<svg viewBox="0 0 ${boyut} ${boyut}" width="${boyut}" height="${boyut}">
    <circle cx="${boyut / 2}" cy="${boyut / 2}" r="${r}" fill="none" stroke="${zemin}" stroke-width="${kalinlik}"/>
    <circle cx="${boyut / 2}" cy="${boyut / 2}" r="${r}" fill="none" stroke="${renk}" stroke-width="${kalinlik}"
      stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - Math.max(0, Math.min(1, oran)))}"/>
  </svg>`;
}
