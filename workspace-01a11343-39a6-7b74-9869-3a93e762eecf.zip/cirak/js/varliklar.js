// İndirilmiş dokuları ve modelleri 3D kütüphanesine hazırlar
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const V = () => window.TEZGAH_VARLIK || {};
function adres(yol) { return V()[yol] || yol; }

const dokular = {};
const yukleyici = new THREE.TextureLoader();

async function doku(ad, renkli = true) {
  const t = await yukleyici.loadAsync(adres(`doku/${ad}.jpg`));
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  if (renkli) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

let insanGltf = null;
let insanUzakGltf = null; // uzaktaki insanlar için sadeleştirilmiş model (üçgen sayısı yarıdan az)

export async function varliklariHazirla() {
  const renkli = ['asfalt', 'parke', 'siva', 'tugla', 'cim', 'ahsap', 'kiremit'];
  const normal = ['asfalt_n', 'parke_n', 'siva_n', 'tugla_n', 'kiremit_n'];
  await Promise.all([
    ...renkli.map(async (ad) => { dokular[ad] = await doku(ad); }),
    ...normal.map(async (ad) => { dokular[ad] = await doku(ad, false); }),
    new GLTFLoader().loadAsync(adres('model/insan.glb')).then((g) => { insanGltf = g; }),
    new GLTFLoader().loadAsync(adres('model/insan-uzak.glb')).then((g) => { insanUzakGltf = g; }).catch(() => { insanUzakGltf = null; }),
  ]);
  // Doku/model çözüldü; indirme Blob kopyalarını bellekte tutma.
  for (const yol of Object.keys(V())) if (/^(doku\/|model\/)/.test(yol)) {
    URL.revokeObjectURL(V()[yol]); delete V()[yol];
  }
}

// Aynı dokuyu farklı tekrar sayısıyla kullanmak için kopyası
// Aynı doku ve tekrar için tek nesne: malzemeler paylaşılır, ekran kartına bir kez yüklenir
const dokuKopyalari = new Map();
export function dokuAl(ad, tekrarX = 1, tekrarY = 1) {
  const kaynak = dokular[ad];
  if (!kaynak) return null;
  const anahtar = ad + ':' + Math.round(tekrarX * 100) + ':' + Math.round(tekrarY * 100);
  if (dokuKopyalari.has(anahtar)) return dokuKopyalari.get(anahtar);
  const t = kaynak.clone();
  dokuKopyalari.set(anahtar, t);
  t.repeat.set(tekrarX, tekrarY);
  t.needsUpdate = true;
  return t;
}

export function insanVerisi() { return insanGltf; }
export function insanUzakVerisi() { return insanUzakGltf; }
