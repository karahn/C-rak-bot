import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.38.0';
// Müzik çalar (Winamp usulü): oyunun müzikleri ve oyuncunun kendi bilgisayarından/telefonundan seçtiği en çok 5 parça.
// Kendi parçaların sunucuya yüklenmez: tarayıcıda okunur ve yalnızca bu tarayıcının kendi deposunda (IndexedDB) saklanır.
// Çalar çalarken oyunun arka plan müziği durur, sokak müzisyenleri kısılır. Pencere kapansa da müzik sürer.
import * as ses from './ses.js?v=0.38.0';
import { esc, bildir } from './yardimci.js?v=0.38.0';

const EN_COK = 5;
const EN_BUYUK = 40 * 1024 * 1024;
const DB_ADI = 'tezgah_calar';

// ---------------------------------------------- tarayıcı deposu (IndexedDB)
function depo() {
  return new Promise((ok, red) => {
    if (!('indexedDB' in window)) return red(new Error('yok'));
    const r = indexedDB.open(DB_ADI, 1);
    r.onupgradeneeded = () => r.result.createObjectStore('parcalar', { keyPath: 'id' });
    r.onsuccess = () => ok(r.result);
    r.onerror = () => red(r.error);
  });
}
async function islem(kip, fn) {
  const db = await depo();
  return new Promise((ok, red) => {
    const t = db.transaction('parcalar', kip);
    const s = t.objectStore('parcalar');
    const r = fn(s);
    t.oncomplete = () => { ok(r && 'result' in r ? r.result : undefined); db.close(); };
    t.onerror = () => { red(t.error); db.close(); };
  });
}
const benimleriOku = () => islem('readonly', (s) => s.getAll()).catch(() => []);
const benimEkle = (p) => islem('readwrite', (s) => s.put(p));
const benimSil = (id) => islem('readwrite', (s) => s.delete(id)).catch(() => {});

// ---------------------------------------------- durum
const el = new Audio();
el.preload = 'metadata';
let oyunListesi = [];       // { id, ad, yollar }
let benimListem = [];       // { id, ad, blob, url }
let simdiki = null;         // çalan parça
let karisik = false, tekrar = 'liste'; // tekrar: 'yok' | 'liste' | 'tek'
let sekme = 'oyun';
let pencere = null, dugme = null, kareIstek = 0;
const spektrum = new Uint8Array(32);
try {
  const a = JSON.parse(localStorage.getItem('tezgah_calar_ayar') || '{}');
  karisik = !!a.karisik; if (['yok', 'liste', 'tek'].includes(a.tekrar)) tekrar = a.tekrar;
  if (a.ses != null) el.volume = Math.max(0, Math.min(1, Number(a.ses)));
} catch (e) { /* yok say */ }
const ayarKaydet = () => { try { localStorage.setItem('tezgah_calar_ayar', JSON.stringify({ karisik, tekrar, ses: el.volume })); } catch (e) { /* yok say */ } };

const tumListe = () => (simdiki && simdiki.benim ? benimListem : oyunListesi);
const sure = (s) => (Number.isFinite(s) ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}` : '-:--');

function cal(p) {
  if (!p) return;
  ses.calarBagla(el);
  simdiki = p;
  let i = 0;
  const yollar = p.benim ? [p.url] : p.yollar;
  el.onerror = () => { if (++i < yollar.length) { el.src = yollar[i]; el.play().catch(() => {}); } else { bildir(_autoSablon`"${p.ad}" çalınamadı.`, true); sonraki(true); } };
  el.src = yollar[0];
  el.play().catch(() => {});
  ciz();
}
function sonraki(otomatik = false) {
  const l = tumListe();
  if (!l.length) return;
  if (otomatik && tekrar === 'tek' && simdiki) { el.currentTime = 0; el.play().catch(() => {}); return; }
  let i = l.findIndex((x) => x.id === (simdiki && simdiki.id));
  if (karisik && l.length > 1) { let j; do { j = Math.floor(Math.random() * l.length); } while (j === i); i = j; }
  else i += 1;
  if (i >= l.length) { if (otomatik && tekrar === 'yok') { durdur(); return; } i = 0; }
  cal(l[i]);
}
function onceki() {
  if (el.currentTime > 3) { el.currentTime = 0; return; }
  const l = tumListe();
  if (!l.length) return;
  let i = l.findIndex((x) => x.id === (simdiki && simdiki.id)) - 1;
  if (i < 0) i = l.length - 1;
  cal(l[i]);
}
function durdur() {
  el.pause();
  try { el.currentTime = 0; } catch (e) { /* yok say */ }
  ciz();
}
function oynatDuraklat() {
  if (!simdiki) { const l = sekme === 'benim' ? benimListem : oyunListesi; if (l.length) cal(karisik ? l[Math.floor(Math.random() * l.length)] : l[0]); return; }
  if (el.paused) { ses.calarBagla(el); el.play().catch(() => {}); } else el.pause();
}
el.addEventListener('play', () => { ses.calarDurumu(true); ciz(); });
el.addEventListener('pause', () => { ses.calarDurumu(false); ciz(); });
el.addEventListener('ended', () => { ses.calarDurumu(false); sonraki(true); });
el.addEventListener('timeupdate', () => zamanCiz());
el.addEventListener('loadedmetadata', () => zamanCiz());

// ---------------------------------------------- kendi parçaların
async function dosyaEkle(dosyalar) {
  const l = [...dosyalar].filter((f) => /^audio\//.test(f.type) || /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|webm)$/i.test(f.name));
  if (!l.length) return bildir(_autoMetin('Bir ses dosyası seç (mp3, m4a, ogg, wav…).'), true);
  let eklenen = 0;
  for (const f of l) {
    if (benimListem.length >= EN_COK) { bildir(_autoSablon`Listende en çok ${EN_COK} parça olabilir. Yer açmak için birini çıkar.`, true); break; }
    if (f.size > EN_BUYUK) { bildir(_autoSablon`"${f.name}" çok büyük (en çok 40 MB).`, true); continue; }
    const p = { id: 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), ad: f.name.replace(/\.[^.]+$/, '').slice(0, 80), blob: f, benim: true };
    try { await benimEkle({ id: p.id, ad: p.ad, blob: f }); } catch (e) { /* depo yoksa yalnızca bu oturumda kalır */ }
    p.url = URL.createObjectURL(f);
    benimListem.push(p);
    eklenen++;
  }
  if (eklenen) { sekme = 'benim'; ciz(); ses.satinAl(); }
}
async function benimCikar(id) {
  const i = benimListem.findIndex((x) => x.id === id);
  if (i < 0) return;
  const [p] = benimListem.splice(i, 1);
  if (simdiki && simdiki.id === id) { durdur(); simdiki = null; el.removeAttribute('src'); }
  setTimeout(() => URL.revokeObjectURL(p.url), 1000);
  await benimSil(id);
  ciz();
}

// ---------------------------------------------- pencere
function ciz() {
  if (dugme) {
    dugme.classList.toggle('caliyor', !el.paused);
    dugme.setAttribute('aria-label', el.paused ? _autoMetin('Müzik çalar') : _autoSablon`Müzik çalar: ${simdiki ? simdiki.ad : ''} çalıyor`);
  }
  if (!pencere) return;
  const muzikKapali = (() => { const a = ses.sesAyarlari(); return a.kapali.muzik || a.muzik <= 0; })();
  pencere.querySelector('[data-baslik]').innerHTML = `<span>${esc(simdiki ? `${simdiki.ad} ${simdiki.benim ? _autoHtml('· Listem') : _autoHtml('· Oyunun müziği')}` : _autoMetin('Tezgâh Çalar · bir parça seç'))}</span>`;
  pencere.querySelector('[data-baslik]').classList.toggle('kayan', !!simdiki && simdiki.ad.length > 24);
  pencere.querySelector('[data-oynat]').innerHTML = el.paused ? '▶' : '❚❚';
  pencere.querySelector('[data-oynat]').setAttribute('aria-label', el.paused ? 'Çal' : 'Duraklat');
  pencere.querySelector('[data-karisik]').classList.toggle('acik', karisik);
  pencere.querySelector('[data-tekrar]').classList.toggle('acik', tekrar !== 'yok');
  pencere.querySelector('[data-tekrar]').textContent = tekrar === 'tek' ? '🔂' : '🔁';
  pencere.querySelector('[data-uyari]').hidden = !muzikKapali;
  pencere.querySelectorAll('[data-sekme]').forEach((b) => b.setAttribute('aria-selected', b.dataset.sekme === sekme));
  const l = sekme === 'benim' ? benimListem : oyunListesi;
  const ul = pencere.querySelector('[data-liste]');
  ul.innerHTML = l.length ? l.map((p, i) => `<li class="${simdiki && simdiki.id === p.id ? 'secili' : ''}"><button type="button" data-cal="${esc(p.id)}"><i>${String(i + 1).padStart(2, '0')}.</i><span>${esc(p.ad)}</span>${simdiki && simdiki.id === p.id && !el.paused ? '<b class="eq" aria-hidden="true"><s></s><s></s><s></s></b>' : ''}</button>${p.benim ? `<button type="button" class="cikar" data-cikar="${esc(p.id)}" aria-label="${esc(p.ad)} listeden çıkar">✕</button>` : ''}</li>`).join('')
    : `<li class="bos">${sekme === 'benim' ? _autoHtml('Listen boş. Aşağıdan bilgisayarından ya da telefonundan en çok 5 şarkı ekle.') : _autoHtml('Müzikler yükleniyor…')}</li>`;
  const ekle = pencere.querySelector('[data-ekle-alan]');
  ekle.hidden = sekme !== 'benim';
  pencere.querySelector('[data-sayac]').textContent = `${benimListem.length}/${EN_COK}`;
  const dolu = benimListem.length >= EN_COK;
  pencere.querySelector('[data-ekle]').toggleAttribute('disabled', dolu);
  pencere.querySelector('[data-dosya]').disabled = dolu;
  pencere.querySelector('[data-ekle]').textContent = dolu ? _autoMetin('Liste dolu (en çok 5 şarkı)') : _autoMetin('＋ Şarkı ekle');
  zamanCiz();
}
function zamanCiz() {
  if (!pencere) return;
  pencere.querySelector('[data-sure]').textContent = simdiki ? sure(el.currentTime) : '0:00';
  pencere.querySelector('[data-toplam]').textContent = simdiki ? sure(el.duration) : '';
  const cubuk = pencere.querySelector('[data-ilerleme]');
  if (!cubuk.matches(':active')) cubuk.value = el.duration ? Math.round((el.currentTime / el.duration) * 1000) : 0;
}
function spektrumCiz() {
  kareIstek = 0;
  if (!pencere) return;
  const tuval = pencere.querySelector('canvas');
  const c = tuval.getContext('2d');
  const w = tuval.width, h = tuval.height;
  c.clearRect(0, 0, w, h);
  const var_ = !el.paused && ses.calarSpektrum(spektrum);
  const n = 16, bw = w / n;
  for (let i = 0; i < n; i++) {
    const v = var_ ? spektrum[i + 1] / 255 : 0.02;
    const bh = Math.max(1, Math.round(v * h));
    const g = c.createLinearGradient(0, h, 0, 0);
    g.addColorStop(0, '#1FD65F'); g.addColorStop(0.6, '#E8E03A'); g.addColorStop(1, '#FF5A36');
    c.fillStyle = g;
    for (let y = h - bh; y < h; y += 3) c.fillRect(i * bw + 1, y, bw - 2, 2);
  }
  kareIstek = requestAnimationFrame(spektrumCiz);
}
function kapat() {
  if (!pencere) return;
  cancelAnimationFrame(kareIstek);
  pencere.classList.add('gidiyor');
  const p = pencere; pencere = null;
  setTimeout(() => p.remove(), 200);
  dugme.setAttribute('aria-expanded', 'false');
  document.removeEventListener('pointerdown', disTik, true);
}
function disTik(e) { if (pencere && !pencere.contains(e.target) && !dugme.contains(e.target)) kapat(); }
function ac() {
  if (pencere) { kapat(); return; }
  pencere = document.createElement('div');
  pencere.className = 'calar';
  pencere.setAttribute('role', 'dialog');
  pencere.setAttribute('aria-label', _autoMetin('Müzik çalar'));
  pencere.innerHTML = `
    <div class="calar-ust"><b>${_autoHtml("TEZGÂH ÇALAR")}</b><button type="button" data-kapat aria-label="${_autoHtml("Kapat")}">✕</button></div>
    <div class="calar-ekran">
      <div class="calar-sol"><span class="calar-durum" data-durum></span><b data-sure>0:00</b><small data-toplam></small></div>
      <div class="calar-sag"><div class="calar-baslik" data-baslik></div><canvas width="160" height="34" aria-hidden="true"></canvas></div>
    </div>
    <input class="calar-ilerleme" type="range" min="0" max="1000" value="0" data-ilerleme aria-label="${_autoHtml("Parçanın neresi")}">
    <div class="calar-dugmeler">
      <button type="button" data-onceki aria-label="${_autoHtml("Önceki")}">⏮</button>
      <button type="button" class="buyuk" data-oynat aria-label="${_autoHtml("Çal")}">▶</button>
      <button type="button" data-durdur aria-label="${_autoHtml("Durdur")}">⏹</button>
      <button type="button" data-sonraki aria-label="${_autoHtml("Sonraki")}">⏭</button>
      <button type="button" data-karisik aria-label="${_autoHtml("Karışık çal")}">🔀</button>
      <button type="button" data-tekrar aria-label="${_autoHtml("Tekrarla")}">🔁</button>
      <label class="calar-ses" aria-label="${_autoHtml("Ses düzeyi")}">🔈<input type="range" min="0" max="100" value="${Math.round(el.volume * 100)}" data-ses></label>
    </div>
    <p class="calar-uyari" data-uyari hidden>${_autoHtml("Oyunun müzik sesi kapalı.")} <button type="button" data-muzik-ac>${_autoHtml("Müziği aç")}</button></p>
    <div class="calar-sekmeler" role="tablist">
      <button type="button" role="tab" data-sekme="oyun">🎼 ${_autoHtml("Oyunun müzikleri")}</button>
      <button type="button" role="tab" data-sekme="benim">⭐ ${_autoHtml("Listem")} <small data-sayac></small></button>
    </div>
    <ol class="calar-liste" data-liste></ol>
    <div class="calar-ekle" data-ekle-alan hidden>
      <label class="calar-ekle-dugme"><input type="file" accept="audio/*,.mp3,.m4a,.ogg,.wav,.flac" multiple data-dosya hidden><span data-ekle>＋ ${_autoHtml("Şarkı ekle")}</span></label>
      <small>${_autoHtml("Dosyaların sunucuya yüklenmez; yalnızca bu tarayıcıda saklanır ve çalınır.")}</small>
    </div>`;
  document.body.appendChild(pencere);
  const r = dugme.getBoundingClientRect();
  if (window.innerWidth > 560) {
    pencere.style.top = (r.bottom + 8) + 'px';
    pencere.style.left = Math.max(8, Math.min(window.innerWidth - 348, r.right - 340)) + 'px';
  } else pencere.classList.add('alt');
  dugme.setAttribute('aria-expanded', 'true');
  const q = (s) => pencere.querySelector(s);
  q('[data-kapat]').addEventListener('click', kapat);
  q('[data-oynat]').addEventListener('click', oynatDuraklat);
  q('[data-durdur]').addEventListener('click', durdur);
  q('[data-sonraki]').addEventListener('click', () => sonraki());
  q('[data-onceki]').addEventListener('click', onceki);
  q('[data-karisik]').addEventListener('click', () => { karisik = !karisik; ayarKaydet(); ciz(); });
  q('[data-tekrar]').addEventListener('click', () => { tekrar = tekrar === 'liste' ? 'tek' : tekrar === 'tek' ? 'yok' : 'liste'; ayarKaydet(); ciz(); });
  q('[data-ses]').addEventListener('input', (e) => { el.volume = Number(e.target.value) / 100; ayarKaydet(); });
  q('[data-ilerleme]').addEventListener('input', (e) => { if (el.duration) el.currentTime = (Number(e.target.value) / 1000) * el.duration; });
  q('[data-muzik-ac]').addEventListener('click', () => { ses.kanalAyarla('muzik', Math.max(0.5, ses.sesAyarlari().muzik)); ciz(); });
  pencere.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { sekme = b.dataset.sekme; ciz(); }));
  q('[data-liste]').addEventListener('click', (e) => {
    const c = e.target.closest('[data-cikar]');
    if (c) { benimCikar(c.dataset.cikar); return; }
    const b = e.target.closest('[data-cal]');
    if (!b) return;
    const p = [...oyunListesi, ...benimListem].find((x) => x.id === b.dataset.cal);
    if (simdiki && p && simdiki.id === p.id) oynatDuraklat(); else cal(p);
  });
  q('[data-dosya]').addEventListener('change', (e) => { dosyaEkle(e.target.files); e.target.value = ''; });
  // sürükleyip bırakma (bilgisayarda)
  pencere.addEventListener('dragover', (e) => { e.preventDefault(); pencere.classList.add('birak'); });
  pencere.addEventListener('dragleave', () => pencere.classList.remove('birak'));
  pencere.addEventListener('drop', (e) => { e.preventDefault(); pencere.classList.remove('birak'); if (e.dataTransfer.files.length) dosyaEkle(e.dataTransfer.files); });
  setTimeout(() => document.addEventListener('pointerdown', disTik, true), 0);
  ciz();
  kareIstek = requestAnimationFrame(spektrumCiz);
}

let kuruldu = false;
export async function calarKur(d) {
  if (pencere) kapat();
  dugme = d;
  dugme.setAttribute('aria-haspopup', 'dialog');
  dugme.setAttribute('aria-expanded', 'false');
  dugme.addEventListener('click', () => { ses.tik(); ac(); });
  ciz();
  if (kuruldu) return;
  kuruldu = true;
  ses.oyunMuzikleri().then((l) => { oyunListesi = l.map((p, i) => ({ ...p, id: 'o' + i })); ciz(); });
  const b = await benimleriOku();
  benimListem = b.slice(0, EN_COK).map((p) => ({ ...p, benim: true, url: URL.createObjectURL(p.blob) }));
  ciz();
}
