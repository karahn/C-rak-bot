// Giriş ve kayıt ekranının sinematik arka planı: gün batımında bir Türk sahil şehri.
// Mor-pembe-turuncu gökyüzü, çizgili dev güneş, camili ve kuleli uzak siluet, asma köprü, vapur, martılar,
// ışıkları yanan apartmanlar ve neon tabelalar, önde ampullü çarşı ve simit tezgâhı.
// Tamamı SVG ve CSS ile çizilir (resim dosyası yok); fare ya da parmakla hafif derinlik (paralaks) verir.

// Aynı şehir her açılışta aynı görünsün diye tohumlu rastgele sayı
function tohumlu(t) {
  let s = t >>> 0;
  return () => { s = (s + 0x6D2B79F5) >>> 0; let r = Math.imul(s ^ (s >>> 15), 1 | s); r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r; return ((r ^ (r >>> 14)) >>> 0) / 4294967296; };
}

// Cami: orta kubbe, yarım kubbeler, minareler
function cami(x, y, o, renk) {
  const k = [];
  k.push(`<rect x="${x - 70 * o}" y="${y - 40 * o}" width="${140 * o}" height="${40 * o}"/>`);
  k.push(`<path d="M${x - 55 * o} ${y - 40 * o} A${55 * o} ${50 * o} 0 0 1 ${x + 55 * o} ${y - 40 * o}Z"/>`);
  k.push(`<rect x="${x - 2 * o}" y="${y - 108 * o}" width="${4 * o}" height="${20 * o}"/>`);
  for (const s of [-1, 1]) {
    k.push(`<path d="M${x + s * 95 * o} ${y - 25 * o} A${32 * o} ${30 * o} 0 0 ${s > 0 ? 1 : 0} ${x + s * 35 * o} ${y - 25 * o}Z"/>`);
    k.push(`<rect x="${x + s * 60 * o - 22 * o}" y="${y - 25 * o}" width="${44 * o}" height="${25 * o}"/>`);
    for (const m of [120, 150]) {
      const mx = x + s * m * o;
      k.push(`<rect x="${mx - 4 * o}" y="${y - 150 * o}" width="${8 * o}" height="${150 * o}"/>`);
      k.push(`<path d="M${mx - 6 * o} ${y - 150 * o} L${mx} ${y - 185 * o} L${mx + 6 * o} ${y - 150 * o}Z"/>`);
      k.push(`<rect x="${mx - 7 * o}" y="${y - 110 * o}" width="${14 * o}" height="${4 * o}"/>`);
    }
  }
  return `<g fill="${renk}">${k.join('')}</g>`;
}
// Tarihi kule (silindir gövde, konik külah)
function kule(x, y, o, renk) {
  return `<g fill="${renk}"><rect x="${x - 18 * o}" y="${y - 150 * o}" width="${36 * o}" height="${150 * o}"/>
    <rect x="${x - 22 * o}" y="${y - 160 * o}" width="${44 * o}" height="${12 * o}"/>
    <path d="M${x - 20 * o} ${y - 160 * o} L${x} ${y - 215 * o} L${x + 20 * o} ${y - 160 * o}Z"/></g>`;
}

function uzakSiluet(r) {
  const renk = '#6A1E7E';
  const k = [];
  // alçak evler
  let x = -40;
  while (x < 1640) {
    const w = 30 + r() * 60;
    const h = 20 + r() * 50;
    k.push(`<rect x="${x.toFixed(0)}" y="${(560 - h).toFixed(0)}" width="${w.toFixed(0)}" height="${h.toFixed(0)}" fill="${renk}"/>`);
    if (r() < 0.4) k.push(`<path d="M${x.toFixed(0)} ${(560 - h).toFixed(0)} L${(x + w / 2).toFixed(0)} ${(545 - h).toFixed(0)} L${(x + w).toFixed(0)} ${(560 - h).toFixed(0)}Z" fill="${renk}"/>`);
    x += w;
  }
  k.push(cami(300, 560, 1.15, renk));
  k.push(kule(640, 560, 1.0, renk));
  k.push(cami(930, 560, 0.8, renk));
  return k.join('');
}

function kopru() {
  const renk = '#55136B';
  const k = [`<rect x="1080" y="532" width="560" height="7" fill="${renk}"/>`];
  for (const tx of [1200, 1480]) {
    k.push(`<rect x="${tx - 7}" y="400" width="14" height="160" fill="${renk}"/><rect x="${tx - 12}" y="420" width="24" height="5" fill="${renk}"/><rect x="${tx - 12}" y="470" width="24" height="5" fill="${renk}"/>`);
  }
  k.push(`<path d="M1060 530 Q1130 525 1200 402 Q1340 520 1480 402 Q1550 520 1640 525" stroke="${renk}" stroke-width="4" fill="none"/>`);
  for (let i = 0; i < 26; i++) {
    const x = 1210 + i * 10.5;
    const t = (x - 1200) / 280;
    const y = 402 + 118 * 4 * t * (1 - t) * 0.98;
    k.push(`<line x1="${x.toFixed(1)}" y1="${y.toFixed(1)}" x2="${x.toFixed(1)}" y2="532" stroke="${renk}" stroke-width="1.2"/>`);
  }
  // köprü ışıkları
  for (let i = 0; i < 18; i++) k.push(`<circle class="gs-kopru-isik" style="animation-delay:${(i * 0.18).toFixed(2)}s" cx="${1090 + i * 31}" cy="531" r="2.4" fill="#FFE1A8"/>`);
  return k.join('');
}

const NEONLAR = [['SİMİT', '#FF4FB3'], ['BAKKAL', '#35F2FF'], ['7/24', '#FFD23F'], ['ÇAY', '#7CFF6B'], ['KEBAP', '#FF6B3D'], ['BERBER', '#B69CFF'], ['BÜFE', '#35F2FF'], ['EMLAK', '#FF4FB3']];

function yakinSehir(r) {
  const k = [];
  const pencereler = [];
  const neonlar = [];
  let x = -30;
  let n = 0;
  while (x < 1640) {
    const w = 110 + r() * 110;
    const h = 170 + r() * 190;
    const y = 900 - h;
    const ton = ['#24093F', '#2C0B4D', '#1E0735', '#330E56'][Math.floor(r() * 4)];
    k.push(`<rect x="${x.toFixed(0)}" y="${y.toFixed(0)}" width="${(w - 6).toFixed(0)}" height="${h.toFixed(0)}" fill="${ton}"/>`);
    // çatı: kiremit üçgen ya da düz, üstünde anten veya su deposu
    if (r() < 0.5) k.push(`<path d="M${(x - 4).toFixed(0)} ${y.toFixed(0)} L${(x + w / 2).toFixed(0)} ${(y - 22).toFixed(0)} L${(x + w - 2).toFixed(0)} ${y.toFixed(0)}Z" fill="${ton}"/>`);
    else k.push(`<rect x="${(x + w * 0.2).toFixed(0)}" y="${(y - 26).toFixed(0)}" width="3" height="26" fill="${ton}"/><rect x="${(x + w * 0.6).toFixed(0)}" y="${(y - 16).toFixed(0)}" width="26" height="16" rx="4" fill="${ton}"/>`);
    // pencereler
    for (let py = y + 18; py < 830; py += 30) {
      for (let px = x + 12; px < x + w - 24; px += 26) {
        if (r() < 0.55) {
          const c = r() < 0.7 ? '#FFD68A' : r() < 0.5 ? '#FF9EC7' : '#8CF3FF';
          pencereler.push(`<rect class="${r() < 0.12 ? 'gs-pencere' : ''}" style="animation-delay:${(r() * 6).toFixed(1)}s" x="${px.toFixed(0)}" y="${py.toFixed(0)}" width="12" height="16" rx="1.5" fill="${c}" opacity="${(0.55 + r() * 0.45).toFixed(2)}"/>`);
        }
      }
    }
    // zemin katta neon tabela
    if (n % 2 === 0) {
      const [yazi, renk] = NEONLAR[(n / 2) % NEONLAR.length];
      const tw = Math.min(w - 26, 20 + yazi.length * 17);
      const tx = x + (w - 6 - tw) / 2;
      neonlar.push(`<g class="gs-neon" style="animation-delay:${(r() * 5).toFixed(1)}s">
        <rect x="${tx.toFixed(0)}" y="822" width="${tw.toFixed(0)}" height="34" rx="8" fill="none" stroke="${renk}" stroke-width="3"/>
        <text x="${(tx + tw / 2).toFixed(0)}" y="846" fill="${renk}" font-family="Anton, Impact, sans-serif" font-size="22" text-anchor="middle" letter-spacing="1">${yazi}</text></g>`);
    }
    x += w;
    n++;
  }
  return { binalar: k.join(''), pencereler: pencereler.join(''), neonlar: neonlar.join('') };
}

// Caddenin üstüne gerilmiş renkli ampul zinciri
function ampulZinciri(x1, y1, x2, y2, sarkma, r) {
  const k = [`<path d="M${x1} ${y1} Q${(x1 + x2) / 2} ${(y1 + y2) / 2 + sarkma * 2} ${x2} ${y2}" stroke="#12051F" stroke-width="2.5" fill="none"/>`];
  const RENK = ['#FFD23F', '#FF4FB3', '#35F2FF', '#7CFF6B', '#FF6B3D'];
  for (let i = 1; i < 22; i++) {
    const t = i / 22;
    const x = (1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * ((x1 + x2) / 2) + t * t * x2;
    const y = (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * ((y1 + y2) / 2 + sarkma * 2) + t * t * y2;
    k.push(`<circle class="gs-ampul" style="animation-delay:${(r() * 3).toFixed(2)}s" cx="${x.toFixed(1)}" cy="${(y + 6).toFixed(1)}" r="5" fill="${RENK[i % RENK.length]}"/>`);
  }
  return k.join('');
}

export function sahneSvg() {
  const r = tohumlu(1453);
  const sehir = yakinSehir(r);
  const yildizlar = Array.from({ length: 70 }, () => `<circle class="gs-yildiz" style="animation-delay:${(r() * 4).toFixed(1)}s" cx="${(r() * 1600).toFixed(0)}" cy="${(r() * 260).toFixed(0)}" r="${(0.6 + r() * 1.4).toFixed(1)}" fill="#fff"/>`).join('');
  const yansimalar = Array.from({ length: 16 }, (_, i) => `<rect class="gs-yansima" style="animation-delay:${(i * 0.35).toFixed(2)}s" x="${(1020 + (r() - 0.5) * 120 - (40 + i * 5)).toFixed(0)}" y="${575 + i * 8}" width="${(80 + i * 10 + r() * 40).toFixed(0)}" height="3" rx="1.5" fill="#FFD7A0"/>`).join('');
  return `<svg class="gs-svg" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMax slice" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="gsGok" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#1A0B3B"/><stop offset=".32" stop-color="#5B1A8E"/><stop offset=".52" stop-color="#C2308F"/>
      <stop offset=".64" stop-color="#FF5E7E"/><stop offset=".72" stop-color="#FF9A4D"/><stop offset=".8" stop-color="#FFC876"/>
    </linearGradient>
    <linearGradient id="gsGunes" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF3B0"/><stop offset=".55" stop-color="#FFB25E"/><stop offset="1" stop-color="#FF4F8B"/></linearGradient>
    <linearGradient id="gsDeniz" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C73C9A"/><stop offset=".5" stop-color="#5E1E8C"/><stop offset="1" stop-color="#23093F"/></linearGradient>
    <clipPath id="gsGunesKes"><rect x="0" y="0" width="1600" height="560"/></clipPath>
    <filter id="gsParilti" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <radialGradient id="gsHale" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFD68A" stop-opacity=".9"/><stop offset="1" stop-color="#FFD68A" stop-opacity="0"/></radialGradient>
  </defs>
  <rect width="1600" height="900" fill="url(#gsGok)"/>
  <g class="gs-yildizlar">${yildizlar}</g>
  <g class="gs-katman" data-derinlik="0.2">
    <g clip-path="url(#gsGunesKes)" class="gs-gunes">
      <circle cx="1020" cy="470" r="175" fill="url(#gsGunes)"/>
      ${Array.from({ length: 9 }, (_, i) => `<rect x="840" y="${470 + i * 13}" width="360" height="${2 + i * 1.2}" fill="#C2308F" opacity=".85"/>`).join('')}
    </g>
    <g class="gs-bulut"><path d="M-60 300 q80 -30 160 -5 q60 -30 140 0 q50 -15 100 10 l0 12 h-400z" fill="#FF8FB1" opacity=".35"/></g>
    <g class="gs-bulut iki"><path d="M1200 230 q90 -30 170 -5 q70 -28 150 2 l0 12 h-320z" fill="#FFB38A" opacity=".3"/></g>
  </g>
  <g class="gs-katman" data-derinlik="0.35">${uzakSiluet(r)}${kopru()}</g>
  <rect x="0" y="558" width="1600" height="160" fill="url(#gsDeniz)"/>
  <g class="gs-yansimalar">${yansimalar}</g>
  <g class="gs-vapur">
    <path d="M0 0 h120 l-12 16 h-96z" fill="#1B0633"/><rect x="22" y="-18" width="70" height="18" rx="2" fill="#1B0633"/>
    <rect x="46" y="-32" width="12" height="14" fill="#1B0633"/>
    ${Array.from({ length: 6 }, (_, i) => `<rect x="${28 + i * 10}" y="-13" width="6" height="6" fill="#FFD68A"/>`).join('')}
  </g>
  <g class="gs-martilar">
    ${[[0, 0, 1], [40, -18, 0.8], [80, 8, 0.9], [-30, 30, 0.7]].map(([x, y, o], i) => `<path class="gs-marti" style="animation-delay:${i * 0.2}s" transform="translate(${x} ${y}) scale(${o})" d="M-14 0 Q-7 -8 0 0 Q7 -8 14 0" stroke="#2A0A45" stroke-width="3" fill="none" stroke-linecap="round"/>`).join('')}
  </g>
  <g class="gs-katman" data-derinlik="0.6">
    ${sehir.binalar}${sehir.pencereler}
    <g filter="url(#gsParilti)">${sehir.neonlar}</g>
  </g>
  <g class="gs-katman" data-derinlik="1">
    ${ampulZinciri(-20, 640, 820, 610, 40, r)}${ampulZinciri(820, 610, 1640, 650, 45, r)}
    <!-- sokak lambaları -->
    ${[120, 1480].map((x) => `<g fill="#12051F"><rect x="${x - 4}" y="640" width="8" height="260"/><path d="M${x} 650 q0 -26 34 -26 h14 v10 h-14 q-24 0 -24 16z"/><rect x="${x + 36}" y="630" width="24" height="10" rx="3"/></g>
      <circle cx="${x + 48}" cy="648" r="46" fill="url(#gsHale)" class="gs-lamba"/>`).join('')}
    <!-- simit tezgâhı ve simitçi -->
    <g fill="#12051F" transform="translate(250 760)">
      <rect x="0" y="40" width="150" height="10"/><rect x="10" y="50" width="8" height="90"/><rect x="132" y="50" width="8" height="90"/>
      <rect x="-6" y="0" width="162" height="42" rx="6"/><path d="M-20 -60 h190 l-18 -40 h-154z"/>
      <circle cx="195" cy="10" r="18"/><path d="M175 140 l6 -110 q14 -16 28 0 l6 110z"/>
    </g>
    <g fill="#FFB25E" transform="translate(250 760)" filter="url(#gsParilti)">
      ${[20, 50, 80, 110].map((x) => `<circle cx="${x}" cy="18" r="11" fill="none" stroke="#FFB25E" stroke-width="6"/>`).join('')}
    </g>
    <!-- duvarda oturan kedi -->
    <g fill="#12051F" transform="translate(1180 800)"><rect x="-80" y="30" width="260" height="70"/>
      <ellipse cx="40" cy="18" rx="22" ry="14"/><circle cx="60" cy="4" r="10"/><path d="M53 -4 l3 -10 l5 8z M63 -4 l4 -10 l3 9z"/><path d="M18 22 q-26 -4 -24 -30" stroke="#12051F" stroke-width="5" fill="none"/></g>
  </g>
</svg>`;
}

let kok = null;
let paralaks = null;
export function girisSahnesiKur(hedef = document.body) {
  if (kok) return kok;
  kok = document.createElement('div');
  kok.id = 'giris-sahnesi';
  kok.setAttribute('aria-hidden', 'true');
  kok.innerHTML = sahneSvg() + '<div class="gs-gren"></div><div class="gs-karartma"></div>';
  hedef.prepend(kok);
  document.body.classList.add('giris-modu');
  const katmanlar = [...kok.querySelectorAll('.gs-katman')];
  let hx = 0; let hy = 0; let x = 0; let y = 0; let istek = 0;
  const hareket = (e) => {
    const p = e.touches ? e.touches[0] : e;
    hx = (p.clientX / window.innerWidth - 0.5) * 2;
    hy = (p.clientY / window.innerHeight - 0.5) * 2;
  };
  const adim = () => {
    x += (hx - x) * 0.05;
    y += (hy - y) * 0.05;
    for (const k of katmanlar) {
      const dr = Number(k.dataset.derinlik);
      k.setAttribute('transform', `translate(${(-x * 22 * dr).toFixed(2)} ${(-y * 10 * dr).toFixed(2)})`);
    }
    istek = requestAnimationFrame(adim);
  };
  window.addEventListener('pointermove', hareket);
  istek = requestAnimationFrame(adim);
  paralaks = () => { cancelAnimationFrame(istek); window.removeEventListener('pointermove', hareket); };
  return kok;
}

export function girisSahnesiKaldir() {
  if (!kok) return;
  if (paralaks) paralaks();
  const k = kok;
  kok = null;
  document.body.classList.remove('giris-modu');
  k.classList.add('gidiyor');
  setTimeout(() => k.remove(), 600);
}
