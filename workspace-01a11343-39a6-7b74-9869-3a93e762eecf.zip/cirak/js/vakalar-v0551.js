import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.55.1';
import { t, urunAdi as _urunAdi } from './dil.js?v=0.55.1';
// 0.55: Olaylar — oyuncunun kendi işine özel beklenmedik anlar (yangın, hırsız, fenalaşan müşteri, toplu sipariş,
// talep dalgası), telefonla doğru numarayı arama, ilk yardım ritim oyunu, mahalle itibarı, dükkân güvenliği,
// mezat (icra malı açık artırma) ve mahalle projeleri. Gelen olay ekranın üstünde telefon kartı olarak belirir.
import { api, tl, esc, simdi, bildir, sureMetni, sayiDili } from './yardimci.js?v=0.55.1';

let h = null;
export function vakaKur(yard) {
  h = yard;
  // olaylar /durum dışında da gelsin: oyun açıkken 45 saniyede bir hafif yoklama (sekme gizliyse atlanır)
  clearInterval(yoklamaZamani);
  yoklamaZamani = setInterval(() => {
    if (document.hidden || !h.genel || !h.genel()) return;
    api('vaka/durum').then((v) => vakaDurum(v)).catch(() => {});
  }, 45000);
}
let yoklamaZamani = null;

const SIMGE = { yangin: '🔥', hirsiz: '🦹', kriz: '🚑', siparis: '📦', talep: '📈' };
const BASLIK = {
  yangin: 'Dükkânında yangın çıktı!', hirsiz: 'Dükkânına hırsız girdi!', kriz: 'Bir müşteri fenalaştı!', siparis: 'Toplu sipariş geldi', talep: 'Talep dalgası',
};
const KIMI_ARA = { yangin: 'İtfaiyeyi ara!', hirsiz: 'Polisi ara!', kriz: 'Ambulans çağır!' };
const SEBEP = {
  dugun: 'düğün', nisan: 'nişan', sunnet: 'sünnet düğünü', mevlit: 'mevlit', okul: 'okul gezisi', sirket: 'şirket yemeği', kina: 'kına gecesi', acilis: 'dükkân açılışı',
  soguk: 'Hava soğuyor', sicak: 'Sıcak dalgası geliyor', yagmur: 'Sağanak yağış bekleniyor', mac: 'Bu akşam derbi var', bayram: 'Bayram alışverişi başladı', pazar: 'Pazar günü kalabalığı', karne: 'Karne günü', konser: 'Mahallede konser var',
};
const PROJE_AD = { park: 'Park yenileme', cesme: 'Mahalle çeşmesi', aydinlatma: 'Sokak aydınlatması', okul: 'Okul boyama', kutuphane: 'Kütüphaneye kitap', kaldirim: 'Kaldırım onarımı', cami: 'Cami halısı', spor: 'Spor sahası' };
const BAND = { saygin: ['Saygın esnaf', '#1FA25A'], iyi: ['İyi tanınıyor', '#3A8EDB'], orta: ['Orta', '#E8A23A'], kotu: ['Kötü şöhret', '#D9483B'] };
const NEDEN = {
  yangin_iyi: 'Yangını zamanında haber verdin', yangin_kotu: 'Yangına geç kalındı', hirsiz_iyi: 'Hırsızın yakalanmasını sağladın', hirsiz_alarm: 'Alarm hırsızı yakalattı',
  hirsiz_kotu: 'Hırsız kaçtı', kriz_iyi: 'Hayat kurtardın', kriz_orta: 'Ambulans çağırdın', kriz_kotu: 'Yardım etmedin', siparis_iyi: 'Siparişi zamanında teslim ettin',
  siparis_kotu: 'Siparişe yetişemedin', proje_bagis: 'Mahalle projesine bağış',
};

const gorulen = new Set(JSON.parse(sessionStorage.getItem('tezgah_vaka_gorulen') || '[]'));
function gorulduYap(id) { gorulen.add(id); try { sessionStorage.setItem('tezgah_vaka_gorulen', JSON.stringify([...gorulen].slice(-50))); } catch (e) { /* yok say */ } }
let sonDurum = null;

// ---------------------------------------------------------------- Durum yoklamasından
export function vakaDurum(v) {
  sonDurum = v || null;
  const r = document.getElementById('vaka-rozet');
  const n = v ? v.acik.filter((x) => ['acik', 'kabul', 'yardim'].includes(x.durum)).length : 0;
  if (r) { r.hidden = !n; r.textContent = String(n); }
  const dg = document.getElementById('vaka-dugme');
  if (dg) dg.classList.toggle('caliyor', !!(v && v.acik.some((x) => x.durum === 'acik' && ['yangin', 'hirsiz', 'kriz'].includes(x.tur))));
  if (!v) return;
  for (const x of v.acik) {
    if (gorulen.has(x.id)) continue;
    if (!(x.durum === 'acik' || (x.tur === 'talep' && x.durum === 'aktif'))) continue;
    gorulduYap(x.id);
    gelenKart(x);
    break;
  }
}

const buyukHarf = (s) => (s ? s.charAt(0).toLocaleUpperCase(sayiDili()) + s.slice(1) : s);
function aciklama(x) {
  const v = x.veri || {};
  if (x.tur === 'yangin') return _autoSablon`${esc(v.isletmeAd || '')}: arka depodan duman yükseliyor. Raftaki mal yanmadan haber ver.`;
  if (x.tur === 'hirsiz') return _autoSablon`${esc(v.isletmeAd || '')}: kepenk zorlandı, biri kasayı karıştırıyor.`;
  if (x.tur === 'kriz') return v.yer === 'dukkan' ? _autoSablon`${esc(v.isletmeAd || '')} önünde bir müşteri yere yığıldı. Ambulans gelene kadar ilk yardım yap.` : _autoHtml('Tezgâhının önünde bir müşteri yere yığıldı. Ambulans gelene kadar ilk yardım yap.');
  if (x.tur === 'siparis' && v.prim) return _autoSablon`${buyukHarf(_autoMetin(SEBEP[v.sebep] || ''))} için ${v.miktar} ${esc(v.birim || '')} ${esc(_urunAdi(v.urunAd || ''))} istiyorlar. Birim ${tl(v.birimFiyat)} (piyasanın %35 üstü) + teslim primi ${tl(v.prim)}, toplam ${tl(v.tutar)}. ${esc(v.isletmeAd || '')} rafından 3 saat içinde teslim.`;
  if (x.tur === 'siparis') return _autoSablon`${buyukHarf(_autoMetin(SEBEP[v.sebep] || ''))} için ${v.miktar} ${esc(v.birim || '')} ${esc(_urunAdi(v.urunAd || ''))} istiyorlar. Birim ${tl(v.birimFiyat)} (piyasanın %35 üstü), toplam ${tl(v.tutar)}. ${esc(v.isletmeAd || '')} rafından 3 saat içinde teslim.`;
  if (x.tur === 'talep') return _autoSablon`${_autoMetin(SEBEP[v.sebep] || '')}: önümüzdeki 2 saat ${(v.urunAdlari || []).map((a) => esc(_urunAdi(a))).join(', ')} çok aranacak. Raflarını doldur.`;
  return '';
}

// ---------------------------------------------------------------- Gelen olay kartı (telefon görünümü)
let kartEl = null, kartZaman = null;
function kartKapat() { if (kartEl) { kartEl.remove(); kartEl = null; } clearInterval(kartZaman); }
function gelenKart(x) {
  kartKapat();
  const acil = ['yangin', 'hirsiz', 'kriz'].includes(x.tur);
  if (acil) h.ses.telefonZili && h.ses.telefonZili(); else h.ses.mesaj();
  kartEl = document.createElement('div');
  kartEl.className = 'vaka-kart' + (acil ? ' acil' : '');
  kartEl.setAttribute('role', 'alertdialog');
  kartEl.innerHTML = `<div class="vk-ust"><span class="vk-simge">${SIMGE[x.tur]}</span><div><b>${_autoHtml(BASLIK[x.tur])}</b>${acil ? `<small>${_autoHtml(KIMI_ARA[x.tur])}</small>` : ''}</div><em class="vk-sure" data-sure></em></div>
    <p>${aciklama(x)}</p>
    <div class="vk-dugmeler">${acil ? `<button class="dugme yesil" data-ara>📞 ${_autoHtml('Ara')}</button>`
    : x.tur === 'siparis' ? `<button class="dugme yesil" data-kabul>✅ ${_autoHtml('Kabul et')}</button><button class="dugme gri" data-ret>${_autoHtml('Reddet')}</button>`
      : `<button class="dugme mavi" data-dukkan>🏪 ${_autoHtml('Dükkânıma git')}</button>`}<button class="dugme gri" data-sonra>${_autoHtml(x.tur === 'talep' ? 'Tamam' : 'Sonra')}</button></div>`;
  document.body.appendChild(kartEl);
  const sure = kartEl.querySelector('[data-sure]');
  const tik = () => { const k = Math.max(0, x.son - simdi()); if (sure) sure.textContent = x.tur === 'talep' ? sureMetni(k) : saatDk(k); if (k <= 0 && x.tur !== 'talep') kartKapat(); };
  tik(); kartZaman = setInterval(tik, 1000);
  kartEl.querySelector('[data-sonra]').addEventListener('click', () => { h.ses.tik(); kartKapat(); });
  kartEl.querySelector('[data-ara]')?.addEventListener('click', () => { kartKapat(); telefon(x); });
  kartEl.querySelector('[data-kabul]')?.addEventListener('click', (e) => siparisCevap(x, true, e.currentTarget));
  kartEl.querySelector('[data-ret]')?.addEventListener('click', (e) => siparisCevap(x, false, e.currentTarget));
  kartEl.querySelector('[data-dukkan]')?.addEventListener('click', () => { kartKapat(); location.hash = '#/tezgahlar'; });
}
const saatDk = (ms) => { const s = Math.ceil(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

async function siparisCevap(x, kabul, b) {
  const r = await h.eylem(b, () => api(`vaka/${x.id}/siparis`, { kabul }));
  if (r === undefined) return;
  kartKapat();
  h.ses.tik();
  bildir(kabul ? _autoMetin('Sipariş kabul edildi. Rafında yeterli mal olunca Olaylar ekranından teslim et.') : _autoMetin('Siparişi geri çevirdin.'));
  yenile();
}

// ---------------------------------------------------------------- Telefon tuş takımı
function telefon(x) {
  const k = document.createElement('div');
  k.className = 'vaka-perde';
  k.innerHTML = `<div class="telefon" role="dialog" aria-label="${esc(_autoMetin('Telefon'))}">
    <div class="tf-ekran"><small>${_autoHtml(KIMI_ARA[x.tur] || '')}</small><output data-no></output><em data-sure></em></div>
    <p class="tf-ipucu" data-ipucu hidden>${_autoHtml('İtfaiye 110 · Polis 155 · Ambulans 112')}</p>
    <div class="tf-tuslar">${['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((n) => `<button data-tus="${n}">${n}</button>`).join('')}</div>
    <div class="tf-alt"><button class="tf-sil" data-sil aria-label="${esc(_autoMetin('Sil'))}">⌫</button><button class="tf-ara" data-cagri aria-label="${esc(_autoMetin('Ara'))}">📞</button><button class="tf-kapat" data-kapat aria-label="${esc(_autoMetin('Kapat'))}">✕</button></div>
  </div>`;
  document.body.appendChild(k);
  const no = k.querySelector('[data-no]'), sure = k.querySelector('[data-sure]');
  let yazi = '';
  const ciz = () => { no.classList.remove('mesaj'); no.textContent = yazi || '—'; };
  ciz();
  const zm = setInterval(() => { const kk = Math.max(0, x.son - simdi()); sure.textContent = saatDk(kk); if (kk <= 0) kapat(); }, 500);
  const kapat = () => { clearInterval(zm); k.remove(); document.removeEventListener('keydown', klavye); };
  const bas = (n) => { if (yazi.length >= 4) return; yazi += n; h.ses.tusSesi && h.ses.tusSesi(n); ciz(); };
  const klavye = (e) => { if (/^[0-9*#]$/.test(e.key)) bas(e.key); else if (e.key === 'Backspace') { yazi = yazi.slice(0, -1); ciz(); } else if (e.key === 'Enter') k.querySelector('[data-cagri]').click(); else if (e.key === 'Escape') kapat(); };
  document.addEventListener('keydown', klavye);
  k.querySelectorAll('[data-tus]').forEach((b) => b.addEventListener('click', () => bas(b.dataset.tus)));
  k.querySelector('[data-sil]').addEventListener('click', () => { yazi = yazi.slice(0, -1); ciz(); });
  k.querySelector('[data-kapat]').addEventListener('click', kapat);
  k.querySelector('[data-cagri]').addEventListener('click', async (e) => {
    if (!yazi) return;
    const b = e.currentTarget;
    b.disabled = true;
    no.classList.add('mesaj'); no.textContent = _autoSablon`${yazi} aranıyor…`;
    h.ses.hatCaliyor && h.ses.hatCaliyor();
    await new Promise((r) => setTimeout(r, 1600));
    const r = await h.eylem(b, () => api(`vaka/${x.id}/ara`, { numara: yazi }));
    b.disabled = false;
    if (r === undefined) { kapat(); return; }
    if (r.yanlis) {
      h.ses.hata();
      no.classList.add('mesaj'); no.textContent = _autoMetin('Yanlış numara!');
      yazi = '';
      const ip = k.querySelector('[data-ipucu]');
      if (ip) ip.hidden = false;
      setTimeout(ciz, 1400);
      return;
    }
    kapat();
    if (r.ilkYardim) { sahne(x); ilkYardim(x); return; }
    h.ses.odul ? h.ses.odul() : h.ses.satinAl();
    sahne(x);
    sonucKarti(x, r);
    yenile();
  });
}
function sahne(x) {
  if (h.mahalle && h.mahalle() && h.aktifRota() === 'mahalle') { try { h.mahalle().vakaSahnesi(x.tur, x.veri && x.veri.yerNo); } catch (e) { /* sahne yoksa yok say */ } }
}

// ---------------------------------------------------------------- İlk yardım: kalp masajı ritmi (dakikada 100–120)
function ilkYardim(x) {
  const k = document.createElement('div');
  k.className = 'vaka-perde';
  const SURE = 15000;
  k.innerHTML = `<div class="ilk-yardim" role="dialog">
    <h3>🚑 ${_autoHtml('Ambulans yolda! Kalp masajı yap')}</h3>
    <p class="kucuk">${_autoHtml('Göğsün ortasına ritimle bas: dakikada 100–120 kez. Kalbin atışına uy; çok hızlı ya da çok yavaş olmasın.')}</p>
    <button class="iy-kalp" data-bas aria-label="${esc(_autoMetin('Bas'))}">❤️</button>
    <div class="iy-olcer"><i data-ibre></i><span>100</span><span>120</span></div>
    <div class="iy-alt"><b data-bpm>—</b><small>${_autoHtml('dakikada')}</small><em data-kalan></em></div>
    <button class="dugme yesil" data-basla>${_autoHtml('Başla')}</button>
  </div>`;
  document.body.appendChild(k);
  const kalp = k.querySelector('[data-bas]'), bpmEl = k.querySelector('[data-bpm]'), ibre = k.querySelector('[data-ibre]'), kalanEl = k.querySelector('[data-kalan]'), basla = k.querySelector('[data-basla]');
  let baslangic = 0, basislar = [], zm = null, bitti = false;
  const metronom = () => { kalp.classList.remove('vur'); void kalp.offsetWidth; kalp.classList.add('vur'); };
  const bas = (ts) => {
    if (!baslangic || bitti) return;
    const t0 = ts || performance.now(); // olay zamanı: sahne yavaşlasa da basış anı doğru ölçülür
    basislar.push(t0);
    h.ses.tik();
    kalp.classList.add('basildi'); setTimeout(() => kalp.classList.remove('basildi'), 90);
    const son = basislar.slice(-4);
    if (son.length >= 2) {
      const ara = (son[son.length - 1] - son[0]) / (son.length - 1);
      const bpm = Math.round(60000 / ara);
      bpmEl.textContent = String(bpm);
      ibre.style.left = `${Math.max(0, Math.min(100, ((bpm - 60) / 120) * 100))}%`;
      bpmEl.className = bpm >= 100 && bpm <= 120 ? 'iyi' : bpm >= 90 && bpm <= 130 ? 'orta' : 'kotu';
    }
  };
  kalp.addEventListener('pointerdown', (e) => { e.preventDefault(); bas(e.timeStamp); });
  const klavye = (e) => { if (e.code === 'Space') { e.preventDefault(); bas(e.timeStamp); } };
  document.addEventListener('keydown', klavye);
  let vurus = null;
  basla.addEventListener('click', () => {
    basla.hidden = true;
    baslangic = performance.now();
    vurus = setInterval(metronom, 545); // 110 atış/dk rehber vuruşu
    zm = setInterval(() => {
      const kalan = SURE - (performance.now() - baslangic);
      kalanEl.textContent = _autoSablon`${Math.ceil(Math.max(0, kalan) / 1000)} sn`;
      if (kalan <= 0) bitir();
    }, 200);
  });
  async function bitir() {
    if (bitti) return;
    bitti = true;
    clearInterval(zm); clearInterval(vurus);
    document.removeEventListener('keydown', klavye);
    // skor: aralıkların ne kadarı 100–120 (±%8 tolerans) bandında + yeterli sayıda basış
    let iyi = 0;
    for (let i = 1; i < basislar.length; i++) { const bpm = 60000 / (basislar[i] - basislar[i - 1]); if (bpm >= 92 && bpm <= 130) iyi++; }
    const beklenen = (SURE / 1000) * (110 / 60);
    const skor = Math.round(Math.min(1, iyi / (beklenen * 0.85)) * 100);
    const r = await h.eylem(null, () => api(`vaka/${x.id}/ilkyardim`, { skor }));
    k.remove();
    if (r === undefined) return;
    if (r.iyi) h.ses.odul ? h.ses.odul() : h.ses.satinAl();
    sonucKarti(x, r);
    yenile();
  }
}

// ---------------------------------------------------------------- Sonuç kartı
function sonucKarti(x, r) {
  const satir = [];
  if (r.tutar) satir.push(`💰 +${tl(r.tutar)}`);
  if (r.tp) satir.push(`⭐ +${r.tp} TP`);
  if (r.itibar) satir.push(`🏅 ${_autoSablon`İtibar +${r.itibar}`}`);
  let baslik = '', metin = '';
  if (x.tur === 'yangin') { baslik = _autoMetin('İtfaiye zamanında yetişti'); metin = _autoMetin('Yangın büyümeden söndürüldü. Belediye sana teşekkür etti.'); }
  else if (x.tur === 'hirsiz') { baslik = _autoMetin('Hırsız yakalandı'); metin = _autoMetin('Polis hırsızı kasayla birlikte yakaladı. Muhbir ödülünü aldın.'); }
  else if (x.tur === 'kriz') { baslik = r.iyi ? _autoMetin('Hayat kurtardın!') : _autoMetin('Ambulans hastayı aldı'); metin = r.iyi ? _autoSablon`İlk yardımın başarılıydı (%${r.skor}). Hastanın yakınları teşekkür etti.` : _autoSablon`Ritim tutmadı (%${r.skor}) ama ambulansı zamanında çağırdın.`; }
  else if (x.tur === 'siparis') { baslik = _autoMetin('Sipariş teslim edildi'); metin = _autoSablon`Kâr: ${tl(r.kar)}.`; }
  const k = document.createElement('div');
  k.className = 'vaka-perde';
  k.innerHTML = `<div class="vaka-sonuc"><span class="vk-simge">${SIMGE[x.tur]}</span><h3>${esc(baslik)}</h3><p>${esc(metin)}</p>${satir.length ? `<div class="vs-odul">${satir.join('<br>')}</div>` : ''}<button class="dugme yesil" data-tamam>${_autoHtml('Tamam')}</button></div>`;
  document.body.appendChild(k);
  k.querySelector('[data-tamam]').addEventListener('click', () => { h.ses.tik(); k.remove(); });
  if (r.bakiye !== undefined && h.bakiye) h.bakiye(r.bakiye);
}

async function yenile() {
  if (h.durumYenile) await h.durumYenile().catch(() => {});
  if (h.aktifRota() === 'olaylar') vakaPaneli();
}

// ---------------------------------------------------------------- Olaylar paneli
const SEKMELER = [['simdi', '📞', 'Olaylar'], ['mezat', '🔨', 'Mezat'], ['proje', '🏗️', 'Proje'], ['itibar', '🏅', 'İtibar']];
let sekme = 'simdi';
export async function vakaPaneli(yeni) {
  if (yeni && SEKMELER.some((s) => s[0] === yeni)) sekme = yeni;
  const p = h.panelAc({ ikon: '📞', baslik: _autoMetin('Olaylar'), rota: 'olaylar', alt: _autoMetin('Acil durumlar, siparişler, mezat ve mahalle'),
    govde: `<div class="sekmeler" role="tablist">${SEKMELER.map(([k, i, a]) => `<button role="tab" data-sekme="${k}" aria-selected="${sekme === k}">${i} ${_autoHtml(a)}</button>`).join('')}</div><div data-icerik><p class="soluk">${_autoHtml('Yükleniyor…')}</p></div>` });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); sekme = b.dataset.sekme; vakaPaneli(); }));
  const kutu = p.querySelector('[data-icerik]');
  try {
    if (sekme === 'simdi') await simdiCiz(kutu);
    else if (sekme === 'mezat') await mezatCiz(kutu);
    else if (sekme === 'proje') await projeCiz(kutu);
    else await itibarCiz(kutu);
  } catch (e) { if (kutu.isConnected) kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; }
}

function durumAdi(x) {
  return { basarili: '✅ ' + _autoMetin('Başarılı'), kacti: '⌛ ' + _autoMetin('Kaçırıldı'), reddedildi: '✋ ' + _autoMetin('Reddedildi'), bitti: '✔️ ' + _autoMetin('Bitti') }[x.durum] || x.durum;
}
async function simdiCiz(kutu) {
  const v = await api('vaka');
  if (!kutu.isConnected) return;
  const acikKart = (x) => {
    const kalan = Math.max(0, x.son - simdi());
    let eylem = '';
    if (x.durum === 'acik' && ['yangin', 'hirsiz', 'kriz'].includes(x.tur)) eylem = `<button class="dugme yesil kucuk" data-ara="${x.id}">📞 ${_autoHtml('Ara')}</button>`;
    else if (x.durum === 'yardim') eylem = `<button class="dugme yesil kucuk" data-yardim="${x.id}">❤️ ${_autoHtml('İlk yardım')}</button>`;
    else if (x.durum === 'acik' && x.tur === 'siparis') eylem = `<button class="dugme yesil kucuk" data-kabul="${x.id}">✅ ${_autoHtml('Kabul et')}</button><button class="dugme gri kucuk" data-ret="${x.id}">${_autoHtml('Reddet')}</button>`;
    else if (x.durum === 'kabul') eylem = `<button class="dugme yesil kucuk" data-teslim="${x.id}">🚚 ${_autoHtml('Teslim et')}</button>`;
    return `<div class="kart vaka-satir vt-${x.tur}"><span class="vk-simge">${SIMGE[x.tur]}</span><div style="flex:1;min-width:0"><b>${_autoHtml(BASLIK[x.tur])}</b>
      <p class="kucuk" style="margin:4px 0">${aciklama(x)}</p><small class="soluk">⏱️ ${x.tur === 'talep' || x.durum === 'kabul' ? sureMetni(kalan) : saatDk(kalan)}</small><div class="vk-dugmeler">${eylem}</div></div></div>`;
  };
  const gecmisSatir = (x) => {
    const s = x.sonuc || {};
    const ek = [s.tutar ? `+${tl(s.tutar)}` : '', s.kayip ? `−${tl(s.kayip)}` : '', s.ceza ? `−${tl(s.ceza)}` : '', s.itibar ? `🏅 ${s.itibar > 0 ? '+' : ''}${s.itibar}` : ''].filter(Boolean).join(' · ');
    return `<li><span>${SIMGE[x.tur]} ${_autoHtml(BASLIK[x.tur])}<small>${new Date(x.baslangic).toLocaleString(sayiDili(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} · ${esc(durumAdi(x))}</small></span><b>${esc(ek)}</b></li>`;
  };
  kutu.innerHTML = `${v.acik.length ? v.acik.map(acikKart).join('') : `<div class="kart vaka-bos"><b>☕ ${_autoHtml('Şimdilik sakin')}</b><p class="kucuk soluk" style="margin:4px 0 0">${_autoHtml('Oyundayken arada bir beklenmedik olaylar olur: yangın, hırsız, fenalaşan müşteri, toplu sipariş, talep dalgası. Hızlı davranırsan ödül ve itibar kazanırsın.')}</p></div>`}
    <p class="kucuk soluk">${_autoSablon`Bugün ${Math.min(v.bugun, v.gunluk)}/${v.gunluk} olay`}</p>
    ${v.gecmis.length ? `<div class="kart"><h3>${_autoHtml('Son olaylar')}</h3><ul class="vaka-gecmis">${v.gecmis.map(gecmisSatir).join('')}</ul></div>` : ''}`;
  const bul = (id) => v.acik.find((x) => x.id === Number(id));
  kutu.querySelectorAll('[data-ara]').forEach((b) => b.addEventListener('click', () => telefon(bul(b.dataset.ara))));
  kutu.querySelectorAll('[data-yardim]').forEach((b) => b.addEventListener('click', () => ilkYardim(bul(b.dataset.yardim))));
  kutu.querySelectorAll('[data-kabul]').forEach((b) => b.addEventListener('click', (e) => siparisCevap(bul(b.dataset.kabul), true, e.currentTarget)));
  kutu.querySelectorAll('[data-ret]').forEach((b) => b.addEventListener('click', (e) => siparisCevap(bul(b.dataset.ret), false, e.currentTarget)));
  kutu.querySelectorAll('[data-teslim]').forEach((b) => b.addEventListener('click', async () => {
    const x = bul(b.dataset.teslim);
    const r = await h.eylem(b, () => api(`vaka/${x.id}/teslim`, {}));
    if (r === undefined) return;
    h.ses.kasa ? h.ses.kasa() : h.ses.satinAl();
    sonucKarti(x, r);
    yenile();
  }));
}

// ---------------------------------------------------------------- Mezat
async function mezatCiz(kutu) {
  const m = await api('mezat');
  if (!kutu.isConnected) return;
  const fark = m.sunucuZamani - Date.now();
  const lot = (x) => `<div class="kart mezat-lot${x.benim ? ' benim' : x.katildim ? ' gecildi' : ''}">
    <div class="ml-ust"><span class="tesis-simge">${x.simge}</span><div style="flex:1;min-width:0"><b>${x.miktar.toLocaleString(sayiDili())} ${esc(x.birim)} ${esc(_urunAdi(x.ad))}</b>
      <div class="kucuk soluk">${_autoSablon`Piyasa değeri ${tl(x.piyasa)} · açılış ${tl(x.taban)}`}</div></div><em class="ml-sure" data-bitis="${x.bitis}"></em></div>
    <div class="ml-teklif"><span>${x.enYuksek ? _autoSablon`En yüksek: <b>${tl(x.enYuksek)}</b>` : _autoHtml('Henüz teklif yok')}${x.lider ? `<small>${x.benim ? '👑 ' + _autoHtml('Sen öndesin') : esc(x.lider)}</small>` : ''}</span>
      <button class="dugme yesil kucuk" data-teklif="${x.id}" data-tutar="${x.enAz}">🔨 ${tl(x.enAz)}</button></div>
    ${x.katildim && !x.benim ? `<p class="kucuk eksi" style="margin:6px 0 0">${_autoHtml('Teklifin geçildi; paran iade edildi.')}</p>` : ''}</div>`;
  kutu.innerHTML = `<p class="kucuk soluk">${_autoHtml('İcradan gelen mallar açık artırmada. Teklif verdiğin para emanete alınır; biri geçerse hemen iade edilir. Son 2 dakikada gelen teklif süreyi uzatır. Kazanırsan mal ambarına girer. (10. seviyeden itibaren)')}</p>
    ${m.acik.map(lot).join('')}
    ${m.biten.length ? `<div class="kart"><h3>${_autoHtml('Son kapanan mezatlar')}</h3><ul class="vaka-gecmis">${m.biten.map((x) => `<li><span>${x.simge} ${x.miktar.toLocaleString(sayiDili())} ${esc(x.birim)} ${esc(_urunAdi(x.ad))}<small>${x.lider ? esc(x.lider) : _autoHtml('Alıcı çıkmadı')}</small></span><b>${x.enYuksek ? tl(x.enYuksek) : '—'}</b></li>`).join('')}</ul></div>` : ''}`;
  const sureler = () => kutu.querySelectorAll('[data-bitis]').forEach((e) => { const k = Number(e.dataset.bitis) - (Date.now() + fark); e.textContent = k > 0 ? (k > 3600000 ? sureMetni(k) : saatDk(k)) : _autoMetin('Kapandı'); e.classList.toggle('son', k < 120000); });
  sureler();
  if (h.zamanlayici) h.zamanlayici(() => { if (!kutu.isConnected) return; sureler(); }, 1000);
  kutu.querySelectorAll('[data-teklif]').forEach((b) => b.addEventListener('click', async () => {
    const x = m.acik.find((y) => y.id === Number(b.dataset.teklif));
    if (!(await h.onayla(_autoSablon`${x.miktar.toLocaleString(sayiDili())} ${x.birim} ${_urunAdi(x.ad)} için ${tl(Number(b.dataset.tutar))} teklif verilsin mi? Tutar emanete alınır.`, { baslik: _autoMetin('Mezat'), evet: _autoMetin('Teklif ver'), ikon: '🔨' }))) return;
    const r = await h.eylem(b, () => api(`mezat/${x.id}/teklif`, { tutar: Number(b.dataset.tutar) }));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(_autoMetin('Teklifin alındı. Şu an en yüksek teklif senin.'));
    if (h.durumYenile) h.durumYenile();
    vakaPaneli();
  }));
}

// ---------------------------------------------------------------- Mahalle projesi
async function projeCiz(kutu) {
  const p = await api('proje');
  if (!kutu.isConnected) return;
  const oran = Math.min(1, p.toplanan / p.hedef);
  kutu.innerHTML = `${p.sonTamam ? `<div class="kart proje-tamam">🎉 ${_autoSablon`${p.sonTamam.simge} ${_autoMetin(PROJE_AD[p.sonTamam.kod] || '')} tamamlandı: ilçendeki dükkânlara %${Math.round(p.etki * 100)} fazla müşteri (${sureMetni(p.sonTamam.etkiBitis - simdi())} kaldı)`}</div>` : ''}
    <div class="kart proje-kart"><div class="pk-ust"><span class="pk-simge">${p.simge}</span><div><b>${_autoHtml(PROJE_AD[p.kod] || p.ad)}</b><small>${_autoSablon`Bitişe ${sureMetni(p.bitis - simdi())}`}</small></div></div>
      <div class="pk-cubuk"><i style="width:${(oran * 100).toFixed(1)}%"></i></div>
      <p class="pk-rakam"><b>${tl(p.toplanan)}</b> / ${tl(p.hedef)} <span>%${Math.floor(oran * 100)}</span></p>
      <p class="kucuk soluk">${_autoSablon`Mahalle olarak hedefe ulaşırsak ${p.etkiGun} gün boyunca ilçedeki bütün dükkânlara %${Math.round(p.etki * 100)} fazla müşteri gelir. Bağışın itibar kazandırır. Hedefe ulaşılamazsa bağışlar iade edilir.`}</p>
      <div class="pk-bagis">${[0.005, 0.02, 0.05].map((k) => Math.max(100000, Math.round((p.hedef * k) / 100000) * 100000)).map((t2) => `<button class="dugme mavi kucuk" data-bagis="${t2}">${tl(t2)}</button>`).join('')}</div>
      ${p.benim ? `<p class="kucuk arti">${_autoSablon`Senin bağışın: ${tl(p.benim)}`}</p>` : ''}</div>
    ${p.bagiscilar.length ? `<div class="kart"><h3>${_autoHtml('En çok bağış yapanlar')}</h3><ol class="vaka-gecmis">${p.bagiscilar.map((b) => `<li><span>${esc(b.ad)}</span><b>${tl(b.tutar)}</b></li>`).join('')}</ol></div>` : ''}`;
  kutu.querySelectorAll('[data-bagis]').forEach((b) => b.addEventListener('click', async () => {
    const tutar = Number(b.dataset.bagis);
    if (!(await h.onayla(_autoSablon`${_autoMetin(PROJE_AD[p.kod] || p.ad)} için ${tl(tutar)} bağış yapılsın mı?`, { baslik: _autoMetin('Mahalle projesi'), evet: _autoMetin('Bağış yap'), ikon: p.simge }))) return;
    const r = await h.eylem(b, () => api('proje/bagis', { tutar }));
    if (r === undefined) return;
    h.ses.satinAl();
    bildir(r.tamamlandi ? _autoMetin('🎉 Proje tamamlandı! Bütün ilçe teşekkür ediyor.') : _autoSablon`Bağışın için teşekkürler. İtibar +${r.itibar}`);
    if (h.durumYenile) h.durumYenile();
    vakaPaneli();
  }));
}

// ---------------------------------------------------------------- İtibar ve dükkân güvenliği
async function itibarCiz(kutu) {
  const v = await api('vaka');
  if (!kutu.isConnected) return;
  const i = v.itibar, [bandAd, renk] = BAND[i.band];
  const isaret = (n) => `${n > 0 ? '+' : ''}${n.toLocaleString(sayiDili())}`;
  kutu.innerHTML = `<div class="kart itibar-kart"><div class="ik-ust"><b style="color:${renk}">${i.puan}</b><span>/ 1000</span><em style="background:${renk}">${_autoHtml(bandAd)}</em></div>
      <div class="ik-cubuk"><i style="width:${i.puan / 10}%;background:${renk}"></i></div>
      <ul class="ik-etki"><li>🏪 ${_autoSablon`Dükkân müşterisi %${isaret(i.musteri)}`}</li><li>🛒 ${_autoSablon`Tezgâh cirosu %${isaret(i.tezgah)}`}</li><li>🏦 ${_autoSablon`Kredi notu ${isaret(i.kredi)}`}</li></ul>
      <p class="kucuk soluk" style="margin:6px 0 0">${_autoHtml('Mahalle itibarı olaylara nasıl davrandığınla, siparişleri zamanında teslim etmenle ve mahalle projelerine bağışınla yükselir.')}</p></div>
    ${v.guvenlik.dukkanlar.length ? `<div class="kart"><h3>🛡️ ${_autoHtml('Dükkân güvenliği')}</h3>
      <p class="kucuk soluk" style="margin:0 0 8px">${v.guvenlik.secenekler.map((g) => `${g.simge} <b>${_autoHtml(g.ad)}</b> (${tl(g.fiyat)}): ${_autoHtml(g.aciklama)}`).join('<br>')}</p>
      <ul class="guvenlik-liste">${v.guvenlik.dukkanlar.map((d) => `<li><span>${esc(d.ad)}</span><span>${v.guvenlik.secenekler.map((g) => d.var.includes(g.kod) ? `<em class="var">${g.simge} ✓</em>` : `<button class="dugme gri kucuk" data-guvenlik="${g.kod}" data-isletme="${d.id}">${g.simge} ${tl(g.fiyat)}</button>`).join('')}</span></li>`).join('')}</ul></div>` : ''}
    ${i.hareketler.length ? `<div class="kart"><h3>${_autoHtml('İtibar geçmişi')}</h3><ul class="vaka-gecmis">${i.hareketler.map((x) => `<li><span>${_autoHtml(NEDEN[x.neden] || x.neden)}<small>${new Date(x.zaman).toLocaleString(sayiDili(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</small></span><b class="${x.degisim > 0 ? 'arti' : 'eksi'}">${isaret(x.degisim)}</b></li>`).join('')}</ul></div>` : ''}`;
  kutu.querySelectorAll('[data-guvenlik]').forEach((b) => b.addEventListener('click', async () => {
    const g = v.guvenlik.secenekler.find((x) => x.kod === b.dataset.guvenlik);
    if (!(await h.onayla(_autoSablon`${_autoMetin(g.ad)} ${tl(g.fiyat)} karşılığında kurulsun mu?`, { baslik: _autoMetin('Dükkân güvenliği'), evet: _autoMetin('Kur'), ikon: g.simge }))) return;
    const r = await h.eylem(b, () => api('vaka/guvenlik', { isletmeId: Number(b.dataset.isletme), tur: g.kod }));
    if (r === undefined) return;
    h.ses.satinAl();
    if (h.durumYenile) h.durumYenile();
    vakaPaneli();
  }));
}

// ---------------------------------------------------------------- Gazete: mahalleden haberler
export function mahalleHaberMetni(x) {
  const d = { ...x.degerler };
  if (d.project) d.project = _autoMetin(PROJE_AD[d.project] || d.project);
  if (d.sebep) d.sebep = _autoMetin(SEBEP[d.sebep] || d.sebep);
  return t(x.anahtar, d);
}
export function sonVakaDurumu() { return sonDurum; }
