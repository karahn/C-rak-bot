// Oyun sesleri, şehir ortam sesi ve müzik. Üç kanal: Müzik (arka plan müziği ve sokak müzisyenleri),
// Ortam (şehir uğultusu, sirenler, kuşlar, kornalar) ve Oyun sesleri (düğmeler, para, seviye…).
// Her kanalın sesi ayrı ayarlanır ve kapatılabilir; ayarlar tarayıcıda saklanır.
// Telefonlar ses çalmak için bir dokunuş bekler; ilk dokunuşta ses motoru açılır.

let ctx = null;
let ana = null;       // ana çıkış (tümü)
let efekt = null;     // oyun sesleri kanalı
let ortam = null;     // şehir uğultusu (mahalle açıkken duyulur)
let sokak = null;     // sirenler, kedi, olay sesleri (mahalle açıkken duyulur)
let kanal = {};       // { muzik, ortam, efekt }: kullanıcının ayarladığı kanal sesleri
let sokakMuzik = null; // sokak müzisyenleri (mahalle açıkken)
let muzikArka = null;  // arka plan müziği

const AYAR_ANAHTARI = 'tezgah_ses_ayar';
const VARSAYILAN = { muzik: 0.7, ortam: 0.8, efekt: 0.9, kapali: { muzik: false, ortam: false, efekt: false } };
let ayar = JSON.parse(JSON.stringify(VARSAYILAN));
let jenerik = null;
try {
  const k = JSON.parse(localStorage.getItem(AYAR_ANAHTARI) || 'null');
  if (k) ayar = { ...ayar, ...k, kapali: { ...ayar.kapali, ...(k.kapali || {}) } };
  else if (localStorage.getItem('tezgah_ses') === 'kapali') ayar.kapali = { muzik: true, ortam: true, efekt: true };
} catch (e) { /* yok say */ }
function ayarKaydet() { try { localStorage.setItem(AYAR_ANAHTARI, JSON.stringify(ayar)); } catch (e) { /* yok say */ } }
const KANAL_KAZANC = { muzik: 0.9, ortam: 1.4, efekt: 1 };
function kanalDegeri(k) { return ayar.kapali[k] ? 0 : ayar[k] * KANAL_KAZANC[k]; }
function kanallariUygula() {
  if (!ctx) { jenerik?.uygula(); return; }
  for (const k of ['muzik', 'ortam', 'efekt']) if (kanal[k]) kanal[k].gain.setTargetAtTime(kanalDegeri(k), ctx.currentTime, 0.08);
  if (arkaEl) arkaDurumuUygula();
  jenerik?.uygula();
}
export function sesAyarlari() { return JSON.parse(JSON.stringify(ayar)); }
export function kanalAyarla(k, deger) {
  if (!(k in KANAL_KAZANC)) return;
  ayar[k] = Math.max(0, Math.min(1, Number(deger)));
  if (ayar[k] > 0) ayar.kapali[k] = false;
  ayarKaydet();
  kanallariUygula();
}
export function kanalSessiz(k, kapali) {
  if (!(k in KANAL_KAZANC)) return;
  ayar.kapali[k] = !!kapali;
  ayarKaydet();
  kanallariUygula();
  if (k === 'efekt' && !kapali) tik();
}
// eski arayüz: hepsi açık mı / hepsini aç-kapat
export function sesAcikMi() { return !(ayar.kapali.muzik && ayar.kapali.ortam && ayar.kapali.efekt); }
export function sesDegistir() {
  const kapat = sesAcikMi();
  ayar.kapali = { muzik: kapat, ortam: kapat, efekt: kapat };
  ayarKaydet();
  kanallariUygula();
  if (!kapat) tik();
  return !kapat;
}

function kur() {
  if (ctx) return ctx;
  const C = window.AudioContext || window.webkitAudioContext;
  if (!C) return null;
  ctx = new C();
  ana = ctx.createGain();
  const sikistirici = ctx.createDynamicsCompressor();
  sikistirici.threshold.value = -12;
  sikistirici.ratio.value = 3;
  ana.connect(sikistirici).connect(ctx.destination);
  for (const k of ['muzik', 'ortam', 'efekt']) {
    kanal[k] = ctx.createGain();
    kanal[k].gain.value = kanalDegeri(k);
    kanal[k].connect(ana);
  }
  efekt = kanal.efekt;
  ortam = ctx.createGain();
  ortam.gain.value = 0;
  ortam.connect(kanal.ortam);
  sokak = ctx.createGain();
  sokak.gain.value = 0;
  sokak.connect(kanal.ortam);
  sokakMuzik = ctx.createGain();
  sokakMuzik.gain.value = 0;
  sokakMuzik.connect(kanal.muzik);
  muzikArka = ctx.createGain();
  muzikArka.gain.value = 1;
  muzikArka.connect(kanal.muzik);
  ctx.addEventListener('statechange', () => {
    if (ctx.state === 'running') { arkaDurumuUygula(); jenerik?.uygula(); }
  });
  return ctx;
}

// İlk dokunuşta ses motorunu aç (iPhone ve Android için şart)
function kilidiAc() {
  const c = kur();
  if (!c) return;
  if (c.state !== 'running') c.resume().then(() => { arkaDurumuUygula(); jenerik?.uygula(); }).catch(() => {});
  const b = c.createBuffer(1, 1, 22050);
  const s = c.createBufferSource();
  s.buffer = b;
  s.connect(c.destination);
  s.start(0);
  ortamBaslat();
  arkaDurumuUygula();
}
['pointerdown', 'touchend', 'keydown', 'click'].forEach((o) => window.addEventListener(o, kilidiAc, { passive: true }));
// Bağlam tarayıcı tarafından sonradan açılınca bekleyen müzik aynı anda başlar.
document.addEventListener('visibilitychange', () => {
  if (!ctx) return;
  if (document.hidden) ctx.suspend().catch(() => {});
  else ctx.resume().then(() => { arkaDurumuUygula(); jenerik?.uygula(); }).catch(() => {});
});

function hazir() {
  if (!ctx || ctx.state !== 'running') return false;
  return true;
}

// Beyaz / pembe / kahverengi gürültü
const tamponlar = {};
function gurultu(tur = 'beyaz', sure = 2) {
  const k = tur + sure;
  if (tamponlar[k]) return tamponlar[k];
  const n = Math.floor(ctx.sampleRate * sure);
  const b = ctx.createBuffer(1, n, ctx.sampleRate);
  const d = b.getChannelData(0);
  let son = 0, b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < n; i++) {
    const w = Math.random() * 2 - 1;
    if (tur === 'kahve') { son = (son + 0.02 * w) / 1.02; d[i] = son * 3.5; }
    else if (tur === 'pembe') { b0 = 0.99765 * b0 + w * 0.099; b1 = 0.963 * b1 + w * 0.2965; b2 = 0.57 * b2 + w * 1.0527; d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.2; }
    else d[i] = w;
  }
  tamponlar[k] = b;
  return b;
}

function ton(frekans, baslangic, sure, tur = 'sine', ses = 0.15, hedef = efekt, frekansSon = null, pan = 0) {
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = tur;
  const t = ctx.currentTime + baslangic;
  // duyulabilir aralığın dışındaki (örnekleme sınırını aşan) frekanslar kırpılır
  const enCok = ctx.sampleRate / 2 - 50;
  frekans = Math.min(enCok, Math.max(20, frekans));
  if (frekansSon) frekansSon = Math.min(enCok, Math.max(20, frekansSon));
  o.frequency.setValueAtTime(frekans, t);
  if (frekansSon) o.frequency.exponentialRampToValueAtTime(frekansSon, t + sure);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(ses, t + 0.005);
  g.gain.exponentialRampToValueAtTime(0.0001, t + sure);
  let son = g;
  if (pan && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = pan; g.connect(p); son = p; }
  o.connect(g);
  son.connect(hedef);
  o.start(t);
  o.stop(t + sure + 0.05);
}

function patlama(baslangic, sure, ses, filtreFrekans, hedef = efekt, tip = 'bandpass', q = 1) {
  const s = ctx.createBufferSource();
  s.buffer = gurultu('beyaz', 1);
  const f = ctx.createBiquadFilter();
  f.type = tip;
  f.frequency.value = filtreFrekans;
  f.Q.value = q;
  const g = ctx.createGain();
  const t = ctx.currentTime + baslangic;
  g.gain.setValueAtTime(ses, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + sure);
  s.connect(f).connect(g).connect(hedef);
  s.start(t);
  s.stop(t + sure + 0.05);
}

// Madeni para: uyumsuz harmoniklerle metalik çınlama
function metal(baslangic, temel, ses = 0.08) {
  for (const [c, g, s] of [[1, 1, 0.35], [2.76, 0.6, 0.25], [5.4, 0.4, 0.18], [8.93, 0.25, 0.12]]) ton(temel * c, baslangic, s, 'sine', ses * g);
  patlama(baslangic, 0.03, ses * 1.5, 6000, efekt, 'highpass');
}

// ------------------------------------------------ Sinematik (açılış)
// Başlık kartı geldiğinde kısa "vuş" sesi
export function kayma() {
  if (!hazir()) return;
  patlama(0, 0.35, 0.18, 900, efekt, 'bandpass', 0.8);
  ton(220, 0, 0.25, 'triangle', 0.05, efekt, 110);
}
// Final logosunda derin bas vuruşu
export function darbe() {
  if (!hazir()) return;
  ton(90, 0, 0.9, 'sine', 0.5, efekt, 38);
  ton(45, 0, 1.1, 'sine', 0.35, efekt, 30);
  patlama(0, 0.5, 0.35, 180, efekt, 'lowpass', 0.7);
  patlama(0, 0.12, 0.25, 3000, efekt, 'highpass');
}

// ------------------------------------------------ Efektler
// bir dokunuş tek tık sesi: aynı anda birkaç yerden (düğme + rota değişimi + panel) çağrılsa da bir kez çalar
let sonTik = 0;
export function tik() {
  if (!hazir()) return;
  const t = performance.now();
  if (t - sonTik < 180) return;
  sonTik = t;
  patlama(0, 0.025, 0.25, 2500, efekt, 'bandpass', 2);
  ton(1400, 0, 0.04, 'triangle', 0.04);
}
export function sikke() {
  if (!hazir()) return;
  metal(0, 2100 + Math.random() * 400, 0.07);
}
export function kasa() {
  if (!hazir()) return;
  // yazar kasa: çekmece kayması + zil
  patlama(0, 0.18, 0.3, 900, efekt, 'lowpass');
  patlama(0.12, 0.05, 0.4, 3000);
  metal(0.2, 1760, 0.12);
  metal(0.21, 2640, 0.08);
}
export function seviye() {
  if (!hazir()) return;
  [523, 659, 784, 1046, 1318].forEach((f, i) => { ton(f, i * 0.1, 0.5, 'triangle', 0.1); ton(f * 2, i * 0.1, 0.3, 'sine', 0.03); });
}
export function hata() {
  if (!hazir()) return;
  ton(220, 0, 0.18, 'sawtooth', 0.04);
  ton(165, 0.12, 0.25, 'sawtooth', 0.04);
}
export function satinAl() {
  if (!hazir()) return;
  metal(0, 1568, 0.06);
  ton(784, 0.05, 0.15, 'triangle', 0.08);
  ton(1175, 0.12, 0.3, 'triangle', 0.08);
}
export function mesaj() {
  if (!hazir()) return;
  ton(988, 0, 0.15, 'sine', 0.1);
  ton(1319, 0.1, 0.25, 'sine', 0.1);
}

// ------------------------------------------------ Ortam sesleri
let ortamKuruldu = false;
let muzikCaliyor = false; // tanıtım müziği çalarken şehir sesi kısılır
let trafikG = null, kalabalikG = null, kalabalikF = null;
let durum = { gece: 0, kalabalik: 0.5, aktif: false };
let sonKus = 0, sonCircir = 0, sonKorna = 0;
// Fisher–Yates karıştırma (sort(() => Math.random() - 0.5) küçük listelerde sırayı çoğunlukla bozmaz)
function karistir(a) {
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
// Sesi bastıranlar: 'cagri' (ezan, çan…), 'duyuru' (müzisyen anonsu), 'calar' (oyuncunun müzik çaları)
const bastirma = new Set();
function bastir(neden, acik) {
  if (acik) bastirma.add(neden); else bastirma.delete(neden);
  if (ctx) ortamAdim(true);
  if (ctx && calarGain) calarGain.gain.setTargetAtTime(bastirma.has('jenerik') ? 0 : 1, ctx.currentTime, .15);
  arkaDurumuUygula();
  jenerik?.uygula();
}

function dongu(tur, filtreTip, frekans, q) {
  const s = ctx.createBufferSource();
  s.buffer = gurultu(tur, 4);
  s.loop = true;
  const f = ctx.createBiquadFilter();
  f.type = filtreTip;
  f.frequency.value = frekans;
  f.Q.value = q;
  const g = ctx.createGain();
  g.gain.value = 0;
  s.connect(f).connect(g).connect(ortam);
  s.start();
  return { g, f };
}

function ortamBaslat() {
  if (ortamKuruldu || !ctx) return;
  ortamKuruldu = true;
  const t = dongu('kahve', 'lowpass', 320, 0.7);   // uzaktan trafik uğultusu
  trafikG = t.g;
  const k = dongu('pembe', 'bandpass', 900, 0.8);  // insan kalabalığı mırıltısı
  kalabalikG = k.g;
  kalabalikF = k.f;
  setInterval(ortamAdim, 200);
}

function ortamAdim(yalnizKanallar = false) {
  if (!hazir()) return;
  const t = ctx.currentTime;
  const cagri = bastirma.has('cagri');
  const hedef = durum.aktif && !muzikCaliyor ? (cagri ? 0.35 : 0.6) : muzikCaliyor ? 0.12 : 0;
  ortam.gain.setTargetAtTime(hedef, t, 0.8);
  sokak.gain.setTargetAtTime(durum.aktif ? 1 : 0, t, 0.5);
  // ezan/çan ya da anons sırasında sokak müzisyenleri susar; oyuncu kendi çalarını açtıysa kısılır
  const sokakHedef = !durum.aktif || muzikCaliyor || cagri || bastirma.has('duyuru') || bastirma.has('jenerik') ? 0 : bastirma.has('calar') ? 0.3 : 1;
  sokakMuzik.gain.setTargetAtTime(sokakHedef, t, 0.6);
  // sokak müzisyeni yakında çalarken arka plan müziği kısılır
  const muzisyenYakin = [...muzisyenler].some((m) => m.guc > 0.15);
  muzikArka.gain.setTargetAtTime(cagri || bastirma.has('calar') ? 0 : bastirma.has('duyuru') ? 0.15 : muzisyenYakin && durum.aktif ? 0.25 : 1, t, 0.8);
  if (yalnizKanallar || !durum.aktif) return;
  trafikG.gain.setTargetAtTime(0.16 * (1 - durum.gece * 0.6), t, 1);
  // kalabalık sesi dalgalanır
  const k = 0.05 * durum.kalabalik * (1 - durum.gece * 0.8) * (0.7 + Math.random() * 0.6);
  kalabalikG.gain.setTargetAtTime(k, t, 0.4);
  kalabalikF.frequency.setTargetAtTime(700 + Math.random() * 500, t, 0.3);

  const simdi = performance.now();
  if (durum.gece < 0.4 && simdi - sonKus > 1500 + Math.random() * 6000) { sonKus = simdi; kusOt(); }
  if (durum.gece > 0.6 && simdi - sonCircir > 700 + Math.random() * 1500) { sonCircir = simdi; circir(); }
  if (simdi - sonKorna > 14000 + Math.random() * 30000) { sonKorna = simdi; korna(Math.random() * 1.6 - 0.8, Math.random() < 0.3); }
}

// Serçe cıvıltısı: hızlı frekans kaymalı kısa notalar
function kusOt() {
  const pan = Math.random() * 1.6 - 0.8;
  const n = 2 + Math.floor(Math.random() * 5);
  const temel = 3200 + Math.random() * 1800;
  for (let i = 0; i < n; i++) {
    const b = i * (0.07 + Math.random() * 0.05);
    ton(temel * (0.9 + Math.random() * 0.25), b, 0.06, 'sine', 0.025, ortam, temel * (1.2 + Math.random() * 0.3), pan);
  }
}
function circir() {
  const pan = Math.random() * 1.6 - 0.8;
  for (let i = 0; i < 3; i++) ton(4600, i * 0.045, 0.03, 'sine', 0.015, ortam, null, pan);
}
export function korna(pan = 0, dolmus = false) {
  if (!hazir() || !durum.aktif) return;
  const s = dolmus ? 0.035 : 0.045;
  const sure = dolmus ? 0.15 : 0.35;
  const tekrar = dolmus ? 2 : 1;
  for (let r = 0; r < tekrar; r++) {
    ton(dolmus ? 520 : 405, r * 0.22, sure, 'square', s, ortam, null, pan);
    ton(dolmus ? 650 : 505, r * 0.22, sure, 'square', s * 0.8, ortam, null, pan);
  }
}

// Saygı duruşu sireni (10 Kasım 09.05): yavaşça yükselip sabitlenen, sonunda inen uzun ve tek ton.
// Döndürdüğü işlev sireni erken susturur.
export function anmaSireni(sure = 60) {
  if (!hazir() || !durum.aktif) return () => {};
  const t = ctx.currentTime;
  const o = ctx.createOscillator();
  const o2 = ctx.createOscillator();
  o.type = 'sawtooth';
  o2.type = 'sine';
  const f = ctx.createBiquadFilter();
  f.type = 'lowpass';
  f.frequency.value = 1400;
  const g = ctx.createGain();
  for (const [osc, k] of [[o, 1], [o2, 2]]) {
    osc.frequency.setValueAtTime(140 * k, t);
    osc.frequency.exponentialRampToValueAtTime(420 * k, t + 6);
    osc.frequency.setValueAtTime(420 * k, t + sure - 6);
    osc.frequency.exponentialRampToValueAtTime(120 * k, t + sure);
  }
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.09, t + 5);
  g.gain.setValueAtTime(0.09, t + sure - 6);
  g.gain.exponentialRampToValueAtTime(0.0001, t + sure);
  o.connect(f); o2.connect(f); f.connect(g); g.connect(ortam);
  o.start(t); o2.start(t);
  o.stop(t + sure + 0.1); o2.stop(t + sure + 0.1);
  return () => { try { g.gain.cancelScheduledValues(ctx.currentTime); g.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.3); o.stop(ctx.currentTime + 1.5); o2.stop(ctx.currentTime + 1.5); } catch (e) { /* bitti */ } };
}

// Gök gürültüsü: önce keskin bir çatırtı, ardından uzun, alçak ve dalgalanan bir gümbürtü
export function gokGurultusu(guc = 1) {
  if (!hazir() || !durum.aktif) return;
  const t = ctx.currentTime;
  const sure = 3.5 + Math.random() * 2.5;
  const s = ctx.createBufferSource();
  s.buffer = gurultu('kahve', 6.5);
  const f = ctx.createBiquadFilter();
  f.type = 'lowpass';
  f.frequency.setValueAtTime(900 * guc + 200, t);
  f.frequency.exponentialRampToValueAtTime(120, t + sure);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.5 * guc, t + 0.06);
  // gümbürtü birkaç kez kabarıp söner
  for (let i = 1; i < 5; i++) g.gain.exponentialRampToValueAtTime((0.12 + Math.random() * 0.3) * guc, t + (sure * i) / 5);
  g.gain.exponentialRampToValueAtTime(0.0001, t + sure);
  s.connect(f);
  f.connect(g);
  g.connect(ortam);
  s.start(t);
  s.stop(t + sure + 0.1);
}

// Araba kapısı kapanır: kısa, boğuk bir "tak" (alçak geçirgenli gürültü + düşük tok ton)
export function kapiKapandi(pan = 0, guc = 1) {
  if (!hazir() || !durum.aktif) return;
  const t = ctx.currentTime;
  const s = ctx.createBufferSource();
  s.buffer = gurultu('pembe', 0.3);
  const f = ctx.createBiquadFilter();
  f.type = 'lowpass';
  f.frequency.value = 420;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.22 * guc, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
  s.connect(f);
  f.connect(g);
  let son = g;
  if (ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = pan; g.connect(p); son = p; }
  son.connect(ortam);
  s.start(t);
  s.stop(t + 0.2);
  ton(95, 0, 0.09, 'sine', 0.06 * guc, ortam, null, pan);
}

// Önden geçen araba: motor sesi + rüzgâr, soldan sağa kayar
export function arabaGecti(yon, hiz) {
  if (!hazir() || !durum.aktif) return;
  const t = ctx.currentTime;
  const sure = 1.6;
  const s = ctx.createBufferSource();
  s.buffer = gurultu('pembe', 2);
  const f = ctx.createBiquadFilter();
  f.type = 'bandpass';
  f.Q.value = 0.6;
  f.frequency.setValueAtTime(500, t);
  f.frequency.linearRampToValueAtTime(900, t + sure / 2);
  f.frequency.linearRampToValueAtTime(380, t + sure);
  const g = ctx.createGain();
  const guc = Math.min(0.2, 0.05 + hiz * 0.012);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(guc, t + sure / 2);
  g.gain.exponentialRampToValueAtTime(0.0001, t + sure);
  let son = g;
  if (ctx.createStereoPanner) {
    const p = ctx.createStereoPanner();
    p.pan.setValueAtTime(-0.9 * yon, t);
    p.pan.linearRampToValueAtTime(0.9 * yon, t + sure);
    g.connect(p);
    son = p;
  }
  s.connect(f).connect(g);
  son.connect(ortam);
  s.start(t);
  s.stop(t + sure);
  // motor tınısı
  const o = ctx.createOscillator();
  o.type = 'sawtooth';
  o.frequency.setValueAtTime(70 + hiz * 4, t);
  o.frequency.linearRampToValueAtTime(58 + hiz * 3, t + sure);
  const og = ctx.createGain();
  og.gain.setValueAtTime(0.0001, t);
  og.gain.exponentialRampToValueAtTime(guc * 0.25, t + sure / 2);
  og.gain.exponentialRampToValueAtTime(0.0001, t + sure);
  const lp = ctx.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = 300;
  o.connect(lp).connect(og);
  og.connect(son === g ? ortam : son);
  o.start(t);
  o.stop(t + sure);
}

// Mahalle sahnesi her saniye durumu bildirir
export function ortamDurumu(d) {
  durum = { ...durum, ...d };
}

// ------------------------------------------------ Arka plan müziği
// Dosyalar web/ses/muzik altında (AAC). Bağlam: 'giris' (giriş ve kayıt), 'yukleniyor', 'intro', 'oyun' (karışık çalma listesi).
// Müzik <audio> öğesinden akarak çalar (tamamı indirilmeden başlar), Web Audio üzerinden Müzik kanalına bağlanır.
// Sabit adlar: giris, yukleniyor, intro. muzik klasöründeki diğer her dosya oyun içi çalma listesine girer.
const SABIT_MUZIK = ['giris', 'yukleniyor', 'intro'];
const MUZIK = {
  giris: ['giris'], yukleniyor: ['yukleniyor'], intro: ['intro'],
  oyun: ['oyun1', 'oyun2', 'oyun3', 'oyun4', 'oyun5', 'oyun6', 'oyun7', 'oyun8', 'oyun9'],
};
let arkaEl = null, arkaKaynak = null, arkaBaglam = null, arkaSira = [], arkaBekleme = null;
function arkaOge() {
  if (arkaEl) return arkaEl;
  arkaEl = new Audio();
  arkaEl.preload = 'auto';
  arkaEl.addEventListener('ended', () => {
    if (MUZIK[arkaBaglam] && MUZIK[arkaBaglam].length > 1) {
      // oyun sırasında parçalar arasında kısa bir sessizlik (sürekli müzik yormasın)
      clearTimeout(arkaBekleme);
      arkaBekleme = setTimeout(() => arkaSonraki(), 20000 + Math.random() * 40000);
    } else if (arkaBaglam && arkaBaglam !== 'intro') { arkaEl.currentTime = 0; arkaEl.play().catch(() => {}); }
  });
  return arkaEl;
}
function arkaSonraki() {
  if (!katalogHazir) { katalogSozu.then(() => { if (arkaBaglam) arkaSonraki(); }); return; }
  const l = MUZIK[arkaBaglam];
  if (!l) return;
  if (!arkaSira.length) arkaSira = karistir(l.slice());
  const ad = arkaSira.shift();
  const el = arkaOge();
  const yollar = adaylar('muzik/' + ad + '.m4a');
  let i = 0;
  // bu biçim açılamazsa aynı parçanın diğer biçimi denenir
  el.onerror = () => { if (++i < yollar.length) { el.src = yollar[i]; arkaDurumuUygula(); } };
  el.src = yollar[0];
  el.currentTime = 0;
  arkaDurumuUygula();
}
function arkaDurumuUygula() {
  if (!arkaEl || !arkaBaglam) return;
  if (arkaBaglam === 'film') { arkaEl.pause(); return; } // tanıtım filmi kendi müziğini çalıyor
  // ezan/çan okunurken ya da oyuncu kendi müzik çalarını dinlerken arka plan müziği durur (sonra kaldığı yerden sürer)
  if (bastirma.has('cagri') || bastirma.has('calar') || bastirma.has('jenerik')) { arkaEl.pause(); return; }
  const kapali = ayar.kapali.muzik || ayar.muzik <= 0;
  // Web Audio yoksa ya da henüz açılmadıysa ses düzeyi öğeden ayarlanır
  if (ctx && !arkaKaynak && ctx.state === 'running') {
    try { arkaKaynak = ctx.createMediaElementSource(arkaEl); arkaKaynak.connect(muzikArka); } catch (e) { arkaKaynak = null; }
  }
  if (!arkaKaynak) arkaEl.volume = kapali ? 0 : Math.min(1, ayar.muzik * 0.6);
  if (kapali) { arkaEl.pause(); return; }
  if (arkaEl.paused && arkaEl.src && (!ctx || ctx.state === 'running')) arkaEl.play().catch(() => {});
}
export function muzikBaglami(baglam) {
  if (baglam === arkaBaglam) { arkaDurumuUygula(); return; }
  arkaBaglam = baglam;
  clearTimeout(arkaBekleme);
  arkaSira = [];
  if (!baglam) { if (arkaEl) arkaEl.pause(); return; }
  arkaSonraki();
}
export function muzikBaglamiNe() { return arkaBaglam; }

// Jenerik kaydı ayrı klasörde kalır; normal oyun çalma listesine girmez.
export function jenerikMuzigi() {
  jenerik?.bitir();
  const el = new Audio();
  const adaylar = [
    ['webm', 'audio/webm; codecs="opus"'],
    ['m4a', 'audio/mp4; codecs="mp4a.40.2"'],
  ].filter(([, tip]) => el.canPlayType(tip));
  // Bildirilen destek bazen gerçek codec desteğiyle uyuşmaz: hata olursa diğer biçim denenir.
  let bicim = 0;
  const kaynakSec = () => {
    const ext = adaylar[bicim]?.[0];
    if (!ext) return false;
    el.src = new URL(`../ses/jenerik/yapimcilar.${ext}?v=0.35.2`, import.meta.url).href;
    return true;
  };
  kaynakSec();
  el.preload = 'metadata';
  el.loop = true;
  let kapandi = false, durak = false, hata = false, kaynak = null, kazanc = null;
  const uygula = () => {
    if (kapandi) return;
    const sessiz = ayar.kapali.muzik || ayar.muzik <= 0;
    if (!kaynak && ctx?.state === 'running') {
      try {
        kaynak = ctx.createMediaElementSource(el);
        kazanc = ctx.createGain(); kazanc.gain.value = .65;
        kaynak.connect(kazanc).connect(kanal.muzik);
      } catch (e) { kaynak = null; }
    }
    el.volume = kaynak ? 1 : Math.min(1, ayar.muzik * .6);
    if (durak || sessiz || document.hidden || hata || bastirma.has('cagri')) { el.pause(); return; }
    if (el.paused) el.play().catch(() => {}); // ses kilidi bir sonraki dokunuşta tekrar denenir
  };
  const sesHatasi = () => {
    if (kapandi) return;
    bicim++;
    if (kaynakSec()) { el.load(); uygula(); return; }
    hata = true; bastir('jenerik', false);
  };
  const api = {
    uygula,
    duraklat(v) { durak = !!v; uygula(); },
    bastan() { try { el.currentTime = 0; } catch (e) { /* kayıt henüz yüklenmedi */ } durak = false; uygula(); },
    bitir() {
      if (kapandi) return;
      kapandi = true; el.pause();
      document.removeEventListener('visibilitychange', uygula);
      for (const o of ['pointerdown', 'touchend', 'keydown']) window.removeEventListener(o, uygula);
      el.removeEventListener('error', sesHatasi);
      kaynak?.disconnect(); kazanc?.disconnect();
      el.removeAttribute('src'); el.load();
      if (jenerik === api) jenerik = null;
      bastir('jenerik', false);
    },
  };
  jenerik = api;
  el.addEventListener('error', sesHatasi);
  document.addEventListener('visibilitychange', uygula);
  for (const o of ['pointerdown', 'touchend', 'keydown']) window.addEventListener(o, uygula, { passive: true });
  bastir('jenerik', !!adaylar.length);
  if (!adaylar.length) hata = true;
  uygula();
  return api;
}

// ------------------------------------------------ Kayıtlı sesler (örnekler)
// Kedi miyavlamaları ve gitar notaları gerçek kayıtlardır (bkz. web/ses/LISANS.txt); ilk ihtiyaçta indirilir.
const ornekler = new Map();
// Ses klasörleri (web/ses/muzik, muzisyen, siren) sunucudan listelenir: klasöre yeni bir dosya yüklemek yeterlidir.
// Aynı adlı dosyalardan (ör. oyun3.webm, oyun3.m4a, oyun3.mp3) tarayıcının çalabildiği en yenisi seçilir.
const MIME = {
  webm: 'audio/webm; codecs="opus"', ogg: 'audio/ogg', opus: 'audio/ogg; codecs="opus"', m4a: 'audio/mp4; codecs="mp4a.40.2"',
  mp4: 'audio/mp4; codecs="mp4a.40.2"', aac: 'audio/aac', mp3: 'audio/mpeg', wav: 'audio/wav', flac: 'audio/flac',
};
const calinabilir = (() => {
  const t = {};
  let a = null;
  try { a = new Audio(); } catch (e) { /* yok say */ }
  for (const [uz, m] of Object.entries(MIME)) t[uz] = !a || !!a.canPlayType(m) || (uz === 'aac' && !!a.canPlayType('audio/mp4'));
  return t;
})();
const BICIM = calinabilir.webm ? 'webm' : 'm4a';
let katalog = null;
let katalogHazir = false; // liste geldi ya da alınamadı (alınamazsa bilinen adlar kullanılır)
const katalogSozu = fetch(new URL('../api/sesler', import.meta.url).href, { cache: 'no-cache' })
  .then((r) => (r.ok ? r.json() : null)).catch(() => null).then((k) => { katalog = k; katalogHazir = true; return k; });
export function sesKatalogu() { return katalogSozu; }
katalogSozu.then((k) => {
  if (!k || !k.muzik) return;
  const l = k.muzik.map((x) => x.ad).filter((a) => !SABIT_MUZIK.includes(a));
  if (l.length) MUZIK.oyun = l;
});
function katalogKaydi(klasor, ad) { return katalog && katalog[klasor] ? katalog[klasor].find((x) => x.ad === ad) || null : null; }
// Bir kaydın indirilebilecek adresleri (tercih sırasıyla)
function adaylar(ad) {
  const m = /^(muzik|muzisyen|siren)\/(.+)\.m4a$/.exec(ad);
  const k = m && katalogKaydi(m[1], m[2]);
  if (k) {
    const l = k.dosyalar.filter((d) => calinabilir[d.uzanti]).map((d) => new URL('../ses/' + d.dosya, import.meta.url).href);
    if (l.length) return l;
  }
  const tek = new URL('../ses/' + ad, import.meta.url).href;
  if (!/\.m4a$/.test(ad)) return [tek];
  return BICIM === 'webm' ? [tek.replace(/\.m4a$/, '.webm'), tek] : [tek];
}
function sesYolu(ad) { return adaylar(ad)[0]; }
function coz(b) {
  return new Promise((ok, red) => {
    const p = ctx.decodeAudioData(b, ok, red);
    if (p && p.catch) p.catch(() => {});
  });
}
function ornekYukle(ad) {
  if (!kur()) return Promise.resolve(null);
  if (!ornekler.has(ad)) {
    const s = { tampon: null, soz: null };
    s.soz = katalogSozu.then(async () => {
      for (const u of adaylar(ad)) {
        try {
          const r = await fetch(u);
          if (!r.ok) continue;
          s.tampon = await coz(await r.arrayBuffer());
          return s.tampon;
        } catch (e) { /* sıradaki biçim */ }
      }
      return null;
    });
    ornekler.set(ad, s);
  }
  return ornekler.get(ad).soz;
}
function ornek(ad) { const s = ornekler.get(ad); return s ? s.tampon : null; }
function ornekCal(tampon, { t = 0, ses = 1, pan = 0, hiz = 1, hedef = efekt, bitis = null } = {}) {
  const k = ctx.createBufferSource();
  k.buffer = tampon;
  k.playbackRate.value = hiz;
  const g = ctx.createGain();
  const bas = Math.max(ctx.currentTime, t || ctx.currentTime);
  g.gain.setValueAtTime(ses, bas);
  if (bitis) { g.gain.setValueAtTime(ses, bitis); g.gain.exponentialRampToValueAtTime(0.0001, bitis + 0.35); }
  let son = g;
  if (pan && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, pan)); g.connect(p); son = p; }
  k.connect(g);
  son.connect(hedef);
  k.start(bas);
  if (bitis) k.stop(bitis + 0.4);
  return k;
}

// Sokak yankısı: binalardan dönen kısa erken yansımalar ve 1,3 sn'lik sönümlü kuyruk
let sokakYankiTamponu = null;
function sokakYankisi() {
  if (!sokakYankiTamponu) {
    const sure = 1.3;
    const n = Math.floor(ctx.sampleRate * sure);
    sokakYankiTamponu = ctx.createBuffer(2, n, ctx.sampleRate);
    for (let k = 0; k < 2; k++) {
      const d = sokakYankiTamponu.getChannelData(k);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 3.2) * 0.35;
      // karşı binalardan gelen erken yansımalar (sol ve sağ kanal farklı)
      for (const [ms, g] of [[23, 0.7], [41, 0.5], [67, 0.42], [94, 0.3], [131, 0.22], [187, 0.15]]) {
        const j = Math.floor(((ms + (k ? 9 : 0)) / 1000) * ctx.sampleRate);
        if (j < n) d[j] += g * (k ? 0.85 : 1);
      }
    }
  }
  const c = ctx.createConvolver();
  c.buffer = sokakYankiTamponu;
  return c;
}

// ------------------------------------------------ Sokak olayları
// Siren: gerçek elektronik sirenler gibi tek bir ton sürekli kayar (kesik kesik notalar değil), korna
// hoparlörünün rezonansından, sokağın yankısından ve yaklaşıp uzaklaşan aracın Doppler kaymasından geçer.
//  polis: "yelp" (hızlı yükselen) ile "wail" (yavaş yükselip alçalan) arasında gidip gelir
//  ambulans: Avrupa tipi iki tonlu "hi-lo" (dü-da), aralarda "wail"
//  itfaiye: ağır, derin "wail" ve arada havalı korna
//  zabıta: kısa "vuup" uyarıları
const SIREN_DESEN = {
  polis: [['yelp', 6], ['wail', 3], ['yelp', 5], ['hilo', 2]],
  ambulans: [['hilo', 6], ['wail', 4]],
  itfaiye: [['agir', 9]],
  zabita: [['vuup', 1]],
};
function sirenDalgasi() {
  // kare dalgaya yakın ama köşeleri yumuşak (sürücü devresi + korna hoparlörü)
  const n = 24;
  const re = new Float32Array(n), im = new Float32Array(n);
  for (let k = 1; k < n; k++) im[k] = k % 2 ? 1 / k : 0.12 / k;
  return ctx.createPeriodicWave(re, im);
}
// Gerçek siren kayıtları (web/ses/siren): polis, ambulans, itfaiye. Kayıt bitmeden bir sonraki kopya
// yumuşak geçişle başlar (kesintisiz döngü); uzaklık, yön ve Doppler (araç yaklaşırken perde yükselir) uygulanır.
// siren klasöründe polis, ambulans, itfaiye ve (varsa) zabita adlı kayıt aranır; olmayan tarayıcıda üretilir
const SIREN_KAYDI = { polis: 'siren/polis.m4a', ambulans: 'siren/ambulans.m4a', itfaiye: 'siren/itfaiye.m4a', zabita: 'siren/zabita.m4a' };
function sirenKaydiVar(tur) { return !!SIREN_KAYDI[tur] && (!katalog || !!katalogKaydi('siren', tur)); }
export function sirenleriYukle() { for (const t of Object.keys(SIREN_KAYDI)) if (sirenKaydiVar(t)) ornekYukle(SIREN_KAYDI[t]); }
function kayitliSiren(tur) {
  const dosya = SIREN_KAYDI[tur];
  const uzak = ctx.createBiquadFilter(); uzak.type = 'lowpass'; uzak.frequency.value = 6000; uzak.Q.value = 0.5;
  const ses = ctx.createGain(); ses.gain.value = 0;
  const panci = ctx.createStereoPanner ? ctx.createStereoPanner() : ctx.createGain();
  const kuru = ctx.createGain(); kuru.gain.value = 0.85;
  const islak = ctx.createGain(); islak.gain.value = 0.35;
  uzak.connect(ses).connect(panci);
  panci.connect(kuru).connect(sokak);
  panci.connect(sokakYankisi()).connect(islak).connect(sokak);
  let hiz = 1, bitti = false, sonraki = 0, zaman = null;
  const kaynaklar = new Set();
  const GECIS = 0.35;
  function parca(t) {
    const b = ornek(dosya);
    if (!b) return false;
    const bas = 0.06, son = Math.max(bas + 1, b.duration - 0.08);
    const k = ctx.createBufferSource();
    k.buffer = b;
    k.playbackRate.value = hiz;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(1, t + GECIS);
    const uzunluk = (son - bas) / hiz;
    g.gain.setValueAtTime(1, t + uzunluk - GECIS);
    g.gain.linearRampToValueAtTime(0, t + uzunluk);
    k.connect(g).connect(uzak);
    k.start(t, bas, son - bas);
    kaynaklar.add(k);
    k.onended = () => kaynaklar.delete(k);
    sonraki = t + uzunluk - GECIS;
    return true;
  }
  function planla() {
    if (bitti || !ctx) return;
    if (!sonraki) { if (!parca(ctx.currentTime + 0.05)) return; }
    if (ctx.currentTime > sonraki - 1) parca(Math.max(sonraki, ctx.currentTime));
  }
  ornekYukle(dosya).then(planla);
  zaman = setInterval(planla, 300);
  return {
    ayarla(guc, pan = 0, yaklasma = 0) {
      if (bitti) return;
      const t = ctx.currentTime;
      const g = Math.max(0, Math.min(1, guc));
      ses.gain.setTargetAtTime(0.95 * g, t, 0.15);
      uzak.frequency.setTargetAtTime(1800 + 9000 * g * g, t, 0.2);
      islak.gain.setTargetAtTime(0.3 + (1 - g) * 0.5, t, 0.3);
      if (panci.pan) panci.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan)), t, 0.15);
      hiz = 343 / (343 - Math.max(-40, Math.min(40, yaklasma)));
      for (const k of kaynaklar) k.playbackRate.setTargetAtTime(hiz, t, 0.2);
    },
    durdur() {
      if (bitti) return;
      bitti = true;
      clearInterval(zaman);
      const t = ctx.currentTime;
      ses.gain.setTargetAtTime(0, t, 0.35);
      for (const k of kaynaklar) { k.playbackRate.setTargetAtTime(hiz * 0.8, t, 0.5); try { k.stop(t + 2); } catch (e) { /* yok say */ } }
      setTimeout(() => { try { panci.disconnect(); } catch (e) { /* yok say */ } }, 3000);
    },
  };
}
export function sirenBaslat(tur = 'polis') {
  if (!kur() || !hazir()) return null;
  if (sirenKaydiVar(tur)) return kayitliSiren(tur);
  const osc = ctx.createOscillator();
  osc.setPeriodicWave(sirenDalgasi());
  const surucu = ctx.createWaveShaper();
  const egri = new Float32Array(1024);
  for (let i = 0; i < 1024; i++) { const x = (i / 1023) * 2 - 1; egri[i] = Math.tanh(x * 2.2) / Math.tanh(2.2); }
  surucu.curve = egri;
  const alcak = ctx.createBiquadFilter(); alcak.type = 'highpass'; alcak.frequency.value = tur === 'itfaiye' ? 220 : 380;
  const korna = ctx.createBiquadFilter(); korna.type = 'peaking'; korna.frequency.value = tur === 'itfaiye' ? 1100 : 1700; korna.Q.value = 1.1; korna.gain.value = 7;
  const korna2 = ctx.createBiquadFilter(); korna2.type = 'peaking'; korna2.frequency.value = 3100; korna2.Q.value = 2; korna2.gain.value = 3;
  const uzak = ctx.createBiquadFilter(); uzak.type = 'lowpass'; uzak.frequency.value = 3000; uzak.Q.value = 0.5;
  const ses = ctx.createGain(); ses.gain.value = 0;
  const kapi = ctx.createGain(); kapi.gain.value = 1; // zabıta uyarıları arasında susmak için
  const panci = ctx.createStereoPanner ? ctx.createStereoPanner() : ctx.createGain();
  const kuru = ctx.createGain(); kuru.gain.value = 0.8;
  const islak = ctx.createGain(); islak.gain.value = 0.45;
  const yanki = sokakYankisi();
  osc.connect(surucu).connect(alcak).connect(korna).connect(korna2).connect(uzak).connect(kapi).connect(ses).connect(panci);
  panci.connect(kuru).connect(sokak);
  panci.connect(yanki).connect(islak).connect(sokak);
  const f = osc.frequency;
  const bas0 = ctx.currentTime + 0.05;
  f.setValueAtTime(tur === 'itfaiye' ? 380 : 650, bas0);
  osc.start(bas0);
  const desen = SIREN_DESEN[tur] || SIREN_DESEN.polis;
  let sira = 0, bolumKalan = 0, bolum = null, ileri = bas0;
  let havaKornasi = 0;
  // frekans eğrisi, yarım saniye ileriye doğru parça parça yazılır
  function planla() {
    if (!ctx) return;
    while (ileri < ctx.currentTime + 0.8) {
      if (bolumKalan <= 0) { bolum = desen[sira++ % desen.length]; bolumKalan = bolum[1]; }
      const t = ileri;
      let sure;
      if (bolum[0] === 'yelp') {
        sure = 0.34;
        f.setValueAtTime(700, t); f.exponentialRampToValueAtTime(1550, t + sure * 0.82); f.exponentialRampToValueAtTime(760, t + sure);
      } else if (bolum[0] === 'wail') {
        sure = 4.2;
        f.setValueAtTime(620, t); f.exponentialRampToValueAtTime(1500, t + 1.9); f.setValueAtTime(1500, t + 2.1); f.exponentialRampToValueAtTime(620, t + sure);
      } else if (bolum[0] === 'hilo') {
        sure = 1.3;
        f.setValueAtTime(f.value || 660, t); f.linearRampToValueAtTime(930, t + 0.05); f.setValueAtTime(930, t + 0.62); f.linearRampToValueAtTime(700, t + 0.68); f.setValueAtTime(700, t + sure);
      } else if (bolum[0] === 'agir') {
        sure = 6.5;
        f.setValueAtTime(330, t); f.exponentialRampToValueAtTime(1050, t + 3); f.setValueAtTime(1050, t + 3.3); f.exponentialRampToValueAtTime(330, t + sure);
        havaKornasi++;
      } else { // vuup
        sure = 2.6;
        f.setValueAtTime(420, t); f.exponentialRampToValueAtTime(1150, t + 0.55); f.exponentialRampToValueAtTime(420, t + 0.9); f.setValueAtTime(420, t + sure);
      }
      // zabıta ve itfaiye arada susar / korna çalar
      if (bolum[0] === 'vuup') {
        kapi.gain.setValueAtTime(0, t); kapi.gain.linearRampToValueAtTime(1, t + 0.04);
        kapi.gain.setValueAtTime(1, t + 0.8); kapi.gain.linearRampToValueAtTime(0, t + 0.95);
      }
      ileri += sure;
      bolumKalan -= bolum[0] === 'wail' || bolum[0] === 'agir' || bolum[0] === 'vuup' ? bolum[1] : sure;
      if (tur === 'itfaiye' && havaKornasi % 2 === 0 && bolum[0] === 'agir') havaKornasiCal(t + sure - 1.4, panci);
    }
  }
  function havaKornasiCal(t, hedef) {
    // itfaiye havalı kornası: iki kalın, hafif akortsuz boru sesi
    for (const [fr, g] of [[146, 0.5], [174, 0.4], [220, 0.25]]) {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = fr;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1400;
      const gg = ctx.createGain();
      gg.gain.setValueAtTime(0, t); gg.gain.linearRampToValueAtTime(g * 0.5, t + 0.04); gg.gain.setValueAtTime(g * 0.5, t + 0.9); gg.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
      o.connect(lp).connect(gg).connect(hedef);
      o.start(t); o.stop(t + 1.2);
    }
  }
  planla();
  const zamanlayici = setInterval(planla, 250);
  let bitti = false;
  return {
    // guc: 0–1 (uzaklık), pan: -1..1, yaklasma: m/s (pozitif yaklaşıyor) → Doppler
    ayarla(guc, pan = 0, yaklasma = 0) {
      if (bitti) return;
      const t = ctx.currentTime;
      const g = Math.max(0, Math.min(1, guc));
      ses.gain.setTargetAtTime(0.16 * g, t, 0.15);
      uzak.frequency.setTargetAtTime(1400 + 7600 * g * g, t, 0.2);
      islak.gain.setTargetAtTime(0.35 + (1 - g) * 0.5, t, 0.3);
      if (panci.pan) panci.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan)), t, 0.15);
      const doppler = 343 / (343 - Math.max(-40, Math.min(40, yaklasma)));
      osc.detune.setTargetAtTime(1200 * Math.log2(doppler), t, 0.2);
    },
    durdur() {
      if (bitti) return;
      bitti = true;
      clearInterval(zamanlayici);
      const t = ctx.currentTime;
      // siren kapanırken ton düşerek söner (motor yavaşlar gibi)
      f.cancelScheduledValues(t);
      f.setValueAtTime(f.value || 600, t);
      f.exponentialRampToValueAtTime(180, t + 1.1);
      ses.gain.setTargetAtTime(0, t + 0.3, 0.25);
      osc.stop(t + 2);
      setTimeout(() => { try { panci.disconnect(); } catch (e) { /* yok say */ } }, 4000);
    },
  };
}
// Eski arayüz: kısa bir siren (tek seferlik)
export function siren(tur = 'polis', sure = 4, guc = 1, pan = 0) {
  if (!hazir() || !durum.aktif || guc <= 0.02) return;
  const s = sirenBaslat(tur);
  if (!s) return;
  s.ayarla(guc, pan);
  setTimeout(() => s.durdur(), sure * 1000);
}
// Düğün konvoyu: art arda korna
export function dugunKornasi(pan = 0) {
  if (!hazir() || !durum.aktif) return;
  const desen = [0, 0.18, 0.36, 0.7, 0.88, 1.06, 1.24];
  desen.forEach((t, i) => { ton(420, t, 0.14, 'square', 0.03, ortam, null, pan); ton(530, t, 0.14, 'square', 0.025, ortam, null, pan + (i % 2 ? 0.2 : -0.2)); });
}
// Sokak müzisyeni: telli bir çalgıdan kısa, neşeli bir ezgi (her çağrıda bir ölçü)
const EZGI = [
  [392, 440, 494, 523, 494, 440, 392, 330],
  [349, 392, 440, 392, 349, 330, 294, 330],
  [392, 494, 587, 523, 494, 440, 494, 392],
];
let ezgiSira = 0;
export function ezgi(guc = 1, pan = 0) {
  if (!hazir() || !durum.aktif || guc <= 0.03) return;
  const notalar = EZGI[ezgiSira++ % EZGI.length];
  notalar.forEach((f, i) => {
    ton(f, i * 0.25, 0.35, 'triangle', 0.05 * guc, ortam, f * 0.995, pan);
    ton(f * 2, i * 0.25, 0.12, 'sine', 0.012 * guc, ortam, null, pan);
    if (i % 4 === 0) ton(f / 2, i * 0.25, 0.5, 'sine', 0.03 * guc, ortam, null, pan);
  });
}
// Kedi: gerçek miyavlama kayıtlarından biri (her seferinde farklı, perdesi hafifçe oynar)
const MIYAV_SAYI = 12;
let sonMiyav = 0;
export function miyav(pan = 0, guc = 1) {
  if (!hazir() || !durum.aktif || guc <= 0.03) return;
  let n = 1 + Math.floor(Math.random() * MIYAV_SAYI);
  if (n === sonMiyav) n = (n % MIYAV_SAYI) + 1;
  sonMiyav = n;
  const ad = `kedi/miyav${n}.mp3`;
  const cal = (t) => { if (t) ornekCal(t, { ses: 0.9 * Math.min(1, guc), pan, hiz: 0.94 + Math.random() * 0.14, hedef: efekt }); };
  const hazirT = ornek(ad);
  if (hazirT) cal(hazirT); else ornekYukle(ad).then(cal);
}
export function kediSesleriniYukle() { for (let i = 1; i <= MIYAV_SAYI; i++) ornekYukle(`kedi/miyav${i}.mp3`); }
export function odul() {
  if (!hazir()) return;
  [523, 659, 784, 1047].forEach((f, i) => ton(f, i * 0.09, 0.22, 'triangle', 0.09));
}

// ------------------------------------------------ Tanıtım müziği
// Tarayıcıda üretilen, yaklaşık 25 saniyelik "gün batımı synthwave" parçası; ezgisi Doğu'ya özgü armonik minör.
// Bölümler (104 BPM, ölçü 2,31 sn): 0-1 giriş (pad ve yükselen ses), 2-3 arp ve bas, 4-7 davul ve saz benzeri ana ezgi,
// 8 gerilim (trampet dizisi), 9 vuruş (logo anı), 10 kuyruk. Tanıtım sahneleri bu ölçülere göre akar.
export const INTRO_BPM = 104;
export const INTRO_OLCU = (60 / INTRO_BPM) * 4;
let yankiTamponu = null;
function yanki() {
  if (!yankiTamponu) {
    const sure = 2.4;
    const n = Math.floor(ctx.sampleRate * sure);
    yankiTamponu = ctx.createBuffer(2, n, ctx.sampleRate);
    for (let k = 0; k < 2; k++) {
      const d = yankiTamponu.getChannelData(k);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2.6);
    }
  }
  const c = ctx.createConvolver();
  c.buffer = yankiTamponu;
  return c;
}
const NOTA = (ad) => {
  const m = /^([A-G])(#?)(\d)$/.exec(ad);
  const yarim = { C: -9, D: -7, E: -5, F: -4, G: -2, A: 0, B: 2 }[m[1]] + (m[2] ? 1 : 0) + (Number(m[3]) - 4) * 12;
  return 440 * Math.pow(2, yarim / 12);
};
// Tanıtım filmi kendi müziğini çalar: arka plan müziği durur, şehir sesi kısılır.
// Dönüş: filmin ses düzeyi (oyuncunun müzik ayarına göre; müzik kapalıysa 0)
export function introVideo(acik) {
  muzikCaliyor = !!acik;
  if (acik) {
    arkaBaglam = 'film';
    clearTimeout(arkaBekleme);
    arkaSira = [];
    if (arkaEl) arkaEl.pause();
    return ayar.kapali.muzik ? 0 : Math.min(1, ayar.muzik * 1.1);
  }
  muzikBaglami('oyun');
  return 0;
}
export function introMuzik() {
  if (!hazir()) { kur(); if (ctx && ctx.state === 'suspended') ctx.resume(); }
  // tanıtımda oyunun kendi tanıtım müziği (web/ses/muzik/intro.m4a) çalar; şehir sesi kısılır
  muzikCaliyor = true;
  muzikBaglami('intro');
  const bitir = (hemen) => {
    muzikCaliyor = false;
    const el = arkaEl;
    if (!el) { muzikBaglami('oyun'); return; }
    const bas = el.volume;
    const adim = hemen ? 8 : 30;
    let i = 0;
    const zaman = setInterval(() => {
      i++;
      if (!arkaKaynak) el.volume = Math.max(0, bas * (1 - i / adim));
      else if (muzikArka) muzikArka.gain.setTargetAtTime(Math.max(0, 1 - i / adim), ctx.currentTime, 0.05);
      if (i >= adim) {
        clearInterval(zaman);
        if (muzikArka) muzikArka.gain.value = 1;
        muzikBaglami('oyun');
      }
    }, 100);
  };
  return { sure: INTRO_OLCU * 11, baslangic: performance.now() + 80, durdur: bitir, olcu: INTRO_OLCU };
}

// ------------------------------------------------ Sokak müzisyeninin repertuvarı
// Hepsi telifsiz: bestecisinin ölümünün üzerinden 70 yıldan çok geçmiş klasik eserler, anonim halk ezgileri
// ve oyunun kendi ürettiği hicaz doğaçlaması. Notalar burada yazılıdır; ses tarayıcıda gitar gibi çalınır.
// Nota: "E5" = mi (5. oktav), "-" = es. Süre vuruş cinsinden.
const PERDE = { C: 0, 'C#': 1, Db: 1, D: 2, 'D#': 3, Eb: 3, E: 4, F: 5, 'F#': 6, Gb: 6, G: 7, 'G#': 8, Ab: 8, A: 9, 'A#': 10, Bb: 10, B: 11 };
function frekans(ad) {
  const m = /^([A-G][#b]?)(\d)$/.exec(ad);
  if (!m) return 0;
  return 440 * Math.pow(2, (PERDE[m[1]] + (Number(m[2]) + 1) * 12 - 69) / 12);
}
// "E4:1 E4:1 F4:1" biçimindeki diziyi çözer
function dizi(yazi) {
  return yazi.trim().split(/\s+/).map((p) => { const [n, s] = p.split(':'); return [n, Number(s || 1)]; });
}
// akor dizisinden gitar arpeji (her akor bir ölçü: 4 vuruş, sekizlik)
function arpej(akorlar, tekrar = 1) {
  const bas = [], ust = [];
  for (let r = 0; r < tekrar; r++) {
    for (const a of akorlar) {
      const [k, ...notalar] = a.split(' ');
      bas.push([k, 4]);
      for (let i = 0; i < 8; i++) ust.push([notalar[[0, 1, 2, 1, 0, 1, 2, 1][i] % notalar.length], 0.5]);
    }
  }
  return { bas, ust };
}
const REPERTUVAR = [
  {
    ad: 'Neşeye Övgü', yazar: 'Beethoven', tempo: 112, keman: true,
    ust: dizi(`E5 E5 F5 G5 G5 F5 E5 D5 C5 C5 D5 E5 E5:1.5 D5:0.5 D5:2
      E5 E5 F5 G5 G5 F5 E5 D5 C5 C5 D5 E5 D5:1.5 C5:0.5 C5:2
      D5 D5 E5 C5 D5 E5:0.5 F5:0.5 E5 C5 D5 E5:0.5 F5:0.5 E5 D5 C5 D5 G4:2
      E5 E5 F5 G5 G5 F5 E5 D5 C5 C5 D5 E5 D5:1.5 C5:0.5 C5:2`),
    bas: dizi(`C3:4 G2:4 C3:4 G2:4 C3:4 G2:4 C3:4 C3:4 G2:4 C3:4 G2:4 G2:4 C3:4 G2:4 C3:4 C3:4`),
  },
  {
    ad: 'Für Elise', yazar: 'Beethoven', tempo: 132, sakin: true,
    ust: dizi(`E5:0.5 D#5:0.5 E5:0.5 D#5:0.5 E5:0.5 B4:0.5 D5:0.5 C5:0.5 A4:1.5 -:0.5 C4:0.5 E4:0.5 A4:0.5 B4:1.5 -:0.5 E4:0.5 G#4:0.5 B4:0.5 C5:1.5 -:0.5
      E4:0.5 E5:0.5 D#5:0.5 E5:0.5 D#5:0.5 E5:0.5 B4:0.5 D5:0.5 C5:0.5 A4:1.5 -:0.5 C4:0.5 E4:0.5 A4:0.5 B4:1.5 -:0.5 E4:0.5 C5:0.5 B4:0.5 A4:2`),
    bas: dizi(`-:3 A2:1.5 -:1.5 E2:1.5 -:1.5 A2:1.5 -:3 A2:1.5 -:1.5 E2:1.5 -:1.5 A2:2`),
  },
  {
    ad: 'Türk Marşı', yazar: 'Mozart', tempo: 126, keman: true,
    ust: dizi(`B4:0.25 A4:0.25 G#4:0.25 A4:0.25 C5:1 D5:0.25 C5:0.25 B4:0.25 C5:0.25 E5:1 F5:0.25 E5:0.25 D#5:0.25 E5:0.25 B5:0.25 A5:0.25 G#5:0.25 A5:0.25 B5:0.25 A5:0.25 G#5:0.25 A5:0.25 C6:1
      A5:0.5 C6:0.5 B5:0.5 A5:0.5 G5:0.5 A5:0.5 B5:0.5 A5:0.5 G5:0.5 A5:0.5 B5:0.5 A5:0.5 G5:0.5 F#5:0.5 E5:1`),
    bas: dizi(`-:1 A3:1 C4:1 E3:1 A3:1 A3:1 A3:1 A3:1 E3:1 E3:1 E3:1 E3:1 E3:1 B2:1 E3:1`),
  },
  {
    ad: 'Minuet (Sol majör)', yazar: 'Petzold', tempo: 120, keman: true,
    ust: dizi(`D5 G4:0.5 A4:0.5 B4:0.5 C5:0.5 D5 G4 G4 E5 C5:0.5 D5:0.5 E5:0.5 F#5:0.5 G5 G4 G4
      C5 D5:0.5 C5:0.5 B4:0.5 A4:0.5 B4 C5:0.5 B4:0.5 A4:0.5 G4:0.5 F#4 G4:0.5 A4:0.5 B4:0.5 G4:0.5 A4:3
      D5 G4:0.5 A4:0.5 B4:0.5 C5:0.5 D5 G4 G4 E5 C5:0.5 D5:0.5 E5:0.5 F#5:0.5 G5 G4 G4
      C5 D5:0.5 C5:0.5 B4:0.5 A4:0.5 B4 C5:0.5 B4:0.5 A4:0.5 G4:0.5 A4 B4:0.5 A4:0.5 G4:0.5 F#4:0.5 G4:3`),
    bas: dizi(`G3:3 B3:3 C4:3 B3:3 A3:3 G3:3 D3:3 D3:3 G3:3 B3:3 C4:3 B3:3 A3:3 G3:3 D3:3 G3:3`),
  },
  {
    ad: 'Greensleeves', yazar: 'Anonim İngiliz halk ezgisi', tempo: 150, keman: true, ezgi: 'klarnet',
    ust: dizi(`A4 C5:2 D5 E5:1.5 F5:0.5 E5 D5:2 B4 G4:1.5 A4:0.5 B4 C5:2 A4 A4:1.5 G#4:0.5 A4 B4:2 G#4 E4:2
      A4 C5:2 D5 E5:1.5 F5:0.5 E5 D5:2 B4 G4:1.5 A4:0.5 B4 C5:1.5 B4:0.5 A4 G#4:1.5 F#4:0.5 G#4 A4:3`),
    bas: dizi(`A2:3 A2:3 G2:3 G2:3 A2:3 A2:3 E2:3 E2:3 A2:3 A2:3 G2:3 G2:3 A2:3 E2:3 A2:3`),
  },
  {
    ad: 'Gymnopédie No. 1', yazar: 'Satie', tempo: 72, sakin: true,
    ust: dizi(`-:3 -:3 -:3 -:3 -:1 F#5 A5 G5 F#5 C#5 B4 C#5 D5 A4:3 F#4:3 -:3 -:1 F#5 A5 G5 F#5 C#5 B4 C#5 D5 A4:3 C#5:3 F#5:6`),
    bas: dizi(`G2:3 D2:3 G2:3 D2:3 G2:3 D2:3 G2:3 D2:3 G2:3 D2:3 G2:3 D2:3 G2:3 D2:3`),
    akor: ['B3 D4 F#4', 'A3 C#4 F#4'],
  },
  (() => {
    const a = arpej(['D3 F#4 A4 D5', 'A2 E4 A4 C#5', 'B2 F#4 B4 D5', 'F#2 C#4 F#4 A4', 'G2 D4 G4 B4', 'D3 D4 F#4 A4', 'G2 D4 G4 B4', 'A2 E4 A4 C#5'], 2);
    return { ad: 'Kanon', yazar: 'Pachelbel', tempo: 84, ust: a.ust, bas: a.bas };
  })(),
  {
    ad: 'İlkbahar (Dört Mevsim)', yazar: 'Vivaldi', tempo: 100, keman: true,
    ust: dizi(`E5:0.5 G#5:0.5 G#5:0.5 G#5:0.5 F#5:0.25 E5:0.25 B5:1.5 B5:0.25 A5:0.25 G#5:0.5 G#5:0.5 G#5:0.5 F#5:0.25 E5:0.25 B5:1.5
      B5:0.25 A5:0.25 G#5:0.5 A5:0.5 B5:0.5 A5:0.5 G#5:0.5 F#5:0.5 D#5:1
      E5:0.5 G#5:0.5 G#5:0.5 G#5:0.5 F#5:0.25 E5:0.25 B5:1.5 B5:0.25 A5:0.25 G#5:0.5 G#5:0.5 G#5:0.5 F#5:0.25 E5:0.25 B5:1.5
      B5:0.25 A5:0.25 G#5:0.5 A5:0.5 B5:0.5 A5:0.5 G#5:0.5 F#5:0.5 E5:2`),
    bas: dizi(`E3:2 E3:2 E3:2 E3:2 E3:1 A2:1 B2:2 E3:2 E3:2 E3:2 E3:2 E3:1 A2:1 B2:1 E3:1`),
  },
  {
    ad: 'Habanera (Carmen)', yazar: 'Bizet', tempo: 96, keman: true,
    ust: dizi(`D5:1 C#5:0.5 C5:0.5 C5:1 B4:0.5 Bb4:0.5 A4:1 A4:0.5 Ab4:0.5 G4:0.5 G4:0.5 F4:0.5 E4:0.5 F4:1 E4:0.5 F4:0.5 G4:1 F4:0.5 E4:0.5 D4:2
      D5:1 C#5:0.5 C5:0.5 C5:1 B4:0.5 Bb4:0.5 A4:1 A4:0.5 Ab4:0.5 G4:0.5 G4:0.5 F4:0.5 E4:0.5 F4:1 E4:0.5 F4:0.5 G4:1 A4:1 D4:2`),
    bas: dizi(`D3:0.75 D3:0.25 A2:0.5 A2:0.5 D3:0.75 D3:0.25 A2:0.5 A2:0.5 D3:0.75 D3:0.25 A2:0.5 A2:0.5 D3:0.75 D3:0.25 A2:0.5 A2:0.5
      A2:0.75 A2:0.25 E3:0.5 E3:0.5 D3:0.75 D3:0.25 A2:0.5 A2:0.5 D3:0.75 D3:0.25 A2:0.5 A2:0.5 D3:0.75 D3:0.25 A2:0.5 A2:0.5
      D3:0.75 D3:0.25 A2:0.5 A2:0.5 D3:0.75 D3:0.25 A2:0.5 A2:0.5 A2:0.75 A2:0.25 E3:0.5 E3:0.5 D3:2`),
  },
  {
    ad: 'Amazing Grace', yazar: 'Anonim ilahi', tempo: 84, keman: true, sakin: true,
    ust: dizi(`-:2 D4:1 G4:2 B4:0.5 G4:0.5 B4:2 A4:1 G4:2 E4:1 D4:2 D4:1 G4:2 B4:0.5 G4:0.5 B4:2 A4:0.5 B4:0.5 D5:3 -:2
      B4:1 D5:1.5 B4:0.5 D5:0.5 B4:0.5 G4:2 D4:1 E4:1.5 G4:0.5 G4:0.5 E4:0.5 D4:2 D4:1 G4:2 B4:0.5 G4:0.5 B4:2 A4:1 G4:3`),
    bas: dizi(`-:2 G2:1 G2:3 G2:3 C3:3 G2:3 G2:3 E2:3 D2:3 D2:3 G2:3 G2:3 C3:3 G2:3 G2:3 E2:3 D2:3 G2:3`),
    akor: ['B3 D4', 'B3 D4', 'C4 E4', 'B3 D4', 'B3 D4', 'B3 E4', 'A3 D4', 'A3 C4'],
  },
  {
    ad: 'Scarborough Fair', yazar: 'Anonim İngiliz halk ezgisi', tempo: 108, keman: true, ezgi: 'klarnet',
    ust: dizi(`D4:2 D4:1 A4:2 A4:1 E4:1.5 F4:0.5 E4:1 D4:3 -:1 A4:1 C5:1 D5:2 C5:1 A4:1 B4:1 G4:1 A4:3
      -:1 D5:2 D5:1 D5:2 C5:1 A4:2 A4:1 G4:1 F4:1 E4:1 C4:3 D4:2 A4:1 G4:2 F4:1 E4:1 D4:1 C4:1 D4:3`),
    bas: dizi(`D3:3 D3:3 A2:3 D3:3 D3:3 F3:3 C3:3 D3:3 D3:3 D3:3 A2:3 C3:3 C3:3 D3:3 A2:3 D3:3`),
  },
  {
    ad: 'Korobeiniki', yazar: 'Anonim Rus halk ezgisi', tempo: 132, keman: true, ezgi: 'klarnet',
    ust: dizi(`E5:1 B4:0.5 C5:0.5 D5:1 C5:0.5 B4:0.5 A4:1 A4:0.5 C5:0.5 E5:1 D5:0.5 C5:0.5 B4:1.5 C5:0.5 D5:1 E5:1 C5:1 A4:1 A4:2
      -:0.5 D5:1 F5:0.5 A5:1 G5:0.5 F5:0.5 E5:1.5 C5:0.5 E5:1 D5:0.5 C5:0.5 B4:1 B4:0.5 C5:0.5 D5:1 E5:1 C5:1 A4:1 A4:2`),
    bas: dizi(`E3:1 E3:1 E3:1 E3:1 A2:1 A2:1 A2:1 A2:1 G#2:1 G#2:1 E2:1 E2:1 A2:1 A2:1 A2:2 D3:1 D3:1 D3:1 D3:1 C3:1 C3:1 C3:1 C3:1 G#2:1 G#2:1 E2:1 E2:1 A2:1 A2:1 A2:2`),
  },
  { ad: 'Hicaz doğaçlama', yazar: 'Çırak', tempo: 96, dogaclama: true, keman: true, ezgi: 'klarnet' },
  { ad: 'Hicaz saz semaisi (doğaçlama)', yazar: 'Çırak', tempo: 104, dogaclama: true, keman: true },
];

// Hicaz makamında oyunun kendi ürettiği ezgi (her seferinde farklı): La hicaz dizisi A Bb C# D E F G A
function hicazUret() {
  const dizi2 = ['A3', 'Bb3', 'C#4', 'D4', 'E4', 'F4', 'G4', 'A4', 'Bb4', 'C#5', 'D5', 'E5'];
  const ust = [];
  let i = 7;
  for (let olcu = 0; olcu < 16; olcu++) {
    let kalan = 4;
    while (kalan > 0) {
      const s = Math.min(kalan, [0.5, 0.5, 1, 1, 1.5, 2][Math.floor(Math.random() * 6)]);
      i = Math.max(0, Math.min(dizi2.length - 1, i + [-2, -1, -1, 1, 1, 2, 0][Math.floor(Math.random() * 7)]));
      if (olcu % 4 === 3 && kalan === s) i = [0, 3, 4, 7][Math.floor(Math.random() * 4)]; // cümle sonu durak/güçlü seste biter
      ust.push([dizi2[i], s]);
      kalan -= s;
    }
  }
  const bas = [];
  for (let olcu = 0; olcu < 16; olcu++) bas.push([['A2', 'A2', 'D3', 'A2', 'G2', 'A2', 'E2', 'A2'][olcu % 8], 4]);
  return { ust, bas };
}

// Gitar: gerçek naylon telli klasik gitar kayıtları (FluidR3 GM, CC BY 3.0). Her küçük üçlüde bir nota
// kaydı vardır; aradaki notalar en yakın kaydın hızı çok az değiştirilerek çalınır (en çok ±1,5 yarım ses).
const GITAR_NOTALARI = [];
for (let o = 2; o <= 6; o++) for (const n of ['C', 'Eb', 'Gb', 'A']) GITAR_NOTALARI.push({ ad: n + o, midi: PERDE[n] + (o + 1) * 12 });
function gitarYukle() { return Promise.all(GITAR_NOTALARI.map((n) => ornekYukle(`gitar/${n.ad}.mp3`))); }
function gitarNota(f, t, sure, ses, hedef) {
  const midi = 69 + 12 * Math.log2(f / 440);
  let en = GITAR_NOTALARI[0];
  for (const n of GITAR_NOTALARI) if (Math.abs(n.midi - midi) < Math.abs(en.midi - midi)) en = n;
  const tampon = ornek(`gitar/${en.ad}.mp3`);
  if (!tampon) return;
  // insan eli: vuruşlar milisaniyelerle kayar, güç biraz değişir
  const kay = (Math.random() - 0.5) * 0.018;
  ornekCal(tampon, { t: t + kay, ses: ses * 5.5 * (0.85 + Math.random() * 0.3), hiz: Math.pow(2, (midi - en.midi) / 12), hedef, bitis: t + Math.max(0.25, sure) + 0.25 });
}

// Keman: gerçek keman kayıtları (FluidR3 GM, CC BY 3.0), küçük üçlü aralıklarla; ezgiyi keman, eşliği gitar çalar
const KEMAN_NOTALARI = [];
for (let o = 3; o <= 6; o++) for (const n of ['C', 'Eb', 'Gb', 'A']) KEMAN_NOTALARI.push({ ad: n + o, midi: PERDE[n] + (o + 1) * 12 });
function kemanYukle() { return Promise.all(KEMAN_NOTALARI.map((n) => ornekYukle(`keman/${n.ad}.mp3`))); }
function kemanNota(f, t, sure, ses, hedef) {
  const midi = 69 + 12 * Math.log2(f / 440);
  let en = KEMAN_NOTALARI[0];
  for (const n of KEMAN_NOTALARI) if (Math.abs(n.midi - midi) < Math.abs(en.midi - midi)) en = n;
  const tampon = ornek(`keman/${en.ad}.mp3`);
  if (!tampon) return;
  // yay: yumuşak başlar, notanın sonunda bırakılır; hafif vibrato için perde çok az oynar
  const k = ctx.createBufferSource();
  k.buffer = tampon;
  k.playbackRate.value = Math.pow(2, (midi - en.midi) / 12);
  const g = ctx.createGain();
  const son = t + Math.max(0.2, sure * 0.96);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(ses * 4.2, t + 0.05);
  g.gain.setValueAtTime(ses * 4.2, Math.max(t + 0.06, son - 0.08));
  g.gain.linearRampToValueAtTime(0, son + 0.12);
  k.connect(g).connect(hedef);
  k.start(t);
  k.stop(son + 0.2);
}

// Klarnet ve org: gerçek kayıtlar (FluidR3 GM, CC BY 3.0), küçük üçlü aralıklarla. Tutulan nota: yumuşak giriş, sonda bırakma.
function notaSeti(klasor, ilk, son) {
  const l = [];
  for (let o = ilk; o <= son; o++) for (const n of ['C', 'Eb', 'Gb', 'A']) l.push({ ad: n + o, midi: PERDE[n] + (o + 1) * 12 });
  return { klasor, l, yukle: () => Promise.all(l.map((n) => ornekYukle(`${klasor}/${n.ad}.mp3`))) };
}
const KLARNET = notaSeti('klarnet', 3, 6);
const ORG = notaSeti('org', 2, 5);
function tutuluNota(set, f, t, sure, ses, hedef, { giris = 0.04, birakma = 0.12, kazanc = 4 } = {}) {
  const midi = 69 + 12 * Math.log2(f / 440);
  let en = set.l[0];
  for (const n of set.l) if (Math.abs(n.midi - midi) < Math.abs(en.midi - midi)) en = n;
  const tampon = ornek(`${set.klasor}/${en.ad}.mp3`);
  if (!tampon) return;
  const k = ctx.createBufferSource();
  k.buffer = tampon;
  k.playbackRate.value = Math.pow(2, (midi - en.midi) / 12);
  const g = ctx.createGain();
  const bit = t + Math.max(0.15, Math.min(tampon.duration - 0.2, sure * 0.95));
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(ses * kazanc, t + giris);
  g.gain.setValueAtTime(ses * kazanc, Math.max(t + giris + 0.01, bit - 0.05));
  g.gain.linearRampToValueAtTime(0, bit + birakma);
  k.connect(g).connect(hedef);
  k.start(t);
  k.stop(bit + birakma + 0.05);
}
const klarnetNota = (f, t, sure, ses, hedef) => tutuluNota(KLARNET, f, t, sure, ses, hedef, { giris: 0.035, birakma: 0.1, kazanc: 4.6 });
const orgNota = (f, t, sure, ses, hedef) => tutuluNota(ORG, f, t, sure, ses, hedef, { giris: 0.02, birakma: 0.18, kazanc: 3.2 });

// Darbuka: tarayıcıda üretilir. D = düm (pesten, gövdeden), T = tek (kenardan, tiz), k = ka (hafif tek)
function darbukaVurus(tur, t, ses, hedef) {
  if (tur === 'D') {
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(120, t);
    o.frequency.exponentialRampToValueAtTime(62, t + 0.14);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(ses * 1.5, t + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 0.42);
    o.connect(g).connect(hedef);
    o.start(t); o.stop(t + 0.45);
  }
  const n = ctx.createBufferSource();
  n.buffer = gurultu('beyaz', 1);
  const bp = ctx.createBiquadFilter();
  bp.type = 'bandpass';
  bp.frequency.value = tur === 'D' ? 900 : tur === 'T' ? 3400 : 2700;
  bp.Q.value = tur === 'D' ? 0.8 : 1.6;
  const ng = ctx.createGain();
  const guc = tur === 'D' ? 0.35 : tur === 'T' ? 1.1 : 0.5;
  const uz = tur === 'D' ? 0.05 : tur === 'T' ? 0.09 : 0.06;
  ng.gain.setValueAtTime(0, t);
  ng.gain.linearRampToValueAtTime(ses * guc, t + 0.002);
  ng.gain.exponentialRampToValueAtTime(0.0008, t + uz);
  n.connect(bp).connect(ng).connect(hedef);
  n.start(t, Math.random() * 0.8); n.stop(t + uz + 0.02);
  if (tur !== 'D') {
    // gövdenin metal çınlaması
    const o = ctx.createOscillator();
    o.type = 'triangle';
    o.frequency.value = tur === 'T' ? 540 : 470;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(ses * (tur === 'T' ? 0.35 : 0.15), t + 0.003);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 0.16);
    o.connect(g).connect(hedef);
    o.start(t); o.stop(t + 0.18);
  }
}
// ritimler (sekizlik vuruşlar): 4/4 maksum, 3/4 vals, ağır parçada sade düm-tek
const DARBUKA_RITIM = { dort: 'DT.TD.T.', uc: 'D.TkTk', agir: 'D..kT..k' };

// muzisyen klasöründeki her kayıt repertuvara girer. Dosya adı eserin adı olur ("Uzun İnce Bir Yoldayım.mp3");
// "sokak3" gibi adlar "Sokak şarkısı 3" diye görünür.
function kayitAdi(ad) {
  const m = /^sokak\s*-?\s*(\d+)$/i.exec(ad);
  return m ? `Sokak şarkısı ${m[1]}` : ad.replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
}
// 0.21: müzisyenler yalnızca bu klasördeki kayıtları çalar (sentez düzenlemeler repertuvardan çıktı).
function repertuvar() {
  const kayitlar = katalog && katalog.muzisyen && katalog.muzisyen.length
    ? katalog.muzisyen.map((x) => ({ ad: kayitAdi(x.ad), yazar: 'Sokak müzisyenleri', kayit: `muzisyen/${x.ad}.m4a` }))
    : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => ({ ad: `Sokak şarkısı ${i}`, yazar: 'Sokak müzisyenleri', kayit: `muzisyen/sokak${i}.m4a` }));
  return kayitlar;
}

// Sokak müzisyenleri (gitarist ve kemancı): eserleri karışık sırayla çalar. Repertuvarda hem oyunun
// gönderilen kayıtları (web/ses/muzisyen) hem de keman-gitar düzenlemeleri var. ayarla(guc, pan) uzaklığa göre sesi ayarlar.
const muzisyenler = new Set();
export function muzisyenBaslat({ parcaDegisti } = {}) {
  if (!kur()) return null;
  const cikis = ctx.createGain();
  cikis.gain.value = 0;
  const panci = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
  if (panci) cikis.connect(panci).connect(sokakMuzik); else cikis.connect(sokakMuzik);
  // açık havanın yankısı
  const yankiG = ctx.createGain(); yankiG.gain.value = 0.22;
  cikis.connect(sokakYankisi()).connect(yankiG).connect(panci || sokakMuzik);
  // Kayıtlar <audio> öğesinden akarak çalar: bütün parça indirilip belleğe açılmaz (uzun kayıtlar
  // tablette yüzlerce MB bellek tutup oyunu dondurabiliyordu); yalnızca çalan parça indirilir.
  const yuklendi = true;
  const kayitEl = new Audio();
  kayitEl.preload = 'auto';
  let kayitDugum = null;
  // parça değişirken (bahşiş isteği) kayıt yumuşakça kısılır; ayarla() cikis'i sürekli güncellediği için ayrı düğüm
  const solma = ctx.createGain();
  solma.connect(cikis);
  const kayitBagla = () => {
    if (kayitDugum || !ctx) return;
    try { kayitDugum = ctx.createMediaElementSource(kayitEl); kayitDugum.connect(solma); } catch (e) { kayitDugum = null; }
  };
  let beklemede = false; // ezan ya da anons sırasında müzisyenler susar
  const kayitCaliyor = () => !kayitEl.paused && !kayitEl.ended && kayitEl.currentTime > 0;
  // her çalgının son vuruş/nota zamanı (sahnede çalan müzisyen canlanır)
  const son = { gitar: -9, keman: -9, klarnet: -9, org: -9, darbuka: -9, kayit: false };
  let liste = repertuvar();
  // Gerçek karıştırma (Fisher–Yates); geçen sefer ilk çalınan parça bu kez başa gelmez
  const siraKur = () => {
    const l = karistir(liste.map((_, i) => i));
    let son = null;
    try { son = localStorage.getItem('tezgah_muzisyen_son'); } catch (e) { /* yok say */ }
    if (l.length > 1 && liste[l[0]] && liste[l[0]].ad === son) l.push(l.shift());
    return l;
  };
  let sira = siraKur();
  let ilkParca = true;
  katalogSozu.then(() => { liste = repertuvar(); sira = siraKur(); sn = 0; });
  let sn = 0;
  let olaylar = [];
  let zamanlayici = null;
  let durdu = false;
  const kayit = { guc: 0 };
  muzisyenler.add(kayit);
  function parcaBaslat() {
    if (sn >= sira.length) { sira = siraKur(); sn = 0; }
    const p = liste[sira[sn++]];
    if (ilkParca) { ilkParca = false; try { localStorage.setItem('tezgah_muzisyen_son', p.ad); } catch (e) { /* yok say */ } }
    olaylar = [];
    solma.gain.cancelScheduledValues(ctx.currentTime);
    solma.gain.setTargetAtTime(1, ctx.currentTime, 0.05);
    if (p.kayit) {
      // kayıt akarak çalar; bitince 3 sn ara verilir. Açılamazsa diğer biçim denenir, o da olmazsa sıradakine geçilir.
      kayitBagla();
      const yollar = adaylar(p.kayit);
      let i = 0;
      const sonraki = (sn2) => { if (!durdu && ctx) sonrakiParca = ctx.currentTime + sn2; };
      kayitEl.onended = () => sonraki(3);
      kayitEl.onerror = () => { if (++i < yollar.length) { kayitEl.src = yollar[i]; kayitEl.play().catch(() => sonraki(4)); } else sonraki(2); };
      kayitEl.src = yollar[0];
      kayitEl.volume = kayitDugum ? 1 : 0.35;
      kayitEl.play().catch(() => sonraki(4));
      if (parcaDegisti) parcaDegisti(p);
      return Infinity; // bitiş olayı sıradakini zamanlar
    }
    const icerik = p.dogaclama ? hicazUret() : p;
    const vurus = 60 / p.tempo;
    const bas = ctx.currentTime + 0.3;
    let t = 0;
    son.kayit = false;
    const ezgi = p.ezgi || (p.keman ? 'keman' : 'gitar');
    for (const [n, s] of icerik.ust) { if (n !== '-') olaylar.push({ t: bas + t * vurus, f: frekans(n), sure: s * vurus, ses: ezgi === 'klarnet' ? 0.075 : 0.08, c: ezgi }); t += s; }
    const uzunluk = t;
    // darbuka: ölçüye göre ritim (bas notaları 3 vuruşluksa 3/4); sakin parçalarda çalmaz
    const ilkBas = (icerik.bas || []).find(([n]) => n !== '-');
    if (!p.sakin) {
      const r = ilkBas && ilkBas[1] === 3 ? DARBUKA_RITIM.uc : p.tempo < 90 ? DARBUKA_RITIM.agir : DARBUKA_RITIM.dort;
      for (let i = 0, x = 0; x < uzunluk; i++, x += 0.5) {
        const v = r[i % r.length];
        if (v !== '.') olaylar.push({ t: bas + x * vurus, darbuka: v, ses: v === 'D' ? 0.16 : v === 'T' ? 0.12 : 0.07 * (0.8 + Math.random() * 0.4) });
      }
    }
    t = 0;
    let ak = 0;
    for (const [n, s] of icerik.bas || []) {
      if (n !== '-') {
        olaylar.push({ t: bas + t * vurus, f: frekans(n), sure: s * vurus, ses: 0.06 });
        // org: basın üstünde tutulan yumuşak akor (kök, beşli, oktav)
        if (s >= 2) {
          const f0 = frekans(n);
          for (const [c, g] of [[2, 0.02], [3, 0.014], [4, 0.012]]) olaylar.push({ t: bas + t * vurus, f: f0 * c, sure: s * vurus, ses: g, c: 'org' });
        }
        if (p.akor) for (const a of p.akor[ak++ % p.akor.length].split(' ')) olaylar.push({ t: bas + (t + 1) * vurus, f: frekans(a), sure: Math.max(0.5, s - 1) * vurus, ses: 0.03 });
        else if (p.keman && s >= 2) {
          // kemanın altında gitar, kökün beşlisi ve oktavıyla basit bir eşlik çalar
          const f0 = frekans(n);
          for (let i = 1; i < s; i++) olaylar.push({ t: bas + (t + i) * vurus, f: f0 * (i % 2 ? 1.5 : 2), sure: vurus, ses: 0.028 });
        }
      }
      t += s;
    }
    olaylar.sort((a, b) => a.t - b.t);
    if (parcaDegisti) parcaDegisti(p);
    return bas + uzunluk * vurus + 3;
  }
  let sonrakiParca = 0;
  zamanlayici = setInterval(() => {
    if (durdu || !hazir() || !yuklendi) return;
    // ezan okunurken ya da anons yapılırken susarlar; bitince kaldıkları yerden devam ederler
    const sus = bastirma.has('cagri') || bastirma.has('duyuru');
    if (sus && !beklemede) { beklemede = true; olaylar = []; if (!kayitEl.paused) { kayitEl.pause(); kayitEl.dataset.bekliyor = '1'; } }
    if (sus) { if (sonrakiParca !== Infinity) sonrakiParca = Math.max(sonrakiParca, ctx.currentTime + 2); return; }
    if (beklemede) {
      beklemede = false;
      if (kayitEl.dataset.bekliyor) { delete kayitEl.dataset.bekliyor; kayitEl.play().catch(() => {}); }
      else if (sonrakiParca !== Infinity) sonrakiParca = ctx.currentTime + 1.5;
    }
    const simdiT = ctx.currentTime;
    if (simdiT > sonrakiParca) sonrakiParca = parcaBaslat();
    while (olaylar.length && olaylar[0].t < simdiT + 0.5) {
      const o = olaylar.shift();
      if (o.t < simdiT - 0.05) continue;
      const tt = Math.max(o.t, simdiT);
      if (o.darbuka) { darbukaVurus(o.darbuka, tt, o.ses, cikis); son.darbuka = tt; continue; }
      if (!o.f) continue;
      const c = o.c || 'gitar';
      (c === 'keman' ? kemanNota : c === 'klarnet' ? klarnetNota : c === 'org' ? orgNota : gitarNota)(o.f, tt, o.sure, o.ses, cikis);
      son[c] = tt;
    }
  }, 120);
  return {
    // çalgı son 0,6 sn içinde çaldı mı (kayıt çalarken herkes çalıyor sayılır)
    // bahşiş isteği: çalan parça kısılıp biter, (varsa) anons yapılır, ardından yeni bir parça başlar
    async sonrakine(once) {
      if (!ctx || durdu) return;
      const t = ctx.currentTime;
      solma.gain.cancelScheduledValues(t);
      solma.gain.setTargetAtTime(0, t, 0.5);
      olaylar = [];
      sonrakiParca = Infinity;
      await new Promise((r) => setTimeout(r, 1800));
      if (durdu) return;
      try { kayitEl.pause(); } catch (e) { /* yok say */ }
      delete kayitEl.dataset.bekliyor;
      if (once) { try { await once(); } catch (e) { /* yok say */ } }
      if (durdu) return;
      sonrakiParca = ctx.currentTime + 0.6;
    },
    caliyor(c) {
      if (!ctx) return false;
      if (beklemede) return false;
      const t = ctx.currentTime;
      if (kayitCaliyor() && solma.gain.value > 0.2) return true;
      return t - son[c] < (c === 'org' || c === 'keman' || c === 'klarnet' ? 1.2 : 0.6);
    },
    sonVurus(c) { return ctx ? ctx.currentTime - son[c] : 9; },
    ayarla(guc, pan = 0) {
      if (!ctx) return;
      kayit.guc = guc;
      // kayıtlar -23 LUFS'e dengelenip sıkıştırıldı; yanında dururken bile arka plan müziğini bastırmaz
      cikis.gain.setTargetAtTime(Math.max(0, Math.min(1, guc)), ctx.currentTime, 0.3);
      if (panci) panci.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan)), ctx.currentTime, 0.3);
    },
    durdur() {
      durdu = true;
      muzisyenler.delete(kayit);
      clearInterval(zamanlayici);
      if (ctx) cikis.gain.setTargetAtTime(0, ctx.currentTime, 0.4);
      setTimeout(() => {
        try { kayitEl.pause(); kayitEl.removeAttribute('src'); kayitEl.load(); if (kayitDugum) kayitDugum.disconnect(); cikis.disconnect(); } catch (e) { /* yok say */ }
      }, 3000);
    },
  };
}
export function muzisyenRepertuvari() { return repertuvar().map((p) => `${p.ad} (${p.yazar})`); }

// ------------------------------------------------ Anons (müzisyenin mikrofonu)
// Tarayıcının Türkçe konuşma sesiyle söylenir. Konuşma sesi Web Audio'dan geçmediği için yankı; mikrofonun açılma
// "tık"ı, kısa bir hoparlör çınlaması ve anonsun ardından salonun yankı kuyruğuyla verilir.
let turkceSes = null;
function sesSec() {
  if (!('speechSynthesis' in window)) return null;
  const l = speechSynthesis.getVoices();
  turkceSes = l.find((v) => /^tr(-|_|$)/i.test(v.lang) && /google|natural|neural|online/i.test(v.name)) || l.find((v) => /^tr(-|_|$)/i.test(v.lang)) || null;
  return turkceSes;
}
if ('speechSynthesis' in window) { sesSec(); speechSynthesis.addEventListener && speechSynthesis.addEventListener('voiceschanged', sesSec); }
function mikrofon(bas, acilis = true) {
  if (!hazir()) return;
  const hedef = sokak || efekt;
  // mikrofonun açılıp kapanma tıkırtısı ve hoparlörün kısa geri beslemesi
  patlama(bas, 0.05, 0.25, acilis ? 1800 : 1200, hedef, 'bandpass', 1.5);
  if (acilis) ton(2350, bas + 0.06, 0.45, 'sine', 0.018, hedef, 2280);
  const y = yanki();
  const g = ctx.createGain(); g.gain.value = 0.5;
  y.connect(g).connect(hedef);
  const s = ctx.createBufferSource(); s.buffer = gurultu('pembe', 1);
  const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = 0.6;
  const gg = ctx.createGain(); const t = ctx.currentTime + bas;
  gg.gain.setValueAtTime(0.05, t); gg.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
  s.connect(f).connect(gg).connect(y); s.start(t); s.stop(t + 0.4);
}
export function duyuru(metin) {
  return new Promise((bitti) => {
    kur();
    bastir('duyuru', true);
    const son = () => { mikrofon(0.05, false); setTimeout(() => { bastir('duyuru', false); bitti(); }, 900); };
    const v = turkceSes || sesSec();
    const efektAcik = !ayar.kapali.efekt && ayar.efekt > 0;
    if (!v || !efektAcik || !('speechSynthesis' in window)) { setTimeout(son, 2200); return; }
    mikrofon(0);
    setTimeout(() => {
      try {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(metin);
        u.voice = v; u.lang = v.lang; u.rate = 0.9; u.pitch = 0.92; u.volume = Math.min(1, ayar.efekt * 1.1);
        let tamam = false;
        const kapat = () => { if (!tamam) { tamam = true; son(); } };
        u.onend = kapat; u.onerror = kapat;
        setTimeout(kapat, 9000);
        speechSynthesis.speak(u);
      } catch (e) { son(); }
    }, 550);
  });
}

// ------------------------------------------------ İbadete çağrılar (ezan, kilise çanı, şofar, tapınak çanı, şankha)
// Kayıtlar web/ses/cagri altında: ezan-<vakit><1|2>.mp3 ve kilise<1..3>.mp3. Diğerleri tarayıcıda üretilir.
// Çağrı sürerken sokak müzisyenleri ve arka plan müziği susar.
let cagri = null;
const cagriDinleyiciler = new Set();
export function cagriDinle(fn) { cagriDinleyiciler.add(fn); return () => cagriDinleyiciler.delete(fn); }
function cagriHaber(d) { for (const f of cagriDinleyiciler) { try { f(d); } catch (e) { /* yok say */ } } }
export function cagriCaliyor() { return cagri ? cagri.tur : null; }
export function cagriDurdur() {
  if (!cagri) return;
  const c = cagri;
  cagri = null;
  try { c.durdur(); } catch (e) { /* yok say */ }
  bastir('cagri', false);
  cagriHaber(null);
}
function cagriCikisi() {
  const g = ctx.createGain();
  g.gain.value = 0;
  // hafif açık hava yankısı (uzaktaki minareden/kuleden geliyormuş gibi)
  const y = yanki(); const yg = ctx.createGain(); yg.gain.value = 0.18;
  g.connect(ana); g.connect(y).connect(yg).connect(ana);
  return g;
}
function cagriDuzeyi() { return (ayar.kapali.ortam ? 0.55 : 0.45 + ayar.ortam * 0.45); }
export function cagriCal(tur, { vakit = null } = {}) {
  if (!kur()) return null;
  if (ctx.state === 'suspended') ctx.resume();
  cagriDurdur();
  const cikis = cagriCikisi();
  const t0 = ctx.currentTime;
  cikis.gain.setValueAtTime(0, t0);
  cikis.gain.linearRampToValueAtTime(cagriDuzeyi(), t0 + 0.8);
  let el = null, dugum = null, zaman = null, sure = 0;
  const kapan = () => {
    const t = ctx.currentTime;
    cikis.gain.cancelScheduledValues(t);
    cikis.gain.setTargetAtTime(0, t, 0.4);
    setTimeout(() => { try { if (el) { el.pause(); el.removeAttribute('src'); el.load(); } if (dugum) dugum.disconnect(); cikis.disconnect(); } catch (e) { /* yok say */ } }, 2500);
    clearTimeout(zaman);
  };
  const bitince = () => { if (cagri && cagri.cikis === cikis) cagriDurdur(); };
  if (tur === 'ezan' || tur === 'kilise') {
    const ad = tur === 'ezan' ? `ezan-${vakit}${1 + Math.floor(Math.random() * 2)}` : `kilise${1 + Math.floor(Math.random() * 3)}`;
    el = new Audio(new URL(`../ses/cagri/${ad}.mp3`, import.meta.url).href);
    el.preload = 'auto';
    try { dugum = ctx.createMediaElementSource(el); dugum.connect(cikis); } catch (e) { el.volume = cagriDuzeyi(); }
    el.addEventListener('ended', bitince);
    el.addEventListener('error', bitince);
    el.play().catch(bitince);
    sure = tur === 'ezan' ? 240 : 25;
  } else {
    sure = CAGRI_SENTEZ[tur] ? CAGRI_SENTEZ[tur](cikis, t0 + 0.3) : 0;
    if (!sure) { cikis.disconnect(); return null; }
    zaman = setTimeout(bitince, (sure + 1.5) * 1000);
  }
  cagri = { tur, vakit, cikis, durdur: kapan };
  bastir('cagri', true);
  cagriHaber({ tur, vakit, sure });
  return cagri;
}
// Sentezle üretilen çağrılar; dönüş: saniye cinsinden süre
function nota(hedef, { f, bas, sure, tip = 'sawtooth', ses = 0.1, filtre = null, vibrato = 0, kayma = null, atak = 0.08 }) {
  const o = ctx.createOscillator(); o.type = tip;
  o.frequency.setValueAtTime(kayma ? kayma : f, bas);
  if (kayma) o.frequency.exponentialRampToValueAtTime(f, bas + 0.18);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, bas);
  g.gain.exponentialRampToValueAtTime(ses, bas + atak);
  g.gain.setValueAtTime(ses, bas + Math.max(atak, sure - 0.12));
  g.gain.exponentialRampToValueAtTime(0.0001, bas + sure);
  let son = o;
  if (filtre) for (const [fr, q] of filtre) { const b = ctx.createBiquadFilter(); b.type = 'bandpass'; b.frequency.value = fr; b.Q.value = q; son.connect(b); son = b; }
  son.connect(g).connect(hedef);
  if (vibrato) { const l = ctx.createOscillator(); const lg = ctx.createGain(); l.frequency.value = 5.2; lg.gain.value = vibrato; l.connect(lg).connect(o.frequency); l.start(bas); l.stop(bas + sure + 0.1); }
  o.start(bas); o.stop(bas + sure + 0.1);
}
function can(hedef, bas, temel, ses, sure) {
  // çan: uyumsuz kısmi sesler, uzun sönüm; tokmağın ilk vuruşu
  for (const [c, g, s] of [[0.5, 0.5, 1], [1, 1, 0.9], [1.19, 0.45, 0.7], [1.5, 0.35, 0.6], [2, 0.3, 0.5], [2.74, 0.2, 0.35], [3.76, 0.12, 0.25]]) {
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = temel * c;
    const gg = ctx.createGain();
    gg.gain.setValueAtTime(0.0001, bas); gg.gain.exponentialRampToValueAtTime(ses * g, bas + 0.01);
    gg.gain.exponentialRampToValueAtTime(0.0001, bas + sure * s);
    o.connect(gg).connect(hedef); o.start(bas); o.stop(bas + sure * s + 0.1);
  }
  const s = ctx.createBufferSource(); s.buffer = gurultu('kahve', 1);
  const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 400;
  const g = ctx.createGain(); g.gain.setValueAtTime(ses * 2, bas); g.gain.exponentialRampToValueAtTime(0.0001, bas + 0.25);
  s.connect(f).connect(g).connect(hedef); s.start(bas); s.stop(bas + 0.3);
}
const CAGRI_SENTEZ = {
  // Şofar (Yahudilik, Şabat girişi): tekiah – şevarim – terua – büyük tekiah
  sofar(h, b) {
    const f = 233, form = [[700, 2], [1400, 3]];
    let t = b;
    const ufle = (sure, ton = f) => { nota(h, { f: ton * 1.5, kayma: ton, bas: t, sure, ses: 0.16, filtre: form, vibrato: 3 }); t += sure + 0.35; };
    ufle(2.6);
    for (let i = 0; i < 3; i++) { nota(h, { f: f * 1.5, kayma: f, bas: t, sure: 0.7, ses: 0.15, filtre: form, vibrato: 2 }); t += 0.85; }
    t += 0.3;
    for (let i = 0; i < 9; i++) { nota(h, { f: f * 1.5, bas: t, sure: 0.16, ses: 0.14, filtre: form, atak: 0.02 }); t += 0.2; }
    t += 0.4;
    ufle(5.5);
    return t - b;
  },
  // Budist tapınak çanı (bonşo): tahta kütükle vurulan büyük çanın üç vuruşu
  budist(h, b) {
    for (let i = 0; i < 3; i++) can(h, b + i * 9, 98, 0.22, 11);
    return 3 * 9 + 5;
  },
  // Şankha (Hinduizm, sabah ve akşam puja): deniz kabuğu borusunun üç uzun üflemesi
  sankha(h, b) {
    let t = b;
    for (const s of [3.2, 3.2, 5]) {
      nota(h, { f: 311, kayma: 262, bas: t, sure: s, ses: 0.14, tip: 'sawtooth', filtre: [[620, 2.5], [1250, 4]], vibrato: 4, atak: 0.35 });
      nota(h, { f: 622, bas: t + 0.2, sure: s - 0.2, ses: 0.03, tip: 'sine', vibrato: 6, atak: 0.4 });
      t += s + 1.1;
    }
    return t - b;
  },
};

// ------------------------------------------------ Müzik çaları (oyuncunun kendi seçtiği parçalar)
// Oyunun müzik listesi ve oyuncunun kendi bilgisayarından seçtiği dosyalar (tarayıcıda okunur, sunucuya gitmez).
export async function oyunMuzikleri() {
  await katalogSozu;
  const l = katalog && katalog.muzik ? katalog.muzik.map((x) => x.ad).filter((a) => !SABIT_MUZIK.includes(a)) : MUZIK.oyun;
  return l.map((ad) => ({ ad: /^oyun\d+$/.test(ad) ? `Tezgâh ${ad.slice(4)}` : ad, yollar: adaylar('muzik/' + ad + '.m4a') }));
}
let calarGain = null, calarAnaliz = null;
const calarDugumleri = new WeakMap();
// spektrum göstergesi için frekans verisi (çalar penceresi açıkken okunur)
export function calarSpektrum(dizi) { if (!calarAnaliz) return false; calarAnaliz.getByteFrequencyData(dizi); return true; }
// Çaların <audio> öğesi müzik kanalına bağlanır; çalarken arka plan müziği durur, sokak müzisyenleri kısılır
export function calarBagla(el) {
  if (!kur()) return;
  if (ctx.state === 'suspended') ctx.resume();
  if (!calarGain) {
    calarGain = ctx.createGain(); calarGain.gain.value = bastirma.has('jenerik') ? 0 : 1; calarGain.connect(kanal.muzik);
    calarAnaliz = ctx.createAnalyser(); calarAnaliz.fftSize = 64; calarAnaliz.smoothingTimeConstant = 0.72;
    calarGain.connect(calarAnaliz);
  }
  if (!calarDugumleri.has(el)) {
    try { const d = ctx.createMediaElementSource(el); d.connect(calarGain); calarDugumleri.set(el, d); } catch (e) { /* yok say */ }
  }
}
export function calarDurumu(caliyor) { bastir('calar', !!caliyor); }
