import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.39.0';
import { sistemMetni as npcMetni } from './dil.js?v=0.39.0';
// Sokak olayları sahnesi: zabıta, polis, ambulans, otobüs, çöp kamyonu, düğün konvoyu, müzisyen, kedi, cüzdan,
// kurye, parkta top oynayan çocuklar ve tezgâhta kuyruk. Olayların zamanı sunucudan gelir (aynı ilçedeki herkes
// aynı anda görür); sahnedeki hareketler burada kurgulanır. Olaylara katılım (112'yi ara, cüzdanı ver…) sunucuya gider.
import * as THREE from 'three';
import { gorevAraci, araba, kapiAyarla, kediModeli, cuzdanModeli, sedyeModeli, gitarModeli, kemanModeli, klarnetModeli, darbukaModeli, orgModeli, topModeli, tabure, tezgahModeli } from './modeller.js?v=0.39.0';
import { insanUret, insanGuncelle, eleVer, insanSaydamlik } from './insanlar.js?v=0.39.0';
import * as ses from './ses.js?v=0.39.0';
import * as kalabalik from './kalabalik.js?v=0.39.0';
import { esc, simdi, tl } from './yardimci.js?v=0.39.0';

const rnd = (a, b) => a + Math.random() * (b - a);
const sec = (d) => d[Math.floor(Math.random() * d.length)];
const KALDIRIM_Y = 0.2;

// Şeritler (mahalle.js ile aynı): 0 doğuya giden (z=5.3, güney yakası), 1 batıya giden (z=2.4, kuzey yakası)
const YAKA = {
  kuzey: { serit: 1, seritZ: 2.4, kenarZ: 0.75, yon: -1, kapiYonu: -1, kaldirimZ: -0.7 },
  guney: { serit: 0, seritZ: 5.3, kenarZ: 7.3, yon: 1, kapiYonu: 1, kaldirimZ: 9.9 },
};

const KAVGA_SOZLERI = ['Sen kime bakıyorsun?!', 'Çekil önümden!', 'Sıramı aldın!', 'Ne var be!', 'Arabamı çizdin!', 'Bak hele!'];
// Görevli ve olay diyalogları (0.37.22): her seferinde biri seçilir; çevirileri dil sözlüğündedir (dialog.npc.*)
const HASTA_SOZLERI = ["Başım dönüyor…", "Gözlerim karardı…", "Nefes alamıyorum…", "Göğsüm sıkışıyor…", "Biri yardım etsin…", "Bacaklarım beni taşımıyor…", "Şekerim düştü galiba…", "Sıcak çarptı sanırım…"];
const CAGIRAN_SOZLERI = ["Ambulans çağırın!", "Kimse dokunmasın, 112'yi arayın!", "Bayıldı, su getirin!", "Etrafını açın, hava alsın!", "Doktor var mı aranızda?"];
const SAGLIKCI_SOZLERI = ["Nabız var, hemen hastaneye!", "Tansiyonu düşük, serum takıyoruz.", "Sakin olun, biz buradayız.", "Bilinci açık, sedyeye alalım.", "Geçmiş olsun, iyileşeceksiniz."];
const POLIS_SOZLERI = ["Polis! Dağılın!", "Sakin olun beyler, kimlikler lütfen.", "Ellerinizi görebileceğim yerde tutun!", "Karakolda konuşacağız.", "Kimse yaralandı mı?", "Tanıklar burada kalsın lütfen."];
const POLIS_DAGIT_SOZLERI = ["Dağılın, gösteri bitti!", "Yolu açık tutalım lütfen.", "Herkes işine dönsün."];
const ITFAIYE_EMIR_SOZLERI = ["Su ver!", "Lütfen geri çekilin!", "Yangın söndü, herkes güvende!", "İçeride kimse kaldı mı?", "Hortumu pencereye doğrult!", "Gaz vanasını kapatın!", "Duman zehirli, yaklaşmayın!", "Merdiveni getirin!"];
// 0.39.0: her olayda farklı bir senaryo (olayın tohumuna göre; aynı ilçedeki herkes aynı senaryoyu görür)
const KAVGA_SENARYOLARI = [
  { a: ['Burası benim park yerim!', 'Sabahtan beri bekliyorum!'], b: ['Üstünde adın mı yazıyor?', 'Çek arabanı oradan!'], polis: ['Park yeri için kavga mı edilir? Kimlikler lütfen.', 'Araç ruhsatlarını da alayım.'], dagit: ['Herkes yoluna, trafik açılsın.'] },
  { a: ['Sıramı aldın!', 'Ben senden önce geldim!'], b: ['Görmedim seni, ne bağırıyorsun?', 'Sıra mıra yok burada!'], polis: ['Sırayla beyler, mahalleyi karıştırmayın.', 'Bir sıra kavgası için bu kadar gürültü mü?'], dagit: ['Kuyruğa dönelim, herkes sırasını alsın.'] },
  { a: ['Hakem sizin takımı taşıdı!', 'O penaltı değildi!'], b: ['Kıskançlık bu, kabul et!', 'Biz sahada kazandık!'], polis: ['Maç sahada kaldı beyler, burada uzatmayın.', 'Takım tutmak kavga sebebi değil.'], dagit: ['Maç bitti, herkes evine.'] },
  { a: ['Arabamı çizdin!', 'Sigortanı ver bakalım!'], b: ['Sen geri geri geldin!', 'Kamera kaydına bakalım!'], polis: ['Kaza tespit tutanağı tutacağız.', 'Ehliyetler ve ruhsatlar lütfen.'], dagit: ['Yolu kapatmayalım, araçlar kenara.'] },
  { a: ['Sen kime bakıyorsun?!', 'Ne var be!'], b: ['Bak hele, sana mı soracağım?', 'Çekil önümden!'], polis: ['Polis! Ellerinizi görebileceğim yerde tutun!', 'Karakolda konuşacağız.'], dagit: ['Dağılın, gösteri bitti!'] },
];
const AMBULANS_SENARYOLARI = [
  { hasta: ['Sıcak çarptı sanırım…', 'Başım dönüyor…'], cagiran: ['Gölgeye alalım, su getirin!', 'Etrafını açın, hava alsın!'], saglikci: ['Sıcak çarpması, serum takıyoruz.', 'Vücudunu serinletelim, iyileşecek.'] },
  { hasta: ['Şekerim düştü galiba…', 'Ellerim titriyor…'], cagiran: ['Şekeri var, meyve suyu getirin!', '112\'yi arayın!'], saglikci: ['Kan şekeri düşük, glukoz veriyoruz.', 'Toparlanıyor, hastanede kontrol edelim.'] },
  { hasta: ['Göğsüm sıkışıyor…', 'Sol kolum uyuşuyor…'], cagiran: ['Kalp krizi olabilir, hemen 112!', 'Kimse dokunmasın, sırtüstü yatırın!'], saglikci: ['EKG çekelim, hemen hastaneye!', 'Nabız var, oksijen veriyoruz.'] },
  { hasta: ['Ayağım burkuldu!', 'Kalkamıyorum…'], cagiran: ['Kaldırımdan düştü, ambulans çağırın!', 'Ayağını oynatma, bekle!'], saglikci: ['Atel takalım, kırık olabilir.', 'Sedyeye alıyoruz, acele yok.'] },
  { hasta: ['Gözlerim karardı…', 'Nefes alamıyorum…'], cagiran: ['Bayıldı, su getirin!', 'Doktor var mı aranızda?'], saglikci: ['Bilinci açık, sedyeye alalım.', 'Tansiyonu düşük, serum takıyoruz.'] },
];
const ITFAIYE_SENARYOLARI = [
  { seyirci: 'Mutfaktan duman çıkıyor!', h1: ['Mutfak penceresine su ver!', 'Tencere alev almış, söndürüyoruz!'], h3: ['Yağ yangını, uzak durun!', 'Gaz vanasını kapatın!'] },
  { seyirci: 'Prizden kıvılcım çıktı, ev yanıyor!', h1: ['Önce elektriği kesin!', 'Elektrik kesildi, şimdi su ver!'], h3: ['Kablolar yanıyor, yaklaşmayın!', 'Sigorta kutusu nerede?'] },
  { seyirci: 'Balkon yanıyor!', h1: ['Hortumu balkona doğrult!', 'Perdeler tutuşmuş, su ver!'], h3: ['Lütfen geri çekilin!', 'Balkondan izmarit atmayın!'] },
  { seyirci: 'Gaz kokusu var, alev çıktı!', h1: ['Pencereleri açın, gazı tahliye edin!', 'Su ver!'], h3: ['Kibrit, çakmak yakmayın!', 'Binayı boşaltın!'] },
  { seyirci: 'Çatı katından alev çıkıyor!', h1: ['Merdiveni getirin!', 'Çatı katına su ver!'], h3: ['İçeride kimse kaldı mı?', 'Duman zehirli, yaklaşmayın!'] },
];
const senaryo = (liste, olay) => liste[Math.abs(Number(olay && olay.tohum) || 0) % liste.length];
const ZABITA_SOZLERI = ["Belediye zabıtası. İzin belgeniz?", "Kolay gelsin, rutin kontrol.", "Tezgâhın yeri burası mı, belgesine bakalım.", "Kaldırımı kapatmayın lütfen.", "Fiyat etiketleri görünür olmalı.", "Hijyen kurallarına dikkat edelim."];
const ZABITA_IYI_SOZLERI = ["😊 İzniniz tamam, kolay gelsin!", "😊 Her şey yolunda, bereketli satışlar!"];
const TESEKKUR = ['Çok teşekkür ederim!', 'Allah razı olsun!', 'Sağ ol komşu!', 'Hayatımı kurtardın!'];

let kilimMalzemesi = null;
function sokakKilimi() {
  if(kilimMalzemesi) return kilimMalzemesi;
  const c=document.createElement('canvas');c.width=512;c.height=192;const x=c.getContext('2d');
  x.fillStyle='#743E35';x.fillRect(0,0,512,192);x.strokeStyle='#C7AD78';x.lineWidth=6;x.strokeRect(12,12,488,168);
  for(let j=0;j<7;j++) {const px=46+j*70; x.beginPath();x.moveTo(px,42);x.lineTo(px+25,96);x.lineTo(px,150);x.lineTo(px-25,96);x.closePath();x.stroke();x.fillStyle=j%2?'#344D58':'#B78359';x.fill();}
  for(let j=0;j<32;j++) {x.fillStyle=j%2?'#C7AD78':'#344D58';x.fillRect(10+j*15,22,7,6);x.fillRect(10+j*15,164,7,6);}
  const map=new THREE.CanvasTexture(c);map.colorSpace=THREE.SRGBColorSpace;map.anisotropy=4;
  kilimMalzemesi=new THREE.MeshStandardMaterial({map,roughness:1,metalness:0});return kilimMalzemesi;
}

export function olayMotoru(c) {
  const sahneler = [];     // süren olay sahneleri
  const oynanan = new Set(); // aynı olay iki kez oynamasın
  let liste = [];          // sunucudan gelen olay takvimi
  let sonIstek = 0;

  // ------------------------------------------------ Yardımcılar: insan, balon, araç
  function kisi(tur, x, z, aci = 0, persona = null) {
    const g = insanUret(tur, persona ? { persona } : {});
    g.position.set(x, KALDIRIM_Y, z);
    g.rotation.y = aci;
    c.sahne.add(g);
    // sokakta birden belirmesin: yavaşça görünür (araca bindirilenler için belirme hemen tamamlanır)
    insanSaydamlik(g, 0);
    return { g, is: [], hiz: 1.3, anim: '', gorunur: true, belir: 0 };
  }
  // Silinen kişi sokakta birden kaybolmaz: yavaşça solar. Kişi nesnesi hemen "gitmiş" sayılır (g boş bir gruba döner),
  // görüntüsü ise solanlar listesinde birkaç yüz milisaniye daha oynar.
  const solanlar = [];
  function kisiSil(k) {
    if (!k || !k.g.parent) return;
    if (k.balon) { balonSil(k.balon); k.balon = null; }
    const g = k.g;
    k.g = new THREE.Group();
    if (g.parent === c.sahne && g.visible && c.yakin(g.position.x, g.position.z)) {
      solanlar.push({ g, a: g.userData.insan && g.userData.insan.saydam !== undefined ? g.userData.insan.saydam : 1 });
      return;
    }
    g.parent.remove(g);
    c.bellektenSil(g, { geometri: false });
  }
  function solanlariGuncelle(dt) {
    for (let i = solanlar.length - 1; i >= 0; i--) {
      const x = solanlar[i];
      x.a -= dt * 1.8;
      if (x.a <= 0) {
        if (x.g.parent) x.g.parent.remove(x.g);
        c.bellektenSil(x.g, { geometri: false });
        solanlar.splice(i, 1);
        continue;
      }
      insanSaydamlik(x.g, x.a);
      insanGuncelle(x.g, dt);
    }
  }
  // Kişinin yapacakları sırayla işlenir: { yuru: [x, z] }, { bekle: sn, anim }, { yap: fn }, { bak: aci }
  function yap(k, ...isler) { k.is.push(...isler); return k; }
  function yonel(g, hedef, dt) {
    let f = hedef - g.rotation.y;
    while (f > Math.PI) f -= Math.PI * 2;
    while (f < -Math.PI) f += Math.PI * 2;
    g.rotation.y += f * Math.min(1, dt * 7);
  }
  function oynat(k, anim, hiz = 1) {
    const i = k.g.userData.insan;
    if (!i) return; // silinmiş (solarak giden) kişi: görüntüsü artık solanlar listesinde
    const a = anim + hiz;
    if (k.anim === a) return;
    k.anim = a;
    i.oynat(anim, 0.25, hiz);
  }
  function kisiGuncelle(k, dt) {
    if (!k.g.parent) return;
    if (k.belir < 1) {
      // araca bağlı (motordaki polis, basamaktaki koruma) olanlar hemen görünür
      k.belir = k.g.parent === c.sahne ? Math.min(1, k.belir + dt * 1.6) : 1;
      insanSaydamlik(k.g, k.belir);
    }
    const is = k.is[0];
    if (!is) {
      if (k.bosAnim) oynat(k, k.bosAnim, k.bosHiz || 1);
    } else if (is.yuru) {
      const [hx, hz] = is.yuru;
      const dx = hx - k.g.position.x;
      const dz = hz - k.g.position.z;
      const d = Math.hypot(dx, dz);
      const hiz = is.hiz || k.hiz;
      if (d < 0.05) { k.is.shift(); k.yolSure = 0; }
      else {
        // engellerin (tezgâh, bank, ağaç…) etrafından dolaşır; çok uzun takılırsa hedefe varır
        const aci = kalabalik.yuru(k.g.position, hx, hz, hiz * dt);
        if (aci !== null) yonel(k.g, aci, dt);
        oynat(k, 'Walk_Loop', hiz / 1.25);
        k.yolSure = (k.yolSure || 0) + dt;
        if (k.yolSure > 20) { k.g.position.x = hx; k.g.position.z = hz; }
      }
    } else if (is.bekle !== undefined) {
      if (is.bak !== undefined) yonel(k.g, is.bak, dt);
      oynat(k, is.anim || 'Idle_Loop', is.animHiz || 1);
      is.bekle -= dt;
      if (is.bekle <= 0) k.is.shift();
    } else if (is.yap) {
      k.is.shift();
      is.yap(k);
    } else if (is.fn) {
      // sürekli iş: tamamlanınca (true dönünce) sıradakine geçilir
      if (is.fn(k, dt)) k.is.shift();
    } else k.is.shift();
    // yürürken kaldırımdan yola inip çıkar (asfalt kaldırımdan alçaktadır)
    if (!k.ozelY && k.g.parent === c.sahne && c.zeminY) {
      const hy = c.zeminY(k.g.position.x, k.g.position.z);
      k.g.position.y += (hy - k.g.position.y) * Math.min(1, dt * 12);
    }
    if (k.yanindaki) {
      // polisin yanında götürülen kişi: yanında yürür
      const y = k.yanindaki;
      const ox = Math.cos(k.g.rotation.y) * 0.55;
      const oz = -Math.sin(k.g.rotation.y) * 0.55;
      y.g.position.set(k.g.position.x + ox, c.zeminY ? c.zeminY(k.g.position.x + ox, k.g.position.z + oz) : KALDIRIM_Y, k.g.position.z + oz);
      y.g.rotation.y = k.g.rotation.y;
      oynat(y, k.anim.startsWith('Walk') ? 'Walk_Loop' : 'Idle_Loop', 1);
    }
    // yukarıdaki iş (yap) kişiyi silmiş olabilir: boş gruba canlandırma uygulanmaz
    if (k.g.parent && c.yakin(k.g.position.x, k.g.position.z)) insanGuncelle(k.g, dt);
  }
  const bakis = (x1, z1, x2, z2) => Math.atan2(x2 - x1, z2 - z1);

  // Konuşma balonu (ya da düğmeli eylem balonu)
  function balon(html, { dugme = null, tur = '', ikinci = null } = {}) {
    // sistem metinleri oyuncunun dilinde (oyuncu adları ve mesajlar değişmez: yalnızca birebir eşleşen sistem metni çevrilir)
    html = npcMetni(html);
    if (ikinci) ikinci = { ...ikinci, metin: npcMetni(ikinci.metin) };
    const e = document.createElement('div');
    e.className = 'etiket gizli';
    e.innerHTML = dugme
      ? `<div class="olay-dugmeler"><button class="olay-dugme ${tur}">${html}</button>${ikinci ? `<button class="olay-dugme gri" data-ikinci>${ikinci.metin}</button>` : ''}</div>`
      : `<div class="olay-balon ${tur}">${html}</div>`;
    c.etiketKutusu.appendChild(e);
    if (dugme) e.querySelector('button').addEventListener('click', (ev) => { ev.stopPropagation(); dugme(e); });
    if (ikinci) e.querySelector('[data-ikinci]').addEventListener('click', (ev) => { ev.stopPropagation(); ikinci.fn(e); });
    return { e, bitis: Infinity };
  }
  function balonSil(b) { if (b && b.e.parentNode) b.e.remove(); }
  function kisiyeBalon(k, metin, sure = 3, tur = '') {
    metin = npcMetni(metin);
    if (k.balon) balonSil(k.balon);
    k.balon = balon(esc(metin), { tur });
    k.balon.bitis = performance.now() + sure * 1000;
  }
  function balonlariGuncelle() {
    const t = performance.now();
    for (const s of sahneler) {
      for (const k of s.kisiler) {
        if (!k.balon) continue;
        if (t > k.balon.bitis || !k.g.parent) { balonSil(k.balon); k.balon = null; continue; }
        c.etiketGoster(k.balon.e, k.g.position.x, 2.35, k.g.position.z);
      }
      for (const b of s.balonlar || []) {
        if (t > b.bitis) { balonSil(b); continue; }
        c.etiketGoster(b.e, b.x, b.y, b.z);
      }
      if (s.balonlar) s.balonlar = s.balonlar.filter((b) => t <= b.bitis && b.e.parentNode);
    }
  }
  function noktayaBalon(s, html, x, y, z, secenek = {}) {
    const b = balon(html, secenek);
    Object.assign(b, { x, y, z, bitis: secenek.sure ? performance.now() + secenek.sure * 1000 : Infinity });
    s.balonlar.push(b);
    return b;
  }

  // Olaya katılım düğmesi: tıklanınca sunucuya bildirilir, ödül ya da bedel ekranda gösterilir
  function katilimDugmesi(s, metin, x, y, z, sonra, ikinci = null) {
    if (s.olay.katildi || !s.olay.eylem) return null;
    const b = noktayaBalon(s, metin, x, y, z, {
      tur: 'yesil',
      ikinci: ikinci ? { metin: ikinci.metin, fn: () => { balonSil(b); ikinci.fn(); } } : null,
      dugme: async (e) => {
        const btn = e.querySelector('button');
        btn.disabled = true;
        const r = await c.katil(s.olay, s.olay.eylem, btn.getBoundingClientRect());
        balonSil(b);
        if (r) {
          s.olay.katildi = true;
          if (sonra) sonra(r);
        } else btn.disabled = false;
      },
    });
    return b;
  }

  // Görev aracı: sokağın ucundan gelir, hedefe yaklaşırken yavaşlar ve S çizerek kaldırıma yanaşıp durur;
  // iş bitince sinyal verip yola döner. Yanaşırken ve çıkarken şeridin dışında sayılır: arkadan gelenler ona çarpmaz.
  const YANAS = 11;   // yanaşma yolu (m)
  const CIKIS = 9;    // yola dönüş yolu (m)
  const yumusak = (k) => { k = Math.max(0, Math.min(1, k)); return k * k * (3 - 2 * k); };
  const yumusakTurev = (k) => (k <= 0 || k >= 1 ? 0 : 6 * k * (1 - k));
  function aracGetir(s, tur, yakaAdi, x, { acil = true, siren = null, vardi, hizli = false } = {}) {
    const yaka = YAKA[yakaAdi];
    const g = gorevAraci(tur);
    const a = g.userData.araba;
    // yola çıkılan yerde başka araba varsa biraz daha geriden çıkar (arabalar iç içe başlamasın)
    // ekranın dışından gelsin: kamera ne kadar uzaktan bakıyorsa o kadar geriden (yol orada da devam eder)
    let bas = x - yaka.yon * (Math.min(150, Math.max(62, 40 + c.kamera().mesafe * 1.4)) + rnd(0, 12));
    for (let i = 0; i < 8 && !c.trafik.bosMu(yaka.serit, bas, 8); i++) bas -= yaka.yon * 9;
    const arac = { g, tur, yaka, x, durum: 'geliyor', t: 0, siren, vardi, parkX: null, kapilar: {} };
    g.position.set(bas, 0.02, yaka.seritZ);
    g.rotation.y = yaka.yon > 0 ? 0 : Math.PI;
    // hedefin YANAS kadar gerisinden kaldırıma doğru kırar: oraya dönüşe uygun hızla gelir
    Object.assign(g.userData, { p: bas, hiz: hizli ? 12 : 9, azami: hizli ? 14 : acil ? 12 : 9, tur, olay: true, acil, durHedef: x - yaka.yon * YANAS, durHiz: 4.2 });
    c.sahne.add(g);
    c.trafik.ekle(g, yaka.serit);
    for (const h of a.haleler) c.gecelik.haleler.add(h);
    s.araclar.push(arac);
    return arac;
  }
  function kapilariGuncelle(arac, dt, t) {
    if (!arac.kapilar) return; // kapısı olmayan araç (konvoy vb.)
    for (const [ad, k] of Object.entries(arac.kapilar)) {
      if (k.kapat && t >= k.kapat) { k.hedef = 0; k.kapat = 0; }
      if (k.deger === k.hedef) continue;
      // açılış biraz yavaş, kapanış hızlı (kapı çarpılır)
      k.deger = k.hedef > k.deger ? Math.min(k.hedef, k.deger + dt * 2.4) : Math.max(k.hedef, k.deger - dt * 3.4);
      kapiAyarla(arac.g, ad, k.deger);
      if (k.deger === 0) {
        const kam = c.kamera();
        const dx = arac.g.position.x - kam.x;
        const uz = Math.hypot(dx, arac.g.position.z - kam.z, kam.mesafe * 0.6);
        if (uz < 45) ses.kapiKapandi(Math.max(-1, Math.min(1, dx / 15)), 1 - uz / 45);
      }
    }
  }
  function kapiAc(arac, ad) {
    if (!ad) return;
    if (!arac.kapilar) arac.kapilar = {};
    const k = arac.kapilar[ad] || (arac.kapilar[ad] = { deger: 0, hedef: 0, kapat: 0 });
    k.hedef = 1;
    k.kapat = 0;
  }
  function kapiKapat(arac, ad, gecikme = 0) {
    const k = ad && arac.kapilar && arac.kapilar[ad];
    if (k) k.kapat = sahneSaati + gecikme;
  }
  function kapiDegeri(arac, ad) { return ad && arac.kapilar && arac.kapilar[ad] ? arac.kapilar[ad].deger : 1; }
  function surus(arac, g, u, dt, xDegis, zDegis) {
    // aracın yönü gidilen yola bakar; ön tekerlekler dönüşe göre kırılır
    const onceki = g.rotation.y;
    const aci = Math.atan2(-zDegis, xDegis);
    let fark = aci - onceki;
    while (fark > Math.PI) fark -= Math.PI * 2;
    while (fark < -Math.PI) fark += Math.PI * 2;
    g.rotation.y = onceki + fark;
    const yol = Math.hypot(xDegis, zDegis);
    if (c.trafik.direksiyon) c.trafik.direksiyon(g, yol > 1e-4 ? (fark / yol) * 2.6 : 0, dt);
    for (const tk of u.araba.tekerler) tk.rotation.z -= yol / u.araba.r;
  }
  let sahneSaati = 0;
  function aracGuncelle(s, arac, dt, t) {
    const g = arac.g;
    const u = g.userData;
    arac.t += dt;
    sahneSaati = t;
    kapilariGuncelle(arac, dt, t);
    // tepe lambaları yanıp söner
    if (u.tepe && arac.isik !== false) {
      const faz = Math.floor(t * 6) % 2;
      u.tepe.forEach((l, i) => {
        const acik = (i % 2) === faz;
        l.m.emissiveIntensity = acik ? 3.5 : 0.2;
        l.h.visible = acik;
        l.h.material.opacity = acik ? 0.75 : 0;
      });
    }
    // siren: araç gelirken sürekli çalar (yaklaşırken perdesi yükselir, uzaklaşırken düşer), varınca susar
    const sirenCalsin = arac.siren && (arac.durum === 'geliyor' || arac.surekliSiren);
    if (sirenCalsin && !arac.sirenSes && !arac.sirenBitti) arac.sirenSes = ses.sirenBaslat(arac.siren);
    if (arac.sirenSes) {
      if (!sirenCalsin) { arac.sirenSes.durdur(); arac.sirenSes = null; arac.sirenBitti = true; }
      else {
        const k = c.kamera();
        const dx = g.position.x - k.x;
        const dz = g.position.z - k.z;
        const uz = Math.hypot(dx, dz, k.mesafe * 0.6);
        const onceki = arac.oncekiUz === undefined ? uz : arac.oncekiUz;
        arac.oncekiUz = uz;
        const yaklasma = dt > 0 ? (onceki - uz) / dt : 0;
        arac.sirenSes.ayarla(Math.max(0, 1 - uz / 170) ** 1.3, Math.max(-1, Math.min(1, dx / 35)), yaklasma);
      }
    }
    const Y = arac.yaka;
    if (arac.durum === 'geliyor') {
      if (u.durHedef != null && u.serit && (u.durHedef - u.p) * Y.yon < 0.3) {
        c.trafik.cikar(g);
        if (c.trafik.engel) c.trafik.engel(g, true);
        Object.assign(arac, { durum: 'yanasiyor', t: 0, yol: 0, bx: g.position.x, v0: Math.max(2.4, u.hiz) });
        Object.assign(u, { sinyal: 'sag', fren: true });
      }
    } else if (arac.durum === 'yanasiyor') {
      // sabit yavaşlamayla durur: hız, kalan yolun karekökü ile azalır
      const v = Math.max(0.35, arac.v0 * Math.sqrt(Math.max(0, 1 - arac.yol / YANAS)));
      const adim = Math.min(YANAS - arac.yol, v * dt);
      arac.yol += adim;
      const k = arac.yol / YANAS;
      const x0 = g.position.x, z0 = g.position.z;
      g.position.x = arac.bx + Y.yon * arac.yol;
      g.position.z = Y.seritZ + (Y.kenarZ - Y.seritZ) * yumusak(k);
      surus(arac, g, u, dt, g.position.x - x0 || Y.yon * 1e-5, g.position.z - z0);
      if (k >= 1) {
        arac.durum = 'duruyor';
        arac.t = 0;
        u.sinyal = 'dortlu'; // kaldırımda dururken dörtlüler yanar
        g.rotation.y = Y.yon > 0 ? 0 : Math.PI;
        if (c.trafik.direksiyon) c.trafik.direksiyon(g, 0, 1);
        // kaldırıma yanaşmış araç yürüyenler için engeldir
        const au = u.araba;
        arac.engel = kalabalik.engelEkle(g.position.x, g.position.z, (au.uzunluk || 4.4) + 0.2, (au.en || 1.8) + 0.1);
        if (arac.vardi) arac.vardi(arac);
      }
    } else if (arac.durum === 'cikacak') {
      // kapılar kapanmış ve arkadan araba gelmiyorsa sinyal verip yola çıkar
      const kapiAcik = Object.values(arac.kapilar).some((k) => k.deger > 0 || k.hedef > 0);
      if (!kapiAcik && c.trafik.bosMu(Y.serit, g.position.x - Y.yon * 6, 16)) {
        Object.assign(arac, { durum: 'cikiyor', t: 0, yol: 0, v: 0, bx: g.position.x, bekle: 1.1 });
        Object.assign(u, { sinyal: 'sol', fren: true });
        kalabalik.engelSil(arac.engel);
        arac.engel = null;
      }
    } else if (arac.durum === 'cikiyor') {
      if (arac.bekle > 0) {
        // direksiyonu yola kırar, sonra kalkar
        arac.bekle -= dt;
        if (c.trafik.direksiyon) c.trafik.direksiyon(g, 0.45 * Math.sign(Y.kenarZ - Y.seritZ) * Y.yon, dt);
        return;
      }
      arac.v = Math.min(7, arac.v + dt * 2.2);
      u.fren = false;
      const adim = arac.v * dt;
      arac.yol += adim;
      const k = arac.yol / CIKIS;
      const x0 = g.position.x, z0 = g.position.z;
      g.position.x = arac.bx + Y.yon * arac.yol;
      g.position.z = Y.kenarZ + (Y.seritZ - Y.kenarZ) * yumusak(k);
      surus(arac, g, u, dt, g.position.x - x0 || Y.yon * 1e-5, g.position.z - z0);
      if (k >= 1) {
        arac.durum = 'gidiyor';
        g.rotation.y = Y.yon > 0 ? 0 : Math.PI;
        g.position.z = Y.seritZ;
        if (c.trafik.engel) c.trafik.engel(g, false);
        Object.assign(u, { p: g.position.x, hiz: arac.v, durHedef: null, durHiz: null, sinyal: null, bitince: () => aracSil(s, arac) });
        c.trafik.ekle(g, Y.serit);
        if (arac.parkX != null) { c.park.birak(arac.parkX); arac.parkX = null; }
      }
    }
  }
  function aracGonder(arac, isikKapat = false) {
    // sirenli görev araçları (polis, ambulans, itfaiye, zabıta) giderken de siren çalar, tepe lambaları yanar
    if (arac.siren) {
      arac.surekliSiren = true;
      arac.sirenBitti = false;
      arac.isik = true;
      isikKapat = false;
    }
    if (isikKapat) {
      arac.isik = false;
      if (arac.g.userData.tepe) for (const l of arac.g.userData.tepe) { l.m.emissiveIntensity = 0.2; l.h.visible = false; }
    }
    for (const ad of Object.keys(arac.kapilar)) kapiKapat(arac, ad, 0);
    arac.durum = 'cikacak';
  }
  function aracSil(s, arac) {
    if (arac.sirenSes) { arac.sirenSes.durdur(); arac.sirenSes = null; }
    if (arac.engel) { kalabalik.engelSil(arac.engel); arac.engel = null; }
    if (c.trafik.engel) c.trafik.engel(arac.g, false);
    c.trafik.cikar(arac.g);
    // araçtaki insanlar (motordaki kurye) ayrıca silinir: insan şekli herkesle ortaktır, araçla birlikte silinmemeli
    const icindekiler = [];
    arac.g.traverse((o) => { if (o !== arac.g && o.userData && o.userData.insan) icindekiler.push(o); });
    for (const o of icindekiler) { o.parent.remove(o); c.bellektenSil(o, { geometri: false }); }
    if (arac.g.parent) arac.g.parent.remove(arac.g);
    for (const h of arac.g.userData.araba.haleler) c.gecelik.haleler.delete(h);
    c.bellektenSil(arac.g);
    if (arac.parkX != null) c.park.birak(arac.parkX);
    s.araclar = s.araclar.filter((a) => a !== arac);
  }

  // ------------------------------------------------ Araçtan inme ve araca binme
  // Aracın yerel ekseni: +x ileri, +z sağ yan (kaldırım tarafı). Yerel noktayı dünya konumuna çevirir.
  function yerel(g, lx, lz) {
    const co = Math.cos(g.rotation.y), si = Math.sin(g.rotation.y);
    return [g.position.x + lx * co + lz * si, g.position.z - lx * si + lz * co];
  }
  function yerelYon(g, dx, dz) {
    const co = Math.cos(g.rotation.y), si = Math.sin(g.rotation.y);
    return Math.atan2(dx * co + dz * si, -dx * si + dz * co);
  }
  // Oturma yerleri: şoför solda önde, yanında yolcu, arkada yolcular. Ambulansın arkasındakiler arka kapıdan iner.
  function koltuklar(arac) {
    const a = arac.g.userData.araba;
    const T = a.kapiTanim || [];
    const bul = (ad) => T.find((k) => k.ad === ad);
    const liste = [];
    const on = bul('onSol');
    if (on) {
      const x = (on.x1 + on.x2) / 2 - 0.1;
      liste.push({ kapi: 'onSol', lx: x, lz: -0.38, taraf: -1 }, { kapi: 'onSag', lx: x, lz: 0.38, taraf: 1 });
    }
    const ar = bul('arkaSag');
    if (ar) {
      const x = (ar.x1 + ar.x2) / 2;
      liste.push({ kapi: 'arkaSag', lx: x, lz: 0.38, taraf: 1 }, { kapi: 'arkaSag', lx: x, lz: -0.2, taraf: 1 });
    }
    const ak = bul('arka');
    if (ak) liste.push({ kapi: 'arka', lx: ak.x1 + 0.8, lz: 0.35, taraf: 0 }, { kapi: 'arka', lx: ak.x1 + 1.1, lz: -0.35, taraf: 0 });
    if (!liste.length) liste.push({ kapi: null, lx: 0, lz: 0.3, taraf: 1 });
    return liste;
  }
  function koltukSec(arac, i) {
    const l = koltuklar(arac);
    return l[i] || l[Math.min(l.length - 1, 1 + ((i - 1) % Math.max(1, l.length - 1)))];
  }
  // Kapının dışındaki durma noktası (dünya)
  function disNokta(arac, k) {
    const a = arac.g.userData.araba;
    if (k.taraf === 0) return yerel(arac.g, a.arkaX - 0.85, k.lz * 1.3);
    return yerel(arac.g, k.lx - 0.15, k.taraf * (a.en / 2 + 0.6));
  }
  // Şoför yol tarafından iner: aracın önünden dolaşıp kaldırıma geçer
  function ondenDolas(arac, disaridan) {
    const a = arac.g.userData.araba;
    const y = a.en / 2 + 0.7;
    const noktalar = [yerel(arac.g, a.onX + 0.9, -y), yerel(arac.g, a.onX + 0.9, y)];
    return (disaridan ? noktalar.reverse() : noktalar).map((n) => ({ yuru: n }));
  }
  // Kapıdan çıkış/giriş adımı: kişi koltuktan eğilerek kalkar, kapıdan dışarı adım atar (ya da tersi)
  function kapiAdimi(arac, kol, yon) {
    let t = 0;
    return (k, dt) => {
      const a = arac.g.userData.araba;
      const ic = yerel(arac.g, kol.lx, kol.lz);
      const dis = disNokta(arac, kol);
      if (t === 0) {
        k.ozelY = true;
        k.sabit = true;
        k.g.visible = true;
        k.belir = 1;
        insanSaydamlik(k.g, 1);
      }
      t = Math.min(1, t + dt / (kol.taraf === 0 ? 1.1 : 0.95));
      const e = t * t * (3 - 2 * t);
      const f = yon === 'in' ? e : 1 - e;
      k.g.position.x = ic[0] + (dis[0] - ic[0]) * f;
      k.g.position.z = ic[1] + (dis[1] - ic[1]) * f;
      // araçtayken oturur gibi alçaktır; dışarı çıktıkça doğrulur (başı tavandan çıkmaz)
      const zemin = c.zeminY ? c.zeminY(dis[0], dis[1]) : KALDIRIM_Y;
      const icY = Math.min(0.02, (a.tavanY || 1.45) - 1.72);
      k.g.position.y = icY + (zemin - icY) * Math.min(1, f * 1.25);
      const disa = kol.taraf === 0 ? yerelYon(arac.g, -1, 0) : yerelYon(arac.g, 0, kol.taraf);
      k.g.rotation.y = yon === 'in' ? disa : disa + Math.PI;
      oynat(k, f < 0.35 ? 'Sitting_Idle_Loop' : 'Walk_Loop', 0.7);
      if (t >= 1) {
        k.ozelY = false;
        k.sabit = false;
        return true;
      }
      return false;
    };
  }
  // n kişi araçtan sırayla iner; her biri kapının önünde bekleyen iş listesiyle döner (arkasına görev eklenir)
  function aractanIn(s, arac, tur, n, { bekle = 0.5, persona = null, ilk = 0 } = {}) {
    const kisiler = [];
    const sira = {};
    for (let i = 0; i < n; i++) {
      const kol = koltukSec(arac, i + ilk);
      const [ix, iz] = yerel(arac.g, kol.lx, kol.lz);
      const k = kisi(tur, ix, iz, 0, persona);
      k.g.visible = false;
      k.ozelY = true;
      k.koltuk = kol;
      s.kisiler.push(k);
      kisiler.push(k);
      // aynı kapıdan inenler sıra bekler; farklı kapılardan inenler neredeyse aynı anda iner
      const kapiSira = sira[kol.kapi] = (sira[kol.kapi] ?? -1) + 1;
      const gecikme = bekle + kapiSira * 1.25 + i * 0.25;
      yap(k, { bekle: gecikme, anim: 'Sitting_Idle_Loop' },
        { fn: () => { kapiAc(arac, kol.kapi); return kapiDegeri(arac, kol.kapi) > 0.72; } },
        { fn: kapiAdimi(arac, kol, 'in') },
        { yap: () => kapiKapat(arac, kol.kapi, kol.taraf === 0 ? 30 : 1.1) });
      if (kol.taraf < 0) yap(k, ...ondenDolas(arac, false));
    }
    return kisiler;
  }
  // Kişi aracına döner, kapıyı açar, biner, kapıyı kapatır
  function arabayaBin(k, arac, sonra, kol = k.koltuk || koltukSec(arac, 1)) {
    const isler = [];
    if (kol.taraf < 0) isler.push(...ondenDolas(arac, true));
    isler.push({ yuru: disNokta(arac, kol) },
      { fn: () => { kapiAc(arac, kol.kapi); return kapiDegeri(arac, kol.kapi) > 0.72; } },
      { fn: kapiAdimi(arac, kol, 'bin') },
      { yap: (kk) => { kk.g.visible = false; kisiSil(kk); kapiKapat(arac, kol.kapi, 0.35); if (sonra) sonra(kk); } });
    yap(k, ...isler);
  }

  // Güney yakasında araç park şeridine yanaşır: yer ayrılır (yoksa kuzey yakası kullanılır)
  function yanasmaYeri(x, yakaAdi) {
    if (yakaAdi === 'kuzey') return { yaka: 'kuzey', x };
    const px = c.park.ayir(x);
    if (px == null) return { yaka: 'kuzey', x };
    return { yaka: 'guney', x: px, park: px };
  }

  function sahneBaslat(olay, kur) {
    const s = { olay, kisiler: [], araclar: [], balonlar: [], nesneler: [], t: 0, bitti: false, adim: null };
    sahneler.push(s);
    kur(s);
    return s;
  }
  function nesneEkle(s, o) { c.sahne.add(o); s.nesneler.push(o); return o; }
  function sahneBitir(s) {
    for (const k of s.kisiler) kisiSil(k);
    for (const a of [...s.araclar]) aracSil(s, a);
    for (const b of s.balonlar) balonSil(b);
    for (const o of s.nesneler) { if (o.parent) o.parent.remove(o); c.bellektenSil(o); }
    if (s.son) s.son();
    s.bitti = true;
  }

  // Sahnedeki olay noktası: kameranın baktığı yere yakın, sokağın sınırları içinde (tohumla hafif kaydırılır)
  function olayX(olay, pay = 18) {
    const k = c.kamera();
    const { XB, XD } = c.sinirlar();
    const kay = ((olay.tohum % 1000) / 1000 - 0.5) * 2 * pay * 0.6;
    return Math.max(XB + 14, Math.min(XD - 14, (Math.abs(k.x) < 90 ? k.x : 0) + kay));
  }

  // ------------------------------------------------ 1. Zabıta tezgâha gelir
  function zabitaSahnesi(yer, ziyaret, sonuc) {
    const tx = yer.x;
    const tz = yer.z;
    const on = tz + 1.95;
    const y = yanasmaYeri(tx, yer.guney ? 'guney' : 'kuzey');
    return sahneBaslat({ tur: 'zabita', id: 'zabita:' + ziyaret.ms, katildi: true }, (s) => {
      // zabıta aracında iki ya da üç görevli: şoför, yanındaki ve bazen arkada biri
      const n = 2 + (Math.random() < 0.55 ? 1 : 0);
      const arac = aracGetir(s, 'zabita', y.yaka, y.x, {
        siren: 'zabita',
        vardi: (a) => {
          if (y.park != null) a.parkX = y.park;
          const ekip = aractanIn(s, a, 'zabita', n);
          for (let i = 0; i < n; i++) {
            const z = ekip[i];
            const [kx] = disNokta(a, z.koltuk);
            const hx = tx + (i - (n - 1) / 2) * 0.75;
            const hz = on + (i === 0 ? 0 : 0.35 + Math.abs(i - (n - 1) / 2) * 0.2);
            const yol = [];
            if (yer.guney) {
              // güneydeki tezgâhın önüne yanından dolaşarak gidilir
              const yan = tx + (hx < tx ? -1.9 : 1.9);
              yol.push({ yuru: [kx, 10.6] }, { yuru: [yan, 10.9 + i * 0.2] }, { yuru: [yan, hz] });
            } else yol.push({ yuru: [kx, -0.7] });
            yol.push({ yuru: [hx, hz] });
            yap(z, ...yol, { bekle: 0.2, bak: Math.PI });
            if (i === 0) {
              yap(z,
                { yap: () => kisiyeBalon(z, sec(ZABITA_SOZLERI), 3) },
                { bekle: 3, anim: 'Interact', bak: Math.PI },
                { yap: () => sonucGoster(s, z, yer, sonuc, ziyaret) },
                { bekle: 3.2, anim: 'Idle_Talking_Loop', bak: Math.PI });
            } else yap(z, { bekle: 6.4, anim: i % 2 ? 'Idle_Loop' : 'Idle_Talking_Loop', bak: Math.PI });
            // araca dönüş
            const donus = [...yol].reverse().slice(1).map((x) => ({ yuru: x.yuru }));
            yap(z, ...donus);
            arabayaBin(z, a, () => { s.donen = (s.donen || 0) + 1; if (s.donen >= n) aracGonder(a, true); });
          }
        },
      });
      s.arac = arac;
    });
  }
  function sonucGoster(s, z, yer, sonuc, ziyaret) {
    const izinli = sonuc === 'kontrol';
    if (izinli) {
      kisiyeBalon(z, sec(ZABITA_IYI_SOZLERI), 3.5, 'iyi');
      for (const k of s.kisiler.slice(1)) if (Math.random() < 0.7) kisiyeBalon(k, '😊', 2.5, 'iyi');
    } else if (sonuc === 'uyari') {
      kisiyeBalon(z, '⚠️ İzin yok! Bu seferlik uyarıyorum.', 3.5, 'uyari');
    } else {
      kisiyeBalon(z, `🧾 İzinsiz satış! Ceza: ${tl(ziyaret.ceza || 0)}`, 3.5, 'kotu');
    }
    c.zabitaSonucu(yer.kod, sonuc, ziyaret);
  }

  // ------------------------------------------------ 2. Kavga ve polis
  function kavgaSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const x = olayX(olay);
      const z = 10.0;
      const a = kisi('yaya', x - 3, z + 0.3, Math.PI / 2, sec(['genc_erkek', 'orta_yas']));
      const b = kisi('yaya', x + 3, z - 0.2, -Math.PI / 2, sec(['genc_erkek', 'orta_yas', 'is_adami']));
      s.kisiler.push(a, b);
      yap(a, { yuru: [x - 0.6, z] });
      yap(b, { yuru: [x + 0.6, z] });
      s.kavga = { a, b, x, z, sure: 0 };
      s.senaryo = senaryo(KAVGA_SENARYOLARI, olay);
      // etrafa toplanan kalabalık
      for (let i = 0; i < 4; i++) {
        const aci = rnd(0, Math.PI * 2);
        const bx = x + Math.cos(aci) * 2.6;
        const bz = z + Math.sin(aci) * 1.6;
        const g = kisi('yaya', bx + (Math.random() < 0.5 ? -9 : 9), bz, 0);
        s.kisiler.push(g);
        yap(g, { bekle: rnd(2, 6) }, { yuru: [bx, bz] }, { yap: (k) => { k.bosAnim = 'Idle_Talking_Loop'; k.g.rotation.y = bakis(bx, bz, x, z); } });
        s.kalabalik = s.kalabalik || [];
        s.kalabalik.push(g);
      }
      s.cagri = katilimDugmesi(s, _autoMetin('📞 155 Polisi ara'), x, 3.1, z, () => { s.polisCagrildi = true; });
      s.adim = (dt) => {
        const k = s.kavga;
        k.sure += dt;
        if (!k.polis && (s.t > 12 || (s.polisCagrildi && s.t > 4))) {
          k.polis = true;
          if (s.cagri && !s.polisCagrildi) setTimeout(() => balonSil(s.cagri), 14000);
          const yy = yanasmaYeri(x, 'guney');
          aracGetir(s, 'polis', yy.yaka, yy.x, { siren: 'polis', vardi: (arac) => polisIner(s, arac, yy) });
        }
        // kavga edenler: birbirine bağırır, arada iter
        if (!k.ayrildi && s.t > 2.5) {
          for (const [p, q] of [[a, b], [b, a]]) {
            if (p.is.length) continue;
            p.g.rotation.y = bakis(p.g.position.x, p.g.position.z, q.g.position.x, q.g.position.z);
            const itme = Math.sin(k.sure * 3 + (p === a ? 0 : 1.7));
            oynat(p, itme > 0.6 ? 'Interact' : 'Idle_Talking_Loop', itme > 0.6 ? 1.6 : 1.9);
          }
          if (Math.random() < dt * 0.5) {
            // önce senaryonun sözleri sırayla (a, b, a, b), sonra karışık
            k.soz = (k.soz || 0) + 1;
            const kim = k.soz % 2 ? a : b;
            const liste = kim === a ? s.senaryo.a : s.senaryo.b;
            kisiyeBalon(kim, k.soz <= 4 ? liste[Math.floor((k.soz - 1) / 2) % liste.length] : sec([...liste, ...KAVGA_SOZLERI]), 2.2, 'kotu');
          }
        }
      };
    });
  }
  function polisIner(s, arac, yy) {
    if (yy.park != null) arac.parkX = yy.park;
    const { a, b, x, z } = s.kavga;
    // ekip otosunda iki ya da üç polis (dördüncü koltuk kavgacılardan birine kalır)
    const n = 2 + (Math.random() < 0.5 ? 1 : 0);
    const polisler = aractanIn(s, arac, 'polis', n, { bekle: 0.3 });
    const [p1, p2] = polisler;
    const kaldirim = yy.yaka === 'guney' ? 9.0 : -0.2;
    // ilk ikisi kavga edenleri alır, diğerleri kalabalığı dağıtır
    yap(p1, { yuru: [p1.g.position.x, kaldirim] }, { yuru: [a.g.position.x - 0.4, z + 0.4] }, { yap: () => { s.kavga.ayrildi = true; kisiyeBalon(p1, (s.senaryo && s.senaryo.polis[0]) || sec(POLIS_SOZLERI), 2.8); if (p2) setTimeout(() => kisiyeBalon(p2, (s.senaryo && s.senaryo.polis[1]) || sec(POLIS_SOZLERI), 2.6), 1500); } }, { bekle: 1.2, anim: 'Interact' },
      { yap: () => { p1.yanindaki = a; a.is = []; } });
    yap(p2, { yuru: [p2.g.position.x, kaldirim] }, { yuru: [b.g.position.x + 0.4, z + 0.4] }, { bekle: 1.2, anim: 'Interact' }, { yap: () => { p2.yanindaki = b; b.is = []; } });
    // gözaltına alınanlar arka koltuğa bindirilir (polis kapıyı açar, kişiyi bindirir, kendisi öne geçer)
    const arkaKol = [koltukSec(arac, 2), koltukSec(arac, 3)];
    const gotur = (p, suclu, kol, onKol) => {
      const [dx, dz] = disNokta(arac, kol);
      yap(p, { yuru: [dx, kaldirim] }, { yuru: [dx + (arac.yaka.yon > 0 ? -0.7 : 0.7), dz] },
        { fn: () => { kapiAc(arac, kol.kapi); return kapiDegeri(arac, kol.kapi) > 0.72; } },
        { yap: () => { p.yanindaki = null; suclu.is = []; yap(suclu, { yuru: disNokta(arac, kol) }, { fn: kapiAdimi(arac, kol, 'bin') }, { yap: (kk) => { kk.g.visible = false; kisiSil(kk); kapiKapat(arac, kol.kapi, 0.4); } }); } },
        { bekle: 1.4, anim: 'Idle_Loop' });
      arabayaBin(p, arac, binen, onKol);
    };
    gotur(p1, a, arkaKol[0], p1.koltuk);
    gotur(p2, b, arkaKol[1], p2.koltuk);
    for (const p of polisler.slice(2)) {
      const hx = x + rnd(-2, 2);
      yap(p, { yuru: [p.g.position.x, kaldirim] }, { yuru: [hx, z + 1.3] }, { yap: () => kisiyeBalon(p, sec([...((s.senaryo && s.senaryo.dagit) || []), ...POLIS_DAGIT_SOZLERI]), 2.8) }, { bekle: 3.5, anim: 'Idle_Talking_Loop', bak: bakis(hx, z + 1.3, x, z) },
        { yuru: [p.g.position.x, kaldirim] });
      arabayaBin(p, arac, binen);
    }
    // kalabalık dağılır
    for (const g of s.kalabalik || []) yap(g, { bekle: rnd(3, 6) }, { yap: (k) => { k.bosAnim = null; } }, { yuru: [g.g.position.x + (Math.random() < 0.5 ? -14 : 14), g.g.position.z] }, { yap: kisiSil });
    let binenSayi = 0;
    function binen() { if (++binenSayi >= n) aracGonder(arac); }
  }

  // ------------------------------------------------ 3. Rahatsızlanan ve ambulans
  function ambulansSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const x = olayX(olay);
      const z = -0.75;
      const h = kisi('yaya', x - 6, -0.35, Math.PI / 2);
      s.kisiler.push(h);
      s.hasta = h;
      s.senaryo = senaryo(AMBULANS_SENARYOLARI, olay);
      yap(h, { yuru: [x, z], hiz: 0.9 }, { bekle: 0.8, anim: 'Idle_Loop' }, { yap: () => { s.dusus = 0; h.ozelY = true; kisiyeBalon(h, s.senaryo.hasta[0], 2.6); setTimeout(() => { if (h.g.parent) kisiyeBalon(h, s.senaryo.hasta[1], 2.4); }, 2900); } });
      for (let i = 0; i < 3; i++) {
        const aci = rnd(-0.5, 3.6);
        const bx = x + Math.cos(aci) * 1.3;
        const bz = z + Math.sin(aci) * 0.9 - 0.3;
        const g = kisi('yaya', bx + (i % 2 ? -10 : 10), -0.95, 0);
        s.kisiler.push(g);
        yap(g, { bekle: 2.5 + i }, { yuru: [bx, bz] }, { yap: (k) => { k.bosAnim = i === 0 ? 'Interact' : 'Idle_Talking_Loop'; k.g.rotation.y = bakis(bx, bz, x, z); if (i === 0) kisiyeBalon(k, s.senaryo.cagiran[0], 3); else if (i === 1) setTimeout(() => kisiyeBalon(k, Math.random() < 0.7 ? s.senaryo.cagiran[1] : sec(CAGIRAN_SOZLERI), 3), 1800); } });
        (s.kalabalik = s.kalabalik || []).push(g);
      }
      s.cagri = katilimDugmesi(s, _autoMetin('📞 112 Acil’i ara'), x, 2.8, z, () => { s.cagrildi = true; });
      s.adim = (dt) => {
        if (s.dusus !== undefined && s.dusus < 1) {
          // yere yığılır: ayaklarının üstünden geriye doğru yatar
          s.dusus = Math.min(1, s.dusus + dt * 1.4);
          const e = s.dusus * s.dusus;
          h.g.rotation.x = -e * Math.PI / 2;
          h.g.position.y = KALDIRIM_Y + e * 0.12;
          oynat(h, 'Idle_Loop', 0.2);
        }
        if (!s.ambulans && (s.t > 11 || (s.cagrildi && s.t > 5))) {
          s.ambulans = aracGetir(s, 'ambulans', 'kuzey', x + 3.5, { siren: 'ambulans', vardi: (a) => { if (s.cagri) balonSil(s.cagri); saglikIner(s, a, x, z); } });
        }
      };
    });
  }
  function saglikIner(s, a, x, z) {
    // şoför ve yanındaki sağlıkçı önden, (varsa) üçüncüsü arka kapıdan iner; sedye arka kapıdan çekilip çıkarılır
    const n = 2 + (Math.random() < 0.5 ? 1 : 0);
    const ekip = aractanIn(s, a, 'saglik', n, { bekle: 0.4 });
    const [m1, m2] = ekip;
    const au = a.g.userData.araba;
    const arkaKol = koltukSec(a, 2);
    const [rx, rz] = yerel(a.g, au.arkaX - 1.0, 0);
    const yan = (d) => yerel(a.g, au.arkaX - 1.05, d);
    const sedye = nesneEkle(s, sedyeModeli());
    sedye.visible = false;
    const zemin = (px, pz) => (c.zeminY ? c.zeminY(px, pz) : KALDIRIM_Y);
    // sedyeyi arka kapıdan çekip çıkarma / geri itme
    const sedyeKaydir = (disari) => {
      let t = 0;
      return (k, dt) => {
        if (t === 0) { kapiAc(a, 'arka'); if (kapiDegeri(a, 'arka') < 0.8) return false; sedye.visible = true; }
        t = Math.min(1, t + dt / 1.4);
        const e = t * t * (3 - 2 * t);
        const f = disari ? e : 1 - e;
        const [sx, sz] = yerel(a.g, au.arkaX + 1.1 - f * 2.4, 0);
        sedye.position.set(sx, zemin(sx, sz) + (1 - f) * 0.45, sz);
        sedye.rotation.y = a.g.rotation.y + Math.PI;
        if (!disari && s.yukleniyor && s.yukleniyor.g.parent) {
          s.yukleniyor.g.position.set(sx + Math.cos(sedye.rotation.y) * 0.85, sedye.position.y + 0.95, sz - Math.sin(sedye.rotation.y) * 0.85);
        }
        oynat(k, 'Interact', 1);
        return t >= 1;
      };
    };
    const tutKonumu = [yan(0.55), yan(-0.55)];
    const hedef = [x + 1.3, z];
    const bak = yerelYon(a.g, 1, 0);
    // ikisi arka kapıya gelir; kapı açılır, sedye çekilip çıkarılır ve hastanın yanına taşınır
    yap(m1, { yuru: [rx, rz] }, { yuru: tutKonumu[0] }, { bekle: 0.2, bak }, { yap: () => { s.m1Hazir = true; } }, { fn: () => !!s.sedye },
      { yuru: [x + 2.35, z] }, { bekle: 0.3, bak: -Math.PI / 2 }, { bekle: 2.6, anim: 'Interact', bak: -Math.PI / 2 });
    yap(m2, { yuru: tutKonumu[1] }, { bekle: 0.2, bak }, { fn: () => !!s.m1Hazir }, { fn: sedyeKaydir(true) },
      { yap: () => { s.sedye = { g: sedye, tutan: [m1, m2], yuk: null }; } },
      { yuru: [x + 0.3, z - 0.1] }, { bekle: 0.3, bak: Math.PI / 2 }, { bekle: 2.6, anim: 'Interact', bak: Math.PI / 2 },
      { yap: () => { s.sedye.yuk = s.hasta; s.hasta.ozelY = true; kisiyeBalon(m2, s.senaryo ? s.senaryo.saglikci[0] : sec(SAGLIKCI_SOZLERI), 2.8, 'iyi'); if (s.senaryo) setTimeout(() => { if (m1.g.parent) kisiyeBalon(m1, s.senaryo.saglikci[1], 2.6, 'iyi'); }, 2600); } });
    if (ekip[2]) yap(ekip[2], { yuru: [x - 0.4, z - 0.9] }, { bekle: 9, anim: 'Idle_Talking_Loop', bak: 0 });
    // dönüş: sedye arka kapıdan içeri itilir, herkes yerine biner
    let binen = 0;
    const bindi = () => { if (++binen >= n) aracGonder(a); };
    yap(m1, { bekle: 0.4 }, { yuru: tutKonumu[0] }, { bekle: 0.3, bak }, { yap: () => { s.m1Dondu = true; } }, { fn: () => !!s.yuklendi });
    yap(m2, { yuru: tutKonumu[1] }, { bekle: 0.3, bak }, { fn: () => !!s.m1Dondu },
      { yap: () => { const sd = s.sedye; s.sedye = null; s.yukleniyor = sd && sd.yuk; } },
      { fn: sedyeKaydir(false) },
      { yap: () => { sedye.visible = false; if (s.hasta) { kisiSil(s.hasta); s.hasta = null; } s.yuklendi = true; if (!ekip[2]) kapiKapat(a, 'arka', 0.3); } });
    if (ekip[2]) yap(ekip[2], { fn: () => !!s.yuklendi });
    arabayaBin(m1, a, bindi);
    arabayaBin(m2, a, bindi);
    if (ekip[2]) arabayaBin(ekip[2], a, bindi, arkaKol);
    for (const g of s.kalabalik || []) yap(g, { bekle: rnd(5, 8) }, { yap: (k) => { k.bosAnim = null; } }, { yuru: [g.g.position.x + (Math.random() < 0.5 ? -14 : 14), -0.35] }, { yap: kisiSil });
    s.sedyeGuncelle = () => {
      const sd = s.sedye;
      if (!sd) return;
      const [t1, t2] = sd.tutan;
      if (!t1.g.parent || !t2.g.parent) return;
      const mx = (t1.g.position.x + t2.g.position.x) / 2;
      const mz = (t1.g.position.z + t2.g.position.z) / 2;
      sd.g.position.set(mx, zemin(mx, mz), mz);
      sd.g.rotation.y = Math.atan2(t2.g.position.z - t1.g.position.z, t1.g.position.x - t2.g.position.x);
      if (sd.yuk) {
        sd.yuk.g.position.set(mx - Math.cos(sd.g.rotation.y) * 0.85, sd.g.position.y + 0.95, mz + Math.sin(sd.g.rotation.y) * 0.85);
        sd.yuk.g.rotation.set(-Math.PI / 2, 0, 0);
        sd.yuk.g.rotateOnWorldAxis(new THREE.Vector3(0, 1, 0), sd.g.rotation.y - Math.PI / 2);
      }
    };
  }

  // ------------------------------------------------ 4. Belediye otobüsü durakta
  function otobusSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const dx = c.durakX();
      const bekleyenler = [];
      for (let i = 0; i < 1 + Math.floor(Math.random() * 3); i++) {
        const k = kisi('yaya', dx + rnd(-1.5, 1.5), 10.4 + rnd(-0.2, 0.3), Math.PI);
        k.bosAnim = 'Idle_Loop';
        s.kisiler.push(k);
        bekleyenler.push(k);
      }
      aracGetir(s, 'otobus', 'guney', dx + 1.5, {
        acil: false,
        vardi: (a) => {
          const kapilar = [a.g.position.x + 4.6, a.g.position.x + 0.2];
          const inen = Math.floor(Math.random() * 4);
          for (let i = 0; i < inen; i++) {
            const kx = kapilar[i % 2];
            const k = kisi('yaya', kx, 8.5, 0);
            s.kisiler.push(k);
            yap(k, { bekle: i * 0.6 }, { yuru: [kx, 9.8 + rnd(0, 0.8)] }, { yuru: [kx + (Math.random() < 0.5 ? -18 : 18), 10.1] }, { yap: kisiSil });
          }
          bekleyenler.forEach((k, i) => yap(k, { bekle: 1 + i * 0.7 }, { yuru: [kapilar[0], 9.2] }, { yuru: [kapilar[0], 8.5] }, { yap: kisiSil }));
          setTimeout(() => aracGonder(a), 8000);
        },
      });
    });
  }

  // ------------------------------------------------ 5. Sabah çöp kamyonu
  // Kamyon caddedeki konteynerlerin yanında şeritte durur (arkadakiler bekler). Arka basamakta duran iki işçiden biri
  // iner, konteyneri kamyonun arkasına çeker; kaldırıcı konteyneri kaldırıp devirir, sallar ve indirir; işçi konteyneri
  // yerine götürür, basamağa geri çıkar ve kamyon sonraki konteynere geçer.
  function copSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const Y = YAKA.guney;
      const kutular = (c.konteynerler ? c.konteynerler() : []).filter((k) => Math.abs(k.yolZ - Y.kenarZ) < 0.5).sort((p, q) => p.x - q.x);
      const arac = aracGetir(s, 'cop', 'guney', kutular.length ? kutular[0].x : olayX(olay), { acil: false });
      const u = arac.g.userData;
      const au = u.araba;
      u.azami = 6;
      u.durHiz = null;
      arac.durum = 'serit';
      // arka basamaktaki işçiler
      const isciler = [0, 1].map((i) => {
        const k = kisi('temizlik', 0, 0, 0);
        arac.g.add(k.g);
        k.g.position.set(au.arkaX - 0.28, 0.32, i ? -0.72 : 0.72);
        k.g.rotation.y = Math.PI / 2;
        k.bosAnim = 'Idle_Loop';
        s.kisiler.push(k);
        return k;
      });
      let sira = 0;
      const durak = (k) => k.x - au.arkaX - 0.2; // kamyonun arkası konteynerin hizasına gelir
      u.durHedef = kutular.length ? durak(kutular[0]) : null;
      if (!kutular.length) { arac.durum = 'gidiyor'; u.bitince = () => aracSil(s, arac); }
      const basamagaCik = (k, i) => {
        const w = new THREE.Vector3();
        k.g.getWorldPosition(w);
        c.sahne.remove(k.g);
        arac.g.add(k.g);
        k.g.position.set(au.arkaX - 0.28, 0.32, i ? -0.72 : 0.72);
        k.g.rotation.y = Math.PI / 2;
        k.ozelY = false;
        k.bosAnim = 'Idle_Loop';
      };
      const basamaktanIn = (k) => {
        const w = new THREE.Vector3();
        k.g.getWorldPosition(w);
        arac.g.remove(k.g);
        c.sahne.add(k.g);
        k.g.position.set(w.x, c.zeminY ? c.zeminY(w.x, w.z) : 0.02, w.z);
        k.g.rotation.y = Math.PI / 2;
        k.bosAnim = null;
      };
      s.adim = (dt) => {
        // şeritte çöp alırken dörtlüler yanar, yeniden yola çıkınca söner
        if (arac.durum === 'serit') u.sinyal = u.hiz < 0.4 && u.durHedef != null && Math.abs(u.durHedef - u.p) < 3 ? 'dortlu' : null;
        if (arac.durum !== 'serit' || arac.bosaltiyor) return;
        if (u.hiz < 0.1 && u.durHedef != null && Math.abs(u.durHedef - u.p) < 0.8) {
          arac.bosaltiyor = true;
          const kutu = kutular[sira];
          const i = sira % 2;
          const isci = isciler[i];
          basamaktanIn(isci);
          const g = arac.g;
          const [lx, lz] = yerel(g, au.arkaX - 1.05, 0);        // kaldırma noktası (kamyonun arkası)
          const tutma = [kutu.x, kutu.z - 0.95];                 // konteynerin yol tarafı
          const K = kutu.g;
          K.rotation.order = 'YXZ';
          const tasi = (hx, hz, sure, donus) => {
            // konteyner işçinin önünde (işçi geri geri çeker)
            let tt = 0;
            let bx = null, bz = null;
            return (k, dt2) => {
              if (bx === null) { bx = K.position.x; bz = K.position.z; }
              tt = Math.min(1, tt + dt2 / sure);
              const e = tt * tt * (3 - 2 * tt);
              K.position.x = bx + (hx - bx) * e;
              K.position.z = bz + (hz - bz) * e;
              K.position.y = c.zeminY ? c.zeminY(K.position.x, K.position.z) : KALDIRIM_Y;
              K.rotation.y = kutu.ry + (donus - kutu.ry) * e;
              const aci = Math.atan2(K.position.x - k.g.position.x, K.position.z - k.g.position.z);
              const ux = K.position.x - Math.sin(aci) * 0.95, uz = K.position.z - Math.cos(aci) * 0.95;
              k.g.position.x = ux;
              k.g.position.z = uz;
              k.g.rotation.y = aci;
              oynat(k, 'Walk_Loop', 0.55);
              return tt >= 1;
            };
          };
          const kaldir = () => {
            let tt = 0;
            return (k, dt2) => {
              tt += dt2;
              // 0–1 sn kalkar, 1–1.6 devrilir, 1.6–3 sallanır, 3–4.2 iner
              const kalk = Math.min(1, tt / 1) - Math.max(0, Math.min(1, (tt - 3) / 1.2));
              const dev = Math.max(0, Math.min(1, (tt - 1) / 0.6)) - Math.max(0, Math.min(1, (tt - 2.9) / 0.5));
              K.position.y = 0.02 + kalk * 1.35;
              K.rotation.x = dev * 2.15 + (tt > 1.6 && tt < 2.9 ? Math.sin(tt * 22) * 0.06 : 0);
              kutu.kapak.rotation.x = -Math.min(1.9, dev * 2.4);
              oynat(k, 'Idle_Loop');
              if (tt >= 4.2) { K.position.y = 0.02; K.rotation.x = 0; kutu.kapak.rotation.x = 0; return true; }
              return false;
            };
          };
          const yuzu = Math.atan2(g.position.x - lx, g.position.z - lz); // konteyner yüzü kamyona dönük
          yap(isci, { yuru: [kutu.x - 0.3, tutma[1] - 0.2] }, { bekle: 0.4, bak: 0 },
            { fn: tasi(lx, lz, 3.2, yuzu) },
            { bekle: 0.3, bak: Math.atan2(lx - isci.g.position.x, lz - isci.g.position.z) },
            { fn: kaldir() },
            { fn: tasi(kutu.x, kutu.z, 3.2, kutu.ry) },
            { yuru: [lx - 1.2, Y.seritZ + 0.9] },
            { yap: (k) => {
              basamagaCik(k, i);
              arac.bosaltiyor = false;
              sira++;
              if (sira < kutular.length) u.durHedef = durak(kutular[sira]);
              else { u.durHedef = null; u.sinyal = null; arac.durum = 'gidiyor'; u.bitince = () => aracSil(s, arac); u.azami = 9; }
            } });
        }
      };
    });
  }

  // ------------------------------------------------ 6. Düğün konvoyu ve geçen araçlar (devriye, itfaiye)
  function konvoySahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const yaka = Math.random() < 0.5 ? 'kuzey' : 'guney';
      const Y = YAKA[yaka];
      const { XB, XD } = c.sinirlar();
      const uzak = Math.min(150, 55 + c.kamera().mesafe);
      const bas = Y.yon > 0 ? XB - uzak : XD + uzak;
      if (!c.trafik.bosMu(Y.serit, bas, 40)) return;
      for (let i = 0; i < 4; i++) {
        const g = i === 0 ? gorevAraci('gelin') : araba(sec(['sedan', 'hatchback', 'suv', 'sedan']));
        const p = bas - Y.yon * i * 7;
        g.position.set(p, 0.02, Y.seritZ);
        g.rotation.y = Y.yon > 0 ? 0 : Math.PI;
        Object.assign(g.userData, { p, hiz: 7, azami: 7, olay: true, bitince: () => { c.sahne.remove(g); c.bellektenSil(g); s.bitenArac = (s.bitenArac || 0) + 1; } });
        c.sahne.add(g);
        c.trafik.ekle(g, Y.serit);
        s.konvoy = s.konvoy || [];
        s.konvoy.push(g);
      }
      s.adim = (dt, t) => {
        const onde = s.konvoy[0];
        if (!onde.parent) return;
        const k = c.kamera();
        if (t - (s.sonKorna || -9) > 3.5 && Math.abs(onde.position.x - k.x) < 45 && k.mesafe < 120) {
          s.sonKorna = t;
          ses.dugunKornasi(Math.max(-1, Math.min(1, (onde.position.x - k.x) / 30)));
          noktayaBalon(s, _autoMetin('🎉 Düğün var!'), onde.position.x, 2.4, onde.position.z, { sure: 2.5, tur: 'iyi' }).takip = onde;
        }
        for (const b of s.balonlar) if (b.takip) { b.x = b.takip.position.x; b.z = b.takip.position.z; }
        if ((s.bitenArac || 0) >= s.konvoy.length) s.bitsin = true;
      };
    });
  }
  function gecisSahnesi(olay, tur, siren) {
    return sahneBaslat(olay, (s) => {
      const yaka = Math.random() < 0.5 ? 'kuzey' : 'guney';
      const Y = YAKA[yaka];
      const { XB, XD } = c.sinirlar();
      const uzak = Math.min(150, 55 + c.kamera().mesafe);
      const bas = Y.yon > 0 ? XB - uzak : XD + uzak;
      if (!c.trafik.bosMu(Y.serit, bas, 20)) { s.bitsin = true; return; }
      const arac = aracGetir(s, tur, yaka, 0, { siren, hizli: tur === 'itfaiye' });
      arac.g.userData.durHedef = null;
      arac.g.userData.p = bas;
      arac.g.position.x = bas;
      arac.durum = 'gidiyor';
      arac.surekliSiren = !!siren;
      arac.g.userData.bitince = () => { aracSil(s, arac); s.bitsin = true; };
      if (!siren) arac.isik = tur === 'zabita';
    });
  }

  // ------------------------------------------------ 6a. Makam konvoyları (ilçe/il belediye başkanı, milletvekili, cumhurbaşkanı)
  // Rütbeye göre konvoy: önde motorlu polisler ve polis araçları, ortada bayraklı makam aracı, çevresinde koruma
  // araçları (basamaklarında korumalar), cumhurbaşkanında ambulans da vardır. Halk kaldırım kenarında birikip el sallar.
  const KONVOY_DIZILIS = {
    konvoy_ilce: ['polis', 'makam', 'koruma', 'polis'],
    konvoy_mv: ['polis', 'makam', 'koruma'],
    konvoy_il: ['polisMotor', 'polisMotor', 'polis', 'makam', 'koruma', 'koruma', 'polis'],
    konvoy_cb: ['polisMotor', 'polisMotor', 'polisMotor', 'polisMotor', 'polis', 'polis', 'koruma', 'koruma', 'cbMakam', 'koruma', 'koruma', 'ambulans', 'polis'],
  };
  const KONVOY_KALABALIK = { konvoy_ilce: 8, konvoy_mv: 8, konvoy_il: 14, konvoy_cb: 24 };
  function makamKonvoyu(olay) {
    return sahneBaslat(olay, (s) => {
      const yaka = olay.tohum % 2 === 0 ? 'kuzey' : 'guney';
      const Y = YAKA[yaka];
      const { XB, XD } = c.sinirlar();
      const uzak = Math.min(150, 50 + c.kamera().mesafe);
      const bas = Y.yon > 0 ? XB - uzak : XD + uzak;
      const kim = olay.kim || { ad: null, makam: 'Makam' };
      const cb = olay.tur === 'konvoy_cb';
      let makamArac = null;
      // araçlar sokağın başından sırayla, aralarında boşluk bırakarak çıkar
      const kuyruk = [...(KONVOY_DIZILIS[olay.tur] || KONVOY_DIZILIS.konvoy_ilce)];
      let polisSayisi = 0;
      const polisToplam = kuyruk.filter((t) => t === 'polis').length;
      const aracCikar = (tur) => {
        const g = gorevAraci(tur);
        const u = g.userData.araba;
        const p = bas;
        g.position.set(p, 0.02, Y.seritZ);
        g.rotation.y = Y.yon > 0 ? 0 : Math.PI;
        const arac = { g, tur, yaka: Y, x: p, durum: 'gidiyor', t: 0, siren: null, surekliSiren: false };
        // öndeki polis sireni çalar (cumhurbaşkanında en arkadaki de)
        if (tur === 'polis') {
          polisSayisi++;
          if (polisSayisi === 1 || (cb && polisSayisi === polisToplam)) { arac.siren = 'polis'; arac.surekliSiren = true; }
        }
        Object.assign(g.userData, { p, hiz: 8, azami: 8, tur, olay: true, acil: true, durHedef: null, bitince: () => aracSil(s, arac) });
        c.sahne.add(g);
        c.trafik.ekle(g, Y.serit);
        for (const h of u.haleler) c.gecelik.haleler.add(h);
        s.araclar.push(arac);
        if (tur === 'polisMotor') {
          const r = kisi('polis', 0, 0, 0);
          r.bosAnim = 'Sitting_Idle_Loop';
          g.add(r.g);
          r.g.position.set(-0.15, 0.46, 0);
          r.g.rotation.y = Math.PI / 2;
          s.kisiler.push(r);
        }
        if (tur === 'koruma' && (olay.tur === 'konvoy_il' || cb)) {
          // SUV'nin basamaklarında birer koruma
          for (const z of [u.en / 2 + 0.28, -u.en / 2 - 0.28]) {
            const k = kisi('fedai', 0, 0, 0);
            k.bosAnim = 'Idle_Loop';
            g.add(k.g);
            k.g.position.set(-0.2, 0.28, z);
            k.g.rotation.y = Math.PI / 2;
            s.kisiler.push(k);
          }
        }
        if (tur === 'makam' || tur === 'cbMakam') {
          makamArac = g;
          // makam aracının üstünde kim olduğu yazar
          const b = noktayaBalon(s, yazi, g.position.x, 3.2, g.position.z, { sure: 600, tur: 'iyi' });
          b.takip = g;
        }
        s.sonCikan = { g, tur };
      };
      const yazi = `${cb ? '🇹🇷' : olay.tur === 'konvoy_mv' ? '🏢' : '🏛️'} ${esc(kim.makam)}${kim.ad ? `<br><b>${esc(kim.ad)}</b>` : ''}`;
      if (c.trafik.kapat) c.trafik.kapat(Y.serit, 60);
      s.kapaliUzat = 0;
      s.ilkCiksin = true;
      // halk: kameranın önünde, iki kaldırımın kenarında birikir
      const kam = c.kamera();
      const merkez = Math.max(XB + 20, Math.min(XD - 20, Math.abs(kam.x) < 90 ? kam.x : 0));
      const n = KONVOY_KALABALIK[olay.tur] || 8;
      s.kalabalik = [];
      for (let i = 0; i < n; i++) {
        const kuzey = i % 2 === 0;
        const kx = merkez + rnd(-22, 22);
        const kenarZ = kuzey ? -0.35 : 8.35;
        const geriZ = kuzey ? rnd(-3.5, -2) : rnd(10.2, 11.5);
        const k = kisi('yaya', kx + rnd(-3, 3), geriZ, kuzey ? 0 : Math.PI);
        k.hiz = rnd(1.1, 1.6);
        yap(k, { yuru: [kx, kenarZ + rnd(-0.25, 0.25)] }, { bekle: 999, bak: kuzey ? 0 : Math.PI, anim: 'Idle_Loop' });
        k.g.userData.elFaz = Math.random() * 6;
        k.kuzey = kuzey;
        // cumhurbaşkanı geçişinde bazıları bayrak sallar
        if ((cb || olay.tur === 'konvoy_il') && Math.random() < 0.45) {
          {
            const b = new THREE.Group();
            const direk = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.5, 5), new THREE.MeshStandardMaterial({ color: '#8A6A3E' }));
            direk.position.y = 0.2;
            const bez = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.21), new THREE.MeshStandardMaterial({ color: '#E30A17', side: THREE.DoubleSide }));
            bez.position.set(0.17, 0.35, 0);
            b.add(direk, bez);
            eleVer(k.g, b);
          }
        }
        s.kisiler.push(k);
        s.kalabalik.push(k);
      }
      s.sonAlkis = -9;
      s.adim = (dt, t) => {
        // ilk araç şeridin başı boşalınca çıkar; sıradaki araç öndeki yeterince uzaklaşınca
        if (s.ilkCiksin && c.trafik.bosMu(Y.serit, bas, 9)) { s.ilkCiksin = false; aracCikar(kuyruk.shift()); }
        if (kuyruk.length && s.sonCikan && t - s.kapaliUzat > 20) { s.kapaliUzat = t; if (c.trafik.kapat) c.trafik.kapat(Y.serit, 40); }
        if (kuyruk.length && s.sonCikan) {
          const on = s.sonCikan;
          const bosluk = (on.g.userData.araba.uzunluk / 2) + (kuyruk[0] === 'polisMotor' ? 3.2 : 4.2) + 2.2;
          if ((!on.g.parent || (on.g.position.x - bas) * Y.yon > bosluk) && c.trafik.bosMu(Y.serit, bas, 5)) aracCikar(kuyruk.shift());
        }
        for (const b of s.balonlar) if (b.takip) { b.x = b.takip.position.x; b.z = b.takip.position.z; }
        const xs = s.araclar.map((a) => a.g.position.x);
        const gecti = !s.araclar.length && !kuyruk.length;
        for (const k of s.kalabalik) {
          if (!k.g.parent || k.dagildi) continue;
          const yakin = xs.some((x) => Math.abs(x - k.g.position.x) < 28);
          const hedef = yakin && k.is.length === 1 ? 1 : 0;
          const e = k.g.userData.elSalla || 0;
          k.g.userData.elSalla = e + (hedef - e) * Math.min(1, dt * 4);
          if (k.g.userData.elSalla < 0.02) k.g.userData.elSalla = 0;
          // konvoy geçip gidince dağılırlar
          if (gecti && !k.dagildi) {
            k.dagildi = true;
            k.g.userData.elSalla = 0;
            k.is = [];
            yap(k, { bekle: rnd(0.5, 2.5) }, { yuru: [k.g.position.x + rnd(-6, 6), k.kuzey ? -4 : 12] }, { yap: (kk) => { kisiSil(kk); } });
          }
        }
        // yakından geçerken alkış ve tezahürat
        const kamx = c.kamera().x;
        if (makamArac && makamArac.parent && Math.abs(makamArac.position.x - kamx) < 30 && t - s.sonAlkis > 4) {
          s.sonAlkis = t;
          const k = sec(s.kalabalik);
          if (k && k.g.parent) kisiyeBalon(k, sec(cb ? [_autoMetin('🇹🇷 Yaşa!'), '👏👏👏', _autoMetin('Hoş geldiniz!'), '🇹🇷🇹🇷'] : [_autoMetin('👏 Hoş geldiniz!'), _autoMetin('👋 Başkanım!'), 'Kolay gelsin!', '👏👏']), 2);
        }
        if (gecti && s.kalabalik.every((k) => !k.g.parent || k.g.visible === false)) s.bitsin = true;
      };
    });
  }

  // ------------------------------------------------ 6b. Yangın ve itfaiye
  // Ana caddedeki bir binanın üst katında yangın çıkar: pencereden alev ve duman yükselir. Biri 110'u arar
  // (ya da oyuncu arar), itfaiye sirenle gelir, itfaiyeciler hortumla suyu pencereye sıkar, alev söner, duman incelir.
  function yumusakDoku(renk) {
    const k = 'yuvarlak:' + renk;
    if (yumusakDoku[k]) return yumusakDoku[k];
    const cv = document.createElement('canvas');
    cv.width = cv.height = 64;
    const x = cv.getContext('2d');
    const g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, renk); g.addColorStop(0.45, renk.replace(/[\d.]+\)$/, '0.55)')); g.addColorStop(1, renk.replace(/[\d.]+\)$/, '0)'));
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    yumusakDoku[k] = t;
    return t;
  }
  function parcacik(s, renk, katki) {
    const m = new THREE.SpriteMaterial({ map: yumusakDoku(renk), transparent: true, depthWrite: false, blending: katki ? THREE.AdditiveBlending : THREE.NormalBlending, opacity: 0 });
    const sp = new THREE.Sprite(m);
    sp.userData.omur = -1;
    return nesneEkle(s, sp);
  }
  function yanginSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      s.senaryo = senaryo(ITFAIYE_SENARYOLARI, olay);
      const hedefX = olayX(olay, 20);
      // ana caddede, olay noktasına en yakın, en az 2 katlı bina
      const binalar = (c.dukkanlar() || []).filter((d) => d.sira === 0 && d.veri && (d.veri.kat || 0) >= 2);
      binalar.sort((a, b) => Math.abs(a.merkezX - hedefX) - Math.abs(b.merkezX - hedefX));
      const d = binalar[0];
      const kat = d ? Math.min(3, 1 + (olay.tohum % Math.max(1, Math.min(3, d.veri.kat - 1)))) : 2;
      const fx = d ? d.merkezX + (((olay.tohum >> 3) % 3) - 1) * Math.min(2.6, (d.veri.genislik || 10) * 0.25) : hedefX;
      const fy = 4.0 + kat * 2.95 - 1.45;
      const fz = -8.2 + 0.25;
      s.ates = 1;
      s.duman = 1;
      // turuncu titrek ışık
      const isik = nesneEkle(s, new THREE.PointLight('#FF7A1A', 0, 14, 1.6));
      isik.position.set(fx, fy, fz + 1.2);
      const alevler = [], dumanlar = [], sular = [];
      for (let i = 0; i < 14; i++) alevler.push(parcacik(s, 'rgba(255,150,40,1)', true));
      for (let i = 0; i < 26; i++) dumanlar.push(parcacik(s, 'rgba(70,70,74,0.9)', false));
      for (let i = 0; i < 40; i++) sular.push(parcacik(s, 'rgba(220,240,255,0.9)', false));
      // kaldırımda seyirciler, biri telefonla arar
      for (let i = 0; i < 4; i++) {
        const bx = fx + rnd(-4, 4), bz = rnd(-3.2, -1.6);
        const g = kisi('yaya', bx + (i % 2 ? -12 : 12), -0.95, 0);
        s.kisiler.push(g);
        yap(g, { bekle: 1 + i * 0.8 }, { yuru: [bx, bz] }, { yap: (k) => { k.bosAnim = i === 0 ? 'Idle_Talking_Loop' : 'Idle_Loop'; k.g.rotation.y = Math.PI; if (i === 0) { kisiyeBalon(k, s.senaryo.seyirci, 3.2, 'uyari'); setTimeout(() => { if (k.g.parent) kisiyeBalon(k, 'Yangın var! İtfaiyeyi arayın!', 3, 'uyari'); }, 3400); } } });
        (s.kalabalik = s.kalabalik || []).push(g);
      }
      s.cagri = katilimDugmesi(s, _autoMetin('📞 110 İtfaiye’yi ara'), fx, fy + 1.6, fz + 1, () => { s.cagrildi = true; });
      s.adim = (dt, t) => {
        // itfaiye: çağrılırsa hemen, çağrılmazsa biraz sonra (başka biri arar) yola çıkar
        if (!s.itfaiye && (s.t > 12 || (s.cagrildi && s.t > 3))) {
          s.itfaiye = aracGetir(s, 'itfaiye', 'kuzey', fx + 4, { siren: 'itfaiye', vardi: (a) => { if (s.cagri) balonSil(s.cagri); itfaiyeIner(s, a, fx, fy, fz); } });
        }
        if (s.sondur) { s.ates = Math.max(0, s.ates - dt / 14); if (s.ates <= 0) s.duman = Math.max(0, s.duman - dt / 16); }
        isik.intensity = s.ates * (22 + Math.sin(t * 17) * 6 + Math.sin(t * 7.3) * 5);
        const ol = (sp, omur, x, y, z) => { sp.userData.omur = omur; sp.userData.yas = 0; sp.position.set(x, y, z); };
        for (const a of alevler) {
          const u = a.userData;
          if (u.omur < 0 || u.yas > u.omur) { if (s.ates > 0.05) ol(a, rnd(0.5, 0.9), fx + rnd(-0.6, 0.6), fy - 0.5, fz + rnd(0, 0.3)); else { a.material.opacity = 0; continue; } }
          u.yas += dt;
          const k = u.yas / u.omur;
          a.position.y += dt * 1.6;
          a.position.x += Math.sin(t * 5 + a.id) * dt * 0.3;
          a.scale.setScalar((1.1 - k * 0.6) * (0.7 + s.ates * 0.6));
          a.material.opacity = Math.sin(k * Math.PI) * 0.9 * s.ates;
          a.material.color.setHSL(0.08 - k * 0.06, 1, 0.55);
        }
        for (const m of dumanlar) {
          const u = m.userData;
          if (u.omur < 0 || u.yas > u.omur) { if (s.duman > 0.03) ol(m, rnd(4, 7), fx + rnd(-0.5, 0.5), fy + 0.2, fz + rnd(0.1, 0.5)); else { m.material.opacity = 0; continue; } }
          u.yas += dt;
          const k = u.yas / u.omur;
          m.position.y += dt * (1.1 + k * 0.6);
          m.position.x += dt * 0.35; // hafif rüzgâr
          m.position.z += dt * 0.25;
          m.scale.setScalar(1 + k * 4.5);
          const koyu = s.sondur ? 0.55 : 0.28; // su değince duman açılır (buhar)
          m.material.color.setScalar(koyu + k * 0.25);
          m.material.opacity = Math.min(1, k * 6) * (1 - k) * 0.75 * s.duman;
        }
        if (s.hortum) {
          const [nx, ny, nz] = s.hortum;
          for (const w of sular) {
            const u = w.userData;
            if (u.omur < 0 || u.yas > u.omur) { if (s.duman > 0.1) ol(w, 0.9, nx, ny, nz); else { w.material.opacity = 0; continue; } u.yas = Math.random() * 0.9; }
            u.yas += dt;
            const k = Math.min(1, u.yas / u.omur);
            w.position.set(nx + (fx - nx) * k + rnd(-0.05, 0.05), ny + (fy - ny) * k + Math.sin(k * Math.PI) * 2.2, nz + (fz + 0.3 - nz) * k);
            w.scale.setScalar(0.18 + k * 0.35);
            w.material.opacity = 0.75 * (1 - k * 0.5);
          }
        }
        if (s.duman <= 0 && s.itfaiye && !s.toplandi) {
          s.toplandi = true;
          for (const k of s.ekip || []) yap(k, { yap: () => { if (k === s.ekip[0]) kisiyeBalon(k, 'Yangın söndü, herkes güvende!', 3, 'iyi'); } }, { bekle: 2 });
          let binen = 0;
          for (const k of s.ekip || []) { k.is = k.is.filter((x) => x.bekle === undefined || x.bekle < 30); arabayaBin(k, s.itfaiye, () => { if (++binen >= s.ekip.length) aracGonder(s.itfaiye, true); }); }
          for (const g of s.kalabalik || []) yap(g, { bekle: rnd(1, 4) }, { yap: (k) => { k.bosAnim = null; } }, { yuru: [g.g.position.x + (Math.random() < 0.5 ? -14 : 14), -0.95] }, { yap: kisiSil });
        }
      };
    });
  }
  function itfaiyeIner(s, a, fx, fy, fz) {
    // şoför solda, iki itfaiyeci sağ kapıdan sırayla iner (kabinden basamakla)
    s.ekip = aractanIn(s, a, 'itfaiye', 3, { bekle: 0.3 });
    const [h1, h2, h3] = s.ekip;
    // iki itfaiyeci hortumu tutar, biri halkı uzak tutar
    yap(h1, { yuru: [fx - 0.6, -4.2] }, { bekle: 0.4, bak: Math.PI }, { yap: () => { s.hortum = [fx - 0.6, 1.5, -4.6]; s.sondur = true; kisiyeBalon(h1, s.senaryo.h1[0], 2.4); setTimeout(() => { if (h1.g.parent) kisiyeBalon(h1, s.senaryo.h1[1], 2.4); }, 4200); setTimeout(() => { if (h1.g.parent) kisiyeBalon(h1, 'Yangın söndü, herkes güvende!', 3, 'iyi'); }, 15500); } }, { bekle: 60, anim: 'Interact', bak: Math.PI });
    yap(h2, { yuru: [fx + 0.2, -3.6] }, { bekle: 60, anim: 'Interact', bak: Math.PI });
    yap(h3, { yuru: [fx + 3, -2.2] }, { yap: () => { kisiyeBalon(h3, s.senaryo.h3[0], 3); setTimeout(() => { if (h3.g.parent) kisiyeBalon(h3, s.senaryo.h3[1], 3); }, 3600); } }, { bekle: 60, anim: 'Idle_Talking_Loop', bak: 0 });
  }

  // ------------------------------------------------ 6c. Gece hayatı (22:00–04:00)
  // Barın, diskonun ya da gece kulübünün önünde kuyruk ve kapıda fedai; sarı taksiler müşteri indirip bindirir;
  // parka yakın kaldırımda gece kokoreççisi, etrafında karnını doyuran gece kuşları. Sunucudan bağımsızdır, saate bağlıdır.
  const GECE_TURLERI = new Set(['bar', 'disko', 'gece_kulubu']);
  const GECE_SOZLERI = [_autoMetin('Sıra ne zaman gelecek?'), _autoMetin('Bu gece DJ kim?'), _autoMetin('İçerisi dolu mu?'), _autoMetin('Arkadaşlar geliyor'), _autoMetin('Müzik harika!')];
  const FEDAI_SOZLERI = [_autoMetin('Liste dışı giriş yok.'), _autoMetin('Sırayla lütfen.'), _autoMetin('Buyurun, iyi eğlenceler.'), _autoMetin('İki kişi daha alıyorum.')];
  const KOKOREC_SOZLERI = [_autoMetin('Yarım, bol baharatlı!'), _autoMetin('Çeyrek alayım usta'), _autoMetin('Gecenin en güzeli!'), _autoMetin('Bir ayran da ver')];
  function geceMi() { const h = c.saat ? c.saat() % 24 : 12; return h >= 22 || h < 4; }
  function geceBitisMs() {
    const h = c.saat ? c.saat() % 24 : 23;
    const kalan = h >= 22 ? 24 - h + 4 : 4 - h;
    return simdi() + kalan * 3600000;
  }
  function geceSahnesi() {
    return sahneBaslat({ tur: 'gece', id: 'gece:' + Date.now(), bas: simdi(), bit: geceBitisMs(), katildi: true }, (s) => {
      const { XB, XD } = c.sinirlar();
      // gece kokoreççisi
      const kx = XB + 8, kz = 10.9;
      const tezgah = nesneEkle(s, tezgahModeli('kokorec'));
      tezgah.position.set(kx, KALDIRIM_Y, kz);
      tezgah.rotation.y = Math.PI; // yüzü yola
      const isik = nesneEkle(s, new THREE.PointLight('#FFB060', 9, 9, 1.8));
      isik.position.set(kx, 2.3, kz - 0.4);
      const usta = kisi('yaya', kx, kz + 0.7, Math.PI);
      usta.bosAnim = 'Interact';
      s.kisiler.push(usta);
      s.kokorec = { x: kx, z: kz, musteriler: [], sonGelen: 0 };
      // gece mekânı: caddede açık bir bar / disko / gece kulübü varsa önünde kuyruk ve fedai
      const mekan = (c.dukkanlar() || []).find((d) => d.sira === 0 && d.veri && d.veri.isletme && GECE_TURLERI.has(d.veri.isletme.tur) && !d.kapali && d.veri.isletme.durum === 'acik');
      if (mekan) {
        const kapiX = mekan.merkezX, kapiZ = mekan.onZ + mekan.yon * 0.9;
        const fedai = kisi('fedai', kapiX + 1.1, kapiZ + 0.3, 0);
        fedai.bosAnim = 'Idle_Loop';
        s.kisiler.push(fedai);
        s.mekan = { x: kapiX, z: kapiZ, fedai, kuyruk: [], sonGiris: 0, sonGelen: 0 };
        for (let i = 0; i < 4 + Math.floor(Math.random() * 3); i++) kuyrugaEkle(s, true);
      }
      s.sonTaksi = -20;
      s.adim = (dt, t) => {
        if (!geceMi()) { s.bitsin = true; for (const k of s.kisiler) k.g.visible = false; return; }
        isik.intensity = 8 + Math.sin(t * 13) * 1.2 + Math.sin(t * 5.1) * 0.8;
        // kokoreç müşterileri gelir, yer, gider
        const ko = s.kokorec;
        ko.musteriler = ko.musteriler.filter((k) => k.g.parent);
        if (ko.musteriler.length < 3 && t - ko.sonGelen > rnd(6, 14)) {
          ko.sonGelen = t;
          const sag = Math.random() < 0.5;
          const bx = ko.x + rnd(-1.4, 1.4), bz = ko.z - rnd(1.0, 1.6);
          const m = kisi('yaya', ko.x + (sag ? 16 : -16), -0.95 + (Math.random() < 0.5 ? 0 : 10.9), 0);
          s.kisiler.push(m);
          ko.musteriler.push(m);
          yap(m, { yuru: [bx, bz] }, { bak: bakis(bx, bz, ko.x, ko.z), bekle: 1 }, { yap: (k) => kisiyeBalon(k, sec(KOKOREC_SOZLERI), 2.5) },
            { bekle: rnd(6, 10), anim: 'Interact', bak: bakis(bx, bz, ko.x, ko.z) }, { yuru: [bx + (sag ? -18 : 18), bz + rnd(-0.4, 0.4)] }, { yap: kisiSil });
        }
        // mekân kuyruğu: fedai sırayla içeri alır, yenileri gelir
        const me = s.mekan;
        if (me) {
          me.kuyruk = me.kuyruk.filter((k) => k.g.parent);
          if (t - me.sonGiris > rnd(14, 24) && me.kuyruk.length) {
            me.sonGiris = t;
            const ilk = me.kuyruk.shift();
            kisiyeBalon(me.fedai, sec(FEDAI_SOZLERI), 2.2);
            yap(ilk, { yuru: [me.x, me.z] }, { yuru: [me.x, me.z - (me.z > 0 ? -1 : 1) * 1.2] }, { yap: (k) => { kisiSil(k); } });
            kuyruguKaydir(me);
          }
          if (me.kuyruk.length < 6 && t - me.sonGelen > rnd(10, 20)) { me.sonGelen = t; kuyrugaEkle(s, false); }
          if (Math.random() < dt * 0.05 && me.kuyruk.length) kisiyeBalon(sec(me.kuyruk), sec(GECE_SOZLERI), 2.5);
        }
        // sarı taksiler: yolcu indirip bindirir
        if (t - s.sonTaksi > rnd(28, 55) && s.araclar.filter((a) => a.tur === 'taksi').length < 2) {
          s.sonTaksi = t;
          const hedefX = me ? me.x - 3 : rnd(XB + 20, XD - 20);
          const tk = aracGetir(s, 'taksi', 'kuzey', hedefX, { acil: false, vardi: (a) => taksiVardi(s, a) });
          tk.g.userData.azami = 10;
        }
      };
    });
  }
  function kuyrukYeri(me, i) { return [me.x - 1.1 - i * 0.75, me.z + (me.z < 0 ? 0.9 : -0.9)]; }
  function kuyrugaEkle(s, hemen) {
    const me = s.mekan;
    const [hx, hz] = kuyrukYeri(me, me.kuyruk.length);
    const k = kisi('yaya', hemen ? hx : hx - 14, hemen ? hz : -0.95, Math.PI / 2);
    s.kisiler.push(k);
    me.kuyruk.push(k);
    k.bosAnim = Math.random() < 0.5 ? 'Idle_Talking_Loop' : 'Idle_Loop';
    if (!hemen) yap(k, { yuru: [hx, hz] }, { bak: Math.PI / 2, bekle: 0.3 });
    else k.g.rotation.y = Math.PI / 2;
  }
  function kuyruguKaydir(me) {
    me.kuyruk.forEach((k, i) => { const [hx, hz] = kuyrukYeri(me, i); yap(k, { yuru: [hx, hz], hiz: 0.8 }, { bak: Math.PI / 2, bekle: 0.2 }); });
  }
  function taksiVardi(s, a) {
    // biri iner (mekâna ya da eve gider), bazen biri biner
    // yolcu arka sağ kapıdan iner (taksici arabadan inmez)
    const [inen] = aractanIn(s, a, 'yaya', 1, { bekle: 0.6, ilk: 2 });
    const [kx] = disNokta(a, inen.koltuk);
    if (s.mekan && Math.random() < 0.7) {
      const me = s.mekan;
      const [hx, hz] = kuyrukYeri(me, me.kuyruk.length);
      me.kuyruk.push(inen);
      yap(inen, { yuru: [kx, -0.95] }, { yuru: [hx, hz] }, { bak: Math.PI / 2, bekle: 0.2 });
      inen.bosAnim = 'Idle_Talking_Loop';
    } else yap(inen, { yuru: [kx, -0.95] }, { yuru: [kx + (Math.random() < 0.5 ? -20 : 20), -0.95] }, { yap: kisiSil });
    const binecek = Math.random() < 0.5;
    if (binecek) {
      const b = kisi('yaya', kx - 8, -0.95, Math.PI / 2);
      s.kisiler.push(b);
      yap(b, { bekle: 1.5 });
      arabayaBin(b, a, () => aracGonder(a), koltukSec(a, 2));
    } else setTimeout(() => aracGonder(a), 3500);
  }
  function geceKontrol() {
    if (!c.kuruldu() || !geceMi()) return;
    if (sahneler.some((x) => !x.bitti && x.olay.tur === 'gece')) return;
    try { geceSahnesi(); } catch (e) { console.warn('Gece sahnesi kurulamadı', e); }
  }

  // ------------------------------------------------ 7. Sokak müzisyenleri
  // Beş kişilik takım (gitar, keman, org, darbuka, klarnet): güney sırasındaki son tezgâhın sağında sabit yerleri
  // vardır, tezgâhların önünde görünürler. Her gün 13.00'ten 23.00'e iki saatte bir gelip 5 dakika çalarlar.
  function muzisyenSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const yer = c.muzisyenYeri ? c.muzisyenYeri() : null;
      const x = yer ? yer.x : olayX(olay, 25);
      const z = yer ? yer.z : 13.0;
      const hali = nesneEkle(s, new THREE.Mesh(new THREE.PlaneGeometry(6.4, 2.2), sokakKilimi()));
      hali.rotation.x = -Math.PI / 2;
      hali.position.set(x, KALDIRIM_Y + 0.015, z);
      const oturan = (dx, dz, aci) => {
        const t = nesneEkle(s, tabure());
        t.position.set(x + dx, KALDIRIM_Y, z + dz);
        const k = kisi('yaya', x + dx, z + dz - 0.05, aci);
        k.g.position.y = KALDIRIM_Y + 0.05;
        k.bosAnim = 'Sitting_Idle_Loop';
        s.kisiler.push(k);
        return k;
      };
      const ayakta = (dx, dz, aci) => {
        const k = kisi('yaya', x + dx, z + dz, aci);
        k.bosAnim = 'Idle_Loop';
        s.kisiler.push(k);
        return k;
      };
      // soldan sağa: gitar (oturur), keman, org (arkada ortada), klarnet, darbuka (oturur)
      const mg = oturan(-2.3, 0.1, 0.25);
      const gitar = gitarModeli();
      gitar.position.set(0.04, 0.66, 0.26);
      gitar.rotation.set(0.15, 0.1, -1.15);
      mg.g.add(gitar);
      const mk = ayakta(-1.2, 0.25, 0.1);
      const keman = kemanModeli();
      keman.position.set(-0.13, 1.36, 0.16);
      keman.rotation.set(-1.25, 0.2, 0.55);
      mk.g.add(keman);
      const org = nesneEkle(s, orgModeli());
      org.position.set(x, KALDIRIM_Y, z - 0.05);
      const mo = ayakta(0, -0.55, 0);
      const mkl = ayakta(1.2, 0.25, -0.1);
      const klarnet = klarnetModeli();
      klarnet.position.set(0, 0.95, 0.3);
      klarnet.rotation.set(0.42, 0, 0);
      mkl.g.add(klarnet);
      const md = oturan(2.3, 0.1, -0.25);
      const darbuka = darbukaModeli();
      darbuka.position.set(0, 0.52, 0.3);
      darbuka.rotation.set(-1.05, 0, 0);
      darbuka.scale.setScalar(0.95);
      md.g.add(darbuka);
      s.muzisyenler = [mg, mk, mo, mkl, md];
      for (const k of s.muzisyenler) k.sabit = true;
      // halı sahnesi yürüyenler için engel
      s.engel = kalabalik.engelEkle(x, z, 6.2, 2.0);
      const eskiSon = () => kalabalik.engelSil(s.engel);
      // bahşiş kutusu: halının önünde açık gitar kutusu; içinde biriken paralar ve küçük bir tabela
      s.konum = { x, z };
      const kx = x - 0.5, kz = z + 1.55;
      const kasa = new THREE.Group();
      const deri = new THREE.MeshStandardMaterial({ color: '#2B1D14', roughness: 0.55, metalness: 0.05 });
      const kadife = new THREE.MeshStandardMaterial({ color: '#8E1330', roughness: 0.95 });
      const govdeSekli = new THREE.Shape();
      // gitar gövdesi biçiminde taban (iki yuvarlak ve sap)
      govdeSekli.absellipse(0.3, 0, 0.3, 0.24, 0, Math.PI * 2);
      const tabanG = new THREE.Mesh(new THREE.ExtrudeGeometry(govdeSekli, { depth: 0.1, bevelEnabled: false }), deri);
      tabanG.rotation.x = -Math.PI / 2;
      kasa.add(tabanG);
      const ust = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.19, 0.1, 20), deri);
      ust.position.set(-0.12, 0.05, 0); kasa.add(ust);
      const sap = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.1, 0.12), deri);
      sap.position.set(-0.55, 0.05, 0); kasa.add(sap);
      const ic1 = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.012, 24), kadife);
      ic1.scale.set(1.1, 1, 0.85); ic1.position.set(0.3, 0.1, 0); kasa.add(ic1);
      const ic2 = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.012, 20), kadife);
      ic2.position.set(-0.12, 0.1, 0); kasa.add(ic2);
      // açık kapak arkada dik durur
      const kapak = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 0.5), deri);
      kapak.position.set(0, 0.2, -0.27); kapak.rotation.x = -1.35; kasa.add(kapak);
      // tabela: "BAHŞİŞ" (kapağın iç yüzünde)
      const tuval = document.createElement('canvas'); tuval.width = 256; tuval.height = 96;
      const tc = tuval.getContext('2d');
      tc.fillStyle = '#F4E7C8'; tc.fillRect(0, 0, 256, 96);
      tc.strokeStyle = '#8E1330'; tc.lineWidth = 6; tc.strokeRect(5, 5, 246, 86);
      tc.fillStyle = '#2B1D14'; tc.font = 'bold 40px system-ui, sans-serif'; tc.textAlign = 'center'; tc.textBaseline = 'middle';
      tc.fillText('♪ BAHŞİŞ ♪', 128, 50);
      const tabela = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.23), new THREE.MeshStandardMaterial({ map: new THREE.CanvasTexture(tuval), roughness: 0.8 }));
      tabela.position.set(0.05, 0.29, -0.23); tabela.rotation.x = -0.22; kasa.add(tabela);
      kasa.position.set(kx, KALDIRIM_Y + 0.005, kz);
      kasa.scale.setScalar(1.45);
      nesneEkle(s, kasa);
      // biriken paralar
      const paraMat = new THREE.MeshStandardMaterial({ color: '#E0B53C', roughness: 0.35, metalness: 0.8 });
      const kagitMat = new THREE.MeshStandardMaterial({ color: '#7FB08A', roughness: 0.9 });
      const paraGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.008, 12);
      const kagitGeo = new THREE.BoxGeometry(0.13, 0.004, 0.065);
      const paraKoy = (kagit = false) => {
        const m = new THREE.Mesh(kagit ? kagitGeo : paraGeo, kagit ? kagitMat : paraMat);
        const a = Math.random() * Math.PI * 2, r = Math.sqrt(Math.random());
        m.position.set(0.3 + Math.cos(a) * 0.22 * r, 0.112 + Math.random() * 0.01, Math.sin(a) * 0.17 * r);
        m.rotation.set((Math.random() - 0.5) * 0.3, Math.random() * Math.PI, (Math.random() - 0.5) * 0.3);
        kasa.add(m);
        return m;
      };
      for (let i = 0; i < 6; i++) paraKoy(i % 3 === 0);
      const ucanlar = [];
      const paraAt = (ex, ey, ez, kagit) => {
        const m = new THREE.Mesh(kagit ? kagitGeo : paraGeo, kagit ? kagitMat : paraMat);
        m.position.set(ex, ey, ez);
        c.sahne.add(m); s.nesneler.push(m);
        ucanlar.push({ m, t: 0, bas: new THREE.Vector3(ex, ey, ez), son: new THREE.Vector3(kx + 0.43 + (Math.random() - 0.5) * 0.35, KALDIRIM_Y + 0.17, kz + (Math.random() - 0.5) * 0.28), kagit });
      };
      // yoldan geçenler ara ara durup kutuya para atar
      s.gecenZaman = 4 + Math.random() * 5;
      const gecenGelsin = () => {
        const soldan = Math.random() < 0.5;
        const serit = kz + 1.5 + Math.random() * 0.5;
        const k = kisi('yaya', x + (soldan ? -16 : 16), serit, soldan ? Math.PI / 2 : -Math.PI / 2);
        k.hiz = 1.1 + Math.random() * 0.3;
        s.kisiler.push(k);
        const durX = kx + 0.43 + (Math.random() - 0.5) * 0.5;
        yap(k,
          { yuru: [durX, kz + 0.95] },
          { bekle: 0.9, bak: Math.PI, anim: 'Idle_Loop' },
          { yap: (kk) => {
            const kagit = Math.random() < 0.25;
            paraAt(kk.g.position.x, KALDIRIM_Y + 0.95, kk.g.position.z - 0.25, kagit);
            const kam = c.kamera();
            if (Math.hypot(kx - kam.x, kz - kam.z) < 45) ses.sikke();
            if (Math.random() < 0.55) kisiyeBalon(kk, sec([_autoMetin('Yüreğinize sağlık 👏'), _autoMetin('Çok güzel çalıyorsunuz'), 'Bravo!', _autoMetin('Bir parça daha!'), _autoMetin('Kemanın sesi harika'), 'Gitar solo nefisti', _autoMetin('Mahalleye renk kattınız'), _autoMetin('Şarkıyı çok sevdim'), _autoMetin('Darbukaya bayıldım'), _autoMetin('Alkışlar size!')]), 2.2);
          } },
          { bekle: 0.8, bak: Math.PI, anim: 'Idle_Loop' },
          { yuru: [x + (soldan ? 18 : -18), serit] },
          { yap: (kk) => { kisiSil(kk); s.kisiler = s.kisiler.filter((y) => y !== kk); } });
      };
      katilimDugmesi(s, _autoMetin('🎻 Bahşiş ver (50 ₺)'), x, 0.3, z + 2.4, (r) => {
        paraAt(kx + 0.43, KALDIRIM_Y + 1.3, kz + 1.0, true);
        s.coskulu = 30;
        const ad = r && r.ad ? r.ad : 'sizin';
        kisiyeBalon(mo, `🎤 Sıradaki şarkı ${ad} için geliyor!`, 6, 'iyi');
        // çalan parça kısılıp biter, orgcu mikrofona anons eder, sonra yeni parça başlar
        if (s.calar) s.calar.sonrakine(() => ses.duyuru(r && r.ad ? _autoSablon`Sıradaki şarkı, ${r.ad} için geliyor!` : _autoMetin('Sıradaki şarkı sizin için geliyor!')));
      },
        { metin: _autoMetin('Bahşiş verme'), fn: () => kisiyeBalon(mo, sec([_autoMetin('Dinlediğiniz için teşekkürler 🙂'), _autoMetin('Müzik paylaştıkça güzel 🎶'), _autoMetin('Bir sonraki şarkıda yine bekleriz!'), _autoMetin('Alkışınız bize yeter 👏'), _autoMetin('Mahallenin sesi olmak güzel'), _autoMetin('Güzel dilekleriniz için sağ olun'), _autoMetin('Şarkılarımız herkese açık'), _autoMetin('Biraz durun, güzel bir parça geliyor')]), 3) });
      // gerçek eserler çalar (web/ses/muzisyen); her gelişte sıra baştan karıştırılır, parça değişince adı balonda görünür
      s.calar = ses.muzisyenBaslat({ parcaDegisti: (p) => { s.parca = p; s.parcaBalonu = true; } });
      s.paraAdim = (dt) => {
        for (let i = ucanlar.length - 1; i >= 0; i--) {
          const u = ucanlar[i];
          u.t = Math.min(1, u.t + dt / (u.kagit ? 0.9 : 0.5));
          u.m.position.lerpVectors(u.bas, u.son, u.t);
          u.m.position.y += Math.sin(u.t * Math.PI) * (u.kagit ? 0.15 : 0.35);
          u.m.rotation.x += dt * (u.kagit ? 4 : 14);
          u.m.rotation.z += dt * (u.kagit ? 3 : 0);
          if (u.t >= 1) {
            ucanlar.splice(i, 1);
            c.sahne.remove(u.m);
            // kutuya düşen para orada kalır (en çok 60 tane birikir)
            if (kasa.children.length < 80) paraKoy(u.kagit);
          }
        }
        if (s.olay.bit && simdi() > s.olay.bit - 20000) return; // bitmeye yakın yeni kişi gelmez
        s.gecenZaman -= dt;
        if (s.gecenZaman <= 0) {
          s.gecenZaman = 7 + Math.random() * 9;
          const kam = c.kamera();
          if (Math.hypot(x - kam.x, z - kam.z) < 70 && s.kisiler.length < s.muzisyenler.length + 3) gecenGelsin();
        }
      };
      s.son = () => { if (s.calar) s.calar.durdur(); s.calar = null; eskiSon(); };
      const cal = (k) => (s.calar ? s.calar.caliyor(k) : true);
      s.adim = (dt, tt) => {
        s.paraAdim(dt);
        const kam = c.kamera();
        const uz = Math.hypot(x - kam.x, z - kam.z);
        const guc = Math.max(0, 1 - uz / 70) * Math.max(0.3, 1 - kam.mesafe / 160) * (s.coskulu > 0 ? 1.25 : 1);
        if (s.calar) s.calar.ayarla(guc, (x - kam.x) / 30);
        if (s.parcaBalonu && uz < 60 && s.parca) {
          s.parcaBalonu = false;
          kisiyeBalon(mo, `🎵 ${s.parca.ad} · ${s.parca.yazar}`, 5, 'nota');
        }
        if (tt - (s.sonNota || -9) > 2.1) {
          s.sonNota = tt;
          if (uz < 60) noktayaBalon(s, s.coskulu > 0 ? '🎶🎶' : '🎵', x + rnd(-2.2, 2.2), 2.4, z, { sure: 1.6, tur: 'nota' });
        }
        if (s.coskulu > 0) s.coskulu -= dt;
        // her çalgı çalarken canlanır
        gitar.rotation.z = -1.15 + (cal('gitar') ? Math.sin(tt * 8) * 0.04 : 0);
        keman.userData.yay.position.x = 0.02 + (cal('keman') ? Math.sin(tt * 3.2) * 0.14 : 0);
        mk.g.rotation.z = cal('keman') ? Math.sin(tt * 1.3) * 0.04 : 0;
        mkl.g.rotation.x = cal('klarnet') ? Math.sin(tt * 1.6) * 0.035 : 0;
        klarnet.rotation.x = 0.42 + (cal('klarnet') ? Math.sin(tt * 2.1) * 0.06 : 0);
        mo.g.position.y = KALDIRIM_Y + (cal('org') ? Math.abs(Math.sin(tt * 2.4)) * 0.025 : 0);
        const dv = s.calar ? s.calar.sonVurus('darbuka') : 9;
        const vur = dv < 0.12 ? 1 - dv / 0.12 : 0;
        darbuka.userData.deri.scale.setScalar(1 + vur * 0.06);
        md.g.rotation.x = vur * 0.05;
      };
    });
  }

  // ------------------------------------------------ 8. Sokak kedisi
  function kediSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const x = olayX(olay, 20);
      const kuzey = olay.tohum % 2 === 0;
      const z = kuzey ? -1.0 : 11.8;
      const kedi = nesneEkle(s, kediModeli(sec(['#E8A33D', '#3A3A3A', '#F4F1EA', '#8C6A3E', '#B0B0B0'])));
      kedi.position.set(x, KALDIRIM_Y, z);
      s.kedi = { g: kedi, hedef: [x, z], bekle: 0, yiyor: 0, sonMiyav: 0 };
      // miyavlama seyrek: en az 15 sn arayla; beslendikten sonra en çok bir kez daha (toplam 1-2) ve kedi en geç 1 dakikada gider
      const miyavla = (t) => {
        const k = s.kedi;
        if (k.beslendi ? k.miyavHakki <= 0 : t - k.sonMiyav < 15) return;
        if (!c.yakin(k.g.position.x, k.g.position.z, 20)) return;
        k.sonMiyav = t;
        if (k.beslendi) k.miyavHakki--;
        ses.miyav(Math.max(-1, Math.min(1, (k.g.position.x - c.kamera().x) / 20)));
      };
      s.miyavla = miyavla;
      ses.kediSesleriniYukle();
      const b = katilimDugmesi(s, '🐱 Kediyi besle (20 ₺)', x, 1.0, z, kediBesle, { metin: _autoMetin('👋 Kediyi kov'), fn: () => {
        // kedi kaçar: hızla sokağın ucuna koşar ve kaybolur
        ses.miyav(Math.max(-1, Math.min(1, (s.kedi.g.position.x - c.kamera().x) / 20)));
        s.kedi.kacis = true;
        s.kedi.hedef = [s.kedi.g.position.x + (Math.random() < 0.5 ? -30 : 30), z];
      } });
      function kediBesle() {
        if (s.kedi.beslendi) return;
        s.kedi.beslendi = true;
        s.kedi.miyavHakki = 1; // yemekten sonra en çok bir teşekkür miyavı
        s.kedi.yiyor = 12;
        const kap = nesneEkle(s, new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.11, 0.07, 14), new THREE.MeshStandardMaterial({ color: '#2F80D1', roughness: 0.4 })));
        kap.position.set(kedi.position.x + 0.4, KALDIRIM_Y + 0.035, kedi.position.z);
        s.kedi.hedef = [kap.position.x - 0.32, kap.position.z];
        ses.miyav();
        noktayaBalon(s, _autoMetin('😻 Mırr…'), kedi.position.x, 0.9, kedi.position.z, { sure: 3, tur: 'iyi' });
      }
      if (b) b.takip = kedi;
      s.adim = (dt, t) => {
        const k = s.kedi;
        const g = k.g;
        const [hx, hz] = k.hedef;
        const dx = hx - g.position.x;
        const dz = hz - g.position.z;
        const d = Math.hypot(dx, dz);
        if (k.kacis) {
          // kovulan kedi koşarak uzaklaşır, gözden kaybolunca sahne biter
          if (d < 0.2) { g.visible = false; s.bitsin = true; return; }
          const hz2 = k.hiz || 4.5;
          g.position.x += (dx / d) * Math.min(d, dt * hz2);
          g.position.z += (dz / d) * Math.min(d, dt * hz2);
          g.rotation.y = Math.atan2(-dz, dx);
          g.position.y = KALDIRIM_Y + Math.abs(Math.sin(t * (hz2 > 2 ? 18 : 10))) * (hz2 > 2 ? 0.05 : 0.02);
          return;
        }
        if (k.yiyor > 0) {
          k.yiyor -= dt;
          if (k.yiyor <= 0) {
            // karnı doydu: bir kez teşekkür eder, sonra sokağın ucuna doğru yürüyüp gider (1 dakikadan kısa sürer)
            if (Math.random() < 0.6) s.miyavla(t);
            k.kacis = true;
            k.hiz = 1.4;
            k.hedef = [g.position.x + (g.position.x < 0 ? -34 : 34), z];
            return;
          }
          if (d > 0.05) { g.position.x += (dx / d) * Math.min(d, dt * 0.8); g.position.z += (dz / d) * Math.min(d, dt * 0.8); }
          g.rotation.y = 0;
          g.position.y = KALDIRIM_Y + Math.abs(Math.sin(t * 6)) * 0.01;
        } else if (d < 0.05) {
          k.bekle -= dt;
          if (k.bekle <= 0) {
            k.hedef = [Math.max(x - 6, Math.min(x + 6, g.position.x + rnd(-3, 3))), z + rnd(-0.4, 0.4)];
            k.bekle = rnd(2, 5);
            if (!k.beslendi && Math.random() < 0.3) s.miyavla(t);
          }
        } else {
          g.position.x += (dx / d) * Math.min(d, dt * 0.7);
          g.position.z += (dz / d) * Math.min(d, dt * 0.7);
          g.rotation.y = Math.atan2(-dz, dx);
          g.position.y = KALDIRIM_Y + Math.abs(Math.sin(t * 10)) * 0.02;
        }
        g.traverse((o) => { if (o.userData.salla !== undefined) o.rotation.x = Math.sin(t * 3) * 0.4; });
        for (const bb of s.balonlar) if (bb.takip) { bb.x = g.position.x; bb.z = g.position.z; }
      };
    });
  }

  // ------------------------------------------------ 9. Düşürülen cüzdan
  function cuzdanSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const x = olayX(olay, 20);
      const z = -0.35;
      const sahip = kisi('yaya', x - 12, z, Math.PI / 2);
      s.kisiler.push(sahip);
      yap(sahip, { yuru: [x, z] }, {
        yap: () => {
          const cz = nesneEkle(s, cuzdanModeli());
          cz.position.set(x, KALDIRIM_Y, z + 0.15);
          cz.rotation.y = 0.6;
          s.cuzdan = cz;
          const isaret = nesneEkle(s, new THREE.Mesh(new THREE.RingGeometry(0.22, 0.28, 24), new THREE.MeshBasicMaterial({ color: '#FFD60A', transparent: true, opacity: 0.8, depthWrite: false })));
          isaret.rotation.x = -Math.PI / 2;
          isaret.position.set(x, KALDIRIM_Y + 0.01, z + 0.15);
          s.isaret = isaret;
          katilimDugmesi(s, _autoMetin('👛 Cüzdan düşmüş! Sahibine ver'), x, 1.0, z + 0.15, () => {
            // sahibi geri döner, teşekkür eder
            sahip.is = [];
            yap(sahip, { yuru: [x + 0.7, z + 0.1], hiz: 2.2 }, { yap: () => { kisiyeBalon(sahip, '🙏 ' + sec(TESEKKUR), 3.5, 'iyi'); if (s.cuzdan) { s.cuzdan.visible = false; s.isaret.visible = false; } } },
              { bekle: 2, anim: 'Interact', bak: -Math.PI / 2 }, { yuru: [x + 25, z] }, { yap: kisiSil });
          });
        },
      }, { yuru: [x + 25, z] }, { yap: (k) => { kisiSil(k); } });
      s.adim = (dt, t) => { if (s.isaret) s.isaret.material.opacity = 0.45 + Math.sin(t * 5) * 0.35; };
    });
  }

  // ------------------------------------------------ 10. Kurye dükkâna paket bırakır
  function kuryeSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const d = c.dukkanlar().filter((x) => x.sira === 0 && x.veri && x.veri.isletme);
      const hedef = d.length ? d[olay.tohum % d.length] : null;
      const x = hedef ? hedef.merkezX : olayX(olay);
      const arac = aracGetir(s, 'kurye', 'kuzey', x, {
        acil: false,
        vardi: (a) => {
          const k = kisi('yaya', a.g.position.x, a.g.position.z - 0.6, Math.PI);
          s.kisiler.push(k);
          const koli = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.3, 0.3), new THREE.MeshStandardMaterial({ color: '#C9A26B', roughness: 0.9 }));
          koli.position.set(0, 1.05, 0.3);
          k.g.add(koli);
          const kapiZ = hedef ? hedef.onZ + 0.5 : -6;
          yap(k, { yuru: [x, kapiZ] }, { yap: () => { koli.visible = false; kisiyeBalon(k, '📦 Kargonuz geldi!', 2.5); } }, { bekle: 2, anim: 'Interact', bak: Math.PI },
            { yuru: [a.g.position.x, a.g.position.z - 0.6] }, { yap: (kk) => { kisiSil(kk); aracGonder(a); } });
        },
      });
      // motorun üstünde kurye (oturur)
      const surucu = kisi('yaya', 0, 0, 0);
      surucu.bosAnim = 'Sitting_Idle_Loop';
      arac.g.add(surucu.g);
      surucu.g.position.set(-0.1, 0.42, 0);
      surucu.g.rotation.y = Math.PI / 2;
      s.kisiler.push(surucu);
      s.adim = () => { surucu.g.visible = arac.durum !== 'duruyor' || !s.kisiler.some((k) => k !== surucu && k.g.parent); };
    });
  }

  // ------------------------------------------------ 11. Parkta top oynayan çocuklar
  function cocukSahnesi(olay) {
    return sahneBaslat(olay, (s) => {
      const x = olayX(olay, 20);
      const z = 25.5;
      const cocuklar = [kisi('yaya', x - 3, z, Math.PI / 2, 'cocuk'), kisi('yaya', x + 3, z, -Math.PI / 2, 'cocuk')];
      for (const k of cocuklar) { k.bosAnim = 'Idle_Loop'; s.kisiler.push(k); }
      const top = nesneEkle(s, topModeli());
      top.position.set(x - 2.5, 0.12, z);
      s.top = { g: top, t: 0, kimde: 0 };
      s.adim = (dt) => {
        const tp = s.top;
        tp.t += dt;
        const [a, b] = tp.kimde === 0 ? cocuklar : [cocuklar[1], cocuklar[0]];
        for (const k of cocuklar) k.g.rotation.y = bakis(k.g.position.x, k.g.position.z, top.position.x, top.position.z);
        const sure = 1.4;
        if (tp.t < 0.5) oynat(a, 'Interact', 1.4);
        else {
          const k = Math.min(1, (tp.t - 0.5) / sure);
          const ax = a.g.position.x + (b.g.position.x > a.g.position.x ? 0.5 : -0.5);
          const bx = b.g.position.x + (b.g.position.x > a.g.position.x ? -0.5 : 0.5);
          top.position.x = ax + (bx - ax) * k;
          top.position.z = a.g.position.z + (b.g.position.z - a.g.position.z) * k;
          top.position.y = 0.12 + Math.sin(k * Math.PI) * 1.1;
          top.rotation.z -= dt * 8;
          oynat(a, 'Idle_Loop');
          if (k >= 1) {
            tp.t = 0;
            tp.kimde = 1 - tp.kimde;
            // arada koşup yer değiştirirler
            if (Math.random() < 0.3) for (const cc of cocuklar) yap(cc, { yuru: [x + rnd(-4, 4), z + rnd(-1.5, 1.5)], hiz: 2 });
          }
        }
      };
    });
  }

  // ------------------------------------------------ 12. Tezgâhta indirim kuyruğu (oyuncunun çalışan tezgâhında)
  function kuyrukSahnesi(olay) {
    const yer = c.calisanTezgah();
    if (!yer) return null;
    return sahneBaslat(olay, (s) => {
      c.kuyrukOlustur(yer.kod, 5);
      noktayaBalon(s, _autoMetin('🔥 Kuyruk var! Müşterilere hızlı servis yap'), yer.x, 4.2, yer.z, { sure: 12, tur: 'uyari' });
    });
  }

  const KURULUMLAR = {
    kavga: kavgaSahnesi, ambulans: ambulansSahnesi, otobus: otobusSahnesi, cop: copSahnesi, dugun: konvoySahnesi,
    muzisyen: muzisyenSahnesi, kedi: kediSahnesi, cuzdan: cuzdanSahnesi, kurye: kuryeSahnesi, cocuk: cocukSahnesi, kuyruk: kuyrukSahnesi,
    devriye: (o) => gecisSahnesi(o, 'zabita', null), itfaiye: yanginSahnesi,
    konvoy_ilce: makamKonvoyu, konvoy_il: makamKonvoyu, konvoy_mv: makamKonvoyu, konvoy_cb: makamKonvoyu,
  };
  const HABERLI = {
    ambulans: ['🚑', _autoMetin('Mahallede biri fenalaştı!'), _autoMetin('112\'yi ara, ambulans gelsin.')],
    kavga: ['🚓', _autoMetin('Caddede kavga çıktı!'), _autoMetin('155 Polis\'i ara, olay büyümesin.')],
    itfaiye: ['🚒', _autoMetin('Mahallede yangın çıktı!'), _autoMetin('110\'u ara, itfaiye gelsin.')],
    dugun: ['🎉', _autoMetin('Düğün konvoyu geliyor!'), _autoMetin('Kornalar çalıyor, gelin arabası caddede.')],
    cuzdan: ['👛', _autoMetin('Biri cüzdanını düşürdü!'), _autoMetin('Bul ve sahibine ver, ödülü kap.')],
    konvoy_cb: ['🇹🇷', _autoMetin('Cumhurbaşkanı mahallenden geçiyor!'), _autoMetin('Konvoy caddede, halk kaldırımlarda.')],
    konvoy_il: ['🏙️', _autoMetin('Belediye başkanının konvoyu geliyor!'), _autoMetin('Halk kaldırımda el sallıyor.')],
  };
  // Uzun süren olaylar sonradan da başlatılabilir
  const GEC_BASLAR = new Set(['muzisyen', 'kedi', 'cocuk']);

  // ------------------------------------------------ Takvim ve güncelleme
  async function takvimYenile(zorla = false) {
    const t = Date.now();
    if (!zorla && t - sonIstek < 90000) return;
    sonIstek = t;
    try {
      const r = await c.api('sokak');
      liste = r.olaylar || [];
    } catch (e) { /* bağlantı yoksa eski takvimle devam */ }
  }

  let sonKontrol = 0;
  function kontrol() {
    const t = simdi();
    if (!c.kuruldu()) return;
    const surenTurler = new Set(sahneler.filter((s) => !s.bitti).map((s) => s.olay.tur));
    for (const o of liste) {
      if (oynanan.has(o.id) || surenTurler.has(o.tur)) continue;
      if (t < o.bas || t > o.bit - 5000) continue;
      // geç kalınsa da sahne oynar (araçlar yola o an çıkar); sona çok az kaldıysa başlatılmaz
      if (!GEC_BASLAR.has(o.tur) && t > o.bit - 45000) { oynanan.add(o.id); continue; }
      if (sahneler.filter((s) => !s.bitti).length >= 6) break;
      oynanan.add(o.id);
      const kur = KURULUMLAR[o.tur];
      if (kur) {
        try {
          kur(o);
          // önemli olaylar ekranda görünmüyorsa haber verilir: "Göster" kamerayı olay yerine götürür
          if (HABERLI[o.tur] && c.haber) c.haber(o, HABERLI[o.tur], olayX(o), -0.75);
        } catch (e) { console.warn('Sokak olayı kurulamadı', o.tur, e); }
      }
    }
    // zabıta: oyuncunun tezgâhlarına sunucunun belirlediği anlarda uğrar
    for (const z of c.zabitaZiyaretleri()) {
      const anahtar = z.yer.kod + ':' + z.ms;
      if (oynanan.has(anahtar)) continue;
      // araç yaklaşık 12 sn önce yola çıkar ki ziyaret anında tezgâhta olsun
      if (t < z.ms - 14000 || t > z.ms + 4000) continue;
      if (sahneler.some((s) => !s.bitti && s.olay.tur === 'zabita')) continue;
      oynanan.add(anahtar);
      // o anda izin geçerliyse (sonradan alınmış olsa bile) zabıta sadece kontrol eder
      const sonuc = z.tur === 'kontrol' || c.izinVar() ? 'kontrol' : z.tur;
      zabitaSahnesi(z.yer, z, sonuc);
    }
  }

  function guncelle(dt, t) {
    solanlariGuncelle(dt);
    if (t - sonKontrol > 1) { sonKontrol = t; kontrol(); takvimYenile(); geceKontrol(); }
    for (const s of sahneler) {
      if (s.bitti) continue;
      s.t += dt;
      if (s.adim) s.adim(dt, t);
      for (const k of s.kisiler) kisiGuncelle(k, dt);
      if (s.sedyeGuncelle) s.sedyeGuncelle();
      for (const a of s.araclar) aracGuncelle(s, a, dt, t);
      // olay süresi dolduysa (ya da her şey bittiyse) sahne temizlenir
      const hepsiGitti = s.araclar.length === 0 && s.balonlar.length === 0 && s.kisiler.every((k) => !k.g.parent || k.g.visible === false) && s.t > 5;
      const surenAracYok = !s.araclar.some((a) => a.durum !== 'gidiyor');
      if (s.bitsin && s.araclar.length === 0) sahneBitir(s);
      else if (hepsiGitti && surenAracYok && !['muzisyen', 'kedi', 'cocuk', 'cuzdan', 'gece'].includes(s.olay.tur)) sahneBitir(s);
      // süre dolduğunda ekranda giden araç varsa (ör. konvoy) ekrandan çıkması beklenir (en çok 90 sn)
      else if (s.olay.bit && simdi() > s.olay.bit + 30000 && (simdi() > s.olay.bit + 90000 || !s.araclar.some((a) => a.g && a.g.parent && c.ekrandaMi && c.ekrandaMi(a.g.position, 3)))) sahneBitir(s);
      else if (s.olay.bit && simdi() > s.olay.bit && ['muzisyen', 'kedi', 'cocuk', 'cuzdan'].includes(s.olay.tur)) sahneBitir(s);
    }
    for (let i = sahneler.length - 1; i >= 0; i--) if (sahneler[i].bitti) sahneler.splice(i, 1);
    balonlariGuncelle();
  }

  // sahnedeki yürüyen/duran insanlar (araçta olanlar hariç): itişme ve arabaların yayaya yol vermesi için
  const insanListesi = [];
  function insanlar() {
    insanListesi.length = 0;
    for (const s of sahneler) {
      if (s.bitti) continue;
      for (const k of s.kisiler) {
        if (!k.g.visible || k.g.parent !== c.sahne) continue;
        k.yuruyor = !!(k.is[0] && k.is[0].yuru);
        insanListesi.push(k);
      }
    }
    return insanListesi;
  }

  return {
    guncelle,
    takvimYenile,
    insanlar,
    // test ve deneme için: bir olayı hemen başlatır
    dene(tur) {
      const o = { id: 'deneme:' + tur + ':' + Date.now(), tur, bas: simdi(), bit: simdi() + 120000, tohum: 500, kim: { ad: _autoMetin('Ayşe Yılmaz'), makam: _autoMetin('Cumhurbaşkanı') }, eylem: { kavga: 'ara155', ambulans: 'ara112', itfaiye: 'ara110', cuzdan: 'ver', kedi: 'besle', muzisyen: 'bahsis' }[tur] || null, katildi: false };
      if (tur === 'gece') return geceSahnesi();
      return KURULUMLAR[tur] ? KURULUMLAR[tur](o) : null;
    },
    zabitaDene(kod, sonuc = 'ceza') {
      const yer = c.yerBul(kod);
      if (yer) zabitaSahnesi(yer, { ms: simdi(), ceza: 100000 }, sonuc);
    },
    sahneSayisi: () => sahneler.length,
    _sahneler: sahneler,
  };
}
