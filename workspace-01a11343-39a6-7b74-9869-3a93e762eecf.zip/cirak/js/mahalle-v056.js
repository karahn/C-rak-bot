import { sistemMetni as npcMetni, sistemSablonu as npcSablon } from './dil.js?v=0.56.3';
import { t as dilMetni } from './dil.js?v=0.56.3';
// "Mahallem" 3D sahnesi: ana cadde, arka sokak, ara sokaklar ve meydandan oluşan mahalle.
// Kiralanabilir dükkânlar, seyyar tezgâhlar, kavşaklarda ışıkta duran arabalar, yayalar ve müşteriler.
// Kamera sokak seviyesinden kuş bakışına kadar yakınlaşıp uzaklaşır ve döner.
import * as THREE from 'three';
import { parcaliIs } from './parcali-is.js?v=0.56.3';
import { araliklariBol, aydinlatmaPayi } from './sehir-duzen.js?v=0.56.3';
import { Sky } from 'three/addons/objects/Sky.js';
import { ekranKonumu, getRenderer } from './sahne.js?v=0.56.3';
import {
  dogalCimMalzemesi, tezgahModeli, bosYer, bosYerOynat, apartman, araba, sokakLambasi, bayrakZinciri, birlestir, birlestirParcali, agac, bank, copKutusu, copKonteyneri, supurge, copArabasi, asiliBayrak, pankart, isikZinciri, vitrinIsigi, durak, cami, buyukCami, isikliCam, hale, isikLekesi,
  trafikLambasi, tabure, ortu, semsiyeTutacak, babaModeli, reklamPanosu, bilboard, reklamAraci, farHuzmesiMalzemeleri, tavanKariMalzemesi, kopekModeli, kopekAdim, kusModeli, kusCirp,
  kovaKancasiAyarla, modelAyrintisi,
} from './modeller.js?v=0.56.3';
import { insanUret, insanGuncelle, insanSaydamlik, mevsimAyarla, kiyafetYenile, hizCarpani, insanLod, insanAdimAraligi } from './insanlar.js?v=0.56.3';
import { dokuAl } from './varliklar.js?v=0.56.3';
import { sehirKur } from './sehir.js?v=0.56.3';
import { devletBinasi, devletBirlestir, kamuYapisi, kamuBirlestir, levha, mermerLevha, parkKapisi, mitingSahnesi, SECIM_RENKLERI, adTabelasi, tabelaIsiklari } from './devletBinalari.js?v=0.56.3';
import { olayMotoru } from './olaylar.js?v=0.56.3';
import { havaEfektleri } from './hava.js?v=0.56.3';
import { kalite } from './kalite.js?v=0.56.3';
import * as kalabalik from './kalabalik.js?v=0.56.3';
import * as ses from './ses.js?v=0.56.3';
import { esc, sade, sureMetni, simdi, halkaSvg, api } from './yardimci.js?v=0.56.3';

const ARALIK = 7.2;          // aynı sıradaki tezgâh yerleri arası mesafe
const TEZGAH_Z = -3.4;       // kuzey kaldırımındaki tezgâh sırası (bina önü)
const GUNEY_TEZGAH_Z = 13.2; // güney kaldırımındaki tezgâh sırası (park gezinti yolu), yüzleri güneye
const MUSTERI_SERIDI_G = 15.35;
const ORTA_Z = (TEZGAH_Z + GUNEY_TEZGAH_Z) / 2; // iki sıranın ortası: kamera buraya bakar
const OLCEK = 1.2;
const ETIKET_Y = 4.2;
const KALDIRIM_Y = 0.2;
const SOKAK = 90;            // sokağın yarı uzunluğu (sahne sınırı)
const BINA_ON = -8.2;        // bina cephesinin z konumu
const GECIT_X = 31;          // yaya geçidi
const DUKKAN_KAPI_Z = BINA_ON + 0.25;

const ARABA_SERITLERI = [{ z: 5.3, yon: 1 }, { z: 2.4, yon: -1 }];
const YAYA_SERITLERI = [{ z: -6.9, yon: 1 }, { z: -6.2, yon: -1 }, { z: -0.95, yon: 1 }, { z: -0.35, yon: -1 }];
const MUSTERI_SERIDI = -1.25;
// Tezgâhlar yolun iki yanına sırayla dağılır: çift sıradakiler kuzeyde, tekler güneyde (etiketler üst üste binmesin)
function yerKonumu(sira, adet) {
  const guney = sira % 2 === 1;
  const sutun = Math.floor(sira / 2);
  const sutunSayisi = Math.ceil(adet / 2);
  const x = (sutun - (sutunSayisi - 1) / 2) * ARALIK + (guney ? 1.8 : -1.8);
  return { x, z: guney ? GUNEY_TEZGAH_Z : TEZGAH_Z, guney };
}
const DUKKAN_SERIDI = -6.55;

const rnd = (a, b) => a + Math.random() * (b - a);

function tohumluRastgele(tohum) {
  let t = tohum >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

// Tezgâh başındaki müşterilerin siparişleri
const SIPARISLER = {
  ayakkabi: ['Boyar mısın?', 'Siyah cila lütfen', 'Parlat şunu!', 'Şu çizikleri de kapatır mısın?', 'Kahverengi cila var mı?', 'Bugün parlasınlar usta', 'İki çift kaç olur?', 'Önce tozunu alalım', 'Cilayı biraz daha parlat', 'Bugün toplantım var', 'İki ayakkabı da aynı olsun', 'Kolay gelsin usta', "Bağcıkları da değiştirir misin?", "Topuğu biraz aşınmış", "Rengi solmuş, canlandır", "Düğüne gidiyorum, parlasın", "Çamura bastım, kurtar beni", "Nubuk ayakkabı da boyar mısın?", "Ne kadar sürer usta?", "Ayna gibi olsun", "Babamdan kalma, özen göster", "Ayakkabıcı bulmak zor, iyi ki varsın"],
  su: ['Bir su alayım', 'Soğuk su var mı?', 'Mendil alayım', 'İki küçük su lütfen', 'Buz gibi olsun', 'Bir paket mendil de ver', 'Su kaç lira?', 'Susuz kaldım, yetiştin', 'İki su da soğuk olsun', 'Büyük şişe var mı?', 'Bir tane de arkadaşıma', 'Yürüyüşten sonra iyi geldi', "Maden suyu var mı?", "Bir şişe de çantaya", "Islak mendil var mı?", "Oda sıcaklığında olsun", "Altı tane alırsam indirim olur mu?", "Çocuğa küçük bir su", "Bugün hava çok sıcak", "Limonlu soda var mı?", "Kapağı sıkı kapalı olsun", "Bir de cep mendili"],
  semsiye: ['Şemsiye kaç para?', 'Büyüğünden bir tane', 'Kırmızı olsun', 'Rüzgâra dayanıklı mı?', 'Katlanır var mı?', 'Yağmur bastırmadan alayım', 'Siyah olanı gösterir misin?', 'İki kişi sığar mı?', 'Sapı sağlam mı?', 'Küçük çantama sığar mı?', 'Lacivert olanı alayım', 'Bir tane paketler misin?', "Bastonlu şemsiye var mı?", "Çocuk şemsiyesi var mı?", "Desenli olanlardan göster", "Otomatik açılanı alayım", "Güneş için de olur mu?", "Yağmur geldi, bir tane çabuk!", "Telleri sağlam mı?", "Yanına kılıfı da ver", "İkinciye indirim var mı?", "Şeffaf olanı alayım"],
  pamuk: ['Pembe olsun!', 'Bir balon!', 'Pamuk şeker!', 'Mavi balon var mı?', 'Çocuğa bir tane alayım', 'Büyük pamuk şeker olsun', 'İki tane hazırlayabilir misin?', 'Şu kırmızı balon çok güzel', "Bir tane de kardeşine", "Beyaz pamuk şeker var mı?", "Balonun ipini uzun bırak", "Paketleyebilir misin?", "Kalp şeklinde balon var mı?", "Rengârenk pamuk şeker!", "Mor olsun!", "Bir balon, bir de pamuk şeker", "Çubuğu kısa olsun", "Uçan balon kaç lira?", "Doğum günü için beş balon", "Mavi pamuk şeker var mı?", "Kocaman olsun!", "Balon patlamasın ama!"],
  simit: ['İki simit lütfen', 'Bir simit alayım', 'Taze çıktı mı?', 'Susamı bol olsun', 'Yanına çay iyi giderdi', 'Çıtır olanından ver', 'Üç tane paketler misin?', 'Sabah simidi gibisi yok', "İki simit paket yapar mısın?", "Biraz çıtır olsun", "Ofise götüreceğim", "Kolay gelsin, bir simit alayım", "Sıcak simit var mı?", "Bir de poğaça alayım", "Peynir koyar mısın?", "Dün de senden almıştım", "İki simit, bir de açma", "Kahvaltılık beş simit", "Kenarı yanık olsun", "Susamlıdan iki tane", "Martılara da bir parça", "Bugün simitler çok güzel"],
  pazar: ['Çorap kaç lira?', 'Üç tişört alayım', 'Bunu alayım', 'Başka renk var mı?', 'Bir beden büyüğü var mı?', 'İkisini birlikte alıyorum', 'Pamuklu mu?', 'Şu modeli gösterebilir misin?', "Kumaşına bakabilir miyim?", "Küçük boyu da var mı?", "İki çift çorap alayım", "Hediye edeceğim", "Bunun pazarlığı olur mu?", "Siyahından var mı?", "Üçü yüz lira olur mu?", "Yıkanınca çeker mi?", "Bir askılık da ver", "Kışlık var mı?", "Çocuk bedeni lazım", "Bunu deneyebilir miyim?", "Poşet de ver lütfen", "Annem için bir şal"],
  misir: ['Közlenmiş olsun', 'Haşlama olsun', 'Bol tuzlu', 'Tereyağı ekler misin?', 'Sıcacık bir mısır', 'İki tane hazırlarsın', 'Tuzu az olsun', 'Kokusu çok güzel geldi', "Tuzsuz bir tane lütfen", "İki tane paket olsun", "Biraz soğusun da alayım", "Büyük boy var mı?", "Az közlü olsun", "Bol baharatlı", "Kaşarlı mısır var mı?", "Kâsede mısır var mı?", "Limon sıkar mısın?", "Pul biber ekle", "Çocuğa bir tane", "Taneleri tatlı mı?", "Peçeteyi unutma", "Akşam yürüyüşüne yakıştı"],
  kestane: ['Yarım kilo', 'Sıcak kestane!', 'Bir külah', 'İyi pişmiş olsun', 'Çocuklara iki külah', 'Biraz daha koyar mısın?', 'Taze kavruldu mu?', 'Kokusu sokağı sardı', "Küçük bir paket yap", "İki kişilik olsun", "Kabukları kolay açılıyor mu?", "Birazdan sıcak sıcak alayım", "Bir külah daha", "Çatlak olanlardan ver", "Sıcacık mı?", "Kâğıt külahta olsun", "Tadına bakabilir miyim?", "Bursa kestanesi mi?", "Kış geldi demek", "İki külah, biri küçük", "Yanmamış olsun", "Eve götüreceğim, sar lütfen"],
  midye: ['On midye lütfen', 'Limonlu olsun', 'Beş tane daha', 'Acı sos var mı?', 'Bir porsiyon hazırla', 'Bol limon sık', 'Tane tane sayalım', 'Arkadaşıma da götüreceğim', "Bir porsiyon paket yap", "Limonu ayrı koyar mısın?", "İki kişiye yeter mi?", "Beş tane deneyelim", "Pilavı bol olsun", "On tane, limon ayrı", "Midyeler taze mi?", "Biberli olsun", "Bir tane tadına bakayım", "Yirmi tane, paket", "Kabuğunu ben açarım", "Limon bitmiş, bir tane ver", "Akşamın en güzeli", "Acısız olsun lütfen"],
  dondurma: ['Çikolatalı olsun', 'Maraş usulü', 'Külahta üç top', 'Bir top fıstık ekle', 'Külah yerine kap olsun', 'Çilekli kaldı mı?', 'Çocuk için küçük boy', 'Sıcak havaya iyi gider', "Vanilyalı da ekleyelim", "İki küçük külah olsun", "Fıstıklı var mı?", "Birini kapta alayım", "Limonlu olsun", "Kakaolu külah", "Üstüne fıstık serp", "Damla sakızlı var mı?", "Dövme dondurma!", "Beni kandırma usta!", "Külahı ver artık!", "Karamelli var mı?", "Dört top, kapta", "Erimeden yiyeyim"],
  gozleme: ['Peynirli olsun', 'Patatesli olsun', 'Bir ıspanaklı', 'Yanına ayran var mı?', 'İyice kızarsın lütfen', 'İki gözleme paket yap', 'Sıcakken yemek lazım', 'Karışık hazırlayabilir misin?', "Patatesle peyniri karıştır", "Bölüp paketler misin?", "Bir tane de eve götüreyim", "Çayı da hazırlayalım", "Kıymalı olsun", "Peynirli, maydanozlu", "Tereyağlı sür", "Sacdan yeni çıksın", "Çay da var mı?", "Yarım porsiyon olur mu?", "Ispanaklı peynirli", "Acı biberli olsun", "Hamuru ince olsun", "Köy tadında, eline sağlık"],
  kokorec: ['Yarım ekmek', 'Çeyrek, acılı', 'Bol kekikli', 'Az acılı olsun', 'Domatesi bol olsun', 'İki yarım hazırla', 'Ekmeği kızartır mısın?', 'Mis gibi kokuyor', "Baharatı az olsun", "Birini acısız yap", "Paket alabilir miyim?", "İnce kıyılmış olsun", "Tam ekmek, acılı", "Bol soğanlı", "Turşu var mı?", "Ayran da ver", "Çeyrek ekmek yeter", "Kekiği bol olsun", "Gece yarısı en iyisi", "İyi pişsin usta", "Biberi ayrı koy", "Acı olsun ama yakmasın"],
};

export function mahalleOlustur({ tiklandi, keseTik, dukkanTiklandi, servisTik, oyunSaati, olayKatil, muzisyenIstek = null, zabitaSonucu, izinVar, olayHaberi, uzaklasti = () => {}, reklamTik = null, komsuTiklandi = () => {}, bilboardTik = null, fisekBasladi = null, mitingTik = null }) {
  const introCekim = typeof window !== 'undefined' && window.CIRAK_INTRO_CEKIM === true;
  const K = kalite();
  modelAyrintisi(K.kod === 'dusuk' && !introCekim);
  const sahne = new THREE.Scene();
  const kamera = new THREE.PerspectiveCamera(38, 1, 0.5, 4200);
  sahne.fog = new THREE.Fog('#B8D4E8', 110, 420);

  // ------------------------------------------------ Gökyüzü ve ışık
  const gokSahne = new THREE.Scene();
  const gok = new Sky();
  gok.scale.setScalar(150);
  const gu = gok.material.uniforms;
  // berrak ve mavi gökyüzü
  gu.turbidity.value = 2.6;
  gu.rayleigh.value = 2.2;
  gu.mieCoefficient.value = 0.003;
  gu.mieDirectionalG.value = 0.8;
  gokSahne.add(gok);
  const gok2 = new Sky();
  gok2.scale.setScalar(3000);
  gok2.material = gok.material;
  sahne.add(gok2);

  const yildizGeo = new THREE.BufferGeometry();
  const yp = [];
  for (let i = 0; i < 900; i++) {
    const t = Math.random() * Math.PI * 2;
    const y = rnd(0.08, 1);
    const r = Math.sqrt(1 - y * y);
    yp.push(Math.cos(t) * r * 800, y * 800, Math.sin(t) * r * 800);
  }
  yildizGeo.setAttribute('position', new THREE.Float32BufferAttribute(yp, 3));
  const yildizlar = new THREE.Points(yildizGeo, new THREE.PointsMaterial({ color: '#FFFFFF', size: 1.6, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false }));
  sahne.add(yildizlar);

  // ------------------------------------------------ Gerçek hava: yağmur, kar, bulut ve sis
  // ıslak zemin, sıçrayan damlalar, şimşek, kar örtüsü ve bulut gölgeleri hava.js'de
  const havaEf = havaEfektleri({ sahne, kalite: K.kod });
  // 0.40: karlı havada sokağın binalarının çatıları, parapetleri ve denizlikleri de beyazlar (şehirdeki gibi)
  kovaKancasiAyarla((k) => { if (k.userData && k.userData.karTutar && !k.transparent) havaEf.zeminEkle(k, 'cati'); });
  havaEf.gokGurultusuAyarla((uzak) => ses.gokGurultusu && ses.gokGurultusu(1.1 - uzak * 0.6));
  // Parçacıklar kameranın baktığı noktanın çevresindeki bir kutuda döner (ekranda hep yağıyormuş gibi görünür)
  const HAVA_KUTU = { x: 110, y: 46, z: 110 };
  const havaSayisi = { dusuk: 500, orta: 1000, yuksek: 1700 }[K.kod] || 800;
  let hava = { tur: 'acik', bulut: 0 };
  let meydanCamisi = null, camiIsikVeri = null; // 0.50.2: büyük cami ve özel gün ışıkları
  const ledler = new Set(); // plazanın LED şerit malzemeleri
  let bulutPayi = 0;   // 0 açık, 1 kapalı
  let hedefBulut = 0;
  let sisCarpani = 1;
  // 0.41.1: kısa, hafif sabah/gece sisi. Bazı geceler 01.00'den sonra, bazı sabahlar 10.00'dan önce birkaç dakika
  // (en çok 5 dk) hafif sis olur; 45 sn'de yavaşça gelir ve gider. Herkeste aynı anda (güne göre belirlenir).
  // Görüşü az kısar (yalnızca uzaklar puslanır), oyunu ve okunabilirliği bozmaz.
  const SIS_PENCERE = [[1, 5.5], [6, 10]];
  let sisOlayOnbellek = { gun: -1, olaylar: [] };
  function hafifSisPayi(ms) {
    const tr = ms + 3 * 3600000;
    const gun = Math.floor(tr / 86400000);
    if (sisOlayOnbellek.gun !== gun) {
      const olaylar = [];
      SIS_PENCERE.forEach(([a, b], i) => {
        let h = (gun * 2654435761 + i * 40503) >>> 0;
        const r = () => { h = (Math.imul(h ^ (h >>> 15), 2246822507) + 0x6d2b79f5) >>> 0; return h / 4294967296; };
        if (r() > 0.33) return; // günlerin yaklaşık üçte birinde
        const sure = (3 + r() * 2) * 60000;
        const bas = gun * 86400000 + a * 3600000 + r() * ((b - a) * 3600000 - sure);
        olaylar.push([bas, bas + sure]);
      });
      sisOlayOnbellek = { gun, olaylar };
    }
    for (const [bas, bit] of sisOlayOnbellek.olaylar) {
      if (tr < bas || tr > bit) continue;
      return Math.min(1, (tr - bas) / 45000, (bit - tr) / 45000);
    }
    return 0;
  }
  let hafifSis = 0, sonSisOlcum = 0;
  const SIS_GRI = new THREE.Color('#C9D1D8');
  function sisEtkin() {
    const t = performance.now();
    if (t - sonSisOlcum > 1000) { sonSisOlcum = t; hafifSis = hafifSisPayi(simdi()); }
    return sisCarpani * (1 - 0.42 * hafifSis);
  }
  let yagis = null;    // { nesne, tur, poz, hiz }
  function yagisKur(tur) {
    if (yagis) { sahne.remove(yagis.nesne); yagis.nesne.geometry.dispose(); yagis.nesne.material.dispose(); yagis = null; }
    if (tur !== 'yagmur' && tur !== 'firtina' && tur !== 'ciseleme' && tur !== 'kar') return;
    const kar = tur === 'kar';
    const n = Math.round(havaSayisi * (tur === 'ciseleme' ? 0.4 : tur === 'firtina' ? 1.3 : 1));
    const poz = new Float32Array(n * (kar ? 3 : 6));
    const hiz = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = rnd(-HAVA_KUTU.x / 2, HAVA_KUTU.x / 2), y = rnd(0, HAVA_KUTU.y), z = rnd(-HAVA_KUTU.z / 2, HAVA_KUTU.z / 2);
      hiz[i] = kar ? rnd(1.2, 2.4) : rnd(22, 30);
      if (kar) poz.set([x, y, z], i * 3);
      else poz.set([x, y, z, x - 0.18, y + 0.8, z], i * 6);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(poz, 3));
    if (!kar) {
      // damla izinin alt ucu belirgin, üst ucu saydam
      const alfa = new Float32Array(n * 2);
      for (let i = 0; i < n; i++) { alfa[i * 2] = rnd(0.6, 1); alfa[i * 2 + 1] = 0; }
      geo.setAttribute('alfa', new THREE.BufferAttribute(alfa, 1));
    }
    const nesne = kar
      ? new THREE.Points(geo, new THREE.PointsMaterial({ color: '#FFFFFF', map: havaEf.karTanesi(), size: 0.16, sizeAttenuation: true, transparent: true, opacity: 0.95, depthWrite: false }))
      : new THREE.LineSegments(geo, havaEf.yagmurMalzemesi(tur === 'firtina' ? '#71869E' : '#8195AC', tur === 'ciseleme' ? 0.5 : 0.85));
    nesne.frustumCulled = false;
    nesne.renderOrder = 5;
    sahne.add(nesne);
    yagis = { nesne, kar, poz, hiz, n };
  }
  function yagisGuncelle(dt, t) {
    if (!yagis) return;
    yagis.nesne.position.set(hedefX, 0, hedefZ);
    const p = yagis.poz;
    const yX = HAVA_KUTU.x / 2, yZ = HAVA_KUTU.z / 2;
    for (let i = 0; i < yagis.n; i++) {
      const dy = yagis.hiz[i] * dt;
      if (yagis.kar) {
        const k = i * 3;
        p[k + 1] -= dy;
        p[k] += Math.sin(t * 0.8 + i) * dt * 0.6;
        if (p[k + 1] < 0) { p[k + 1] += HAVA_KUTU.y; p[k] = rnd(-yX, yX); p[k + 2] = rnd(-yZ, yZ); }
      } else {
        const k = i * 6;
        p[k + 1] -= dy; p[k + 4] -= dy;
        p[k] -= dy * 0.22; p[k + 3] -= dy * 0.22;
        if (p[k + 1] < 0) {
          const x = rnd(-yX, yX), z = rnd(-yZ, yZ), y = HAVA_KUTU.y + p[k + 1];
          p[k] = x; p[k + 1] = y; p[k + 2] = z; p[k + 3] = x - 0.18; p[k + 4] = y + 0.8; p[k + 5] = z;
        }
      }
    }
    yagis.nesne.geometry.attributes.position.needsUpdate = true;
  }
  let kiyafetAnahtari = '';
  function havaAyarla(h, mevsim) {
    const yeni = h || { tur: 'acik', bulut: 0 };
    // kıyafetler mevsime ve sıcaklığa uysun: sıcaklık kuşağı değişince sokaktakiler yeniden giyinir
    const derece = h && Number.isFinite(h.hissedilen) ? h.hissedilen : h && Number.isFinite(h.sicaklik) ? h.sicaklik : { kis: 5, ilkbahar: 16, yaz: 28, sonbahar: 14 }[mevsim] ?? 18;
    const anahtar = `${mevsim}|${derece <= 10 ? 'soguk' : derece >= 24 ? 'sicak' : 'ilik'}`;
    if (anahtar !== kiyafetAnahtari) {
      kiyafetAnahtari = anahtar;
      mevsimAyarla(mevsim, derece);
      for (const k of [...yayalar, ...gecenler, ...musteriler]) kiyafetYenile(k);
    }
    const degisti = !yagis !== !['yagmur', 'firtina', 'ciseleme', 'kar'].includes(yeni.tur) || (yagis && hava.tur !== yeni.tur);
    hava = yeni;
    hedefBulut = { acik: 0, parcali: 0.25, bulutlu: 0.6, sis: 0.55, ciseleme: 0.65, yagmur: 0.8, kar: 0.75, firtina: 0.95 }[yeni.tur] || 0;
    sisCarpani = yeni.tur === 'sis' ? 0.3 : yeni.tur === 'kar' || yeni.tur === 'firtina' ? 0.6 : yeni.tur === 'yagmur' ? 0.75 : 1;
    if (degisti) yagisKur(yeni.tur);
    havaEf.ayarla(yeni.tur, { simsek: !!yeni.simsek });
    semsiyeleriAyarla(['yagmur', 'firtina', 'ciseleme', 'kar'].includes(yeni.tur));
  }
  // Yağmurda yayaların çoğu şemsiye açar
  let semsiyeAcik = false;
  const SEMSIYE_RENK = ['#1C1C1C', '#C0392B', '#2F80D1', '#8E44AD', '#1FA25A', '#F2C14E', '#E67E22', '#34495E'];
  function semsiyeleriAyarla(acik) {
    if (acik === semsiyeAcik) return;
    semsiyeAcik = acik;
    for (const y of [...yayalar, ...gecenler, ...musteriler]) {
      if (acik && Math.random() < 0.7) {
        const s2 = semsiyeTutacak(SEMSIYE_RENK[Math.floor(Math.random() * SEMSIYE_RENK.length)]);
        s2.position.set(0.18, 0, 0.1);
        y.add(s2);
        y.userData.semsiye = s2;
      } else if (!acik && y.userData.semsiye) {
        y.remove(y.userData.semsiye);
        bellektenSil(y.userData.semsiye);
        y.userData.semsiye = null;
      }
    }
  }
  const bulutSis = new THREE.Color('#9AA4AF');
  const SIMSEK_RENK = new THREE.Color('#E8EEFF');

  const yarim = new THREE.HemisphereLight('#D6ECFF', '#9C8B6E', 0.45);
  sahne.add(yarim);
  const gunes = new THREE.DirectionalLight('#FFF4DE', 2.8);
  gunes.castShadow = K.golge;
  if (K.golge) {
    gunes.shadow.mapSize.set(K.golgeBoyut, K.golgeBoyut);
    Object.assign(gunes.shadow.camera, { left: -26, right: 26, top: 22, bottom: -22, near: 1, far: 140 });
    gunes.shadow.bias = -0.0004;
    gunes.shadow.normalBias = 0.03;
  }
  sahne.add(gunes);
  sahne.add(gunes.target);

  const pmrem = new THREE.PMREMGenerator(getRenderer());
  let ortam = null;
  let sonOrtamYuk = -99;
  const gunesYonu = new THREE.Vector3();

  // ------------------------------------------------ Mahalle düzeni
  // Ana cadde (z=4.3) ile arka sokak (z=-42) paralel, iki ara sokak (XB ve XD) bunları dik keser.
  const A_Z = 4.3;          // ana cadde orta çizgisi
  const B_Z = -42;          // arka sokak orta çizgisi
  const B_YARI = 3.5;       // arka sokak yarı genişliği
  const SIRA = {
    0: { on: BINA_ON, yon: 1, serit: DUKKAN_SERIDI },         // ana cadde, bina yüzü güneye
    1: { on: -34.5, yon: -1, serit: -35.3 },                  // arka sokağın güney sırası, yüzü kuzeye
    2: { on: -49.5, yon: 1, serit: -48.7 },                   // arka sokağın kuzey sırası, yüzü güneye
  };
  let DURAK_X = 55;         // otobüs durağı (güney kaldırımı)
  let XB = -85;             // batıdaki ara sokak
  let XD = 85;              // doğudaki ara sokak
  // 0.52: meydandaki büyük cami (ölçek 1.3, meydanın ortasında; arka yüzü kuzeydeki kurum binalarının önünde)
  const CAMI = { olcek: 1.3, x: () => XD + 40, z: -38.1 };
  let kuruldu = false;
  let sehir = null;       // çevredeki semt (uzaktan görünür)
  const sokakEtiketleri = [];
  let sokakAdlari = null;

  // 0.40: çim zemin ortada sık, kenarlarda seyrek ızgara: büyük üçgenlerde (bazı ekran kartlarında) derinlik hesabı
  // kayıyor, çim yolun ve kaldırımın üstüne üçgen biçiminde taşıyordu. Ortada ~6 m, kenarda ~40 m'lik kareler.
  const zeminGeo = new THREE.PlaneGeometry(2, 2, K.kod === 'dusuk' ? 96 : 140, K.kod === 'dusuk' ? 96 : 140);
  {
    const p = zeminGeo.attributes.position;
    const f = (u) => 1200 * (0.35 * u + 0.65 * u * u * u);
    for (let i = 0; i < p.count; i++) p.setXY(i, f(p.getX(i)), f(p.getY(i)));
    const uv = zeminGeo.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, (p.getX(i) + 1200) / 2400, (p.getY(i) + 1200) / 2400);
    zeminGeo.computeBoundingSphere();
  }
  const zemin = new THREE.Mesh(zeminGeo, dogalCimMalzemesi(480,480));
  zemin.userData.cimZemin = true;
  havaEf.zeminEkle(zemin.material, 'cim');
  zemin.rotation.x = -Math.PI / 2;
  zemin.position.y = -0.05;
  // 0.40: çim zemin derinlikte geriye itilir: uzaktan ve alçaktan bakınca (bazı ekran kartlarında derinlik hassasiyeti
  // düşük) çim, yolun ve kaldırımın üstüne üçgen üçgen taşmasın
  zemin.material.polygonOffset = true;
  zemin.material.polygonOffsetFactor = 4;
  zemin.material.polygonOffsetUnits = 16;
  zemin.receiveShadow = true;
  sahne.add(zemin);

  const beyazBoya = new THREE.MeshStandardMaterial({ color: '#FFFFFF', roughness: 0.6, emissive: '#FFFFFF', emissiveIntensity: 0.08, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -8 }); // 0.41.1: asfaltın üstünde kalsın (yatık bakışta asfalt çizgileri örtüyordu)
  const bordurMat = new THREE.MeshStandardMaterial({ color: '#C8C5BF', roughness: 0.9, map: dokuAl('siva', 40, 1) });
  // kavşak ve geçit başlarında kırmızı-beyaz boyalı bordür (araç park etmesin diye)
  const cizgiliBordurMat = (() => {
    const c = document.createElement('canvas');
    c.width = 128; c.height = 16;
    const x = c.getContext('2d');
    x.fillStyle = '#F2F0EA'; x.fillRect(0, 0, 128, 16);
    x.fillStyle = '#C8201E'; x.fillRect(0, 0, 64, 16);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return (uzunluk) => {
      const k = t.clone();
      k.repeat.set(uzunluk / 1.0, 1);
      k.needsUpdate = true;
      return new THREE.MeshStandardMaterial({ map: k, roughness: 0.7 });
    };
  })();
  function cizgiliBordur(x1, x2, z1, z2) {
    const parcalar = z1 < 1 ? araliklariBol(x1, x2, [XB, XD]) : [[x1, x2]];
    if (parcalar.length !== 1 || parcalar[0][0] !== x1 || parcalar[0][1] !== x2) {
      for (const [a, b] of parcalar) cizgiliBordur(a, b, z1, z2);
      return;
    }
    const b = new THREE.Mesh(new THREE.BoxGeometry(x2 - x1, 0.27, z2 - z1), cizgiliBordurMat(x2 - x1));
    b.position.set((x1 + x2) / 2, 0.135, (z1 + z2) / 2);
    b.receiveShadow = true;
    sahne.add(b);
  }

  // Kaldırım: kilitli parke taşı dokusu (açık gri taşlar, aralıklarla kiremit rengi bantlar), hafif kabartma.
  // Doku bir kez çizilir; her kaldırım kendi ölçüsünde tekrar eder.
  const kaldirimDokulari = (() => {
    const B = 512; // 4 m × 4 m
    const renkC = document.createElement('canvas');
    renkC.width = renkC.height = B;
    const kabC = document.createElement('canvas');
    kabC.width = kabC.height = B;
    const r = renkC.getContext('2d');
    const k = kabC.getContext('2d');
    r.fillStyle = '#9C958C';
    r.fillRect(0, 0, B, B);
    k.fillStyle = '#000';
    k.fillRect(0, 0, B, B);
    const tas = 32;        // 0,25 m
    // Türkiye kaldırımları: gri-bej kilit parke, aralarda kırmızı-kahve bant
    const TONLAR = ['#CFCBC3', '#C5C1B9', '#D6D2CA', '#C9C4BB', '#BEB9B0', '#D1CCC2'];
    const BANT = ['#A45544', '#98503F', '#AD5E4B'];
    // balıksırtı dizilim: 2:1 taşlar
    for (let y = -2; y < B / tas + 2; y++) {
      for (let x = -2; x < B / tas + 2; x++) {
        // Şaşırtmalı derzler: taşlar üst üste binmez.
        const px = x * tas * 2 + (y % 2 ? tas : 0);
        const py = y * tas;
        const w = tas * 2 - 3;
        const h = tas - 3;
        // her 4 m'de bir 0,5 m genişliğinde kiremit bant
        const bant = ((py % B) + B) % B < 64;
        const renk = bant ? BANT[Math.abs(x * 7 + y * 3) % 3] : TONLAR[Math.abs(x * 13 + y * 7) % TONLAR.length];
        r.fillStyle = renk;
        r.beginPath(); r.roundRect(px + 1.5, py + 1.5, w, h, 4); r.fill();
        // Fırınlanmış taş gözenekleri: ek geometri ve kare başına iş yok.
        r.fillStyle = 'rgba(55,45,35,.09)';
        for (let t = 0; t < 7; t++) { const tx = 3 + ((x * 17 + y * 23 + t * 13) % 53 + 53) % 53, ty = 3 + ((x * 7 + y * 11 + t * 9) % 23 + 23) % 23; r.fillRect(px + tx, py + ty, 1, 1); }
        const gr = k.createLinearGradient(px, py, px + w, py + h);
        gr.addColorStop(0, '#E6E6E6'); gr.addColorStop(1, '#BDBDBD');
        k.fillStyle = gr;
        k.beginPath(); k.roundRect(px + 1.5, py + 1.5, w, h, 5); k.fill();
      }
    }
    const renk = new THREE.CanvasTexture(renkC);
    renk.colorSpace = THREE.SRGBColorSpace;
    const kabartma = new THREE.CanvasTexture(kabC);
    for (const t of [renk, kabartma]) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8; }
    return { renk, kabartma };
  })();
  // 0.51: kaldırım dokusu dünya koordinatına göre döşenir (her parça kendi köşesinden başlamaz): yan yana ve üst üste
  // gelen kaldırımlarda taş sıraları ve kiremit bantlar kesintisiz devam eder, kayık/çakışan desen kalmaz.
  // Bütün kaldırımlar tek malzemeyi paylaşır (bellek ve çizim çağrısı tasarrufu).
  let kaldirimMat = null;
  function kaldirimX(x1, x2, z1, z2, ust = sahne) {
    const w = x2 - x1;
    const d = z2 - z1;
    if (!(w > 0.01 && d > 0.01)) return;
    if (!kaldirimMat) {
      kaldirimMat = new THREE.MeshStandardMaterial({ color: '#FFFFFF', map: kaldirimDokulari.renk, bumpMap: kaldirimDokulari.kabartma, bumpScale: 0.025, roughness: 0.88 });
      havaEf.zeminEkle(kaldirimMat, 'kaldirim');
    }
    const cx = (x1 + x2) / 2, cz = (z1 + z2) / 2;
    const g = new THREE.BoxGeometry(w, KALDIRIM_Y, d);
    const p = g.attributes.position, nr = g.attributes.normal, uv = g.attributes.uv;
    for (let i = 0; i < p.count; i++) {
      const X = p.getX(i) + cx, Y = p.getY(i) + KALDIRIM_Y / 2, Z = p.getZ(i) + cz;
      if (Math.abs(nr.getY(i)) > 0.5) uv.setXY(i, X / 4, -Z / 4);
      else if (Math.abs(nr.getX(i)) > 0.5) uv.setXY(i, Z / 4, Y / 4);
      else uv.setXY(i, X / 4, Y / 4);
    }
    const m = new THREE.Mesh(g, kaldirimMat);
    m.position.set(cx, KALDIRIM_Y / 2, cz);
    m.receiveShadow = true;
    ust.add(m);
  }
  // Görme engelliler için sarı kabartmalı kılavuz şerit (kaldırım boyunca)
  const kilavuzMat = (() => {
    const c = document.createElement('canvas');
    c.width = 64; c.height = 64;
    const x = c.getContext('2d');
    x.fillStyle = '#F2C230';
    x.fillRect(0, 0, 64, 64);
    x.strokeStyle = '#D9A91C';
    x.lineWidth = 5;
    for (const yy of [16, 48]) { x.beginPath(); x.moveTo(4, yy); x.lineTo(60, yy); x.stroke(); }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return (uzunluk) => {
      const k = t.clone();
      k.repeat.set(uzunluk / 0.6, 1);
      k.needsUpdate = true;
      return new THREE.MeshStandardMaterial({ map: k, roughness: 0.7 });
    };
  })();
  function kilavuz(x1, x2, z) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(x2 - x1, 0.4), kilavuzMat(x2 - x1));
    m.rotation.x = -Math.PI / 2;
    m.position.set((x1 + x2) / 2, KALDIRIM_Y + 0.004, z);
    m.receiveShadow = true;
    sahne.add(m);
  }
  // Kaldırım ağacı çukuru: dökme demir ızgara
  const izgaraMat = new THREE.MeshStandardMaterial({ color: '#3B3F46', roughness: 0.5, metalness: 0.6 });
  function agacCukuru(x, z) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.02, 1.3), izgaraMat);
    m.position.set(x, KALDIRIM_Y + 0.01, z);
    sabitler.add(m);
  }
  function asfalt(x1, x2, z1, z2, y = 0.02) {
    const w = x2 - x1;
    const d = z2 - z1;
    // 0.40: uzun yol tek dev üçgen olmasın (alçak ve yatık bakışta derinlik hassasiyeti çimle çakışıyordu)
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d, Math.max(1, Math.ceil(w / 16)), Math.max(1, Math.ceil(d / 16))), new THREE.MeshStandardMaterial({
      color: '#B4BAC6', map: dokuAl('asfalt', w / 8, d / 8), normalMap: dokuAl('asfalt_n', w / 4, d / 4), roughness: 0.92,
      polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
    }));
    m.rotation.x = -Math.PI / 2;
    m.position.set((x1 + x2) / 2, y, (z1 + z2) / 2);
    m.receiveShadow = true;
    havaEf.zeminEkle(m.material, 'asfalt');
    sahne.add(m);
  }
  // Hareket etmeyen süs ve çevre nesneleri: mahalle kurulunca malzemelerine göre birleştirilir (az çizim, akıcı oyun)
  const sabitler = new THREE.Group();
  sahne.add(sabitler);
  function cizgi(x, z, w, d) {
    const s = new THREE.Mesh(new THREE.PlaneGeometry(w, d), beyazBoya);
    s.rotation.x = -Math.PI / 2;
    s.position.set(x, 0.035, z);
    sabitler.add(s);
  }
  function bordur(x1, x2, z1, z2) {
    if (z1 < 1) {
      const parcalar = araliklariBol(x1, x2, [XB, XD]);
      if (parcalar.length !== 1 || parcalar[0][0] !== x1 || parcalar[0][1] !== x2) {
        for (const [a, b] of parcalar) bordur(a, b, z1, z2);
        return;
      }
    }
    const b = new THREE.Mesh(new THREE.BoxGeometry(x2 - x1, 0.26, z2 - z1), bordurMat);
    b.position.set((x1 + x2) / 2, 0.13, (z1 + z2) / 2);
    b.receiveShadow = true;
    sahne.add(b);
  }

  const lambalar = [];
  const isiklar = [];        // { grup, eksen }
  const gecelik = { haleler: new Set(), tabelalar: new Set() };
  // Sahneden kaldırılan bir nesnenin GPU belleğini boşaltır ve gece ışıkları listesinden çıkarır.
  // Malzemeler modeller arasında paylaşıldığı için silinmez; yalnızca binaya özel tabela dokusu silinir.
  // geometri=false: şekli başka kopyalarla paylaşılan nesneler (insanlar) için
  function bellektenSil(kok, { geometri = true } = {}) {
    if (!kok) return;
    kok.traverse((o) => {
      gecelik.haleler.delete(o);
      if (geometri && o.geometry && !o.geometry.userData.paylasimli) o.geometry.dispose();
      if (o.material) {
        for (const m of Array.isArray(o.material) ? o.material : [o.material]) {
          if (m.userData && m.userData.tabela) {
            gecelik.tabelalar.delete(m);
            if (m.map) m.map.dispose();
            if (m.emissiveMap && m.emissiveMap !== m.map) m.emissiveMap.dispose();
            m.dispose();
          } else if (!geometri && m.userData && m.userData.kisisel) m.dispose();
        }
      }
    });
  }
  function geceIsiklariniTopla(kok) {
    kok.traverse((o) => {
      if (o.userData.hale || o.userData.leke) gecelik.haleler.add(o);
      if (o.isMesh) {
        const liste = Array.isArray(o.material) ? o.material : [o.material];
        for (const m of liste) if (m.userData && m.userData.tabela && !gecelik.tabelalar.has(m)) { if (!m.emissiveMap) m.emissiveMap = m.map; gecelik.tabelalar.add(m); }
      }
    });
  }
  function lambaKoy(x, z, ry) {
    const l = sokakLambasi();
    l.position.set(x, KALDIRIM_Y, z);
    l.rotation.y = ry;
    sahne.add(l);
    lambalar.push(l);
    geceIsiklariniTopla(l);
  }
  function isikKoy(x, z, ry, eksen) {
    const t = trafikLambasi();
    t.position.set(x, KALDIRIM_Y, z);
    t.rotation.y = ry;
    sahne.add(t);
    isiklar.push({ grup: t, eksen });
  }

  // Satır genişliklerine göre bütün mahalleyi kurar (ilk cadde verisi gelince bir kez)
  // çöp konteynerleri (mahalleKur yerleştirir; çöp kamyonu ve çöpçüler kullanır)
  const konteynerler = [];
  // Yürünen zeminin yüksekliği: asfaltta yol seviyesi, kaldırımda kaldırım seviyesi (inen biner kaldırıma adım atar)
  function zeminY(x, z) {
    if (z > 0.2 && z < 8.4) return 0.02;
    if (z > B_Z - B_YARI && z < B_Z + B_YARI && x > XB - 3.5 && x < XD + 3.5) return 0.02;
    if (z < 0.2 && (Math.abs(x - XB) < 3.5 || Math.abs(x - XD) < 3.5)) return 0.02;
    return KALDIRIM_Y;
  }
  // reklam panoları (aşağıda: panoCiz, reklamlariAyarla)
  const panolar = [];
  let reklamlar = [];
  let panoSira = 0;
  let sonPano = 0;
  // 0.43: bilboardlar (aşağıda: bilboardCiz, bilboardlariAyarla)
  const bilboardlar = [];
  let bilboardVeri = [];
  let sonBilboard = 0;
  function mahalleKur(genislikler) {
    kuruldu = true;
    const yari = Math.max(60, ...genislikler.map((g) => g / 2));
    XB = -(yari + 6.5);
    XD = yari + 6.5;
    const S = { x1: XB - 70, x2: XD + 70 };

    // Ana cadde: yol, iki yanda kaldırım (kuzeydeki tezgâh kaldırımı ara sokaklar arasında)
    asfalt(S.x1, S.x2, 0.2, 8.4);
    kaldirimX(XB + 3.5, XD - 3.5, BINA_ON, 0.2);
    kaldirimX(S.x1, XB - 3.5, BINA_ON, 0.2);
    kaldirimX(XD + 3.5, S.x2, BINA_ON, 0.2);
    // güney kaldırımı geniş bir gezinti yolu: yol kenarında lambalar ve durak, ortada tezgâh sırası, parka doğru çiçek tarhları
    // Ara sokaklar ana caddede biter; karşı kaldırım kesintisiz devam eder.
    kaldirimX(S.x1, S.x2, 8.4, 17.8);
    kilavuz(S.x1, S.x2, 11.4);
    kilavuz(XB + 3.5, XD - 3.5, -1.55);
    bordur(S.x1, S.x2, -0.04, 0.24);
    bordur(S.x1, S.x2, 17.7, 17.95);
    bordur(S.x1, S.x2, 8.36, 8.64);
    // geçit ve kavşak başlarında boyalı bordür ve siyah-sarı babalar
    for (const [ax, bx] of [[GECIT_X - 6, GECIT_X + 6], [XB - 12, XB + 12], [XD - 12, XD + 12]]) {
      cizgiliBordur(ax, bx, -0.05, 0.25);
      cizgiliBordur(ax, bx, 8.35, 8.65);
    }
    for (const [bx, bz] of [[GECIT_X - 2.6, -0.5], [GECIT_X + 2.6, -0.5], [GECIT_X - 2.6, 9.1], [GECIT_X + 2.6, 9.1], [XB + 4.2, -0.5], [XB + 5.6, -0.5], [XD - 4.2, -0.5], [XD - 5.6, -0.5], [XB + 4.2, 9.1], [XD - 4.2, 9.1]]) {
      const b = babaModeli();
      b.position.set(bx, KALDIRIM_Y, bz);
      sabitler.add(b);
      kalabalik.engelEkle(bx, bz, 0.25, 0.25);
    }
    for (let x = S.x1; x < S.x2; x += 6) if (Math.abs(x - GECIT_X) > 8 && Math.abs(x - XB) > 6 && Math.abs(x - XD) > 6) cizgi(x, 3.85, 3, 0.14);
    for (let z = 0.95; z < 7.8; z += 0.9) cizgi(GECIT_X, z, 3.2, 0.5);
    cizgi(GECIT_X - 2.6, 5.9, 0.3, 3.4);
    cizgi(GECIT_X + 2.6, 2.1, 0.3, 3.4);

    // Arka sokak
    asfalt(XB - 3.5, XD + 3.5, B_Z - B_YARI, B_Z + B_YARI);
    kaldirimX(XB + 3.5, XD - 3.5, B_Z + B_YARI, SIRA[1].on);
    kaldirimX(XB + 3.5, XD - 3.5, SIRA[2].on, B_Z - B_YARI);
    bordur(XB + 3.5, XD - 3.5, B_Z + B_YARI - 0.14, B_Z + B_YARI + 0.14);
    bordur(XB + 3.5, XD - 3.5, B_Z - B_YARI - 0.14, B_Z - B_YARI + 0.14);
    for (let x = XB + 8; x < XD - 6; x += 6) cizgi(x, B_Z, 3, 0.14);

    // Ara sokaklar (kuzey-güney)
    for (const X of [XB, XD]) {
      asfalt(X - 3.5, X + 3.5, -75, 8.4, 0.021);
      for (const kx of [X - 5.5, X + 5.5]) {
        // 0.51: arka sokak yalnız iki ara sokağın arasında; dış kaldırım kesintisiz (köşede çimen boşluğu kalmasın)
        const ic = X === XB ? kx > X : kx < X;
        for (const [a, b] of ic ? araliklariBol(-75, BINA_ON, [B_Z], B_YARI) : [[-75, BINA_ON]]) kaldirimX(kx - 2, kx + 2, a, b);
      }
      for (let z = -72; z < 0; z += 6) if (Math.abs(z - B_Z) > 7) cizgi(X, z, 0.14, 3);
      // köşe ışıkları: biri ana cadde trafiğine, biri ara sokak trafiğine bakar
      isikKoy(X - 4.3, 9.2, -Math.PI / 2, 'x');
      isikKoy(X + 4.3, -0.6, 0, 'z');
      isikKoy(X - 4.3, B_Z + B_YARI + 0.6, -Math.PI / 2, 'x');
      isikKoy(X + 4.3, B_Z - B_YARI - 0.6, 0, 'z');
      for (let z = 1; z < 8; z += 0.9) cizgi(X - 5.2, z, 1.6, 0.4);
    }
    // yaya geçidindeki ışıklar
    isikKoy(GECIT_X - 2.2, 8.85, -Math.PI / 2, 'x');
    isikKoy(GECIT_X + 2.2, -0.15, Math.PI / 2, 'x');

    // Lambalar ve eşyalar (0.39.0: kaldırımın farklı yerlerinde en az üç bank; yayalar arada oturup dinlenir)
    let lambaSira = 0;
    for (let lx = S.x1 + 10; lx <= S.x2 - 10; lx += 13.8) {
      if (Math.abs(lx - XB) < 6 || Math.abs(lx - XD) < 6) continue;
      lambaKoy(lx, 8.95, Math.PI / 2);
      if (Math.abs(lx - GECIT_X) < 5) continue;
      lambaSira++;
      if (lambaSira % 3 === 1 || Math.random() < 0.3) {
        const b = bank();
        b.position.set(lx + 3.2, KALDIRIM_Y, 10.6);
        b.rotation.y = Math.PI;
        sabitler.add(b);
        kalabalik.engelEkle(lx + 3.2, 10.65, 1.7, 0.5);
        banklar.push({ x: lx + 3.2, z: 10.6, oturan: [] });
      } else {
        const k = copKutusu();
        k.position.set(lx + 2.5, KALDIRIM_Y, 9.4);
        sabitler.add(k);
        kalabalik.engelEkle(lx + 2.5, 9.4, 0.45, 0.45);
      }
    }
    for (let lx = XB + 12; lx <= XD - 12; lx += 16) {
      lambaKoy(lx, B_Z + B_YARI + 0.6, -Math.PI / 2);
    }
    // ana caddenin üstünde renkli bayrak zincirleri (şenlikli çarşı havası)
    for (let bx = S.x1 + 17; bx <= S.x2 - 17; bx += 27.6) {
      if (Math.abs(bx - XB) < 8 || Math.abs(bx - XD) < 8) continue;
      sabitler.add(bayrakZinciri([bx - 3, 6.6, BINA_ON + 0.4], [bx + 3, 5.4, 8.9], 1.1));
    }
    const d = durak();
    DURAK_X = Math.min(55, XD - 12);
    d.position.set(DURAK_X, KALDIRIM_Y, 10.4);
    d.rotation.y = Math.PI;
    sabitler.add(d);
    kalabalik.engelEkle(DURAK_X, 10.95, 3.4, 0.45);
    // kaldırımdaki ışıklı reklam panoları: reklam kampanyası süren dükkânların adı sırayla döner
    for (const px of [DURAK_X - 4.2, XB + 16]) {
      const pano = reklamPanosu();
      pano.position.set(px, KALDIRIM_Y, 10.25);
      sahne.add(pano);
      kalabalik.engelEkle(px, 10.25, 1.5, 0.45);
      const isabet = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.6, 0.6), new THREE.MeshBasicMaterial({ visible: false }));
      isabet.position.set(px, 1.5, 10.25);
      isabet.userData.pano = true;
      sahne.add(isabet);
      panolar.push({ g: pano, isabet, sira: panolar.length });
    }
    panoCiz();
    // 0.43: bilboardlar — caddenin iki ucunda (batıda parkın, doğuda meydanın önünde) ve güneydeki park yolunda
    for (const [no, bx, bz, ry] of [[1, XB - 24, -11, 0], [2, XD + 66, -11, 0], [3, GECIT_X + 6, 25.4, Math.PI]]) {
      const b = bilboard();
      b.userData.dijital = K.golge !== false; // 0.49.7: düşük grafikte geçiş animasyonu yok
      b.position.set(bx, bz < 0 ? KALDIRIM_Y : 0, bz);
      b.rotation.y = ry;
      sahne.add(b);
      const engel = kalabalik.engelEkle(bx, bz, 1.5, 1.5);
      const isabet = new THREE.Mesh(new THREE.BoxGeometry(7.6, 4.2, 1), new THREE.MeshBasicMaterial({ visible: false }));
      isabet.position.set(bx, 7.1, bz);
      isabet.rotation.y = ry;
      isabet.userData.bilboard = no;
      sahne.add(isabet);
      bilboardlar.push({ no, g: b, isabet, sira: 0, gosterilen: null, engel, ilkX: bx, ilkZ: bz });
    }
    bilboardCiz();
    // Belediye çöp konteynerleri: güney kaldırımında yol kenarında ve arka sokakta (çöp kamyonu bunları boşaltır)
    const yasak = [[DURAK_X, 4.2], [DURAK_X - 4.2, 2], [XB + 16, 2.2], [GECIT_X, 7], [XB, 6], [XD, 6]];
    for (let lx = S.x1 + 10; lx <= S.x2 - 10; lx += 13.8) yasak.push([lx, 1.1], [lx + 2.5, 1.2], [lx + 3.2, 1.6]);
    const serbest = (x) => yasak.every(([yx, pay]) => Math.abs(x - yx) > pay + 0.8);
    const konteynerKoy = (x, z, ry, yolZ) => {
      const k = copKonteyneri();
      k.position.set(x, KALDIRIM_Y, z);
      k.rotation.y = ry;
      sahne.add(k);
      kalabalik.engelEkle(x, z, 1.5, 1.15);
      konteynerler.push({ g: k, x, z, ry, yolZ, kapak: k.userData.kapak });
    };
    for (const hedef of [XB + 24, (XB + XD) / 2 - 9, XD - 24]) {
      let x = hedef;
      for (let i = 0; i < 30 && !serbest(x); i++) x += (i % 2 ? -1 : 1) * (i + 1) * 0.7;
      if (serbest(x) && x > XB + 8 && x < XD - 8) konteynerKoy(x, 9.5, 0, 7.3);
    }
    konteynerKoy(XB + 9.5, B_Z + B_YARI + 0.95, Math.PI, B_Z + 1.7);
    konteynerKoy(XD - 9.5, B_Z - B_YARI - 0.95, 0, B_Z - 1.7);
    const cali = new THREE.MeshStandardMaterial({ color: '#547349', roughness: 0.95, flatShading: false });
    havaEf.zeminEkle(cali, 'cim');
    for (let cx = S.x1; cx < S.x2; cx += 2.2) {
      if (Math.abs(cx - XB) < 5 || Math.abs(cx - XD) < 5) continue;
      const m = new THREE.Mesh(new THREE.IcosahedronGeometry(rnd(0.7, 1), 1), cali);
      m.scale.y = 0.6;
      m.position.set(cx, 0.45, 18.5 + rnd(-0.15, 0.15));
      m.castShadow = true;
      sabitler.add(m);
    }
    // İki sıra binanın arasındaki avlulara ağaç
    for (let ax = XB + 10; ax < XD - 8; ax += rnd(9, 15)) {
      const a = agac();
      a.position.set(ax, 0, rnd(-25, -21));
      sabitler.add(a);
    }
    // kaldırım ağaçları (tezgâh bölgesi ve geçit dışında)
    for (let ax = XB + 8; ax <= XD - 6; ax += ARALIK * 2.5) {
      if (Math.abs(ax) < 29 || Math.abs(ax - GECIT_X) < 5) continue;
      const a = agac();
      a.scale.setScalar(0.8);
      a.position.set(ax, KALDIRIM_Y, -0.6);
      sabitler.add(a);
      agacCukuru(ax, -0.6);
      kalabalik.engelEkle(ax, -0.6, 0.7, 0.7);
    }

    // Doğuda meydan ve cami, batıda park
    const meydanX = XD + 40;
    kaldirimX(XD + 7.5, XD + 72, -60, -12);
    // 0.50.2: Selimiye'den esinlenen dört minareli büyük cami; gece projektörle aydınlanır, özel günlerde mahya
    // 0.52: cami büyüdü ve meydanın ortasına geçti (plaza şehirdeki ayrılmış bloğa taşındı)
    const c = buyukCami();
    c.scale.setScalar(CAMI.olcek);
    c.position.set(CAMI.x(), KALDIRIM_Y, CAMI.z);
    birlestir(c, { tut: (o) => o.userData && o.userData.ayri });
    sabitler.add(c);
    meydanCamisi = c;
    if (camiIsikVeri) c.userData.mod(camiIsikVeri);
    kalabalik.engelEkle(CAMI.x(), CAMI.z, 26 * CAMI.olcek, 26 * CAMI.olcek);
    // ağaçlar caminin iki yanında; ortası kitabeye ve taç kapıya açık
    for (const [ax, az] of [[-25, -16], [25, -16], [-25, -26], [25, -26], [-27, -38], [27, -38]]) {
      const a = agac();
      a.position.set(CAMI.x() + ax, KALDIRIM_Y, az);
      sabitler.add(a);
    }
    for (const bx of [-16, -10, 10, 16]) {
      const b = bank();
      b.position.set(CAMI.x() + bx, KALDIRIM_Y, -17.2);
      sabitler.add(b);
    }
    // iki yanda süs havuzu
    const havuzM = new THREE.MeshStandardMaterial({ color: '#C9C6BE', roughness: 0.8 }), suM = new THREE.MeshStandardMaterial({ color: '#4A8FC2', roughness: 0.1, metalness: 0.3 });
    for (const hx of [XD + 14, XD + 66]) {
      const havuz = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.5, 0.6, 32), havuzM);
      havuz.position.set(hx, 0.3, -47);
      sabitler.add(havuz);
      const su = new THREE.Mesh(new THREE.CircleGeometry(2.9, 32), suM);
      su.rotation.x = -Math.PI / 2;
      su.position.set(hx, 0.55, -47);
      sabitler.add(su);
      kalabalik.engelEkle(hx, -47, 7, 7);
    }
    // 0.49: batıdaki parkın caddeye bakan önü devlet binalarına (kaymakamlık, belediye) ayrılır
    for (let i = 0, n = 0; i < 80 && n < 22; i++) {
      const ax = XB - 12 - rnd(0, 55), az = rnd(-70, -12);
      if (az > -44) continue;
      const a = agac();
      a.position.set(ax, 0, az);
      sabitler.add(a);
      n++;
    }
    // Çevredeki mahalle: cadde ızgarası, apartman blokları, parklar ve camiler (uzaklaşınca bütün semt görünür)
    const ankara = !!(devletListesi && devletListesi.some((x) => x.tur === 'kulliye'));
    sehir = sehirKur({
      cekirdek: { x1: S.x1, x2: S.x2, zK: -75, zG: 42 },
      araSokaklar: [XB, 0, XD],
      anaCadde: { z1: 0.2, z2: 8.4 },
      tohum: 7,
      yaricap: SEHIR_YARICAP,
      // 0.49: Ankara'da (Çankaya, Yenimahalle) güneydeki bloklar Külliye, TBMM ve bakanlıklara ayrılır
      ayrilan: ankara ? { x1: XB - 85, x2: XD + 85, z1: 44, z2: 175 } : null,
      // 0.50: bağışla ad alan kamu yapıları (ek: kilise ya da kültür merkezi)
      // 0.52: plaza, devlet hastanesi, emniyet ve itfaiye de çekirdeğe yakın ayrılmış bloklara kurulur
      kamu: ['millet', 'plaza', 'hastane', 'emniyet', 'itfaiye', 'ilkokul', 'lise', 'spor', 'ortaokul', 'kutuphane', 'ek'],
    });
    sahne.add(sehir.grup);
    kamuKur();
    // Semtin dışı boş bir zeminle kesilmez: dünya konumuna bağlı sis kenarı.
    // Merkezdeki modeller ve dokular değişmez; dış bloklar havanın rengine karışır.
    const kenarMalzemeleri = new Set([zemin.material]);
    sehir.grup.traverse((o) => { if (o.material) for (const m of Array.isArray(o.material) ? o.material : [o.material]) kenarMalzemeleri.add(m); });
    for (const m of kenarMalzemeleri) {
      if (!m.fog || m.isShaderMaterial) continue;
      const derle = m.onBeforeCompile, anahtar = m.customProgramCacheKey.bind(m);
      const eskiAnahtar = anahtar();
      m.onBeforeCompile = function (shader, renderer) {
        derle.call(this, shader, renderer);
        shader.vertexShader = 'varying vec2 vCirakKenar;\n' + shader.vertexShader;
        shader.vertexShader = shader.vertexShader.replace('#include <worldpos_vertex>', `#include <worldpos_vertex>
          vec4 cirakYer = vec4(transformed, 1.0);
          #ifdef USE_INSTANCING
            cirakYer = instanceMatrix * cirakYer;
          #endif
          vCirakKenar = (modelMatrix * cirakYer).xz;`);
        shader.fragmentShader = 'varying vec2 vCirakKenar;\n' + shader.fragmentShader;
        shader.fragmentShader = shader.fragmentShader.replace('#include <fog_fragment>', `#include <fog_fragment>
          #ifdef USE_FOG
            float cirakSinir = length(vec2(vCirakKenar.x / 300.0, vCirakKenar.y / (vCirakKenar.y > 0.0 ? 225.0 : 300.0)));
            gl_FragColor.rgb = mix(gl_FragColor.rgb, fogColor, smoothstep(0.72, 1.0, cirakSinir));
          #endif`);
      };
      m.customProgramCacheKey = () => eskiAnahtar + '|cirak-semt-sisi-0359';
      m.needsUpdate = true;
    }
    if (sehir.malzemeler) { havaEf.zeminEkle(sehir.malzemeler.asfalt, 'asfalt'); havaEf.zeminEkle(sehir.malzemeler.kaldirim, 'kaldirim'); havaEf.zeminEkle(sehir.malzemeler.cim, 'cim'); if (sehir.malzemeler.cati) havaEf.zeminEkle(sehir.malzemeler.cati, 'cati'); }

    // Ana caddenin güneyi: ağaçlı park şeridi, çiçek tarhları, yürüyüş yolu ve banklar
    kaldirimX(S.x1, S.x2, 20.2, 22.6);
    const tarhRenk = ['#C37D87', '#D8B467', '#AD6D83', '#C08F63', '#9B8AAC', '#E3DED3'];
    const toprak = new THREE.MeshStandardMaterial({ color: '#8B5A3C', roughness: 1 });
    for (let px = S.x1 + 6; px < S.x2 - 6; px += rnd(9, 13)) {
      if (Math.abs(px - (GECIT_X + 6)) < 6) continue; // park yolundaki bilboardın önü açık kalsın
      const a = agac();
      a.position.set(px, 0, rnd(25, 31));
      sabitler.add(a);
      if (Math.random() < 0.6) {
        const a2 = agac();
        a2.scale.setScalar(rnd(0.7, 0.9));
        a2.position.set(px + rnd(3, 5), 0, rnd(31, 38));
        sabitler.add(a2);
      }
      // çiçek tarhı
      const tx = px + rnd(-2, 2);
      const tarh = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.3, 1.1), toprak);
      tarh.position.set(tx, KALDIRIM_Y + 0.15, 16.9);
      sabitler.add(tarh);
      kalabalik.engelEkle(tx, 16.9, 3.2, 1.1);
      const renk = tarhRenk[Math.floor(Math.random() * tarhRenk.length)];
      const cicekMat = new THREE.MeshStandardMaterial({ color: renk, roughness: 0.9, flatShading: false });
      for (let i = 0; i < 6; i++) {
        const px=tx-1.3+i*.52,pz=16.9+rnd(-.18,.18);
        const yesil=new THREE.Mesh(new THREE.IcosahedronGeometry(.14,1),cali);yesil.position.set(px,KALDIRIM_Y+.35,pz);yesil.scale.y=.55;sabitler.add(yesil);
        if(i%2) {
          for(let j=0;j<5;j++) {const aci=j*Math.PI*2/5;const petal=new THREE.Mesh(new THREE.SphereGeometry(.06,6,4),cicekMat);petal.scale.set(1,.5,.65);petal.position.set(px+Math.cos(aci)*.067,KALDIRIM_Y+.47,pz+Math.sin(aci)*.067);sabitler.add(petal);}
          const merkez=new THREE.Mesh(new THREE.SphereGeometry(.025,6,4),cicekMat);merkez.position.set(px,KALDIRIM_Y+.48,pz);sabitler.add(merkez);
        }
      }
      if (Math.random() < 0.35) {
        const b = bank();
        b.position.set(px + 1.5, KALDIRIM_Y, 20.9);
        b.rotation.y = Math.PI;
        sabitler.add(b);
      }
    }

    // 0.49: asfaltta döküm rögar kapakları, bordür dibinde yağmur suyu ızgaraları, kaldırımda yangın muslukları
    {
      const c = document.createElement('canvas'); c.width = 128; c.height = 128;
      const x = c.getContext('2d');
      x.fillStyle = '#3A3B3D'; x.beginPath(); x.arc(64, 64, 62, 0, Math.PI * 2); x.fill();
      x.strokeStyle = '#55575B'; x.lineWidth = 5; x.beginPath(); x.arc(64, 64, 56, 0, Math.PI * 2); x.stroke();
      x.strokeStyle = '#2A2B2D'; x.lineWidth = 3;
      for (let i = -48; i <= 48; i += 12) { x.beginPath(); x.moveTo(64 + i, 14); x.lineTo(64 + i, 114); x.stroke(); }
      x.fillStyle = '#4A4C50'; x.font = '700 14px Arial'; x.textAlign = 'center'; x.fillText('BELEDİYE', 64, 70);
      const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
      const rogarMat = new THREE.MeshStandardMaterial({ map: t, roughness: 0.6, metalness: 0.45, polygonOffset: true, polygonOffsetFactor: -2 });
      for (let rx = S.x1 + 18; rx < S.x2 - 18; rx += rnd(26, 40)) {
        if (Math.abs(rx - GECIT_X) < 6 || Math.abs(rx - XB) < 6 || Math.abs(rx - XD) < 6) continue;
        const m = new THREE.Mesh(new THREE.CircleGeometry(0.42, 18), rogarMat);
        m.rotation.x = -Math.PI / 2; m.position.set(rx, 0.215, rnd(3, 5.6)); m.receiveShadow = true;
        sabitler.add(m);
      }
      const izgaraMat = new THREE.MeshStandardMaterial({ color: '#2B2D30', roughness: 0.5, metalness: 0.6 });
      for (let ix = S.x1 + 10; ix < S.x2 - 10; ix += 22) for (const iz of [0.45, 7.9]) {
        if (Math.abs(ix - GECIT_X) < 5 || Math.abs(ix - XB) < 6 || Math.abs(ix - XD) < 6) continue;
        const m = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.02, 0.35), izgaraMat);
        m.position.set(ix, 0.21, iz); m.receiveShadow = true;
        sabitler.add(m);
      }
      const kirmizi = new THREE.MeshStandardMaterial({ color: '#C62828', roughness: 0.45, metalness: 0.2 });
      for (const hx of [XB + 9, XD - 9, GECIT_X + 9]) {
        const g = new THREE.Group();
        const gv = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.7, 10), kirmizi); gv.position.y = 0.35; g.add(gv);
        const bs = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), kirmizi); bs.position.y = 0.7; g.add(bs);
        for (const sx of [-1, 1]) { const a = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.12, 8), kirmizi); a.rotation.z = Math.PI / 2; a.position.set(sx * 0.15, 0.5, 0); g.add(a); }
        g.position.set(hx, KALDIRIM_Y, 9.3);
        sabitler.add(g);
        kalabalik.engelEkle(hx, 9.3, 0.4, 0.4);
      }
    }

    // hareket etmeyen her şey malzemesine göre birleşir: yüzlerce çizim birkaç taneye iner
    // hücreli birleştirme: sokakta yalnızca görünen kısım (ve gölge alanı) çizilir
    birlestir(sabitler, { hucre: 48 });

    devletKur();
    sokakEtiketi('anaCadde', 'Cumhuriyet Caddesi', 0, A_Z);
    sokakEtiketi('arkaSokak', 'İstiklal Sokak', 0, B_Z);
    sokakEtiketi('batiSokak', 'Atatürk Bulvarı', XB, -20);
    sokakEtiketi('doguSokak', 'Lale Sokak', XD, -20);
    sokakEtiketi('meydan', 'Meydan', meydanX - 26, -14);
    // 0.30: yağmurda asfaltta su birikintileri (yol kenarlarına yakın, çukurlarda); kuruyunca kaybolur
    for (let i = 0; i < 46; i++) {
      const arka = i % 4 === 3;
      const zm = arka ? B_Z : A_Z;
      const kenar = (Math.random() < 0.5 ? -1 : 1) * ((arka ? B_YARI - 1.1 : 3.1) + (Math.random() - 0.5) * 1.0);
      havaEf.birikintiEkle(XB + 4 + Math.random() * (XD - XB - 8), 0.034, zm + kenar, 0.8 + Math.random() * 2.2, 0.45 + Math.random() * 0.8);
    }

    trafikKur();
    if (bekleyenDolasan) { const l = bekleyenDolasan; bekleyenDolasan = null; setTimeout(() => dolasanlarAyarla(l), 0); }
    yayaKur();
    copcuKur();
    if (semsiyeAcik) { semsiyeAcik = false; semsiyeleriAyarla(true); }
    if (sokakAdlari) caddeGuncelle([], sokakAdlari);
  }

  function sokakEtiketi(anahtar, ad, x, z) {
    const e = document.createElement('div');
    e.className = 'etiket gizli';
    e.innerHTML = `<button class="sokak-adi">${esc(ad)}</button>`;
    etiketKutusu.appendChild(e);
    e.querySelector('button').addEventListener('click', () => ucusYap(x, z, 34));
    // etiket sokağın görünen bir noktasına konur: sokak boyunca birkaç aday nokta, binaların ardında kalanlar elenir
    const adaylar = anahtar === 'anaCadde' || anahtar === 'arkaSokak'
      ? [-60, -30, 0, 30, 60].map((dx) => [x + dx, z])
      : anahtar === 'meydan' ? [[x, z]] : [-110, -95, -80, -65, -50, -35, -20, -5, 10].map((zz) => [x, zz]);
    sokakEtiketleri.push({ e, x, z, anahtar, adaylar, gx: x, gz: z, gorunur: false, sonBakis: 0 });
  }
  // Görüş denetimi: kameradan noktaya giden ışın bir binayı (dükkân sıraları ya da semtin binaları) kesiyor mu?
  const gorusIsini = new THREE.Ray();
  const gorusYon = new THREE.Vector3();
  const gorusNokta = new THREE.Vector3();
  function noktaGorunur(x, y, z) {
    gorusYon.set(x, y, z).sub(kamera.position);
    const boy = gorusYon.length();
    gorusIsini.set(kamera.position, gorusYon.normalize());
    for (const d of dukkanlar.values()) {
      if (!d.kutu || d.engel) continue; // kesit alınmış (saydamlaşmış) bina görüşü kapatmaz
      const k = gorusIsini.intersectBox(d.kutu, gorusNokta);
      if (k && kamera.position.distanceTo(gorusNokta) < boy - 1) return false;
    }
    const kl = sehir && sehir.binaKutulari;
    if (kl) {
      for (const b of kl) {
        const k = gorusIsini.intersectBox(b, gorusNokta);
        if (k && kamera.position.distanceTo(gorusNokta) < boy - 1) return false;
      }
    }
    return true;
  }
  function sokakEtiketiKonumla(s) {
    const t = performance.now();
    if (t - s.sonBakis < 220) return s.gorunur;
    s.sonBakis = t;
    // bakılan yere en yakın görünen aday seçilir
    const sirali = s.adaylar.slice().sort((a, b) => Math.hypot(a[0] - hedefX, a[1] - hedefZ) - Math.hypot(b[0] - hedefX, b[1] - hedefZ));
    // 0.30: etiket yazısı birkaç metre yer kaplar; yalnızca noktası değil, yazının üst kenarı ve iki yanı da açıkta
    // olmalı (yoksa ad binaların arkasından yarım yamalak görünüyordu)
    const px = (mesafe * 1.15) / Math.max(320, window.innerHeight); // bir ekran pikselinin metre karşılığı
    const w = s.e.offsetWidth ? s.e.offsetWidth / 2 : 70;
    const sagX = Math.cos(aci) * w * px, sagZ = -Math.sin(aci) * w * px;
    const ust = 30 * px;
    const tamGorunur = (ax, az) => noktaGorunur(ax, 0.6, az) && noktaGorunur(ax, ust, az)
      && noktaGorunur(ax + sagX, 0.6, az + sagZ) && noktaGorunur(ax - sagX, 0.6, az - sagZ);
    const bulunan = sirali.find(([ax, az]) => tamGorunur(ax, az));
    s.gorunur = !!bulunan;
    if (bulunan) { s.gx = bulunan[0]; s.gz = bulunan[1]; }
    return s.gorunur;
  }

  // ------------------------------------------------ 0.49: Devlet binaları
  // Batıdaki parkın önünde kaymakamlık ve ilçe belediyesi; il merkezinde meydanın kuzeyinde valilik ve büyükşehir
  // belediyesi; Ankara'da güneydeki ayrılmış bloklarda Cumhurbaşkanlığı Külliyesi, TBMM ve bakanlıklar.
  let devletListesi = null, devletGrubu = null, devletAnahtar = '';
  const devletHedefler = [];
  const DEVLET_BLOK = new Set(['plaza', 'hastane', 'emniyet', 'itfaiye']); // 0.52: şehirdeki ayrılmış bloklarda
  const DEVLET_ROTA = { kaymakamlik: '#/vergi', valilik: '#/ihale', belediye: '#/belediye', ilbelediye: '#/secim/ilbelediye', kulliye: '#/secim/cb', tbmm: '#/secim/mv', bakanlik: '#/ihale', plaza: '#/plaza' };
  // ------------------------------------------------ 0.50: Kamu yapıları ve bağışla verilen adlar
  // Şehirdeki ayrılmış bloklara okullar, kütüphane, spor salonu, millet bahçesi, kilise ya da kültür merkezi kurulur;
  // meydandaki cami, en yakın iki cami ve batıdaki park ad levhası alır. Adlar sunucudan gelir (bağış ya da sistem adı).
  const kamuYerleri = new Map(); // kod → { g, tabelalar: [mesh], isabet }
  const kamuHedefler = [];
  let kamuVeri = null, kamuEkTur = null, kamuGrubu = null;
  function kamuHedefEkle(kod, x, z, en, derin, boy = 14) {
    const h = new THREE.Mesh(new THREE.BoxGeometry(en, boy, derin), new THREE.MeshBasicMaterial({ visible: false }));
    h.position.set(x, boy / 2, z);
    h.userData.kamu = kod;
    kamuGrubu.add(h);
    kamuHedefler.push(h);
    return h;
  }
  function kamuBlokKur(b, kod) {
    const cx = (b.x1 + b.x2) / 2, cz = (b.z1 + b.z2) / 2;
    // ön yüz çekirdeğe (oyuncunun caddesine) bakar
    const dx = -cx, dz = -16 - cz;
    const ry = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Math.PI / 2 : -Math.PI / 2) : (dz > 0 ? 0 : Math.PI);
    const yan = Math.abs(ry) === Math.PI / 2;
    const alan = { en: (yan ? b.z2 - b.z1 : b.x2 - b.x1) - 2, derin: (yan ? b.x2 - b.x1 : b.z2 - b.z1) - 2 };
    const g = kamuYapisi(kod, alan);
    g.position.set(cx, 0.18, cz);
    g.rotation.y = ry;
    kamuBirlestir(g);
    bayraklariTopla(g);
    geceIsiklariniTopla(g); // 0.51: tabelalar ve projektörleri gece yanar
    kamuGrubu.add(g);
    const eski = kamuYerleri.get(b.kod === 'ek' ? 'ek' : kod);
    if (eski) { kamuGrubu.remove(eski.g); bellektenSil(eski.g); if (eski.isabet) { kamuGrubu.remove(eski.isabet); kamuHedefler.splice(kamuHedefler.indexOf(eski.isabet), 1); } }
    const isabet = kamuHedefEkle(kod, cx, cz, b.x2 - b.x1 - 4, b.z2 - b.z1 - 4, kod === 'millet' ? 6 : 16);
    kamuYerleri.set(b.kod === 'ek' ? 'ek' : kod, { kod, g, tabelalar: g.userData.adTabelalari || [], isabet });
  }
  function kamuKur() {
    if (!sehir || !sehir.kamuBloklar) return;
    kamuGrubu = new THREE.Group();
    kamuGrubu.name = 'kamu';
    sahne.add(kamuGrubu);
    for (const b of sehir.kamuBloklar) if (b.kod !== 'ek' && !DEVLET_BLOK.has(b.kod)) kamuBlokKur(b, b.kod);
    // meydandaki cami: girişin önünde ad levhası
    const lg = new THREE.Group();
    const camiLevha = mermerLevha(lg, CAMI.x(), CAMI.z + 14.6 * CAMI.olcek, 7);
    // 0.51: gerçek camilerdeki gibi adı taç kapının üstünde de yazar: yeşil zemin, altın harf, gece projektörle aydınlanır
    const camiAdi = adTabelasi(5.2, 1.0, { zemin: '#0E4D2F', renk: '#E9C46A', kenar: '#C9A24A', w: 1024 });
    camiAdi.scale.setScalar(CAMI.olcek);
    camiAdi.position.set(CAMI.x(), KALDIRIM_Y + (1.1 + 8.75) * CAMI.olcek, CAMI.z + 11.33 * CAMI.olcek + 0.02);
    lg.add(camiAdi);
    tabelaIsiklari(camiAdi, { adet: 3, kol: 0.45 });
    kamuYerleri.set('cami1', { kod: 'cami1', g: lg, tabelalar: [camiLevha, camiAdi], isabet: kamuHedefEkle('cami1', CAMI.x(), CAMI.z, 26 * CAMI.olcek, 26 * CAMI.olcek, 38) });
    // şehirdeki en yakın iki cami
    const yakin = [...(sehir.camiler || [])].sort((a, b) => Math.hypot(a.x, a.z) - Math.hypot(b.x, b.z)).slice(0, 2);
    yakin.forEach((c, i) => {
      const kod = 'cami' + (i + 2);
      const t = mermerLevha(lg, c.x, c.z + 13, 6);
      kamuYerleri.set(kod, { kod, g: lg, tabelalar: [t], isabet: kamuHedefEkle(kod, c.x, c.z, 20, 20, 22) });
    });
    // batıdaki park: devlet binalarının arkasında, ara sokağa bakan kapı
    const pk = new THREE.Group();
    parkKapisi(pk, XB - 9, -47, Math.PI / 2, 6);
    kamuYerleri.set('park', { kod: 'park', g: pk, tabelalar: pk.userData.adTabelalari || [], isabet: kamuHedefEkle('park', XB - 38, -57, 50, 24, 8) });
    birlestir(lg, { tut: (o) => o.userData && o.userData.adTabela });
    birlestir(pk, { tut: (o) => o.userData && o.userData.adTabela });
    geceIsiklariniTopla(lg);
    geceIsiklariniTopla(pk); // 0.51: park kapısının tabelası ve fenerleri gece yanar
    kamuGrubu.add(lg, pk);
    if (kamuVeri) kamuAyarla(kamuVeri);
  }
  // sunucudan gelen adlar: { kilise, yerler: { kod: { ad } } }
  function kamuAyarla(v) {
    kamuVeri = v || null;
    if (!kamuGrubu || !v) return;
    const ekTur = v.kilise ? 'kilise' : 'kultur';
    if (ekTur !== kamuEkTur) {
      const b = sehir.kamuBloklar.find((x) => x.kod === 'ek');
      if (b) kamuBlokKur(b, ekTur);
      kamuEkTur = ekTur;
    }
    for (const [anahtar, y] of kamuYerleri) {
      const kod = anahtar === 'ek' ? kamuEkTur : anahtar;
      const ad = v.yerler && v.yerler[kod] && v.yerler[kod].ad;
      if (ad) for (const t of y.tabelalar) t.userData.yaz(ad);
    }
  }
  // ------------------------------------------------ 0.50: Seçim kampanyası (pankart, seçim aracı, miting)
  let secimVeri = null, secimAnahtar = '', secimGrup = null, miting = null;
  const PANKART_X = () => [XB + 44, GECIT_X + 18, XD - 22, XB + 66].filter((x) => x > XB + 10 && x < XD - 10);
  function secimAyarla(v) {
    secimVeri = v || null;
    if (!kuruldu) return;
    const afis = (v && v.afisler) || [];
    const anahtar = JSON.stringify(afis.map((a) => [a.id, a.ad, a.makam]));
    if (anahtar !== secimAnahtar) {
      secimAnahtar = anahtar;
      if (secimGrup) { sahne.remove(secimGrup); bellektenSil(secimGrup); secimGrup = null; }
      if (afis.length) {
        secimGrup = new THREE.Group();
        secimGrup.name = 'secim-pankart';
        const yerler = PANKART_X();
        afis.slice(0, yerler.length).forEach((a, i) => {
          const p = pankart(`${a.ad.toLocaleUpperCase('tr')} · ${a.makam.toLocaleUpperCase('tr')} ADAYI`, { zemin: SECIM_RENKLERI[a.renk % SECIM_RENKLERI.length], renk: '#FFFFFF' });
          p.position.set(yerler[i], KALDIRIM_Y, i % 2 ? -0.75 : 9.75);
          secimGrup.add(p);
        });
        sahne.add(secimGrup);
      }
    }
    secimAracListesi = ((v && v.araclar) || []).map((a) => ({ arac: true, secim: true, id: 's' + a.id, ad: a.ad, makam: a.makam, renk: a.renk }));
    reklamAraclariAyarla([...sonReklamListesi, ...secimAracListesi]);
    mitingAyarla(v && v.miting);
  }
  // Miting: güneydeki parkta sahne ve kalabalık (başlamadan 10 dakika önce kurulur, bitince kaldırılır)
  function mitingAyarla(m) {
    const t = Date.now();
    const gerek = m && t > m.bas - 10 * 60000 && t < m.bit;
    if (miting && (!gerek || miting.veri.kampanyaId !== m.kampanyaId)) {
      sahne.remove(miting.g); bellektenSil(miting.g);
      for (const k of miting.kalabalik) { sahne.remove(k); bellektenSil(k, { geometri: false }); }
      kalabalik.engelSil(miting.engel);
      miting = null;
    }
    if (miting) { miting.veri = m; return; }
    if (!gerek) return;
    const g = mitingSahnesi(m.ad, m.makam, m.renk);
    // sahne caddeye yakın, önü güneye (kameraya) bakar; kalabalık sahnenin önünde, sırtı kameraya dönük
    const mx = Math.round((XB + XD) / 2) - 22, mz = 26;
    g.position.set(mx, 0.02, mz);
    devletBirlestir(g);
    sahne.add(g);
    const isabet = new THREE.Mesh(new THREE.BoxGeometry(22, 8, 20), new THREE.MeshBasicMaterial({ visible: false }));
    isabet.position.set(mx, 4, mz - 6);
    isabet.userData.miting = true;
    g.add(isabet); isabet.position.set(0, 4, 8);
    // kalabalık: sahneye dönük, gevşek sıralar
    const kal = [];
    const n = K.kod === 'dusuk' ? 10 : 18;
    for (let i = 0; i < n; i++) {
      const y = insanUret('yaya');
      const sira = Math.floor(i / 6), s2 = i % 6;
      y.position.set(mx - 7.5 + s2 * 3 + rnd(-0.8, 0.8), KALDIRIM_Y, mz + 7.5 + sira * 2.4 + rnd(-0.5, 0.5));
      y.rotation.y = Math.PI + rnd(-0.25, 0.25); // kuzeye (sahneye) bakar
      y.userData.insan.oynat(Math.random() < 0.3 ? 'Idle_Talking_Loop' : 'Idle_Loop', 0);
      insanGuncelle(y, 0.05 + Math.random());
      if (Math.random() < 0.35) { y.userData.elSalla = 0.85; y.userData.elFaz = Math.random() * 6; } // adaya el sallayanlar
      sahne.add(y);
      kal.push(y);
    }
    // kürsüde konuşan aday
    const k = insanUret('yaya', { persona: 'orta_yas' });
    const ku = g.userData.kursu;
    k.position.set(mx + ku.x, ku.y + 0.02, mz + ku.z - 0.6);
    k.rotation.y = 0;
    k.userData.insan.oynat('Idle_Talking_Loop', 0);
    insanGuncelle(k, 0.1);
    sahne.add(k);
    kal.push(k);
    miting = { veri: m, g, isabet, kalabalik: kal, engel: kalabalik.engelEkle(mx, mz + 6, 22, 16) };
  }
  let mitingKontrol = 0;
  // 0.50: bayraklar rüzgârda dalgalanır (yalnızca yakındakiler; her bayrak birkaç düzine köşe)
  const bayraklar = new Set();
  function bayraklariTopla(kok) { kok.traverse((o) => { if (o.isMesh && o.userData.bayrak && o.geometry && o.geometry.parameters && o.geometry.parameters.width) bayraklar.add(o); }); }
  const _bayrakP = new THREE.Vector3();
  let bayrakKare = 0;
  function bayraklariDalgalandir(t) {
    if (!bayraklar.size || (K.kod === 'dusuk' && (bayrakKare++ & 1))) return;
    const r = hava && Number.isFinite(Number(hava.ruzgar)) ? Number(hava.ruzgar) : 14;
    const guc = 0.05 + Math.min(1, r / 40) * 0.16, hiz = 3 + Math.min(40, r) / 8;
    for (const b of bayraklar) {
      if (!b.parent) { bayraklar.delete(b); continue; }
      b.getWorldPosition(_bayrakP);
      if (_bayrakP.distanceToSquared(kamera.position) > 19600) continue;
      const geo = b.geometry, p = geo.attributes.position, en = geo.parameters.width;
      for (let i = 0; i < p.count; i++) { const u = (p.getX(i) + en / 2) / en; p.setZ(i, Math.sin(u * 5.5 - t * hiz + p.getY(i) * 0.8) * guc * u * en * 0.5); }
      p.needsUpdate = true; geo.computeVertexNormals();
    }
  }
  // 0.50: gündüz caminin ve meydanın üstünde dönen güvercin sürüsü (tek örnekli çizim)
  let guvercinler = null;
  function guvercinSurusu(t, dt) {
    const gorunur = gecePayi < 0.5 && !yagis && !introCekim;
    if (!guvercinler) {
      if (!gorunur) return;
      const n = K.kod === 'dusuk' ? 8 : 16;
      const kanat = new THREE.BufferGeometry();
      kanat.setAttribute('position', new THREE.BufferAttribute(new Float32Array([
        0.22, 0, 0, -0.18, 0.02, 0, 0, 0.03, 0.05, 0.22, 0, 0, 0, 0.03, -0.05, -0.18, 0.02, 0,
        0.05, 0.02, 0, -0.06, 0.02, 0, -0.02, 0.06, 0.34, 0.05, 0.02, 0, -0.02, 0.06, -0.34, -0.06, 0.02, 0,
      ]), 3));
      kanat.computeVertexNormals();
      const m = new THREE.InstancedMesh(kanat, new THREE.MeshLambertMaterial({ color: '#7D8590', side: THREE.DoubleSide }), n);
      m.frustumCulled = false;
      m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      guvercinler = { m, n, faz: Array.from({ length: n }, () => Math.random() * 6), ofs: Array.from({ length: n }, () => [Math.random() * 7 - 3.5, Math.random() * 3 - 1.5, Math.random() * 7 - 3.5]) };
      sahne.add(m);
    }
    const g = guvercinler;
    g.m.visible = !!gorunur;
    if (!gorunur) return;
    const cx = XD + 30, cz = -20, a = t * 0.11;
    const mx = cx + Math.cos(a) * 34, mz = cz + Math.sin(a * 1.3) * 18, my = 22 + Math.sin(a * 0.7) * 5;
    const yon = Math.atan2(-(Math.cos(a * 1.3) * 1.3 * 18), -Math.sin(a) * 34);
    const mat = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), sc = new THREE.Vector3(), p = new THREE.Vector3();
    for (let i = 0; i < g.n; i++) {
      g.faz[i] += dt * (11 + (i % 3));
      const o = g.ofs[i];
      const ci = Math.sin(g.faz[i]);
      e.set(0, yon + Math.sin(t * 0.7 + i) * 0.2, Math.sin(t + i) * 0.15); q.setFromEuler(e);
      mat.compose(p.set(mx + o[0] + Math.sin(t * 0.9 + i) * 1.2, my + o[1] + Math.sin(t * 1.7 + i) * 0.5, mz + o[2]), q, sc.set(1.4, 1.4 + ci * 1.2, 1.4));
      g.m.setMatrixAt(i, mat);
    }
    g.m.instanceMatrix.needsUpdate = true;
  }
  // 0.50.2: gece gösterisi: caminin projektör ve şerefe ışıkları, plazanın renk değiştiren LED şeritleri
  const ledKoyu = new THREE.Color('#4A5460');
  function geceGosterisi(t) {
    const gece = isikAcikPayi;
    if (meydanCamisi) meydanCamisi.userData.isik(gece, t);
    for (const m of ledler) {
      if (gece < 0.03) { if (!m.color.equals(ledKoyu)) m.color.copy(ledKoyu); continue; }
      m.color.setHSL((t * 0.035 + (m.userData.led === 2 ? 0.5 : 0)) % 1, 0.85, 0.58).lerp(ledKoyu, 1 - gece);
    }
  }
  function mitingGuncelle(dt) {
    mitingKontrol += dt;
    if (!miting && secimVeri && secimVeri.miting && mitingKontrol > 3) { mitingKontrol = 0; mitingAyarla(secimVeri.miting); }
    if (!miting) return;
    if (Date.now() > miting.veri.bit) { mitingAyarla(null); return; }
    for (const k of miting.kalabalik) if (mesafe < 120 && ekrandaMi(k.position, 2)) insanGuncelle(k, dt);
  }
  // bilboardu yeni yerine taşır (x verilmezse ilk yerine döner); yaya engeli de taşınır
  function bilboardTasi(no, x, z) {
    const b = bilboardlar.find((y) => y.no === no);
    if (!b) return;
    const nx = x == null ? b.ilkX : x, nz = z == null ? b.ilkZ : z;
    b.g.position.x = nx; b.g.position.z = nz;
    b.isabet.position.x = nx; b.isabet.position.z = nz;
    kalabalik.engelSil(b.engel);
    b.engel = kalabalik.engelEkle(nx, nz, 1.5, 1.5);
  }
  function devletAyarla(liste) {
    const anahtar = JSON.stringify(liste || []);
    if (anahtar === devletAnahtar) return;
    devletAnahtar = anahtar;
    devletListesi = liste || [];
    if (kuruldu) devletKur();
  }
  const devletEngeller = [];
  // blok kenarına ağaç: ön kenarda (caddeye bakan) ve binanın üstünde olmaz
  function agacKoy(g, x, z, fx, fz, cx, cz, W, D, olcek, iz) {
    const on = (x - cx) * fx + (z - cz) * fz; // ön yöne uzaklık
    const yari = Math.abs(fx) ? W / 2 : D / 2;
    if (on > yari - 4) return;
    const yanUz = Math.abs((x - cx) * fz - (z - cz) * fx);
    if (yanUz < (iz.en * olcek) / 2 + 1.5 && on > yari - 4 - iz.derin * olcek - 2) return;
    const a = agac();
    a.scale.setScalar(0.85);
    a.position.set(x, 0.18, z);
    g.add(a);
  }
  // 0.52: şehirdeki ayrılmış bloğa kurum binası: ön yüz çekirdeğe döner, bina bloğun o kenarına yaslanır, sığmazsa küçülür
  function devletBlokKur(g, b, x) {
    const bina = devletBinasi(x.tur, x.ad);
    const iz = bina.userData.ayakIzi;
    const cx = (b.x1 + b.x2) / 2, cz = (b.z1 + b.z2) / 2;
    const dx = -cx, dz = -16 - cz;
    const ry = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? Math.PI / 2 : -Math.PI / 2) : (dz > 0 ? 0 : Math.PI);
    const yan = Math.abs(ry) === Math.PI / 2;
    const alanEn = (yan ? b.z2 - b.z1 : b.x2 - b.x1) - 3, alanDerin = (yan ? b.x2 - b.x1 : b.z2 - b.z1) - 3;
    const olcek = Math.min(x.tur === 'plaza' ? 1 : 1.2, alanEn / iz.en, alanDerin / iz.derin);
    bina.scale.setScalar(olcek);
    const kay = Math.max(0, alanDerin / 2 - iz.onZ * olcek); // ön kenar bloğun ön kenarına
    bina.rotation.y = ry;
    bina.position.set(cx + Math.sin(ry) * kay, 0.18, cz + Math.cos(ry) * kay);
    g.add(bina);
    // bloğun arka ve yan kenarlarında ağaç sırası (ön yüz caddeye açık)
    const W = b.x2 - b.x1, D = b.z2 - b.z1;
    const fx = Math.round(Math.sin(ry)), fz = Math.round(Math.cos(ry));
    for (let t = 3; t <= W - 3; t += 8) for (const z of [b.z1 + 2.5, b.z2 - 2.5]) agacKoy(g, b.x1 + t, z, fx, fz, cx, cz, W, D, olcek, iz);
    for (let t = 3; t <= D - 3; t += 8) for (const x of [b.x1 + 2.5, b.x2 - 2.5]) agacKoy(g, x, b.z1 + t, fx, fz, cx, cz, W, D, olcek, iz);
    const h = new THREE.Mesh(new THREE.BoxGeometry(b.x2 - b.x1 - 4, x.tur === 'plaza' ? 70 : 22, b.z2 - b.z1 - 4), new THREE.MeshBasicMaterial({ visible: false }));
    h.position.set(cx, x.tur === 'plaza' ? 35 : 11, cz);
    h.userData.devlet = { tur: x.tur, ad: x.ad, rota: DEVLET_ROTA[x.tur] || null };
    h.userData.ry = ry;
    g.add(h);
    devletHedefler.push(h);
    return bina;
  }
  function devletKur() {
    if (devletGrubu) { sahne.remove(devletGrubu); bellektenSil(devletGrubu); devletGrubu = null; }
    // 0.51: eski binaların yaya engelleri de kalkar (gezintide binalar değişir)
    for (const e of devletEngeller.splice(0)) kalabalik.engelSil(e);
    devletHedefler.length = 0;
    const l = devletListesi || [];
    if (!l.length) return;
    const g = new THREE.Group();
    g.name = 'devlet';
    // F: binanın ön yüzünün (merdiven ucu) dünya z'si; kuzeye bakan (yon -1) binalar 180° döner
    const koy = (x, ad, tur, F, yon = 1, no = 0) => {
      const b = devletBinasi(tur, ad, no);
      const iz = b.userData.ayakIzi;
      b.rotation.y = yon > 0 ? 0 : Math.PI;
      b.position.set(x, KALDIRIM_Y, yon > 0 ? F - iz.onZ : F + iz.onZ);
      g.add(b);
      // zemin: binanın altı ve önü taş kaplı meydan
      const z1 = yon > 0 ? F - iz.derin - 1 : F, z2 = yon > 0 ? F : F + iz.derin + 1;
      kaldirimX(x - iz.en / 2 - 1.5, x + iz.en / 2 + 1.5, z1, z2, g); // 0.51: bina grubuyla birlikte silinir
      // dokunma kutusu: binayı kaplar
      const h = new THREE.Mesh(new THREE.BoxGeometry(iz.en, 18, iz.derin), new THREE.MeshBasicMaterial({ visible: false }));
      h.position.set(x, 9, (z1 + z2) / 2);
      h.userData.devlet = { tur, ad, rota: DEVLET_ROTA[tur] || '#/belediye' };
      g.add(h);
      devletHedefler.push(h);
      devletEngeller.push(kalabalik.engelEkle(x, (z1 + z2) / 2 - (yon > 0 ? 2 : -2), iz.en, iz.derin - 4));
      return b;
    };
    const yerel = l.filter((x) => ['kaymakamlik', 'valilik', 'belediye', 'ilbelediye'].includes(x.tur));
    // batı: ilk iki (kaymakamlık ya da merkez valiliği ve ilçe belediyesi), doğu meydanı: valilik ve büyükşehir
    const bati = yerel.filter((x) => x.tur === 'kaymakamlik' || x.tur === 'belediye' || (x.tur === 'valilik' && !yerel.some((y) => y.tur === 'kaymakamlik')));
    const dogu = yerel.filter((x) => !bati.includes(x));
    bati.slice(0, 2).forEach((x, i) => koy(XB - 23 - i * 31, x.ad, x.tur, -12.5));
    dogu.slice(0, 2).forEach((x, i) => koy(XD + 25 + i * 34, x.ad, x.tur, -55));
    // 0.52: plaza, devlet hastanesi, emniyet ve itfaiye şehirdeki ayrılmış bloklarda; ön yüzleri oyuncunun caddesine bakar
    for (const x of l) {
      if (!DEVLET_BLOK.has(x.tur)) continue;
      const b = sehir && sehir.kamuBloklar && sehir.kamuBloklar.find((y) => y.kod === x.tur);
      if (b) devletBlokKur(g, b, x);
    }
    // 0.50: bilboardlar binaların önünde tabelaları kapatmasın — batıda iki devlet binasının arasına
    const batiB = g.children.filter((c) => c.userData && c.userData.ayakIzi && Math.abs(c.position.z + 12.5) < 40 && c.position.x < XB);
    if (batiB.length >= 2) {
      const [b1, b2] = [...batiB].sort((a, b) => b.position.x - a.position.x);
      const sag = b2.position.x + b2.userData.ayakIzi.en / 2, sol = b1.position.x - b1.userData.ayakIzi.en / 2;
      bilboardTasi(1, (sag + sol) / 2, -11);
    } else if (batiB.length === 1) {
      const b1 = batiB[0];
      bilboardTasi(1, b1.position.x - b1.userData.ayakIzi.en / 2 - 5, -11);
    } else bilboardTasi(1);
    bilboardTasi(2);
    // Ankara: ayrılmış bloklar (yakından uzağa); Külliye ve TBMM ilk iki blokta, bakanlıklar blok başına dört
    const ankara = l.filter((x) => ['kulliye', 'tbmm', 'bakanlik', 'egm'].includes(x.tur));
    const bloklar = sehir && sehir.ayrilanBloklar ? [...sehir.ayrilanBloklar].sort((a, b) => (a.z1 - b.z1) || Math.abs(a.x1 + a.x2) - Math.abs(b.x1 + b.x2)) : [];
    if (ankara.length && bloklar.length) {
      const kul = ankara.find((x) => x.tur === 'kulliye'), mec = ankara.find((x) => x.tur === 'tbmm');
      const bak = ankara.filter((x) => x.tur === 'bakanlik' || x.tur === 'egm');
      const bos = [...bloklar];
      const al = (enAz) => { const i = bos.findIndex((b) => b.x2 - b.x1 >= enAz && b.z2 - b.z1 >= 30); return i < 0 ? null : bos.splice(i, 1)[0]; };
      const kb = kul && al(50);
      if (kb) koy((kb.x1 + kb.x2) / 2, kul.ad, 'kulliye', kb.z1 + 2, -1);
      const mb = mec && al(56);
      if (mb) koy((mb.x1 + mb.x2) / 2, mec.ad, 'tbmm', mb.z1 + 2, -1);
      let bi = 0;
      for (const b of bos) {
        const w = b.x2 - b.x1, d = b.z2 - b.z1;
        const sutun = Math.max(1, Math.floor(w / 27));
        const yer = [];
        for (let s = 0; s < sutun; s++) yer.push([b.x1 + (w / sutun) * (s + 0.5), b.z1 + 2, -1]);
        if (d >= 50) for (let s = 0; s < sutun; s++) yer.push([b.x1 + (w / sutun) * (s + 0.5), b.z2 - 2, 1]);
        for (const [x, F, yon] of yer) { if (bi >= bak.length) break; koy(x, bak[bi].ad, bak[bi].tur, F, yon, bi); bi++; }
        if (bi >= bak.length) break;
      }
    }
    devletBirlestir(g);
    geceIsiklariniTopla(g);
    bayraklariTopla(g);
    ledler.clear();
    g.traverse((o) => { if (o.isMesh && o.material && o.material.userData && o.material.userData.led) ledler.add(o.material); });
    devletGrubu = g;
    sahne.add(g);
    golgeKirli = true;
  }

  // ------------------------------------------------ Dükkânlar (3 sıra)
  const dukkanlar = new Map(); // no -> { grup, veri, anahtar, etiket, isabet, merkezX, sira }
  const etiketKutusu = document.getElementById('etiketler');

  function dukkanAnahtari(y) {
    const i = y.isletme;
    return i ? `${i.tur}|${i.ad}|${i.durum}|${i.tabela ? `${i.tabela.neon || ''}|${i.tabela.yazi || ''}` : ''}` : 'kiralik';
  }

  let ilkCaddeHazirlik = null;
  function binayiUret(y) {
    const i = y.isletme;
    // 0.40.2: düşük kalitede (zayıf ekran kartlı tablet ve telefonlar) binalar sade kurulur: pencere, cephe, zemin kat,
    // tabela ve kepenk aynı; balkon, klima, saksı, çanak anten gibi küçük ayrıntılar yok (üçgen sayısı yarıdan aza iner)
    return apartman({ genislik:y.genislik, kat:y.kat, derinlik:9, sade: K.kod === 'dusuk' && !introCekim, rng:tohumluRastgele(y.tohum),
      dukkan:i ? {ad:i.ad,tur:i.tur,durum:i.durum,simge:i.simge,tabela:i.tabela || null} : {durum:'kiralik'} });
  }
  async function caddeHazirla(yerler, isimler) {
    if (ilkCaddeHazirlik) { await ilkCaddeHazirlik; return caddeGuncelle(yerler, isimler); }
    if (dukkanlar.size) return caddeGuncelle(yerler, isimler);
    const hazir = new Map();
    ilkCaddeHazirlik = (async () => {
      const siralar = [0,1,2].map(k => yerler.filter(y => (y.sira || 0) === k).sort((a,b) => a.no-b.no));
      const genislikler = siralar.map(l => l.reduce((a,y) => a+y.genislik+.25,0));
      if (!kuruldu) mahalleKur(genislikler);
      const liste = siralar.flatMap((l,k) => {
        const sigdir = Math.min(1,(XD-XB-8.5)/Math.max(1,genislikler[k]));
        return l.map(y => sigdir < 1 ? {...y,genislik:Math.round(y.genislik*sigdir*10)/10} : y);
      });
      let i = 0;
      await parcaliIs(() => { if (i >= liste.length) return false; const y = liste[i++]; hazir.set(y.no,binayiUret(y)); return true; });
      caddeGuncelle(yerler, isimler, false, hazir);
    })();
    try { await ilkCaddeHazirlik; }
    finally { ilkCaddeHazirlik = null; for (const g of hazir.values()) bellektenSil(g); }
  }

  function caddeGuncelle(yerler, isimler, zorla = false, hazirBinalar = null) {
    // başka ilçeyi gezerken kendi caddemizin yenilenen verisi saklanır, ekrana basılmaz
    if (!ziyaret || !zorla) kendiCadde = { yerler, isimler: isimler || (kendiCadde && kendiCadde.isimler) };
    if (ziyaret && !zorla) return;
    if (isimler) {
      for (const s2 of sokakEtiketleri) {
        const b = s2.e.querySelector('button');
        if (b && isimler[s2.anahtar] && b.textContent !== isimler[s2.anahtar]) b.textContent = isimler[s2.anahtar];
      }
      sokakAdlari = isimler;
    }
    const siralar = [0, 1, 2].map((k) => yerler.filter((y) => (y.sira || 0) === k).sort((a, b) => a.no - b.no));
    const genislikler = siralar.map((l) => l.reduce((a, y) => a + y.genislik + 0.25, 0));
    if (!kuruldu) mahalleKur(genislikler);
    siralar.forEach((liste, k) => {
      const S = SIRA[k];
      // başka bir ilçenin (ya da sonradan genişleyen) dükkân sırası ara sokaklara taşmasın: gerekirse sıkıştırılır
      const sigdir = Math.min(1, (XD - XB - 8.5) / Math.max(1, genislikler[k]));
      let bx = (-genislikler[k] / 2) * sigdir;
      for (const y0 of liste) {
        const y = sigdir < 1 ? { ...y0, genislik: Math.round(y0.genislik * sigdir * 10) / 10 } : y0;
        const merkezX = bx + y.genislik / 2;
        bx += y.genislik + 0.25 * sigdir;
        let d = dukkanlar.get(y.no);
        const anahtar = `${dukkanAnahtari(y)}|${merkezX.toFixed(2)}|${y.genislik}|${y.kat || 2}|${k}`; // 0.49.3: yer değişirse bina da taşınır
        if (!d) {
          const etiket = document.createElement('div');
          etiket.className = 'etiket gizli';
          etiketKutusu.appendChild(etiket);
          // tıklama alanı binanın tamamı: cephe, üst katlar ve çatı (kuş bakışında da dokunulabilsin)
          const yukseklik = 4 + (y.kat || 2) * 3.1;
          const isabet = new THREE.Mesh(new THREE.BoxGeometry(y.genislik * 0.96, yukseklik, 9.4), new THREE.MeshBasicMaterial({ visible: false }));
          isabet.position.set(merkezX, yukseklik / 2, S.on - S.yon * 4.3);
          isabet.userData.dukkan = y.no;
          sahne.add(isabet);
          d = { etiket, isabet };
          dukkanlar.set(y.no, d);
        }
        Object.assign(d, { veri: y, merkezX, sira: k, onZ: S.on, yon: S.yon, seritZ: S.serit });
        // 0.49.3: dokunma kutusu bina ile birlikte taşınır. Önceden kutu ilk kurulduğu yerde kalıyordu; dükkân sırası
        // değişince (yeni dükkân, sıkıştırma, başka ilçeyi gezme) bir dükkâna dokununca yanındakinin bilgisi açılıyordu.
        {
          const yukseklik = 4 + (y.kat || 2) * 3.1;
          const boyut = `${y.genislik}:${y.kat || 2}`;
          if (d.isabetBoyut !== undefined && d.isabetBoyut !== boyut) {
            d.isabet.geometry.dispose();
            d.isabet.geometry = new THREE.BoxGeometry(y.genislik * 0.96, yukseklik, 9.4);
          }
          d.isabetBoyut = boyut;
          d.isabet.position.set(merkezX, yukseklik / 2, S.on - S.yon * 4.3);
          d.isabet.userData.dukkan = y.no;
        }
        if (d.anahtar !== anahtar) {
          if (d.grup) {
            sahne.remove(d.grup);
            saydamlikUygula(d, 1); // saydam kopyalar silinir, asıl malzemeler geri takılır
            bellektenSil(d.grup);
          }
          if (d.uzak) { sahne.remove(d.uzak); bellektenSil(d.uzak); d.uzak = null; }
          topluBinalariSil();
          caddeBirlesimSil();
          d.saydamlik = 1;
          d.golgeVar = true;
          const i = y.isletme;
          d.grup = hazirBinalar?.get(y.no) || binayiUret(y);
          hazirBinalar?.delete(y.no);
          d.grup.position.set(merkezX, KALDIRIM_Y, S.on - S.yon * 4.5);
          d.grup.rotation.y = S.yon > 0 ? 0 : Math.PI;
          sahne.add(d.grup);
          d.kutu = new THREE.Box3().setFromObject(d.grup);
          geceIsiklariniTopla(d.grup);
          d.uzakAyar = { genislik: y.genislik, kat: y.kat, tohum: y.tohum, dukkan: i ? { ad: i.ad, tur: i.tur, durum: i.durum, simge: i.simge, tabela: i.tabela || null } : { durum: 'kiralik' }, x: merkezX, z: S.on - S.yon * 4.5, ry: S.yon > 0 ? 0 : Math.PI };
          d.uzakta = false;
          d.anahtar = anahtar;
          d.etiketDurum = '';
        }
        dukkanEtiketi(d);
      }
    });
    // 0.41: listede olmayan eski dükkânlar (başka sokağa ya da başka ilçeye geçilince) kaldırılır
    const gelen = new Set(yerler.map((y) => y.no));
    for (const [no, d] of dukkanlar) {
      if (gelen.has(no)) continue;
      if (d.grup) { sahne.remove(d.grup); saydamlikUygula(d, 1); bellektenSil(d.grup); }
      if (d.uzak) { sahne.remove(d.uzak); bellektenSil(d.uzak); }
      if (d.isabet) { sahne.remove(d.isabet); d.isabet.geometry.dispose(); }
      if (d.etiket) d.etiket.remove();
      dukkanlar.delete(no);
      topluBinalariSil();
      caddeBirlesimSil();
    }
    topluBinalarIste();
    caddeBirlesimIste();
  }

  // Dükkânların üstünde yazı balonu yok: ad tabelada, kapalıysa kepenkte "🌙 KAPALI" yazar.
  // Yalnızca kendi dükkânının önünde, tezgâhtaki "+" çerçevesi gibi yavaşça yanıp sönen bir dokunma işareti durur.
  // ------------------------------------------------ Reklam panoları
  function panoCiz() {
    panolar.forEach((p, i) => {
      const r = reklamlar.length ? reklamlar[(panoSira + i) % reklamlar.length] : null;
      p.gosterilen = r;
      if (!r) {
        p.g.userData.ciz({ baslik: i ? npcMetni('Mahallenin yıldızı sen ol') : npcMetni('Burada reklamın olabilir'), alt: npcMetni('Dükkânına reklam ver'), simge: '📣', sira: i + 3, sistem: true });
        return;
      }
      if (r.kutlama) { p.g.userData.ciz({ baslik: r.ad, alt: '@' + r.oyuncu, simge: r.simge || '🎉', sira: panoSira + i }); return; }
      const d = [...dukkanlar.values()].find((x) => x.veri && x.veri.no === r.yerNo);
      const simge = d && d.veri.isletme ? d.veri.isletme.simge : '🏪';
      p.g.userData.ciz({ baslik: r.ad, alt: npcMetni(['Hemen yanı başında!', 'Mahallenin gözdesi', 'Kaliteli ve uygun', 'Bekliyoruz!'][(panoSira + i) % 4]), simge, sira: panoSira + i });
    });
  }
  // 0.49.7: reklam araçları: ilçede reklam aracı kampanyası süren dükkânlar dijital ekranlı kamyonlarla sokaklarda gezer.
  // En çok 3 araç; her araç kendi reklamını ve (birden çok kampanya varsa) diğerlerini 9 saniyede bir sırayla gösterir.
  const reklamAraclari = [];
  let reklamAracListesi = [], sonAracReklam = 0, reklamAracAnahtar = '';
  function reklamAraclariAyarla(liste) {
    reklamAracListesi = (liste || []).filter((x) => x.arac).slice(0, 12);
    if (!kuruldu || !SERITLER.length) return;
    const anahtar = JSON.stringify(reklamAracListesi.map((x) => [x.id, x.ad, x.tur]));
    if (anahtar === reklamAracAnahtar && reklamAraclari.length === Math.min(3, reklamAracListesi.length)) return;
    reklamAracAnahtar = anahtar;
    const istenen = Math.min(3, reklamAracListesi.length);
    while (reklamAraclari.length > istenen) {
      const a = reklamAraclari.pop();
      const i = arabalar.indexOf(a); if (i > -1) arabalar.splice(i, 1);
      for (const h of a.userData.araba.haleler) gecelik.haleler.delete(h);
      sahne.remove(a); bellektenSil(a);
    }
    const baslangic = SERITLER.filter((s) => s.bas === 'uzak' && s.eksen === 'x');
    while (reklamAraclari.length < istenen && baslangic.length) {
      const n = reklamAraclari.length;
      const a = reklamAraci();
      a.userData.reklam.dijital = K.golge !== false;
      const sr = baslangic[n % baslangic.length];
      const p = (sr.yon > 0 ? sr.min : sr.max) + sr.yon * (30 + n * 37);
      const [px, pz] = seritKonum(sr, p);
      a.position.set(px, 0.02, pz);
      a.rotation.y = seritAcisi(sr);
      Object.assign(a.userData, { serit: sr, p, hiz: rnd(4.5, 6), azami: rnd(6, 7.5), tur: 'kamyon', dolasan: 'reklam-' + n, reklamSira: n });
      a.userData.araba.haleler.forEach((h) => gecelik.haleler.add(h));
      sahne.add(a);
      arabalar.push(a);
      reklamAraclari.push(a);
    }
    reklamAraciCiz(true);
  }
  function reklamAraciCiz(hepsi = false) {
    const l = reklamAracListesi;
    if (!l.length) return;
    reklamAraclari.forEach((a, i) => {
      const r = l[(a.userData.reklamSira + i) % l.length];
      const anahtar = r.id + ':' + r.ad;
      if (!hepsi && a.userData.reklamGosterilen === anahtar && l.length === 1) return;
      a.userData.reklamGosterilen = anahtar;
      // tek kampanya varsa ad ile davet sırayla döner
      const ikinci = l.length === 1 && a.userData.reklamSira % 2 === 1;
      // 0.50: seçim aracı: adayın adı ve makamı, "oyunu ver" çağrısı
      if (r.secim) a.userData.reklam.goster({ baslik: r.ad, alt: ikinci ? npcMetni('Oyunu ver!') : npcSablon`${r.makam} adayı`, simge: '🗳️', renk: r.renk || 0 });
      else a.userData.reklam.goster({ baslik: r.ad, alt: ikinci ? npcMetni('Hemen uğra!') : npcMetni('Mahallende, kapın açık'), simge: dukkanSimgesi(r.yerNo), renk: Number(r.id) || 0 });
    });
  }
  const dukkanSimgesi = (no) => { const d = dukkanlar.get(no); return (d && d.veri && d.veri.isletme && d.veri.isletme.simge) || '🛍️'; };
  let sonReklamListesi = [], secimAracListesi = [];
  function reklamlariAyarla(l) {
    sonReklamListesi = (l || []).filter((x) => !x.kutlama);
    reklamAraclariAyarla([...sonReklamListesi, ...secimAracListesi]);
    const anahtar = JSON.stringify(l || []);
    if (anahtar === JSON.stringify(reklamlar)) return;
    reklamlar = l || [];
    panoCiz();
  }
  function panoGuncelle(t) {
    for (const p of panolar) p.g.userData.yuz.emissiveIntensity = 0.22 + gecePayi * 0.95;
    if (reklamlar.length > 1 && t - sonPano > 7) { sonPano = t; panoSira++; panoCiz(); }
    for (const b of bilboardlar) b.g.userData.yuz.emissiveIntensity = 0.2 + gecePayi * 0.9;
    // her bilboardda en çok 5 reklam, 8 saniyede bir sıradakine geçer
    if (reklamAraclari.length && t - sonAracReklam > 9) { sonAracReklam = t; for (const a of reklamAraclari) a.userData.reklamSira++; reklamAraciCiz(); }
    if (t - sonBilboard > 8) { sonBilboard = t; let degisti = false; for (const b of bilboardlar) { const l = bilboardReklamlari(b.no); if (l.length > 1) { b.sira = (b.sira + 1) % l.length; degisti = true; } } if (degisti) bilboardCiz(); }
  }
  // ------------------------------------------------ Bilboardlar (0.43)
  const bilboardReklamlari = (no) => ((bilboardVeri.find((x) => x.no === no) || {}).reklamlar || []);
  function bilboardCiz() {
    for (const b of bilboardlar) {
      const l = bilboardReklamlari(b.no);
      if (b.sira >= l.length) b.sira = 0;
      const r = l[b.sira] || null;
      const anahtar = r ? r.id + ':' + b.sira + ':' + l.length : 'bos';
      b.gosterilen = r;
      if (b.cizilen === anahtar) continue;
      b.cizilen = anahtar;
      if (!r) b.g.userData.ciz({ baslik: npcMetni('Bu alanı kiralayın'), alt: npcMetni('Dokun, reklamını ver'), simge: '🪧', renk: b.no, sistem: true });
      else b.g.userData.ciz({ baslik: r.baslik, alt: r.alt, simge: r.simge, renk: r.renk, veren: r.oyuncu, sira: b.sira, adet: l.length });
    }
  }
  function bilboardlariAyarla(l) {
    const anahtar = JSON.stringify(l || []);
    if (anahtar === JSON.stringify(bilboardVeri)) return;
    bilboardVeri = l || [];
    bilboardCiz();
  }

  function dukkanEtiketi(d) {
    const i = d.veri.isletme;
    let html = '';
    if (i && i.benim) {
      const kasa = i.kasa > 0 && i.durum !== 'ruhsat';
      const ad = `${esc(i.ad)}${i.durum === 'ruhsat' ? ' (ruhsat bekliyor)' : ''}${kasa ? `, kasada ${sade(i.kasa)} ₺` : ''}`;
      html = `<button class="dukkan-isaret${kasa ? ' kasa' : ''}${i.durum === 'ruhsat' ? ' bekliyor' : ''}" data-dukkan="${d.veri.no}" aria-label="${ad}"><i></i></button>`;
    }
    // 0.40: kiralık dükkânın işaretinde numarası ve arka sokakta olduğu yazar (taşırken ve kiralarken karışmasın)
    if (!i || i.durum === 'kiralik') html = `<button class="dukkan-isaret kiralik" data-dukkan="${d.veri.no}" aria-label="${npcMetni('Kiralık dükkânı incele')} · No ${d.veri.no}"><i></i><span class="dukkan-no${(d.veri.sira || 0) > 0 ? ' arka' : ''}">${d.veri.no}</span></button>`;
    if (d.etiketDurum !== html) { d.etiket.innerHTML = html; d.etiketDurum = html; }
  }

  // Günün saatine göre sokak yoğunluğu: işe gidiş, öğle ve iş çıkışı en kalabalık saatler
  const YOGUNLUK = [0.2, 0.15, 0.1, 0.1, 0.12, 0.25, 0.55, 1, 1, 0.75, 0.6, 0.65, 0.95, 0.9, 0.65, 0.6, 0.7, 1, 1, 0.95, 0.7, 0.5, 0.4, 0.3];
  function yogunluk() {
    const s = oyunSaati();
    const a = Math.floor(s) % 24;
    const b = (a + 1) % 24;
    const k = s - Math.floor(s);
    return YOGUNLUK[a] * (1 - k) + YOGUNLUK[b] * k;
  }

  // ------------------------------------------------ Trafik ışıkları
  // x yönündeki (doğu-batı) ve z yönündeki (kuzey-güney) trafik sırayla yeşil yanar
  // her yeşilden sonra kısa bir "hepsi kırmızı" süresi: kavşakta kalan araba çıkmadan öbür yön kalkmaz
  const DONGU = [['x-yesil', 20], ['x-sari', 3], ['kirmizi', 2], ['z-yesil', 14], ['z-sari', 3], ['kirmizi', 2]];
  let isikEvre = 0;
  let isikSure = rnd(0, 15);
  function isikAdi() { return DONGU[isikEvre][0]; }
  function yesilMi(eksen) { return isikAdi() === eksen + '-yesil'; }
  function sariMi(eksen) { return isikAdi() === eksen + '-sari'; }

  function isikGuncelle(dt) {
    isikSure += dt;
    if (isikSure > DONGU[isikEvre][1]) { isikSure = 0; isikEvre = (isikEvre + 1) % DONGU.length; }
    for (const { grup, eksen } of isiklar) {
      const { lambalar: l, yaya } = grup.userData.lamba;
      const acik = { kirmizi: !yesilMi(eksen) && !sariMi(eksen), sari: sariMi(eksen), yesil: yesilMi(eksen) };
      for (const k of ['kirmizi', 'sari', 'yesil']) {
        l[k].m.emissiveIntensity = acik[k] ? 3 : 0;
        l[k].h.material.opacity = acik[k] ? 0.5 + gecePayi * 0.5 : 0;
      }
      // yayalar, o yöndeki araç trafiği kırmızıyken geçer
      const gec = eksen === 'x' ? yesilMi('z') : yesilMi('x');
      yaya.gec.emissiveIntensity = gec ? 3 : 0;
      yaya.dur.emissiveIntensity = gec ? 0 : 3;
    }
  }

  // ------------------------------------------------ Trafik
  // Şeritler yalnızca asfaltın olduğu yerlerde uzanır. Ana cadde ve ara sokakların kuzey ucu çevre ızgaranın caddelerine
  // bağlanır (sisin içinde, uzakta); arabalar yola orada girer ve orada çıkar. Ara sokakların güney ucu ve arka sokağın
  // iki ucu kavşakta biter: arabalar oraya gelince sağa ya da sola döner (yolun olmadığı bina aralarından ya da parktan
  // araç çıkmaz). Ana caddedekiler de ara sıra ara sokaklara döner.
  const arabalar = [];
  let SERITLER = [];
  let KAVSAKLAR = [];
  const donenler = [];      // kavşakta dönen arabalar (şeritten çıkmış, eğri üstünde)
  const disEngeller = new Set(); // şerit dışında yolda duran/yanaşan görev araçları
  const UZAK = 170;         // ana caddenin iki yanda, ara sokakların kuzeyde uzandığı mesafe (sisin içi)
  // Türkiye sokaklarındaki araç karışımı: sedan ve hatchback çoğunlukta, SUV, hafif ticari (Doblo tipi), sarı taksi ve dolmuş
  const TURLER = ['sedan', 'hatchback', 'sedan', 'taksi', 'suv', 'kombi', 'sedan', 'hatchback', 'dolmus', 'taksi', 'suv', 'sedan', 'kombi', 'hatchback'];

  function seritKonum(s, p) {
    return s.eksen === 'x' ? [p, s.sabit] : [s.sabit, p];
  }
  function seritAcisi(s) {
    return s.eksen === 'x' ? (s.yon > 0 ? 0 : Math.PI) : (s.yon > 0 ? -Math.PI / 2 : Math.PI / 2);
  }
  // Dönüş eğrisi: kaynak şeritten hedef şeride, iki şeridin kesiştiği köşe (C) kontrol noktası olan ikinci derece Bezier.
  // r: köşeden ne kadar önce dönmeye başlanır (sağa dönüş dar, sola dönüş geniş)
  function donus(kaynak, hedef, r) {
    const C = kaynak.eksen === 'x' ? [hedef.sabit, kaynak.sabit] : [kaynak.sabit, hedef.sabit];
    const kose = kaynak.eksen === 'x' ? hedef.sabit : hedef.sabit; // kaynak ekseninde köşenin konumu
    const pA = kose - kaynak.yon * r;
    const pB = (kaynak.eksen === 'x' ? kaynak.sabit : kaynak.sabit) + hedef.yon * r;
    const A = seritKonum(kaynak, pA);
    const B = seritKonum(hedef, pB);
    // yay uzunluğu (örnekleyerek)
    let uz = 0;
    let [px, pz] = A;
    for (let i = 1; i <= 12; i++) {
      const [x, z] = bezier(A, C, B, i / 12);
      uz += Math.hypot(x - px, z - pz);
      px = x; pz = z;
    }
    // sağa mı sola mı: gidiş yönleri arasındaki dönüşün işareti (x doğu, z güney; +z sağ taraf)
    const kv = kaynak.eksen === 'x' ? [kaynak.yon, 0] : [0, kaynak.yon];
    const hv = hedef.eksen === 'x' ? [hedef.yon, 0] : [0, hedef.yon];
    const taraf = kv[0] * hv[1] - kv[1] * hv[0] > 0 ? 'sag' : 'sol';
    return { kaynak, hedef, r, A, B, C, pA, pB, uz, taraf, hiz: 2.2 + r * 1.1 };
  }
  function bezier(A, C, B, t) {
    const u = 1 - t;
    return [u * u * A[0] + 2 * u * t * C[0] + t * t * B[0], u * u * A[1] + 2 * u * t * C[1] + t * t * B[1]];
  }
  function bezierTurev(A, C, B, t) {
    return [2 * (1 - t) * (C[0] - A[0]) + 2 * t * (B[0] - C[0]), 2 * (1 - t) * (C[1] - A[1]) + 2 * t * (B[1] - C[1])];
  }

  function trafikKur() {
    const L1 = XB - UZAK;
    const L2 = XD + UZAK;
    const KZ = -75 - UZAK;
    const anaDogu = { eksen: 'x', sabit: 5.3, yon: 1, min: L1, max: L2, dur: [XB - 4.7, GECIT_X - 2.8, XD - 4.7], bas: 'uzak', son: 'uzak' };
    const anaBati = { eksen: 'x', sabit: 2.4, yon: -1, min: L1, max: L2, dur: [XD + 4.7, GECIT_X + 2.8, XB + 4.7], bas: 'uzak', son: 'uzak' };
    const arkaDogu = { eksen: 'x', sabit: B_Z + 1.7, yon: 1, min: XB - 3.5, max: XD + 3.5, dur: [XD - 4.7], bas: 'donus', son: 'donus' };
    const arkaBati = { eksen: 'x', sabit: B_Z - 1.7, yon: -1, min: XB - 3.5, max: XD + 3.5, dur: [XB + 4.7], bas: 'donus', son: 'donus' };
    SERITLER = [anaDogu, anaBati, arkaDogu, arkaBati];
    const ara = {};
    for (const X of [XB, XD]) {
      const guneye = { eksen: 'z', sabit: X - 1.7, yon: 1, min: KZ, max: 8.4, dur: [B_Z - B_YARI - 1, -0.8], bas: 'uzak', son: 'donus' };
      const kuzeye = { eksen: 'z', sabit: X + 1.7, yon: -1, min: KZ, max: 8.4, dur: [B_Z + B_YARI + 1], bas: 'donus', son: 'uzak' };
      SERITLER.push(guneye, kuzeye);
      ara[X] = { guneye, kuzeye };
    }
    for (const s of SERITLER) s.cikislar = [];
    // 0.50: karşı şerit (sollama için): aynı yolun öbür yönü
    anaDogu.karsi = anaBati; anaBati.karsi = anaDogu; arkaDogu.karsi = arkaBati; arkaBati.karsi = arkaDogu;
    for (const X of [XB, XD]) { ara[X].guneye.karsi = ara[X].kuzeye; ara[X].kuzeye.karsi = ara[X].guneye; }
    const SAG = 2.0, SOL = 3.4;
    const cikis = (s, secenekler, olasilik) => s.cikislar.push({ secenekler, olasilik, zorunlu: olasilik >= 1, p: Math.min(...secenekler.map((d) => d.pA * s.yon)) * s.yon });
    for (const X of [XB, XD]) {
      const { guneye, kuzeye } = ara[X];
      // ana caddeden ara sokağa (kuzeye) dönüş
      cikis(anaDogu, [donus(anaDogu, kuzeye, SOL)], 0.16);
      cikis(anaBati, [donus(anaBati, kuzeye, SAG)], 0.16);
      // ara sokağın güney ucu ana caddede biter: sağa (batıya) ya da sola (doğuya)
      cikis(guneye, [donus(guneye, anaBati, SAG), donus(guneye, anaDogu, SOL)], 1);
    }
    // ara sokaklardan arka sokağa
    cikis(ara[XB].guneye, [donus(ara[XB].guneye, arkaDogu, SOL)], 0.3);
    cikis(ara[XD].guneye, [donus(ara[XD].guneye, arkaBati, SAG)], 0.3);
    cikis(ara[XB].kuzeye, [donus(ara[XB].kuzeye, arkaDogu, SAG)], 0.3);
    cikis(ara[XD].kuzeye, [donus(ara[XD].kuzeye, arkaBati, SOL)], 0.3);
    // arka sokağın uçları: kavşakta sağa ya da sola
    cikis(arkaDogu, [donus(arkaDogu, ara[XD].guneye, SAG), donus(arkaDogu, ara[XD].kuzeye, SOL)], 1);
    cikis(arkaBati, [donus(arkaBati, ara[XB].kuzeye, SAG), donus(arkaBati, ara[XB].guneye, SOL)], 1);
    for (const s of SERITLER) s.cikislar.sort((a, b) => (a.p - b.p) * s.yon);

    // kavşak kutuları: içinde öbür yönden bir araba varken kavşağa girilmez
    KAVSAKLAR = [];
    for (const X of [XB, XD]) {
      KAVSAKLAR.push({ x1: X - 3.6, x2: X + 3.6, z1: 0.1, z2: 8.7, dolu: { x: false, z: false } });
      KAVSAKLAR.push({ x1: X - 3.6, x2: X + 3.6, z1: B_Z - B_YARI - 0.1, z2: B_Z + B_YARI + 0.1, dolu: { x: false, z: false } });
    }
    // arabalar yalnızca uzak uçtan başlayan şeritlere dağıtılır (arka sokağa ve kuzeye giden şeride dönerek girilir)
    const baslangic = SERITLER.filter((s) => s.bas === 'uzak');
    const adet = Math.max(Math.round(K.araba * 1.7) + 4, 10);
    for (let i = 0; i < adet; i++) {
      const s = baslangic[i % baslangic.length];
      const tur = TURLER[i % TURLER.length];
      const a = araba(tur);
      // görünür kısma yakın başlasınlar: şeridin ilk 3/4'ünde, birbirinden aralıklı
      const ilk = s.cikislar.find((c) => c.zorunlu);
      const son = ilk ? ilk.p - s.yon * 12 : (s.yon > 0 ? s.max : s.min);
      const bas = s.yon > 0 ? s.min : s.max;
      const p = bas + (son - bas) * (0.08 + ((i * 0.37) % 1) * 0.84);
      const [x, z] = seritKonum(s, p);
      a.position.set(x, 0.02, z);
      a.rotation.y = seritAcisi(s);
      Object.assign(a.userData, { serit: s, p, hiz: rnd(5, 8), azami: s.eksen === 'x' && s.sabit > 0 ? rnd(8, 11) : rnd(6, 8), tur });
      a.userData.araba.haleler.forEach((h) => gecelik.haleler.add(h));
      sahne.add(a);
      arabalar.push(a);
    }
    // şeritte üst üste başlayanlar ayrılır
    for (const s of SERITLER) {
      const l = arabalar.filter((a) => a.userData.serit === s).sort((a, b) => (a.userData.p - b.userData.p) * s.yon);
      for (let i = 1; i < l.length; i++) if ((l[i].userData.p - l[i - 1].userData.p) * s.yon < 9) l[i].visible = false;
    }
    // park yerleri: bir kısmı dolu başlar
    for (let px = XB + 10; px < XD - 8; px += rnd(9, 14)) {
      // yaya geçidi ve otobüs durağının önüne park edilmez
      if (Math.abs(px - GECIT_X) < 7 || Math.abs(px - Math.min(55, XD - 12)) < 9) continue;
      // konteynerlerin önüne de park edilmez (çöp kamyonu yanaşır)
      if (konteynerler.some((k) => k.yolZ > 7 && k.yolZ < 8 && Math.abs(px - k.x) < 5.5)) continue;
      const yer = { x: px, araba: null, sure: 0 };
      if (Math.random() < 0.6) {
        const a = araba(['sedan', 'hatchback', 'sedan', 'suv', 'kombi', 'hatchback'][Math.floor(Math.random() * 6)]);
        a.position.set(px, 0.02, 7.25);
        farlar(a, false);
        lambaAyarla(a, 0);
        sahne.add(a);
        Object.assign(a.userData, { durum: 'park', hiz: 0, azami: rnd(6, 8), tur: 'sedan' });
        yer.araba = a;
        yer.sure = rnd(20, 200);
      }
      parkYerleri.push(yer);
    }
  }

  // Ön tekerlekler direksiyonla döner (dönüşte ve park ederken)
  function direksiyon(a, aci, dt) {
    const u = a.userData;
    u.direksiyon = (u.direksiyon || 0) + (Math.max(-0.55, Math.min(0.55, aci)) - (u.direksiyon || 0)) * Math.min(1, dt * 6);
    for (const t of u.araba.tekerler) if (t.position.x > 0) t.rotation.y = u.direksiyon;
  }
  function tekerDondur(a, yol) {
    const d = yol / a.userData.araba.r;
    for (const t of a.userData.araba.tekerler) t.rotation.z -= d;
  }
  // Yol üstündeki aracın bir eksen boyunca yarı boyu (yan duran araç şeritte daha az yer kaplar)
  function eksenYarisi(a, eksen) {
    const au = a.userData.araba;
    const c = Math.abs(eksen === 'x' ? Math.cos(a.rotation.y) : Math.sin(a.rotation.y));
    return (au.uzunluk / 2) * c + ((au.en || 1.8) / 2) * (1 - c);
  }

  // Uzak uca varan araba (görünmeden) başka bir yoldan yeniden gelir: sokağın yoğunluğuna göre görünür ya da görünmez
  function yenidenDagit(a) {
    const u = a.userData;
    const adaylar = SERITLER.filter((s) => s.bas === 'uzak' && !(s.kapaliBitis > performance.now()));
    const s = adaylar.length ? adaylar[Math.floor(Math.random() * adaylar.length)] : u.serit;
    let bas = s.yon > 0 ? s.min : s.max;
    // 0.40: başlangıç noktası ekrandaysa araba ekranın dışında, yolun gerisinde doğar (ekranda birden belirmez)
    for (let i = 0; i < 60; i++) {
      const [bx, bz] = seritKonum(s, bas);
      if (!ekrandaMi({ x: bx, y: 0, z: bz }, 3.5)) break;
      bas -= s.yon * 12;
    }
    const dolu = arabalar.some((b) => b !== a && b.userData.serit === s && b.visible && Math.abs(b.userData.p - bas) < 11);
    Object.assign(u, { serit: s, p: bas, hiz: u.azami * 0.8, cikis: null, karar: null, bekleme: 0 });
    a.visible = !dolu && !(s.kapaliBitis > performance.now()) && (u.dolasan ? true : Math.random() < yogunluk());
    const [x, z] = seritKonum(s, bas);
    a.position.set(x, 0.02, z);
    a.rotation.y = seritAcisi(s);
    direksiyon(a, 0, 1);
  }

  const parkYerleri = [];
  const parkEdenler = [];   // park etmeye ya da çıkmaya çalışan arabalar
  let sonParkGelis = 0;
  // Park eden arabanın farları söner. Haleler yalnızca hava kararınca çizilir (gündüz boşuna çizilmesin).
  let isikAcikPayi = 0;
  function farlar(a, acik) {
    for (const h of a.userData.araba.haleler) { h.userData.kapali = !acik; h.visible = acik && isikAcikPayi > 0.01; }
  }
  const yumusak = (k) => { k = Math.max(0, Math.min(1, k)); return k * k * (3 - 2 * k); };
  const yumusakTurev = (k) => (k <= 0 || k >= 1 ? 0 : 6 * k * (1 - k));
  const PARK_YOL = 9;       // şeritten park yerine S çizerek geçilen mesafe
  const PARK_Z = 7.25;
  const SERIT_Z = 5.3;
  const PARK_BOY = 4.8;     // park eden arabanın boyu (en uzun binek) + pay
  // 0.41: park yerinin önündeki ve arkasındaki boşluk (komşu park yerlerindeki ya da yanaşan arabalara göre)
  function parkBoslugu(x, haric) {
    let on = Infinity, arka = Infinity;
    for (const y of parkYerleri) {
      const b = y.araba;
      if (!b || b === haric) continue;
      const bx = b.userData.durum === 'park' || !b.position ? y.x : b.position.x; // ayrılmış (rezerve) yerin arabası yok
      const d = bx - x;
      if (d > 0.05) on = Math.min(on, d - PARK_BOY);
      else if (d < -0.05) arka = Math.min(arka, -d - PARK_BOY);
    }
    // çıkmakta olan arabalar da yer kaplar
    for (const b of parkEdenler) {
      if (b === haric || b.userData.durum !== 'cikis') continue;
      const d = b.position.x - x;
      if (d > 0.05) on = Math.min(on, d - PARK_BOY);
      else if (d < -0.05) arka = Math.min(arka, -d - PARK_BOY);
    }
    return { on, arka };
  }
  // yolda (park şeridine yakın) yürüyen biri var mı: x1..x2 aralığında
  function parkYayasi(x1, x2, z) {
    for (const y of yoldakiler) if (y.x > x1 && y.x < x2 && Math.abs(y.z - z) < 2.2) return true;
    return false;
  }

  // 0.50: park eden/çıkan arabanın gövdesi park etmiş arabaların gövdesine girmesin: yönlü dikdörtgen (OBB) çakışması
  function govde(a, x, z, aci) {
    const au = a.userData.araba;
    const ox = ((au.onX ?? 2.1) + (au.arkaX ?? -2.1)) / 2;
    const c = Math.cos(aci), sn = Math.sin(aci);
    // yerel +x (ileri) dünyada (cos, -sin); yerel +z (yan) dünyada (sin, cos)
    return { x: x + ox * c, z: z - ox * sn, ux: c, uz: -sn, vx: sn, vz: c, hl: (au.uzunluk || 4.4) / 2, hw: (au.en || 1.8) / 2 };
  }
  function govdeCakisir(A, B, pay = 0.12) {
    const dx = B.x - A.x, dz = B.z - A.z;
    for (const [ax, az] of [[A.ux, A.uz], [A.vx, A.vz], [B.ux, B.uz], [B.vx, B.vz]]) {
      const ra = A.hl * Math.abs(A.ux * ax + A.uz * az) + A.hw * Math.abs(A.vx * ax + A.vz * az);
      const rb = B.hl * Math.abs(B.ux * ax + B.uz * az) + B.hw * Math.abs(B.vx * ax + B.vz * az);
      if (Math.abs(dx * ax + dz * az) > ra + rb + pay) return false;
    }
    return true;
  }
  // park etmiş (ya da park yolundaki) diğer arabaların gövdeleri
  function parkGovdeleri(haric) {
    const l = [];
    for (const y of parkYerleri) {
      const b = y.araba;
      if (!b || b === haric || !b.position || b.userData.durum !== 'park') continue;
      l.push(govde(b, b.position.x, b.position.z, b.rotation.y));
    }
    for (const b of parkEdenler) if (b !== haric && b.userData.durum !== 'park') l.push(govde(b, b.position.x, b.position.z, b.rotation.y));
    return l;
  }
  function yolCakisir(a, x, z, aci, govdeler) {
    const g = govde(a, x, z, aci);
    for (const o of govdeler) if (Math.abs(o.x - g.x) < 9 && govdeCakisir(g, o)) return true;
    return false;
  }
  // ana caddede yakındaki hareketli arabalar (şeritteki ve kavşakta dönen)
  function yakinYolGovdeleri(x, menzil) {
    const l = [];
    for (const b of arabalar) if (b.visible && b.userData.serit && b.position.z > 0 && b.position.z < 8.6 && Math.abs(b.position.x - x) < menzil) l.push(govde(b, b.position.x, b.position.z, b.rotation.y));
    for (const d of donenler) if (d.a.position.z > 0 && d.a.position.z < 8.6 && Math.abs(d.a.position.x - x) < menzil) l.push(govde(d.a, d.a.position.x, d.a.position.z, d.a.rotation.y));
    return l;
  }
  // park yolunun tamamı (S eğrisi) önceden denenir: yolda park etmiş bir arabaya değecekse o yere girilmez / çıkılmaz
  function girisYoluBos(a, hedefX) {
    const gl = parkGovdeleri(a);
    for (let k = 0; k <= 1.0001; k += 0.1) {
      const x = hedefX - PARK_YOL * (1 - k), z = SERIT_Z + (PARK_Z - SERIT_Z) * yumusak(k);
      const aci = -Math.atan(((PARK_Z - SERIT_Z) * yumusakTurev(k)) / PARK_YOL);
      if (yolCakisir(a, x, z, aci, gl)) return false;
    }
    return true;
  }
  function cikisYoluBos(a, basX, egri) {
    const gl = parkGovdeleri(a);
    for (let k = 0; k <= 1.0001; k += 0.1) {
      const x = basX + egri * k, z = PARK_Z - (PARK_Z - SERIT_Z) * yumusak(k);
      const aci = -Math.atan((-(PARK_Z - SERIT_Z) * yumusakTurev(k)) / egri);
      if (yolCakisir(a, x, z, aci, gl)) return false;
    }
    return true;
  }
  function parkGuncelle(dt, t) {
    const ana = SERITLER[0];
    // süresi dolan park eden araba çıkar
    for (const yer of parkYerleri) {
      if (!yer.araba || yer.araba.userData.durum !== 'park') continue;
      yer.sure -= dt;
      if (yer.sure > 0) continue;
      // arkadan gelen araba yoksa çık (önce sinyal verip bekler)
      const arkada = arabalar.some((b) => b.userData.serit === ana && b.visible && yer.x - b.userData.p > -2 && yer.x - b.userData.p < 16 + b.userData.hiz * 1.5);
      if (arkada) { yer.sure = 1.5; continue; }
      const a = yer.araba;
      // 0.41: öndeki park etmiş arabaya sürtmeden çıkmak için gereken yer: eğri en az 5 m; önde yer yoksa önce geri gelir
      const { on, arka } = parkBoslugu(yer.x, a);
      const geri = on - 0.6 < 5 ? Math.max(0, Math.min(arka - 0.8, 5 - (on - 0.6))) : 0;
      // 0.50: eğri, önde açılan boşluktan uzun olamaz (öndeki arabaya sürtmesin); 5 m'den kısaysa çıkılmaz
      const egri = Math.min(PARK_YOL, on - 0.6 + geri);
      if (egri < 5 || !cikisYoluBos(a, yer.x - geri, egri)) { yer.sure = rnd(4, 9); continue; } // sıkışmış: biraz sonra tekrar dener
      yer.araba = null;
      Object.assign(a.userData, { durum: 'cikis', hiz: 0, basX: a.position.x, bekle: 0.9, egri, geri, geriBas: a.position.x });
      farlar(a, true);
      parkEdenler.push(a);
    }
    // ara sıra yoldan geçen bir araba boş yere park eder
    if (t - sonParkGelis > rnd(25, 70)) {
      sonParkGelis = t;
      // 0.41: yalnızca arkasında S çizecek kadar boşluk olan yerlere girilir (arkadaki park etmiş arabaya sürtmesin)
      const bos = parkYerleri.filter((y) => !y.araba && parkBoslugu(y.x).arka > PARK_YOL - PARK_BOY + 1.2 && parkBoslugu(y.x).on > 0.6);
      for (const yer of bos) {
        // önündeki park yeri de boşsa girer (ileri park için yer lazım)
        const aday = arabalar.find((b) => b.userData.serit === ana && b.visible && !b.userData.olay && !b.userData.dolasan && !b.userData.cikis && !b.userData.solla && yer.x - b.userData.p > PARK_YOL + 10 && yer.x - b.userData.p < 45);
        if (aday && girisYoluBos(aday, yer.x)) {
          const i = arabalar.indexOf(aday);
          arabalar.splice(i, 1);
          aday.userData.serit = null;
          Object.assign(aday.userData, { durum: 'giris', hedefYer: yer });
          yer.araba = aday;
          parkEdenler.push(aday);
          break;
        }
      }
    }
    for (let i = parkEdenler.length - 1; i >= 0; i--) {
      const a = parkEdenler[i];
      const u = a.userData;
      if (u.durum === 'giris') {
        // yavaşlayarak yaklaşır, park yerinin önünde S çizerek kaldırıma yanaşır ve durur
        const hedefX = u.hedefYer.x;
        const kalan = hedefX - a.position.x;
        let sinir = Math.min(u.azami, Math.sqrt(0.25 + 2 * 1.6 * Math.max(0, kalan)));
        // şeritteyken önündeki arabayı ve geçitteki yayayı gözetir
        if (a.position.z < 6.4) {
          for (const b of arabalar) {
            if (b.userData.serit !== ana || !b.visible) continue;
            const on = b.userData.p - a.position.x - (u.araba.uzunluk + b.userData.araba.uzunluk) / 2;
            if (on > -1) sinir = Math.min(sinir, Math.max(0, (on - 2) * 1.1));
          }
          for (const y of yoldakiler) if (Math.abs(y.z - SERIT_Z) < 1.8 && y.x - a.position.x > 0 && y.x - a.position.x < 14) sinir = Math.min(sinir, Math.max(0, (y.x - a.position.x - 3) * 1.1));
          // 0.50: önünde park etmeye/çıkmaya çalışan başka bir araba varsa onu da gözetir
          for (const b of parkEdenler) {
            if (b === a || b.userData.durum === 'park' || Math.abs(b.position.z - a.position.z) > 1.9) continue;
            const on = b.position.x - a.position.x - (u.araba.uzunluk + b.userData.araba.uzunluk) / 2;
            if (on > -1) sinir = Math.min(sinir, Math.max(0, (on - 1) * 1.1));
          }
        } else if (parkYayasi(a.position.x, a.position.x + 6, PARK_Z)) sinir = 0; // yanaşırken önüne çıkan yayayı bekler
        u.fren = sinir < u.hiz - 0.3 || u.hiz < 0.3;
        u.sinyal = 'sag';
        u.hiz = Math.max(0, u.hiz + Math.max(-7 * dt, Math.min(2.2 * dt, sinir - u.hiz)));
        let adim = Math.min(kalan, u.hiz * dt);
        // şeritteyken önü uzun süre kapalı kalırsa park etmekten vazgeçip yoluna devam eder
        u.girisBekle = u.hiz < 0.3 && a.position.z < SERIT_Z + 0.25 ? (u.girisBekle || 0) + dt : 0;
        if (u.girisBekle > 7) {
          u.hedefYer.araba = null;
          a.rotation.y = 0; a.position.z = SERIT_Z; direksiyon(a, 0, 1);
          Object.assign(u, { durum: 'yol', serit: ana, p: a.position.x, cikis: null, karar: null, sinyal: null, takili: 0, girisBekle: 0, hedefYer: null });
          arabalar.push(a);
          parkEdenler.splice(i, 1);
          continue;
        }
        // 0.50: bir sonraki konum başka bir arabanın gövdesine giriyorsa beklenir; şeritteyken uzun beklerse park etmekten vazgeçer
        {
          const nx = a.position.x + adim, nk = 1 - (hedefX - nx) / PARK_YOL;
          if (adim > 0 && nk > 0 && yolCakisir(a, nx, SERIT_Z + (PARK_Z - SERIT_Z) * yumusak(nk), -Math.atan(((PARK_Z - SERIT_Z) * yumusakTurev(nk)) / PARK_YOL), parkGovdeleri(a))) {
            adim = 0; u.hiz = 0; u.fren = true; u.takili = (u.takili || 0) + dt;
            if (u.takili > 4 && a.position.z < SERIT_Z + 0.25) {
              u.hedefYer.araba = null;
              a.rotation.y = 0; a.position.z = SERIT_Z; direksiyon(a, 0, 1);
              Object.assign(u, { durum: 'yol', serit: ana, p: a.position.x, cikis: null, karar: null, sinyal: null, takili: 0, hedefYer: null });
              arabalar.push(a);
              parkEdenler.splice(i, 1);
              continue;
            }
          } else u.takili = 0;
        }
        a.position.x += adim;
        const k = 1 - (hedefX - a.position.x) / PARK_YOL;
        a.position.z = SERIT_Z + (PARK_Z - SERIT_Z) * yumusak(k);
        const egim = ((PARK_Z - SERIT_Z) * yumusakTurev(k)) / PARK_YOL;
        const aci = -Math.atan(egim);
        direksiyon(a, (aci - a.rotation.y) * 6, dt);
        a.rotation.y = aci;
        tekerDondur(a, adim);
        if (kalan < 0.03) {
          u.durum = 'park';
          u.hiz = 0;
          a.position.set(hedefX, 0.02, PARK_Z);
          a.rotation.y = 0;
          direksiyon(a, 0, 1);
          u.hedefYer.sure = rnd(60, 240);
          u.fren = false;
          u.sinyal = null;
          lambaAyarla(a, 0);
          farlar(a, false);
          parkEdenler.splice(i, 1);
        }
      } else if (u.durum === 'cikis') {
        u.sinyal = 'sol';
        u.fren = u.bekle > 0;
        if (u.bekle > 0) { u.bekle -= dt; direksiyon(a, -0.45, dt); continue; }
        // 0.41: önce gerekiyorsa yavaşça geri gelir (geri vites lambası yanar)
        if (u.geri > 0.01) {
          u.fren = false;
          const g = Math.min(u.geri, 1.2 * dt);
          a.position.x -= g; u.geri -= g;
          tekerDondur(a, -g);
          direksiyon(a, 0, dt);
          if (u.geri <= 0.01) { u.geri = 0; u.basX = a.position.x; u.bekle = 0.35; }
          continue;
        }
        // önüne yaya çıkarsa ya da arkadan araba gelirse bekler
        if (parkYayasi(a.position.x - 1, a.position.x + 7, a.position.z)) { u.hiz = 0; u.fren = true; continue; }
        u.hiz = Math.min(6.5, u.hiz + dt * 2.2);
        const adim = u.hiz * dt;
        const egriBoy = u.egri || PARK_YOL;
        {
          const nk = (a.position.x + adim - u.basX) / egriBoy;
          if (nk < 1 && yolCakisir(a, a.position.x + adim, PARK_Z - (PARK_Z - SERIT_Z) * yumusak(nk), -Math.atan((-(PARK_Z - SERIT_Z) * yumusakTurev(nk)) / egriBoy), parkGovdeleri(a).concat(yakinYolGovdeleri(a.position.x, 12)))) { u.hiz = 0; u.fren = true; continue; }
        }
        a.position.x += adim;
        const k = (a.position.x - u.basX) / egriBoy;
        a.position.z = PARK_Z - (PARK_Z - SERIT_Z) * yumusak(k);
        const egim = (-(PARK_Z - SERIT_Z) * yumusakTurev(k)) / egriBoy;
        const aci = -Math.atan(egim);
        direksiyon(a, (aci - a.rotation.y) * 6, dt);
        a.rotation.y = aci;
        tekerDondur(a, adim);
        if (k >= 1) {
          // ana caddedeki trafiğe katılır
          a.rotation.y = 0;
          a.position.z = SERIT_Z;
          Object.assign(u, { durum: 'yol', serit: ana, p: a.position.x, cikis: null, karar: null, sinyal: null });
          arabalar.push(a);
          parkEdenler.splice(i, 1);
        }
      }
    }
  }

  // Yolun üstündeki yayalar (geçitten geçenler ve sokak olaylarındaki insanlar): arabalar önlerinde durur
  let yoldakiler = [];
  function yoldakileriTopla() {
    yoldakiler = [];
    for (const y of gecenler) if (y.userData.gecis && y.position.z > 0.1 && y.position.z < 8.5) yoldakiler.push({ x: y.position.x, z: y.position.z });
    if (olaylar) for (const k of olaylar.insanlar()) if (k.g.position.z > 0.1 && k.g.position.z < 8.5) yoldakiler.push({ x: k.g.position.x, z: k.g.position.z });
  }
  // Yürüyenler birbirinin içinden geçmesin: hafifçe itişirler
  const itisListesi = [];
  function itisme(dt) {
    // park etmiş arabalar da yürüyenler için engeldir
    for (const yer of parkYerleri) {
      const dolu = !!(yer.araba && (yer.araba.userData.durum === 'park' || yer.gecici)); // oyuncunun kendi arabası da (ayrılmış yer)
      if (dolu && !yer.engel) yer.engel = kalabalik.engelEkle(yer.x, 7.25, 4.5, 1.9);
      else if (!dolu && yer.engel) { kalabalik.engelSil(yer.engel); yer.engel = null; }
    }
    itisListesi.length = 0;
    for (const y of yayalar) if (y.visible) itisListesi.push({ p: y.position, itZ: (dz) => { y.userData.kay = Math.max(-1.4, Math.min(1.4, (y.userData.kay || 0) + dz)); } });
    for (const m of musteriler) if (m.visible) itisListesi.push({ p: m.position, agir: m.userData.durum === 'bekle' });
    for (const y of gecenler) itisListesi.push({ p: y.position, agir: !y.userData.gecis });
    for (const y of yerler.values()) if (y.insan) itisListesi.push({ p: y.insan.getWorldPosition(new THREE.Vector3()), sabit: true });
    if (olaylar) for (const k of olaylar.insanlar()) itisListesi.push({ p: k.g.position, agir: !k.yuruyor, sabit: !!k.sabit });
    for (const c of copculer) if (c.g.visible) itisListesi.push({ p: c.g.position, agir: true });
    kalabalik.itis(itisListesi, dt);
  }

  // Şerit dışındaki yol engelleri (dönen, park eden, kaldırıma yanaşan araçlar): arkalarından gelen onlara çarpmaz
  const yolEngelleri = [];
  function yolEngelleriniTopla() {
    yolEngelleri.length = 0;
    for (const d of donenler) yolEngelleri.push(d.a);
    for (const a of parkEdenler) if (a.userData.durum !== 'park') yolEngelleri.push(a);
    for (const a of disEngeller) if (a.parent) yolEngelleri.push(a);
    // 0.50: sollayan araba karşı şeritteyken o şeridin arabaları için engeldir
    for (const a of arabalar) if (a.visible && a.userData.solla && Math.abs(a.userData.kacis || 0) > 0.6) yolEngelleri.push(a);
  }
  // Hedef şeride dönmek için yer var mı: yaklaşan araba yakınsa ya da dönüş noktasının hemen önü doluysa beklenir
  function donusBosMu(d, a) {
    const h = d.hedef;
    if (h.kapaliBitis > performance.now()) return false;
    for (const b of arabalar) {
      if (b === a || b.userData.serit !== h || !b.visible) continue;
      const fark = (d.pB - b.userData.p) * h.yon; // pozitif: araba dönüş noktasının gerisinde (geliyor)
      if (fark > -7 && fark < 0) return false;
      if (fark >= 0 && fark < 4 + b.userData.hiz * 1.6) return false;
    }
    for (const o of donenler) if (o.d.hedef === h && o.t < 0.85) return false;
    return true;
  }
  function donusBaslat(a, d) {
    const u = a.userData;
    arabalar.splice(arabalar.indexOf(a), 1);
    u.serit = null;
    donenler.push({ a, d, t: 0, hiz: Math.max(1.5, u.hiz) });
  }
  function donenleriGuncelle(dt) {
    for (let i = donenler.length - 1; i >= 0; i--) {
      const o = donenler[i];
      const { a, d } = o;
      const u = a.userData;
      // dönüşte yavaş, çıkışta hızlanır; önüne (hedef şeritte) araba çıkarsa durur
      let hedefHiz = d.hiz + o.t * 2;
      for (const b of arabalar) {
        if (b.userData.serit !== d.hedef || !b.visible) continue;
        const on = (b.userData.p - d.pB) * d.hedef.yon;
        if (on > -1 && on < 7 && o.t > 0.5) hedefHiz = Math.min(hedefHiz, Math.max(0, (on - 4.5) * 1.2));
      }
      u.fren = hedefHiz < o.hiz - 0.6;
      u.sinyal = o.t < 0.75 ? d.taraf : null;
      o.hiz += Math.max(-8 * dt, Math.min(2.5 * dt, hedefHiz - o.hiz));
      o.hiz = Math.max(0, o.hiz);
      const [tx, tz] = bezierTurev(d.A, d.C, d.B, o.t);
      const turevBoy = Math.hypot(tx, tz) || 1;
      o.t = Math.min(1, o.t + (o.hiz * dt) / turevBoy);
      const [x, z] = bezier(d.A, d.C, d.B, o.t);
      const yol = Math.hypot(x - a.position.x, z - a.position.z);
      a.position.x = x;
      a.position.z = z;
      const [vx, vz] = bezierTurev(d.A, d.C, d.B, Math.min(0.999, o.t));
      const aci = Math.atan2(-vz, vx);
      let fark = aci - a.rotation.y;
      while (fark > Math.PI) fark -= Math.PI * 2;
      while (fark < -Math.PI) fark += Math.PI * 2;
      a.rotation.y += fark;
      direksiyon(a, yol > 1e-4 ? (fark / yol) * 2.6 : u.direksiyon || 0, dt);
      tekerDondur(a, yol);
      if (o.t >= 1) {
        donenler.splice(i, 1);
        Object.assign(u, { serit: d.hedef, p: d.pB, hiz: o.hiz, cikis: null, karar: null, bekleme: 0 });
        a.rotation.y = seritAcisi(d.hedef);
        arabalar.push(a);
      }
    }
  }

  // Stop lambaları ve sinyaller (yakındaki araçlarda; malzeme yalnızca durum değişince güncellenir)
  function lambaAyarla(a, stop, sol = 0, sag = 0) {
    const L = a.userData.araba;
    if (!L || !L.stopMat) return;
    const u = a.userData;
    const anahtar = stop * 100 + sol * 10 + sag;
    if (u.lambaAnahtar === anahtar) return;
    u.lambaAnahtar = anahtar;
    L.stopMat.emissiveIntensity = stop === 2 ? 3.2 : stop === 1 ? 0.5 : 0.15;

    // sinyal yanınca köşelerdeki turuncu hale de parlar (gündüz de uzaktan seçilir)
    if (L.sinyalHale) {
      for (const h of L.sinyalHale.sol) { h.visible = !!sol; h.material.opacity = 0.95; }
      for (const h of L.sinyalHale.sag) { h.visible = !!sag; h.material.opacity = 0.95; }
    }
  }
  function lambalariGuncelle(t) {
    const yanik = Math.floor(t * 2.8) % 2 === 0;
    const isle = (a) => {
      if (!a.visible || !a.userData.araba || !a.userData.araba.stopMat) return;
      const u = a.userData;
      if (u.durum === 'park') { lambaAyarla(a, 0); return; }
      if (!yakinMi(a.position.x, a.position.z, 50)) return;
      const sn = u.sinyal;
      lambaAyarla(a, u.fren ? 2 : 1, yanik && (sn === 'sol' || sn === 'dortlu') ? 1 : 0, yanik && (sn === 'sag' || sn === 'dortlu') ? 1 : 0);
    };
    for (const a of arabalar) isle(a);
    for (const d of donenler) isle(d.a);
    for (const a of parkEdenler) isle(a);
    for (const a of disEngeller) isle(a);
  }

  function trafikGuncelle(dt) {
    yolEngelleriniTopla();
    donenleriGuncelle(dt);
    // kavşaklarda hangi yönden araba var (dönen araba iki yönü de tutar)
    for (const k of KAVSAKLAR) { k.dolu.x = false; k.dolu.z = false; }
    for (const a of arabalar) {
      if (!a.visible || !a.userData.serit) continue;
      const yari = (a.userData.araba.uzunluk || 4) / 2;
      const ex = a.userData.serit.eksen;
      for (const k of KAVSAKLAR) {
        const icinde = ex === 'x'
          ? a.position.z > k.z1 && a.position.z < k.z2 && a.position.x + yari > k.x1 && a.position.x - yari < k.x2
          : a.position.x > k.x1 && a.position.x < k.x2 && a.position.z + yari > k.z1 && a.position.z - yari < k.z2;
        if (icinde) k.dolu[ex] = true;
      }
    }
    for (const o of donenler) {
      if (o.t <= 0.02) continue;
      for (const k of KAVSAKLAR) {
        if (o.a.position.x > k.x1 - 1.5 && o.a.position.x < k.x2 + 1.5 && o.a.position.z > k.z1 - 1.5 && o.a.position.z < k.z2 + 1.5) { k.dolu.x = true; k.dolu.z = true; }
      }
    }
    const simdiMs = performance.now();
    for (const s of SERITLER) {
      const liste = arabalar.filter((a) => a.userData.serit === s && a.visible);
      const gizli = arabalar.filter((a) => a.userData.serit === s && !a.visible);
      const zorunlu = s.cikislar.find((c) => c.zorunlu);
      for (const a of gizli) {
        a.userData.p += a.userData.azami * s.yon * dt;
        const p = a.userData.p;
        const bitti = zorunlu ? (p - zorunlu.p) * s.yon > 0 : p > s.max || p < s.min;
        if (bitti) yenidenDagit(a);
      }
      const durmali = !yesilMi(s.eksen);
      liste.sort((a, b) => (a.userData.p - b.userData.p) * s.yon);
      for (let j = 0; j < liste.length; j++) {
        const a = liste[j];
        const u = a.userData;
        const yari = u.araba.uzunluk / 2;
        const ondeki = liste[j + 1];
        let bosluk = ondeki ? (ondeki.userData.p - u.p) * s.yon - (yari + ondeki.userData.araba.uzunluk / 2) : Infinity;
        let hizSiniri = u.azami;
        // şerit dışındaki yol engelleri (dönen, park eden, yanaşan araçlar)
        // 0.41.1: şeride taşan geniş araç (kaldırıma yanaşmış itfaiye, kamyon) içinden geçilmez: yan yana gelen araba
        // yavaşlayıp yandan dolanır; dolanacak yer yoksa arkasında bekler.
        let kacis = 0;
        // 0.50: sollama — önde uzun süre duran araç (görev aracı, yanaşmış kamyon ya da kuyruğun başında bekleyen) varsa ve
        // karşı şerit boşsa karşı şeritten geçip kendi şeridine döner
        const sol = sollamaGuncelle(a, s, liste, j, dt);
        if (sol) bosluk = sol.bosluk; // sollarken öndeki (sollanan) araç hesaba katılmaz
        for (const e of yolEngelleri) {
          if (e === a || (u.solla && e === u.solla.hedef)) continue;
          const yan = s.eksen === 'x' ? e.position.z : e.position.x;
          const yanFark = yan - s.sabit;
          const ust = eksenYarisi(e, s.eksen === 'x' ? 'z' : 'x') + (u.araba.en || 1.8) / 2 + 0.12;
          if (Math.abs(yanFark) > ust) continue;
          const on = ((s.eksen === 'x' ? e.position.x : e.position.z) - u.p) * s.yon;
          const uzun = eksenYarisi(e, s.eksen);
          const ileri = on - yari - uzun;
          if (on < -(yari + uzun + 0.5)) continue; // geride kaldı
          // 0.50: park etmeye ya da çıkmaya çalışan araba şeritten tamamen çıkmadan yanından geçilmez (içinden geçmesin)
          if ((e.userData.durum === 'giris' || e.userData.durum === 'cikis') && Math.abs(yanFark) < (u.araba.en || 1.8) / 2 + 0.95 && on > 0) {
            bosluk = Math.min(bosluk, Math.max(-0.5, ileri));
            continue;
          }
          // 0.50: önüne park yerinden çıkan araç girdi: arkadan gelen sürücü selektör yapar, bazen korna çalar
          if (e.userData.durum === 'cikis' && on > 0 && on < 14 && (u.parkUyari || 0) < performance.now() - 20000) {
            u.parkUyari = performance.now();
            if (Math.random() < 0.65) selektorTetikle(a);
            if (Math.random() < 0.3) kornaCal(a, a.position.x, 'kisa');
          }
          const kac = ust - Math.abs(yanFark);
          // zaten yanındayken (ör. araç kaldırıma yanaşırken) içine girmemek için hemen yana kaçar
          if ((Math.abs(yanFark) <= 1.55 || kac > 0.9) && !(ileri < 0 && kac <= 1.3)) { if (on > 0) bosluk = Math.min(bosluk, ileri); continue; }
          if (ileri < 9) {
            const hedef = -Math.sign(yanFark || 1) * kac;
            // 0.50: ana caddede kaldırım tarafına kaçarken park etmiş arabaya sürtülmez: yer yoksa arkasında bekler
            if (s === SERITLER[0] && hedef > 0.12 && parkYerleri.some((y) => y.araba && y.araba.userData.durum === 'park' && Math.abs(y.araba.position.x - u.p) < (yari + 3))) {
              bosluk = Math.min(bosluk, Math.max(-0.5, ileri));
              continue;
            }
            if (kac > Math.abs(kacis)) kacis = hedef;
            hizSiniri = Math.min(hizSiniri, 5.5);
            // yeterince yana kaymadan yanına girmez: kayana kadar arkasında bekler (içinden geçmez)
            const kaydi = (u.kacis || 0) * Math.sign(hedef);
            if (kaydi < kac - 0.06) bosluk = Math.min(bosluk, Math.max(-0.5, ileri) + (kaydi > kac * 0.6 ? 1.2 : 0));
          }
        }
        const oncekiKacis = u.kacis || 0;
        const kacisHedef = u.solla ? u.solla.kay : kacis;
        u.kacis = oncekiKacis + (kacisHedef - oncekiKacis) * Math.min(1, dt * (u.solla ? 1.6 : 2.6));
        if (Math.abs(u.kacis) < 0.002) u.kacis = 0;
        u.yanHiz = dt > 0 ? (u.kacis - oncekiKacis) / dt : 0;
        if (u.solla) hizSiniri = Math.min(hizSiniri, u.solla.hiz);
        // kavşağın içinde öbür yönden araba varsa girmeden bekler (acil araçlar da)
        const obur = s.eksen === 'x' ? 'z' : 'x';
        for (const k of KAVSAKLAR) {
          if (!k.dolu[obur]) continue;
          const serittenGecer = s.eksen === 'x' ? s.sabit > k.z1 && s.sabit < k.z2 : s.sabit > k.x1 && s.sabit < k.x2;
          if (!serittenGecer) continue;
          const giris = s.eksen === 'x' ? (s.yon > 0 ? k.x1 : k.x2) : (s.yon > 0 ? k.z1 : k.z2);
          const kalan = (giris - (u.p + s.yon * yari)) * s.yon;
          if (kalan > -0.3 && kalan < 14) bosluk = Math.min(bosluk, kalan + 1.6);
        }
        // yolda yaya varsa (geçitte ya da olay yerinde) araç önünde durur; acil araçlar da ezmez
        if (s.eksen === 'x' && s.sabit < 9) {
          for (const y of yoldakiler) {
            if (Math.abs(y.z - s.sabit) > 1.75) continue;
            const on = (y.x - u.p) * s.yon - yari;
            if (on > -0.8 && on < 16) bosluk = Math.min(bosluk, on - 0.4);
          }
        }
        // görev aracı (zabıta, polis, ambulans…) hedef noktasında durur ya da (yanaşacaksa) o noktaya yavaşlayarak gelir
        if (u.durHedef != null) {
          const kalan = (u.durHedef - u.p) * s.yon;
          if (u.durHiz) hizSiniri = Math.min(hizSiniri, Math.sqrt(u.durHiz * u.durHiz + 2 * 3 * Math.max(0, kalan)));
          else bosluk = Math.min(bosluk, kalan + 2.3);
        }
        // kırmızı ışıkta durur (acil durum araçları beklemez)
        if (durmali && !u.acil) {
          for (const cizgiP of s.dur) {
            const kalan = (cizgiP - (u.p + s.yon * yari)) * s.yon;
            if (kalan > -0.5 && kalan < 30 && !(sariMi(s.eksen) && kalan < 3)) bosluk = Math.min(bosluk, kalan + 2.3);
          }
        }
        // kavşakta dönüş: yaklaşırken karar verilir, dönüşe uygun hıza yavaşlanır, yol boşsa dönülür
        if (!u.olay && u.durHedef == null) {
          const c = s.cikislar.find((x) => (x.p - u.p) * s.yon > -0.5 && (x.p - u.p) * s.yon < 40);
          if (c && u.karar !== c) {
            u.karar = c;
            u.cikis = null;
            if (c.zorunlu || Math.random() < c.olasilik) {
              const uygun = c.secenekler.filter((d) => !(d.hedef.kapaliBitis > simdiMs));
              u.cikis = (uygun.length ? uygun : c.secenekler)[Math.floor(Math.random() * (uygun.length || c.secenekler.length))];
              u.cikisBekleme = 0;
            }
          }
          if (u.cikis) {
            const d = u.cikis;
            const kalan = (d.pA - u.p) * s.yon;
            hizSiniri = Math.min(hizSiniri, Math.sqrt(d.hiz * d.hiz + 2 * 2.6 * Math.max(0, kalan)));
            if (kalan <= 0.05 || (kalan < 0.6 && u.hiz < 0.5)) {
              if (donusBosMu(d, a)) { donusBaslat(a, d); continue; }
              // yol açılana kadar dönüş noktasında bekler; isteğe bağlı dönüşten uzun beklerse vazgeçip düz devam eder
              u.cikisBekleme = (u.cikisBekleme || 0) + dt;
              if (!(u.karar && u.karar.zorunlu) && u.cikisBekleme > 8) u.cikis = null;
              if (u.cikis) bosluk = Math.min(bosluk, Math.max(0, kalan) + 2.3);
            } else if (kalan < 6) {
              // dönüş noktasına gelirken dolu şeride dalmamak için önceden yavaşlar
              if (!donusBosMu(d, a)) bosluk = Math.min(bosluk, kalan + 2.3);
            }
          }
        }
        // saygı duruşu: bütün araçlar olduğu yerde yavaşça durur (acil araçlar hariç), dörtlüler yanar
        if (durus && !u.acil) { hizSiniri = 0; if (!u.olay) u.sinyal = 'dortlu'; }
        const hedefHiz = Math.max(0, Math.min(hizSiniri, (bosluk - 2.3) * 1.1));
        // stop lambası: yavaşlarken ve dururken yanar; dönüşe yaklaşırken sinyal verilir
        u.fren = u.hiz > 0.4 ? hedefHiz < u.hiz - 0.6 : true;
        if (!u.olay) u.sinyal = u.solla ? (Math.abs(u.solla.kay) > 0.1 ? u.solla.sinyal : (u.solla.sinyal === 'sol' ? 'sag' : 'sol')) : u.cikis && (u.cikis.pA - u.p) * s.yon < 32 ? u.cikis.taraf : null;
        u.hiz += Math.max(-9 * dt, Math.min(3 * dt, hedefHiz - u.hiz));
        u.hiz = Math.max(0, u.hiz);
        // 0.50: frende burun hafifçe iner, kalkışta kalkar (gövde yalpası; tek açı, ek çizim yok)
        if (dt > 0) {
          const ivme = (u.hiz - (u.oncekiHiz ?? u.hiz)) / dt;
          u.oncekiHiz = u.hiz;
          u.yalpa = (u.yalpa || 0) + (Math.max(-0.022, Math.min(0.012, ivme * 0.0035)) - (u.yalpa || 0)) * Math.min(1, dt * 6);
          a.rotation.z = Math.abs(u.yalpa) < 0.0005 ? 0 : u.yalpa;
        }
        u.p += u.hiz * s.yon * dt;
        const asim = u.p > s.max ? u.p - s.max : u.p < s.min ? s.min - u.p : 0;
        // 0.40: yolun başlangıç ucunun gerisinden (ekran dışından) gelen araba yola girene kadar düz ilerler
        const once = asim > 0 && (s.yon > 0 ? u.p < s.min : u.p > s.max);
        if (once) {
          const [x2, z2] = seritKonum(s, u.p);
          a.position.x = x2; a.position.z = z2;
          tekerDondur(a, u.hiz * dt);
          continue;
        }
        // ekran ne kadar geniş görürse görsün (uzaklaştırılmış kamera, büyük tablet ekranı) araba ekrandan çıkmadan kaybolmaz
        if (asim > 0 && asim < 900 && ekrandaMi(a.position, 3.5)) {
          // yolun ucu ekranın içinde: araba ekrandan çıkana kadar düz devam eder (birden kaybolmaz)
          const [x2, z2] = seritKonum(s, u.p);
          a.position.x = x2; a.position.z = z2;
          tekerDondur(a, u.hiz * dt);
          continue;
        }
        if (u.olay && (u.p > s.max || u.p < s.min)) {
          // görev aracı sokağın sonuna gelince sahneden çıkar
          arabalar.splice(arabalar.indexOf(a), 1);
          if (u.bitince) u.bitince();
          continue;
        }
        if (u.p > s.max || u.p < s.min || (zorunlu && !u.cikis && (u.p - zorunlu.p) * s.yon > 1)) {
          // yolun uzak ucuna varan araba başka bir yoldan yeniden gelir
          yenidenDagit(a);
          continue;
        }
        const [x, z] = seritKonum(s, u.p);
        const onceX = a.position.x - hedefX;
        a.position.x = x + (s.eksen === 'x' ? 0 : u.kacis);
        a.position.z = z + (s.eksen === 'x' ? u.kacis : 0);
        // şerit değiştirirken burnu gittiği yöne döner
        if (Math.abs(u.yanHiz || 0) > 0.05 && u.hiz > 0.3) {
          const vx = s.eksen === 'x' ? u.hiz * s.yon : u.yanHiz, vz = s.eksen === 'x' ? u.yanHiz : u.hiz * s.yon;
          a.rotation.y = Math.atan2(-vz, vx);
          direksiyon(a, -Math.sign(u.yanHiz) * Math.sign(s.eksen === 'x' ? s.yon : -s.yon) * 0.25, dt);
        } else {
          a.rotation.y = seritAcisi(s);
          if (u.direksiyon) direksiyon(a, 0, dt);
        }
        tekerDondur(a, u.hiz * dt);
        // kameranın önünden geçen araba sesi (yalnızca yakındaki ana cadde trafiği)
        if (aktifMi && s.eksen === 'x' && mesafe < 60 && Math.abs(z - hedefZ) < 20) {
          const sonra = x - hedefX;
          if (Math.sign(onceX) !== Math.sign(sonra) && Math.abs(sonra) < 2 && u.hiz > 2) ses.arabaGecti(s.yon, u.hiz);
        }
        u.bekleme = u.hiz < 0.3 ? (u.bekleme || 0) + dt : 0;
        if (!u.olay && u.bekleme > 6 && yesilMi(s.eksen) && Math.random() < dt * 0.2 && mesafe < 80) {
          kornaCal(a, x, u.bekleme > 14 ? 'uzun' : 'cift');
          if (Math.random() < 0.6) selektorTetikle(a);
          u.bekleme = 0;
        }
      }
    }
  }

  // ------------------------------------------------ Özel günler: bayrak, pankart, ışık zinciri ve saygı duruşu
  // Millî bayramlarda binalara Türk bayrakları asılır, caddeye pankart gerilir; dinî bayramlarda ve yılbaşında
  // renkli ampul zincirleri yanar. 10 Kasım 09.05'te bir dakikalık saygı duruşu: trafik durur, yürüyenler durur.
  let susleme = null;   // { kod, grup, zincirler: [] }
  let durus = false;
  function ozelGunAyarla(o) {
    const kod = o && o.susleme ? o.kod + ':' + o.susleme : '';
    if ((susleme ? susleme.kod : '') === kod) return;
    if (susleme) { sahne.remove(susleme.grup); bellektenSil(susleme.grup); susleme = null; }
    if (!kod || !kuruldu) return;
    const grup = new THREE.Group();
    const zincirler = [];
    if (o.susleme === 'bayrak') {
      // cephelerden sarkan bayraklar: her binaya bir tane (bir atlayarak)
      let i = 0;
      for (const d of dukkanlar.values()) {
        if (i++ % 2) continue;
        const b = asiliBayrak(1.6, 2.4);
        b.position.set(d.merkezX + 2.6, 6.2, d.onZ + d.yon * 0.32);
        b.rotation.y = d.yon > 0 ? 0 : Math.PI;
        grup.add(b);
      }
      // lamba direklerine küçük bayraklar
      for (const l of lambalar) {
        const b = asiliBayrak(0.55, 0.85);
        b.position.set(l.position.x + 0.3, 3.3, l.position.z);
        grup.add(b);
      }
    }
    if (o.susleme === 'yilbasi' || o.susleme === 'bayram') {
      // cadde boyunca ve caddenin üstünden sarkan ampul zincirleri
      const renkler = o.susleme === 'yilbasi' ? ['#FF3B3B', '#FFD23F', '#3DDC97', '#4DA3FF', '#FFFFFF'] : ['#FFD23F', '#FF8A3D', '#FF4D8D', '#8AE0FF', '#B38CFF'];
      const nokta = [];
      for (let x = XB + 8; x <= XD - 8; x += 11) nokta.push([x, 5.4, x % 2 ? -0.6 : 9.1]);
      const z = isikZinciri(nokta.map((n, k) => [n[0], n[1], k % 2 ? -0.6 : 9.1]), renkler);
      grup.add(z);
      zincirler.push(z);
      const z2 = isikZinciri([[XB + 6, 4.6, 9.4], [XD - 6, 4.6, 9.4]], renkler);
      grup.add(z2);
      zincirler.push(z2);
    }
    // caddeye gerilen pankart(lar)
    const metin = {
      '23nisan': '23 NİSAN ULUSAL EGEMENLİK VE ÇOCUK BAYRAMI KUTLU OLSUN',
      '19mayis': '19 MAYIS GENÇLİK VE SPOR BAYRAMI KUTLU OLSUN',
      '30agustos': '30 AĞUSTOS ZAFER BAYRAMI KUTLU OLSUN',
      '29ekim': '29 EKİM CUMHURİYET BAYRAMIMIZ KUTLU OLSUN',
      '15temmuz': '15 TEMMUZ DEMOKRASİ VE MİLLÎ BİRLİK GÜNÜ',
      '10kasim': 'ATAMIZI SAYGI VE ÖZLEMLE ANIYORUZ',
      canakkale: 'ÇANAKKALE GEÇİLMEZ',
      yilbasi: 'MUTLU YILLAR', yilbasi_arife: 'MUTLU YILLAR',
    }[o.kod] || (o.tur === 'dini' ? 'BAYRAMINIZ MÜBAREK OLSUN' : null);
    if (metin) {
      const anma = o.tur === 'anma';
      for (const px of [XB + 22, GECIT_X - 12]) {
        const p = pankart(metin, { zemin: anma ? '#15171A' : o.tur === 'dini' ? '#1F6F54' : o.susleme === 'yilbasi' ? '#0F3D7A' : '#C8102E', renk: '#FFFFFF' });
        p.position.set(px, KALDIRIM_Y, 9.75);
        grup.add(p);
      }
    }
    sahne.add(grup);
    susleme = { kod, grup, zincirler };
  }
  function suslemeGuncelle(t) {
    if (!susleme) return;
    // ampuller sırayla göz kırpar (gece daha parlak)
    const faz = Math.floor(t * 1.5);
    for (const z of susleme.zincirler) {
      const m = z.userData.ampuller.material;
      m.color.setScalar(0.55 + isikAcikPayi * 0.9 + (faz % 2) * 0.25);
    }
    for (const b of susleme.grup.children) if (b.userData.dalga) b.rotation.z = Math.sin(t * 1.3 + b.position.x) * 0.03;
  }
  function sayginDurus(aktif) { durus = !!aktif; }

  // ------------------------------------------------ Çöpçüler
  // Gündüz belediyenin temizlik görevlileri el arabalarını iterek kaldırımları süpürür: birkaç adımda bir durur,
  // arabayı bırakır, süpürgeyle yeri süpürür, çöpü arabaya atar ve yoluna devam eder. Konteynerlerin önünü de toplar.
  const copculer = [];
  function copcuKur() {
    const hatlar = [
      { z: 11.75, x1: XB + 6, x2: XD - 6 },   // güney gezinti yolu
      { z: -1.75, x1: XB + 6, x2: XD - 6 },   // kuzey kaldırımı (tezgâhların önü)
    ];
    for (let i = 0; i < Math.min(2, Math.max(1, Math.round(K.yaya / 8))); i++) {
      const h = hatlar[i % hatlar.length];
      const g = insanUret('temizlik');
      const sp = supurge();
      sp.position.set(-0.28, 1.02, 0.28);
      g.add(sp);
      const araba = copArabasi();
      const x = rnd(h.x1, h.x2);
      g.position.set(x, KALDIRIM_Y, h.z);
      araba.position.set(x + 1, KALDIRIM_Y, h.z);
      sahne.add(g, araba);
      copculer.push({ g, sp, araba, hat: h, yon: Math.random() < 0.5 ? 1 : -1, durum: 'yuru', sayac: rnd(4, 9), t: 0, hedef: null });
    }
  }
  function copcuGuncelle(dt, animDt) {
    const saat = oyunSaati() % 24;
    const mesai = saat >= 6 && saat < 19.5;
    for (const c of copculer) {
      const { g, araba, hat } = c;
      const ins = g.userData.insan;
      // mesai dışında görünmezler (arabayla birlikte)
      const gor = mesai;
      if (g.visible !== gor) { g.visible = gor; araba.visible = gor; }
      if (!gor) continue;
      c.t += dt;
      if (durus) { ins.oynat('Idle_Loop', 0.4); }
      else if (c.durum === 'yuru') {
        // arabayı önünde iterek yürür
        const hiz = 0.75;
        const hx = c.yon > 0 ? hat.x2 : hat.x1;
        const aci = kalabalik.yuru(g.position, hx, hat.z, hiz * dt);
        if (aci !== null) yonel(g, aci, dt);
        if (Math.abs(g.position.x - hx) < 0.4) c.yon = -c.yon;
        araba.position.set(g.position.x + Math.sin(g.rotation.y) * 1.05, KALDIRIM_Y, g.position.z + Math.cos(g.rotation.y) * 1.05);
        araba.rotation.y = g.rotation.y + Math.PI / 2; // sapı kişiye dönük
        for (const o of araba.children) if (o.geometry && o.geometry.type === 'CylinderGeometry' && o.rotation.x) o.rotation.y += hiz * dt / 0.2;
        c.sp.rotation.y = 0;
        ins.oynat('Walk_Loop', 0.3, 0.62);
        c.sayac -= hiz * dt;
        if (c.sayac <= 0) {
          // süpürülecek yer: yolun kenarına doğru ya da tezgâhların önü
          c.durum = 'supur';
          c.t = 0;
          c.sure = rnd(4, 7);
          c.merkez = [g.position.x + rnd(-0.6, 0.6), hat.z + rnd(-0.7, 0.7)];
        }
      } else if (c.durum === 'supur') {
        // süpürge sağa sola, ufak adımlarla yer değiştirerek
        const [mx, mz] = c.merkez;
        const hx = mx + Math.sin(c.t * 0.9) * 0.5;
        if (Math.abs(g.position.x - hx) > 0.05) kalabalik.yuru(g.position, hx, mz, 0.35 * dt);
        yonel(g, c.yon > 0 ? Math.PI / 2 : -Math.PI / 2, dt);
        c.sp.rotation.y = Math.sin(c.t * 5.5) * 0.55;
        c.sp.position.x = -0.28 + Math.sin(c.t * 5.5) * 0.08;
        ins.oynat('Idle_Loop', 0.3);
        if (c.t > c.sure) {
          c.durum = 'bosalt';
          c.t = 0;
        }
      } else if (c.durum === 'bosalt') {
        // çöpü el arabasının kovasına atar
        yonel(g, Math.atan2(araba.position.x - g.position.x, araba.position.z - g.position.z), dt);
        c.sp.rotation.y *= 0.9;
        ins.oynat('Interact', 0.25);
        if (c.t > 1.4) { c.durum = 'yuru'; c.sayac = rnd(5, 11); }
      }
      g.position.y = KALDIRIM_Y;
      if (animDt && yakinMi(g.position.x, g.position.z)) insanGuncelle(g, animDt);
    }
  }

  // ------------------------------------------------ Yayalar ve karşıya geçenler
  const yayalar = [];
  const esliCocuklar = []; // 0.46: anne/babasının yanında yürüyen çocuklar
  const gecenler = [];
  const banklar = [];
  let YAYA_SERITLERI = [];

  function yayaKur() {
    const x1 = XB + 5;
    const x2 = XD - 5;
    YAYA_SERITLERI = [
      { z: -6.9, yon: 1 }, { z: -6.2, yon: -1 }, { z: -0.95, yon: 1 }, { z: -0.35, yon: -1 },
      { z: 10.1, yon: 1 }, { z: 15.85, yon: -1 },
      { z: -35.9, yon: 1 }, { z: -36.9, yon: -1 }, { z: -48.1, yon: 1 }, { z: -47.1, yon: -1 },
    ].map((s) => ({ ...s, min: x1, max: x2 }));
    const adet = K.yaya + 4;
    for (let i = 0; i < adet; i++) {
      const s = YAYA_SERITLERI[i % YAYA_SERITLERI.length];
      const y = insanUret('yaya');
      y.position.set(rnd(x1, x2), KALDIRIM_Y, s.z + rnd(-0.1, 0.1));
      y.rotation.y = s.yon > 0 ? Math.PI / 2 : -Math.PI / 2;
      Object.assign(y.userData, { serit: s, hiz: rnd(1.05, 1.4) * hizCarpani(y) });
      y.userData.azami = y.userData.hiz;
      sahne.add(y);
      yayalar.push(y);
    }
    // 0.46: her beş yayadan birinin yanında çocuğu yürür (yetişkin yavaşlar, çocuk elini tutar gibi yanında kalır)
    const yetiskinler = yayalar.filter((y) => !(y.userData.insan && y.userData.insan.persona && y.userData.insan.persona.cocuk));
    for (let i = 0; i < Math.max(1, Math.floor(adet / 5)) && i < yetiskinler.length; i++) {
      const ebeveyn = yetiskinler[(i * 3 + 1) % yetiskinler.length];
      if (ebeveyn.userData.cocugu) continue;
      const c = insanUret('yaya', { persona: 'cocuk' });
      c.userData.ebeveyn = ebeveyn;
      c.userData.yan = Math.random() < 0.5 ? 0.42 : -0.42;
      ebeveyn.userData.cocugu = c;
      ebeveyn.userData.azami = Math.min(ebeveyn.userData.azami, 1.0);
      ebeveyn.userData.hiz = Math.min(ebeveyn.userData.hiz, 1.0);
      c.position.copy(ebeveyn.position);
      sahne.add(c);
      esliCocuklar.push(c);
    }
    for (let i = 0; i < Math.min(4, Math.ceil(K.yaya / 4)); i++) {
      const y = insanUret('yaya');
      const karsi = i % 2 === 0;
      y.position.set(GECIT_X + rnd(-1.2, 1.2), KALDIRIM_Y, karsi ? 9.3 : -0.4);
      y.userData.hedefZ = karsi ? -0.4 : 9.3;
      y.userData.gecis = false;
      sahne.add(y);
      gecenler.push(y);
    }
  }

  function yonel(y, hedefAci, dt) {
    let f = hedefAci - y.rotation.y;
    while (f > Math.PI) f -= Math.PI * 2;
    while (f < -Math.PI) f += Math.PI * 2;
    y.rotation.y += f * Math.min(1, dt * 8);
  }

  function yakinMi(x, z, sinir = 60) {
    return Math.abs(x - hedefX) < sinir + mesafe * 0.6 && Math.abs(z - hedefZ) < sinir + mesafe * 0.6;
  }

  // Bankta dinlenme: kaldırımdaki yaya yakındaki boş bankta 15–40 sn oturur, sonra yoluna devam eder
  function bankaYonel(y, s) {
    if (Math.abs(s.z - 10.1) > 0.5) return false;
    const b = banklar.find((b) => b.oturan.length < 2 && (b.x - y.position.x) * s.yon > 0.5 && (b.x - y.position.x) * s.yon < 4);
    if (!b) return false;
    const yer = b.oturan.length ? (b.oturan[0].userData.oturma.dx > 0 ? -0.45 : 0.45) : (Math.random() < 0.5 ? -0.45 : 0.45);
    b.oturan.push(y);
    y.userData.oturma = { b, dx: yer, faz: 'git', t: 0, sure: 15 + Math.random() * 25 };
    return true;
  }
  function oturmaGuncelle(y, s, dt, animDt) {
    const u = y.userData, o = u.oturma, ins = u.insan;
    const hx = o.b.x + o.dx, hz = o.b.z + 0.02;
    if (o.faz === 'git') {
      const dx = hx - y.position.x, dz = hz - y.position.z, d = Math.hypot(dx, dz);
      if (d < 0.08) { o.faz = 'otur'; y.rotation.y = Math.PI; }
      else { const v = Math.min(d, 1.1 * dt); y.position.x += dx / d * v; y.position.z += dz / d * v; yonel(y, Math.atan2(dx, dz), dt); ins.oynat('Walk_Loop', 0.3, 0.9); }
    } else if (o.faz === 'otur') {
      o.t += dt;
      y.position.y += ((KALDIRIM_Y + 0.05) - y.position.y) * Math.min(1, dt * 6);
      ins.oynat('Sitting_Idle_Loop', 0.5);
      if (o.t > o.sure || durus === 'kalk') o.faz = 'kalk';
    } else {
      y.position.y += (KALDIRIM_Y - y.position.y) * Math.min(1, dt * 6);
      const dz = s.z - y.position.z;
      if (Math.abs(dz) < 0.05) {
        o.b.oturan = o.b.oturan.filter((x) => x !== y);
        u.oturma = null; u.kay = 0; u.kayHedef = 0; y.position.y = KALDIRIM_Y;
      } else { y.position.z += Math.sign(dz) * Math.min(Math.abs(dz), 1.1 * dt); yonel(y, s.yon > 0 ? Math.PI / 2 : -Math.PI / 2, dt); ins.oynat('Walk_Loop', 0.3, 0.9); }
    }
    if (animDt && yakinMi(y.position.x, y.position.z)) insanGuncelle(y, animDt);
  }
  function yayaGuncelle(dt, animDt) {
    for (const s of YAYA_SERITLERI) {
      const liste = yayalar.filter((y) => y.userData.serit === s && y.visible);
      const boy = s.max - s.min;
      for (const y of liste) {
        const u = y.userData;
        if (u.kay === undefined) { u.kay = 0; u.kayHedef = 0; }
        if (u.oturma || (!durus && banklar.length && Math.random() < dt * 0.012 && bankaYonel(y, s))) { oturmaGuncelle(y, s, dt, animDt); continue; }
        // yalnızca aynı hizada yürüyen biri önü keser
        let enYakin = Infinity;
        let ondeki = null;
        for (const b of liste) {
          if (b === y || b.userData.oturma || Math.abs((b.userData.kay || 0) - u.kay) > 0.35) continue;
          let fark = (b.position.x - y.position.x) * s.yon;
          if (fark <= 0) fark += boy;
          if (fark < enYakin) { enYakin = fark; ondeki = b; }
        }
        let hedefHiz = durus ? 0 : u.azami; // saygı duruşunda herkes olduğu yerde durur
        // önünde tezgâh, ağaç, bank gibi bir engel varsa yanından dolaşır
        const engelZ = kalabalik.seritEngeli(y.position.x, s.z + u.kay, s.yon, 2.6);
        if (engelZ !== null) {
          u.kayHedef = Math.max(-1.4, Math.min(1.4, engelZ - s.z));
          u.engelde = 1.2;
        } else if (u.engelde > 0) u.engelde -= dt;
        if (u.engelde > 0) {
          // engelin yanından geçerken şerit sollama kuralı uygulanmaz
        } else if (ondeki && enYakin < 1.8) {
          // öndeki yavaşsa yana kayıp sollar
          if (ondeki.userData.hiz < u.azami - 0.05) u.kayHedef = (ondeki.userData.kay || 0) >= 0 ? -0.42 : 0.42;
          hedefHiz = Math.min(u.azami, Math.max(0, (enYakin - 0.7) * 1.6));
        } else if (!ondeki || enYakin > 3) {
          u.kayHedef = 0;
        }
        if (ondeki && enYakin < 1.8 && u.engelde > 0) hedefHiz = Math.min(u.azami, Math.max(0, (enYakin - 0.7) * 1.6));
        u.kay += (u.kayHedef - u.kay) * Math.min(1, dt * (u.engelde > 0 ? 4 : 2.5));
        if (durus) hedefHiz = 0;
        u.hiz += Math.max(-4 * dt, Math.min(2 * dt, hedefHiz - u.hiz));
        y.position.x += u.hiz * s.yon * dt;
        y.position.z = s.z + u.kay;
        const tasti = y.position.x > s.max || y.position.x < s.min;
        const asimY = y.position.x > s.max ? y.position.x - s.max : s.min - y.position.x;
        // kaldırımın ucu ekrandaysa yaya ekrandan çıkana kadar yürür; ekran dışında karşı uca alınır
        if (tasti && (asimY > 600 || !ekrandaMi(y.position, 1.2))) {
          y.position.x = y.position.x > s.max ? s.min : s.max;
          if (Math.random() > yogunluk() + 0.15) y.visible = false;
        }
        // başlangıç ucu ekrandaysa yavaşça belirir (birden ortaya çıkmasın)
        {
          const kalan = s.yon > 0 ? s.max - y.position.x : y.position.x - s.min;
          const gecen = boy - kalan;
          insanSaydamlik(y, Math.max(0, Math.min(1, gecen / 3.5)));
        }
        yonel(y, s.yon > 0 ? Math.PI / 2 : -Math.PI / 2, dt);
        if (animDt) {
          const ins = u.insan;
          if (u.hiz < 0.15) ins.oynat('Idle_Loop', 0.3);
          else ins.oynat('Walk_Loop', 0.3, u.hiz / 1.2);
          // uzaktaki insanların animasyonu atlanır (hız için)
          if (yakinMi(y.position.x, y.position.z)) insanGuncelle(y, animDt);
        }
      }
      // kalabalık saatlerde gizli yayalar sokağa geri döner
      if (animDt) {
        for (const y of yayalar) {
          if (y.userData.serit === s && !y.visible && Math.random() < animDt * 0.05 * yogunluk()) {
            y.position.x = s.yon > 0 ? s.min : s.max;
            y.visible = true;
          }
        }
      }
    }
    // anne/babasıyla yürüyen çocuklar: yanında, yarım adım geride; durunca durur, oturunca yanında bekler
    for (const c of esliCocuklar) {
      const e = c.userData.ebeveyn, eu = e.userData;
      c.visible = e.visible;
      if (!e.visible) continue;
      const yon = eu.serit ? eu.serit.yon : 1;
      const hx = e.position.x - yon * 0.18, hz = e.position.z + (eu.oturma ? 0.65 : c.userData.yan);
      if (Math.abs(hx - c.position.x) > 3 || Math.abs(hz - c.position.z) > 3) c.position.set(hx, KALDIRIM_Y, hz); // ebeveyn karşı uca alındı
      c.position.x += (hx - c.position.x) * Math.min(1, dt * 8);
      c.position.z += (hz - c.position.z) * Math.min(1, dt * 8);
      c.position.y = KALDIRIM_Y;
      c.rotation.y = eu.oturma ? e.rotation.y : yon > 0 ? Math.PI / 2 : -Math.PI / 2;
      const ei = eu.insan;
      if (ei && ei.saydam !== undefined) insanSaydamlik(c, ei.saydam);
      if (animDt) {
        const hiz = eu.oturma ? 0 : eu.hiz || 0;
        if (hiz < 0.15) c.userData.insan.oynat('Idle_Loop', 0.3);
        else c.userData.insan.oynat('Walk_Loop', 0.3, (hiz / 1.2) * 1.3); // kısa bacaklar: daha sık adım
        if (yakinMi(c.position.x, c.position.z)) insanGuncelle(c, animDt);
      }
    }
    const gec = yesilMi('z');
    for (const y of gecenler) {
      const u = y.userData;
      const f = u.hedefZ - y.position.z;
      // karşıya geçmeye yalnızca yeşilin başında başlanır (yolun ortasında kırmızıya yakalanmasın)
      if ((gec && isikSure > 0.8 && isikSure < DONGU[isikEvre][1] - 8) || u.gecis) {
        u.gecis = Math.abs(f) > 0.05;
        if (u.gecis) {
          y.position.z += Math.sign(f) * Math.min(Math.abs(f), 1.35 * dt);
          y.position.y = (y.position.z > 0.25 && y.position.z < 8.4) ? 0.02 : KALDIRIM_Y;
          yonel(y, f > 0 ? 0 : Math.PI, dt);
          u.insan.oynat('Walk_Loop', 0.25, 1.1);
        } else {
          u.hedefZ = u.hedefZ > 4 ? -0.4 : 9.3;
          y.position.x = GECIT_X + rnd(-1.2, 1.2);
        }
      } else {
        yonel(y, f > 0 ? 0 : Math.PI, dt);
        u.insan.oynat('Idle_Loop', 0.4);
      }
      if (animDt && yakinMi(y.position.x, y.position.z)) insanGuncelle(y, animDt);
    }
  }

  // ------------------------------------------------ Müşteriler (tezgâh ve dükkânlara gelip gidenler)
  const musteriler = [];
  for (let i = 0; i < K.musteri + 4; i++) {
    const m = insanUret('musteri');
    m.visible = false;
    m.userData.durum = 'havuz';
    sahne.add(m);
    musteriler.push(m);
  }
  function bosMusteri() { return musteriler.find((m) => m.userData.durum === 'havuz'); }

  function tezgahaGonder(yer) {
    const m = bosMusteri();
    if (!m) return;
    const tx = yer.grup.position.x;
    const soldan = Math.random() < 0.5 ? -1 : 1;
    const tz = yer.grup.position.z;
    const serit = yer.guney ? MUSTERI_SERIDI_G : MUSTERI_SERIDI;
    const nokta = new THREE.Vector3(tx + rnd(-0.8, 0.8), KALDIRIM_Y, tz + 1.55 + rnd(0, 0.25));
    m.position.set(tx + soldan * rnd(9, 13), KALDIRIM_Y, serit + rnd(-0.1, 0.1));
    m.visible = true;
    insanSaydamlik(m, 0);
    Object.assign(m.userData, {
      belir: 0,
      durum: 'yol', hedefYer: yer, bekleme: rnd(4, 9), sonra: 'bekle', bakis: Math.PI,
      yol: [new THREE.Vector3(nokta.x, KALDIRIM_Y, serit), nokta],
      donus: [new THREE.Vector3(nokta.x, KALDIRIM_Y, serit), new THREE.Vector3(tx - soldan * rnd(11, 15), KALDIRIM_Y, serit)],
    });
    yer.musteri = (yer.musteri || 0) + 1;
  }

  // Dükkân şu an çalışıyor mu (ruhsatlı + çalışma saatleri içinde). Kapalıyken müşteri girmez, kepenk iner.
  function dukkanAcikMi(d) {
    const i = d.veri && d.veri.isletme;
    if (!i || i.durum !== 'acik') return false;
    const h = oyunSaati();
    const [a, b] = i.saat || [8, 21];
    const hs = Math.floor(h);
    return (hs >= a && hs < b) || (b > 24 && hs < b - 24);
  }
  function kepenkleriGuncelle() {
    for (const d of dukkanlar.values()) {
      const k = d.grup && d.grup.userData.kepenk;
      if (!k) continue;
      const i = d.veri && d.veri.isletme;
      const kapali = !!i && i.durum !== 'ruhsat' && !dukkanAcikMi(d);
      d.kapali = kapali;
      if (k.visible !== kapali) k.visible = kapali;
    }
  }
  function dukkanaGonder(d) {
    const m = bosMusteri();
    if (!m) return;
    const soldan = Math.random() < 0.5 ? -1 : 1;
    const kapi = new THREE.Vector3(d.merkezX + rnd(-0.6, 0.6), KALDIRIM_Y, d.onZ + d.yon * 0.25);
    m.position.set(d.merkezX + soldan * rnd(10, 14), KALDIRIM_Y, d.seritZ + rnd(-0.1, 0.1));
    m.visible = true;
    insanSaydamlik(m, 0);
    Object.assign(m.userData, {
      belir: 0,
      durum: 'yol', hedefDukkan: d, bekleme: rnd(4, 10), sonra: 'iceri',
      yol: [new THREE.Vector3(kapi.x, KALDIRIM_Y, d.seritZ), kapi],
      donus: [new THREE.Vector3(kapi.x, KALDIRIM_Y, d.seritZ), new THREE.Vector3(d.merkezX - soldan * rnd(11, 15), KALDIRIM_Y, d.seritZ)],
    });
    d.musteri = (d.musteri || 0) + 1;
  }

  // Sipariş balonu: oyuncu dokunursa bizzat servis yapmış olur (ek kazanç ve bahşiş)
  let sonrakiSiparisBalonu = 0;
  const sonSiparisMetni = new Map();
  function siparisVer(m, yer) {
    const an = performance.now();
    if (an < sonrakiSiparisBalonu || musteriler.some((k) => k.userData.siparis)) return;
    sonrakiSiparisBalonu = an + rnd(8000, 14000);
    const liste = SIPARISLER[yer.veri.kod] || ['Bir tane!'];
    const e = document.createElement('div');
    e.className = 'etiket gizli';
    const uygun = liste.filter((metin) => metin !== sonSiparisMetni.get(yer.veri.kod));
    const secim = (uygun.length ? uygun : liste);
    const metin = secim[Math.floor(Math.random() * secim.length)];
    sonSiparisMetni.set(yer.veri.kod, metin);
    const gorunen=yer.veri.kod==='simit'?dilMetni('dialog.simit'+(liste.indexOf(metin)+1)):npcMetni(metin);
    e.innerHTML = `<button class="siparis">${esc(gorunen)}</button>`;
    etiketKutusu.appendChild(e);
    m.userData.siparis = e;
    m.userData.bekleme = Math.max(m.userData.bekleme, 6);
    e.querySelector('button').addEventListener('click', (ev) => {
      ev.stopPropagation();
      const rect = e.getBoundingClientRect();
      siparisKaldir(m);
      m.userData.insan.oynat('Interact', 0.2);
      m.userData.bekleme = 1.4;
      servisTik(yer.veri.kod, rect);
    });
  }
  function siparisKaldir(m) {
    if (m.userData.siparis) { m.userData.siparis.remove(); m.userData.siparis = null; }
  }

  let sonTezgahMusterisi = 0;
  let sonDukkanMusterisi = 0;
  let sonKepenk = -99;
  function musteriGuncelle(dt, t, animDt) {
    if (t - sonKepenk > 2) { sonKepenk = t; kepenkleriGuncelle(); }
    if (animDt && t - sonTezgahMusterisi > rnd(1.5, 3.5)) {
      sonTezgahMusterisi = t;
      const calisan = [...yerler.values(), ...[...komsular.values()].filter((k) => !k.sehir && k.model)].filter((y) => y.grup.visible && y.aktif && y.aktif.bitis > simdi() && (y.musteri || 0) < 2 && yakinMi(y.grup.position.x, y.grup.position.z, 10));
      // 0.41: kendi tezgâhların öncelikli (komşu tezgâhlar çoğalınca sipariş balonu ve toplu sipariş seyrekleşiyordu)
      const benim = calisan.filter((y) => !y.komsu);
      if (benim.length && Math.random() < 0.7) tezgahaGonder(benim[Math.floor(Math.random() * benim.length)]);
      else if (calisan.length) tezgahaGonder(calisan[Math.floor(Math.random() * calisan.length)]);
    }
    if (animDt && t - sonDukkanMusterisi > rnd(1.2, 3.5) * (1.4 - yogunluk() * 0.6)) {
      sonDukkanMusterisi = t;
      const acik = [...dukkanlar.values()].filter((d) => dukkanAcikMi(d) && (d.musteri || 0) < 2 && yakinMi(d.merkezX, d.onZ, 10));
      if (acik.length) dukkanaGonder(acik[Math.floor(Math.random() * acik.length)]);
    }
    for (const m of musteriler) {
      const u = m.userData;
      if (u.durum === 'havuz') continue;
      const ins = u.insan;
      // belirme / solma: gelişte yavaşça belirir; ayrılırken son iki metrede, dükkâna girerken kapıda solar
      if (u.belir < 1) u.belir = Math.min(1, u.belir + dt * 1.2);
      let solma = 1;
      if ((u.durum === 'gidis' && u.yol.length === 1) || (u.durum === 'yol' && u.sonra === 'iceri' && u.yol.length === 1)) {
        const son = u.yol[0];
        solma = Math.min(1, Math.hypot(son.x - m.position.x, son.z - m.position.z) / (u.durum === 'gidis' ? 2.2 : 0.9));
      }
      insanSaydamlik(m, Math.min(u.belir, solma));
      if (u.durum === 'yol' || u.durum === 'gidis') {
        const hedef = u.yol[0];
        const f = new THREE.Vector3().subVectors(hedef, m.position);
        f.y = 0;
        const uzaklik = f.length();
        if (uzaklik < 0.06) {
          u.yolSure = 0;
          u.yol.shift();
          if (!u.yol.length) {
            if (u.durum === 'gidis') {
              u.durum = 'havuz';
              m.visible = false;
            } else if (u.sonra === 'iceri' && u.hedefDukkan && !dukkanAcikMi(u.hedefDukkan)) {
              // vardığında dükkân kapanmışsa içeri girmez, yoluna devam eder
              u.hedefDukkan.musteri = Math.max(0, (u.hedefDukkan.musteri || 1) - 1);
              u.hedefDukkan = null;
              u.durum = 'gidis';
              u.yol = u.donus;
            } else if (u.sonra === 'iceri') {
              u.durum = 'iceride';
              m.visible = false;
            } else {
              u.durum = 'bekle';
              if (u.hedefYer && !u.hedefYer.komsu && Math.random() < 0.85) siparisVer(m, u.hedefYer);
            }
          }
        } else {
          // engellerin (tezgâh, bank…) etrafından dolaşarak yürür; çok uzun takılırsa hedefe atlar
          const aci = kalabalik.yuru(m.position, hedef.x, hedef.z, 1.2 * dt);
          if (aci !== null) yonel(m, aci, dt);
          ins.oynat('Walk_Loop', 0.25, 1);
          u.yolSure = (u.yolSure || 0) + dt;
          if (u.yolSure > 25) { m.position.x = hedef.x; m.position.z = hedef.z; u.yolSure = 0; }
        }
      } else if (u.durum === 'bekle') {
        yonel(m, Math.PI, dt);
        if (!u.siparis && u.bekleme < 1.5) ins.oynat('Interact', 0.3);
        else ins.oynat('Idle_Talking_Loop', 0.35);
        u.bekleme -= dt;
        const hala = u.hedefYer && u.hedefYer.aktif && u.hedefYer.aktif.bitis > simdi();
        if (u.bekleme <= 0 || !hala) {
          siparisKaldir(m);
          if (u.hedefYer) u.hedefYer.musteri = Math.max(0, (u.hedefYer.musteri || 1) - 1);
          u.hedefYer = null;
          u.durum = 'gidis';
          u.yol = u.donus;
        }
      } else if (u.durum === 'iceride') {
        u.bekleme -= dt;
        if (u.bekleme <= 0) {
          if (u.hedefDukkan) u.hedefDukkan.musteri = Math.max(0, (u.hedefDukkan.musteri || 1) - 1);
          const d = u.hedefDukkan;
          u.hedefDukkan = null;
          m.visible = true;
          u.belir = 0;
          m.rotation.y = d && d.yon > 0 ? 0 : Math.PI;
          u.durum = 'gidis';
          u.yol = u.donus;
        }
      }
      if (m.visible && animDt) insanGuncelle(m, animDt);
    }
  }

  // ------------------------------------------------ Komşu tezgâhları ve başka ilçeyi gezme
  // Aynı ilçedeki diğer oyuncuların açık tezgâhları caddenin ara sokaklardan sonraki uzantısında durur.
  // Başka bir ilçe gezilirken o ilçenin dükkânları kurulur, oradaki oyuncuların tezgâhları ana sıralara dizilir,
  // kendi tezgâhlarımız gizlenir; dönünce her şey eski hâline gelir.
  const komsular = new Map();
  let ziyaret = null;
  let kendiCadde = null;
  // Semtin caddelerinde komşu tezgâhlar için yerler: caddelerin iki kenarı boyunca, kavşaklardan uzak,
  // mahalleye en yakından başlayarak (ilk gelen oyuncular hemen yanı başında, kalabalık ilçelerde semt boyunca)
  let sehirYerleri = null;
  function sehirYerleriniHazirla() {
    if (sehirYerleri || !sehir || !sehir.yollar) return sehirYerleri || [];
    const { yatay, dikey, orta, Y2, cekirdek: c } = sehir.yollar;
    const l = [];
    const tumDikey = [...dikey, ...orta];
    const cekirdekte = (x, z) => x > c.x1 - 4 && x < c.x2 + 4 && z > c.zK - 4 && z < c.zG + 4;
    const kavsakta = (d, liste) => liste.some((v) => Math.abs(v - d) < Y2 + 7);
    const R = Math.min(SEHIR_YARICAP * 0.8, 700);
    for (const z0 of yatay) {
      for (let x = -R; x <= R; x += 17) {
        if (kavsakta(x, tumDikey)) continue;
        for (const yan of [-1, 1]) {
          const z = z0 + yan * (Y2 - 1.1);
          if (cekirdekte(x, z) || Math.hypot(x, z - ORTA_Z) > R) continue;
          l.push({ x, z, ry: yan < 0 ? 0 : Math.PI, sehir: true });
        }
      }
    }
    for (const x0 of dikey) {
      for (let z = -R; z <= R * 0.75; z += 17) {
        if (kavsakta(z, yatay)) continue;
        for (const yan of [-1, 1]) {
          const x = x0 + yan * (Y2 - 1.1);
          if (cekirdekte(x, z) || Math.hypot(x, z - ORTA_Z) > R) continue;
          l.push({ x, z, ry: yan < 0 ? Math.PI / 2 : -Math.PI / 2, sehir: true });
        }
      }
    }
    // mahalleye yakın olanlar önce; aynı uzaklıktakiler karışık (hep aynı caddeye yığılmasın)
    l.sort((a, b) => Math.hypot(a.x, a.z - ORTA_Z) - Math.hypot(b.x, b.z - ORTA_Z));
    sehirYerleri = l;
    return l;
  }
  function komsuKonumlari(adet, mod) {
    const l = [];
    if (mod === 'sehir') {
      // önce caddenin uzantısındaki (ara sokakların dışındaki) yerler, sonra semtin caddeleri
      const kenar = komsuKonumlari(Math.min(adet, 8), 'kenar');
      return [...kenar, ...sehirYerleriniHazirla().slice(0, Math.max(0, adet - kenar.length))];
    }
    if (mod === 'ana') {
      const n = Math.max(adet, isler.length || 12);
      for (let i = 0; i < adet; i++) l.push(yerKonumu(i, n));
      return l;
    }
    const sutun = Math.max(1, Math.floor((70 - 16) / ARALIK) + 1);
    for (let j = 0; j < sutun && l.length < adet; j++) {
      for (const [x, guney] of [[XD + 12 + j * ARALIK, true], [XB - 12 - j * ARALIK, true], [XD + 12 + j * ARALIK + 1.8, false], [XB - 12 - j * ARALIK - 1.8, false]]) {
        if (l.length < adet) l.push({ x, z: guney ? GUNEY_TEZGAH_Z : TEZGAH_Z, guney });
      }
    }
    return l;
  }
  // Komşu tezgâh önce yalnızca etiket (kuş bakışında iğne) ve dokunma alanıyla kurulur; kamera yaklaşınca tezgâhın
  // kendisi, satıcısı ve ışıkları yüklenir, uzaklaşınca kaldırılır (60 tezgâh ve satıcı birden çizilmez).
  function komsuKur(x, p) {
    const grup = new THREE.Group();
    // semtin caddelerinde tezgâh yol kenarında (asfaltta), satıcı arkasında kaldırımda durur
    grup.position.set(p.x, p.sehir ? 0.02 : KALDIRIM_Y, p.z);
    grup.rotation.y = p.ry || 0;
    const govde = new THREE.Group();
    govde.scale.setScalar(OLCEK);
    grup.add(govde);
    const isabet = new THREE.Mesh(new THREE.BoxGeometry(3.8, 4.2, 3.6), new THREE.MeshBasicMaterial({ visible: false }));
    isabet.position.y = 1.9;
    isabet.userData.komsu = x.id;
    grup.add(isabet);
    sahne.add(grup);
    const etiket = document.createElement('div');
    etiket.className = 'etiket gizli';
    etiketKutusu.appendChild(etiket);
    etiket.addEventListener('click', (e) => { e.stopPropagation(); const k = komsular.get(x.id); if (k) komsuTiklandi(k.veri); });
    const dik = Math.abs(Math.sin(p.ry || 0)) > 0.5;
    const engel = kalabalik.engelEkle(p.x, p.z, dik ? 2.4 : 5.0, dik ? 5.0 : 2.4);
    const k = { grup, govde, model: null, insan: null, isabet, etiket, ampul: null, isik: null, engel, guney: p.guney, sehir: !!p.sehir, p, isKodu: x.isKodu, calisan: x.calisan, komsu: true, buyume: 1, musteri: 0, gorunum: x.gorunum || null };
    return k;
  }
  function komsuDetay(k, gerekli) {
    if (gerekli && !k.model) {
      k.model = tezgahModeli(k.isKodu, k.gorunum);
      k.model.traverse((o) => { if (o.userData.acikta) o.visible = true; });
      k.model.scale.setScalar(0.01);
      k.buyume = 0;
      k.govde.add(k.model);
      k.insan = insanUret(k.calisan === 'cirak' ? 'cirak' : 'ben');
      k.insan.position.set(0.2, k.p.sehir ? 0.16 : 0, -1.3);
      k.insan.userData.insan.oynat('Idle_Talking_Loop', 0);
      k.grup.add(k.insan);
      k.ampul = hale('#FFD28A', 2.6);
      k.ampul.position.set(0, 2.6, 0.2);
      k.isik = isikLekesi('#FFC878', 5);
      k.isik.position.y = 0.03;
      k.grup.add(k.ampul, k.isik);
      gecelik.haleler.add(k.ampul).add(k.isik);
    } else if (!gerekli && k.model) {
      gecelik.haleler.delete(k.ampul); gecelik.haleler.delete(k.isik);
      k.govde.remove(k.model);
      k.grup.remove(k.insan, k.ampul, k.isik);
      bellektenSil(k.model);
      bellektenSil(k.insan, { geometri: false });
      bellektenSil(k.ampul); bellektenSil(k.isik);
      k.model = k.insan = k.ampul = k.isik = null;
    }
  }
  function komsuDetaylariAyarla() {
    for (const k of komsular.values()) {
      const u = Math.hypot(k.grup.position.x - hedefX, k.grup.position.z - hedefZ);
      // yakındaysa yükle; kaldırmak için biraz daha uzaklaşmak gerekir (sınırda gidip gelmesin)
      if (!k.model && u < 150 && mesafe < 230) komsuDetay(k, true);
      else if (k.model && (u > 230 || mesafe > 320)) komsuDetay(k, false);
    }
  }
  function komsuSil(k) {
    komsuDetay(k, false);
    kalabalik.engelSil(k.engel);
    sahne.remove(k.grup);
    bellektenSil(k.grup, { geometri: false });
    k.etiket.remove();
  }
  function komsuEtiketi(k) {
    const x = k.veri;
    const html = `<button class="balon komsu-balon"><span class="kb-simge">${x.simge}</span><span><b>${esc(x.ad)}</b><small>${esc(x.isAdi)} · ${x.seviye}. sv</small></span></button>`;
    if (k.etiket._html !== html) { k.etiket.innerHTML = html; k.etiket._html = html; }
  }
  function komsulariAyarla(liste, mod = 'kenar') {
    if (!kuruldu) return;
    const gelen = new Set(liste.map((x) => x.id));
    for (const [id, k] of komsular) if (!gelen.has(id) || k.mod !== mod) { komsuSil(k); komsular.delete(id); }
    const yerlesim = komsuKonumlari(liste.length, mod);
    liste.forEach((x, i) => {
      const p = yerlesim[i];
      if (!p) return;
      let k = komsular.get(x.id);
      if (!k) { k = komsuKur(x, p); k.mod = mod; komsular.set(x.id, k); }
      k.veri = x;
      k.aktif = { bitis: x.bitis };
      komsuEtiketi(k);
    });
  }
  function kendiTezgahlariGizle(gizle) {
    for (const y of yerler.values()) {
      y.grup.visible = !gizle;
      if (gizle) {
        y.etiket.classList.add('gizli');
        if (y.engel) { kalabalik.engelSil(y.engel); y.engel = null; }
      } else if (y.model && !y.engel) {
        y.engel = kalabalik.engelEkle(y.grup.position.x, y.grup.position.z, 5.0, 2.4);
      }
    }
    if (arabam) arabam.g.visible = !gizle;
  }
  function musterileriSal() {
    for (const m of musteriler) {
      if (m.userData.durum === 'havuz') continue;
      siparisKaldir(m);
      m.userData.durum = 'havuz';
      m.userData.hedefYer = null;
      m.userData.hedefDukkan = null;
      m.visible = false;
    }
    for (const y of yerler.values()) y.musteri = 0;
    for (const d of dukkanlar.values()) d.musteri = 0;
  }
  function ziyaretBasla(v) {
    if (!kuruldu) return false;
    ziyaret = { ilce: v.ilce };
    kendiTezgahlariGizle(true);
    musterileriSal();
    caddeGuncelle(v.yerler, v.isimler, true);
    komsulariAyarla(v.tezgahlar || [], 'ana');
    tumunuGoster = { aniden: false };
    if (boyut.ilk) tumunuGosterUygula();
    return true;
  }
  function ziyaretBitir() {
    if (!ziyaret) return;
    ziyaret = null;
    musterileriSal();
    komsulariAyarla([], 'ana');
    kendiTezgahlariGizle(false);
    if (kendiCadde) caddeGuncelle(kendiCadde.yerler, kendiCadde.isimler, true);
    tumunuGoster = { aniden: false };
    if (boyut.ilk) tumunuGosterUygula();
  }

  // ------------------------------------------------ Tezgâh yerleri
  const yerler = new Map();
  let isler = [];
  let aktifler = [];

  function yerKur(liste) {
    liste.forEach((is, sira) => {
      if (yerler.has(is.kod)) return;
      const grup = new THREE.Group();
      const k = yerKonumu(sira, liste.length);
      grup.position.set(k.x, KALDIRIM_Y, k.z);
      const govde = new THREE.Group();
      govde.scale.setScalar(OLCEK);
      grup.add(govde);
      const isabet = new THREE.Mesh(new THREE.BoxGeometry(3.8, 4.2, 3.6), new THREE.MeshBasicMaterial({ visible: false }));
      isabet.position.y = 1.9;
      isabet.userData.kod = is.kod;
      grup.add(isabet);
      const ampul = hale('#FFD28A', 2.6);
      ampul.position.set(0, 2.6, 0.2);
      const isik = isikLekesi('#FFC878', 5);
      isik.position.y = 0.03;
      ampul.visible = isik.visible = false;
      grup.add(ampul, isik);
      gecelik.haleler.add(ampul).add(isik);
      sahne.add(grup);
      const etiket = document.createElement('div');
      etiket.className = 'etiket gizli';
      etiketKutusu.appendChild(etiket);
      yerler.set(is.kod, { grup, govde, model: null, isabet, etiket, insan: null, durum: '', veri: is, ampul, isik, guney: k.guney });
    });
  }

  // 0.41: tezgâhın yanındaki para kutusu kaldırıldı (kazanç panelde ve uçan yazılarla görünür)
  function paraGuncelle() {}
  // tezgâhta biriken kazanç (etiketteki 💰 tutarı): satış ilerledikçe ve bahşiş geldikçe büyür
  function birikim(a) {
    if (!a) return 0;
    const oran = Math.max(0, Math.min(1, (simdi() - a.baslangic) / (a.bitis - a.baslangic)));
    return Math.round((a.ciro || 0) * oran + (a.bonus || 0));
  }

  function durumAnahtari(is, a) {
    if (a) return a.bitis <= simdi() ? 'bitti' : 'suruyor-' + a.calisan;
    if (is.sahip) return 'bos';
    if (is.kilitli) return 'kilit';
    return 'satin';
  }

  function durumGuncelle(veri) {
    isler = veri.isler;
    aktifler = veri.aktifler;
    yerKur(isler);
    // 0.42.2: tezgâh deseni ve ışık zinciri (mağaza); değişince tezgâhlar yeniden kurulur
    const gor = veri.gorunum || null;
    const gorAnahtar = gor ? JSON.stringify(gor) : '';
    for (const is of isler) {
      const y = yerler.get(is.kod);
      y.veri = is;
      const a = aktifler.find((z) => z.isKodu === is.kod) || null;
      y.aktif = a;
      if (is.sahip && y.model && y.gorAnahtar !== gorAnahtar && !introCekim) {
        y.govde.remove(y.model, y.ortu);
        bellektenSil(y.model); bellektenSil(y.ortu);
        kalabalik.engelSil(y.engel); y.engel = null;
        if (y.tabure) { y.grup.remove(y.tabure); bellektenSil(y.tabure); y.tabure = null; }
        y.model = y.ortu = null;
      }
      if (is.sahip && !y.model) {
        y.gorAnahtar = gorAnahtar;
        // tezgâh yürüyenler için engeldir (içinden geçilmez)
        y.engel = kalabalik.engelEkle(y.grup.position.x, y.grup.position.z, 5.0, 2.4); // tezgâh, halı, tabela ve kasalar
        y.model = tezgahModeli(is.kod, gor);
        // örtü (branda) tezgâhın gövdesinin ölçüsünde, tabanı yerde
        const { boy, merkez } = y.model.userData.govdeKutu;
        y.ortu = ortu(boy, is.kod, { desen: gor && gor.desen });
        y.ortu.position.set(merkez.x, merkez.y - boy.y / 2, merkez.z);
        y.acikta = [];
        y.model.traverse((o) => { if (o.userData.acikta) y.acikta.push(o); });
        y.govde.add(y.model, y.ortu);
        y.model.scale.setScalar(0.01);
        y.buyume = 0;
        if (is.kod === 'ayakkabi') {
          y.tabure = tabure();
          y.tabure.position.set(-0.85, 0, -0.25);
          y.grup.add(y.tabure);
        }
      } else if (!is.sahip && y.model) {
        kalabalik.engelSil(y.engel);
        y.engel = null;
        y.govde.remove(y.model, y.ortu);
        bellektenSil(y.model); bellektenSil(y.ortu);
        if (y.tabure) { y.grup.remove(y.tabure); bellektenSil(y.tabure); }
        y.model = y.ortu = y.tabure = null;
      }
      if (y.ortu) y.ortu.visible = !a;
      if (y.acikta) for (const o of y.acikta) o.visible = !!a;
      // yerdeki çerçeve: satın alınabilir yerde "+", kilitli yerde soluk kilit, çalışmayan kendi tezgâhında "▶"
      const bosTur = !is.sahip ? (is.kilitli ? 'kilit' : 'arti') : !a ? 'oynat' : null;
      if (y.bos && y.bos.userData.tur !== bosTur) {
        y.grup.remove(y.bos);
        bellektenSil(y.bos);
        y.bos = null;
      }
      if (bosTur && !y.bos) {
        y.bos = bosYer(bosTur);
        // ▶ çerçevesi tezgâhın önünde (müşterinin durduğu yanda) durur
        if (bosTur === 'oynat') { y.bos.scale.setScalar(0.62); y.bos.position.z = y.guney ? -1.9 : 1.9; }
        y.grup.add(y.bos);
      }
      vitrinGuncelle(y, is);
      y.ampul.visible = y.isik.visible = !!a;
      const kim = a ? a.calisan : null;
      if (y.insanTur !== kim) {
        if (y.insan) { y.grup.remove(y.insan); bellektenSil(y.insan, { geometri: false }); }
        y.insan = null;
        if (kim) {
          y.insan = insanUret(kim);
          if (is.kod === 'ayakkabi') {
            y.insan.position.set(-0.85, 0.02, -0.25);
            y.insan.rotation.y = Math.PI / 2;
            y.insan.userData.insan.oynat('Sitting_Idle_Loop', 0);
          } else {
            y.insan.position.set(0.2, 0, -1.3);
            y.insan.userData.insan.oynat('Idle_Talking_Loop', 0);
          }
          y.grup.add(y.insan);
        }
        y.insanTur = kim;
      }
      y.durum = '';
      etiketCiz(y);
    }
    if (ziyaret) kendiTezgahlariGizle(true);
    if (introDolgu) introDolguUygula();
  }

  // ------------------------------------------------ Tanıtım: dolu sokak ve tezgâh açılışı
  // Tanıtım boyunca sokaktaki bütün tezgâh yerleri açık tezgâhla ve taburesinde oturan satıcıyla doldurulur
  // (sokak boş görünmesin). Oyuncunun kendi tezgâhında küçük bir açılış hazırlığı oynatılır:
  // satıcı gelir, brandayı kaldırıp katlar, mallar tezgâha dizilir, satıcı taburesine oturur.
  // Tanıtım bitince her şey oyunun gerçek durumuna döner.
  let introDolgu = null;
  function introSatici(tur) {
    const ins = insanUret(tur);
    ins.userData.insan.oynat('Sitting_Idle_Loop', 0);
    return ins;
  }
  function introDoldur(acik, anaKod) {
    if (!acik) {
      if (!introDolgu) return;
      for (const [y, d] of introDolgu.yerler) {
        if (d.model) { y.govde.remove(d.model); bellektenSil(d.model); }
        if (d.ortu) { y.govde.remove(d.ortu); bellektenSil(d.ortu); }
        if (d.insan) { y.grup.remove(d.insan); bellektenSil(d.insan, { geometri: false }); }
        if (d.tabure) { y.grup.remove(d.tabure); bellektenSil(d.tabure); }
        if (d.engel) kalabalik.engelSil(d.engel);
        if (y.ortu) { y.ortu.visible = !y.aktif; y.ortu.position.copy(d.ortuYer || y.ortu.position); y.ortu.scale.setScalar(1); y.ortu.rotation.set(0, 0, 0); }
        if (y.acikta) for (const o of y.acikta) { o.visible = !!y.aktif; if (o.userData.introOlcek) { o.scale.copy(o.userData.introOlcek); delete o.userData.introOlcek; } }
        if (y.bos) y.bos.visible = true;
        y.ampul.visible = y.isik.visible = !!y.aktif;
      }
      introDolgu = null;
      return;
    }
    if (introDolgu) return introDolgu.konum;
    introDolgu = { yerler: new Map(), acilis: null };
    const liste = [...yerler.values()];
    const ana = (anaKod && yerler.get(anaKod)) || liste.find((y) => y.veri && y.veri.sahip) || liste[0];
    for (const y of liste) {
      if (y.aktif && y.insan) continue; // zaten çalışan tezgâh
      const d = {};
      if (!y.model) {
        d.model = tezgahModeli(y.veri.kod);
        d.model.traverse((o) => { if (o.userData.acikta) o.visible = true; });
        y.govde.add(d.model);
      }
      d.tabure = tabure();
      d.tabure.position.set(0.95, 0, -1.45);
      y.grup.add(d.tabure);
      d.insan = introSatici(y.veri && y.veri.sahip ? 'ben' : 'yaya');
      d.insan.position.set(0.95, 0.02, -1.45);
      y.grup.add(d.insan);
      if (d.model) d.engel = kalabalik.engelEkle(y.grup.position.x, y.grup.position.z, 5.0, 2.4);
      introDolgu.yerler.set(y, d);
      // filmde bütün tezgâhlar çalışır: gece ampulleri ve ışıkları yanar
      if (introCekim && y.ampul && y.isik) { y.ampul.visible = y.isik.visible = true; gecelik.haleler.add(y.ampul).add(y.isik); }
      if (y === ana) {
        // açılış hazırlığı: brandalı başlar, satıcı tezgâhın yanında ayakta bekler
        const model = y.model || d.model;
        if (!y.ortu) {
          const { boy, merkez } = model.userData.govdeKutu;
          d.ortu = ortu(boy, y.veri.kod);
          d.ortu.position.set(merkez.x, merkez.y - boy.y / 2, merkez.z);
          y.govde.add(d.ortu);
        }
        const o = y.ortu || d.ortu;
        d.ortuYer = o.position.clone();
        const acikta = [];
        model.traverse((x) => { if (introCekim ? x.userData.introUrun : x.userData.acikta) acikta.push(x); });
        // Kaldırım tabelası ürün değildir; çekimde branda açılırken ekrana sıçramasın.
        if (introCekim && y.veri.kod === 'simit') model.traverse((x) => { if (x.userData.acikta && x.type === 'Group' && x.position.x < -1.2) x.visible = false; });
        introDolgu.acilis = { y, d, ortu: o, acikta, t: -1 };
        d.insan.position.set(-2.1, 0, -1.65);
        d.insan.rotation.y = Math.PI / 2;
        d.insan.userData.insan.oynat('Idle_Loop', 0);
      }
    }
    introDolguUygula();
    introDolgu.konum = ana ? { x: ana.grup.position.x, z: ana.grup.position.z } : null;
    return introDolgu.konum;
  }
  // durum yenilense de tanıtımdaki görünüm korunur
  function introDolguUygula() {
    for (const [y, d] of introDolgu.yerler) {
      const acilis = introDolgu.acilis && introDolgu.acilis.y === y;
      const once = acilis && introDolgu.acilis.t < 0;
      if (y.ortu && !d.ortu) y.ortu.visible = once;
      if (d.ortu) d.ortu.visible = once;
      if (y.acikta && !d.model) for (const o of y.acikta) o.visible = !once;
      if (acilis && (once || introCekim)) for (const o of introDolgu.acilis.acikta) o.visible = false;
      if (y.bos) y.bos.visible = false;
      if (y.etiket) y.etiket.classList.add('gizli');
    }
  }
  function introAcilisBaslat() { if (introDolgu && introDolgu.acilis) introDolgu.acilis.t = 0; }
  const yumusakK = (k) => { k = Math.max(0, Math.min(1, k)); return k * k * (3 - 2 * k); };
  function introDolguGuncelle(dt) {
    for (const d of introDolgu.yerler.values()) if (d.insan) insanGuncelle(d.insan, dt);
    const a = introDolgu.acilis;
    if (!a || a.t < 0 || a.bitti) return;
    a.t += dt;
    const t = a.t;
    const ins = a.d.insan;
    // 0-0.5 sn: satıcı brandanın yanına yürür
    if (t < 0.5) {
      if (!a.yuruyor) { a.yuruyor = true; ins.userData.insan.oynat('Walk_Loop', 0.2, 1); }
      ins.position.x = -2.1 + yumusakK(t / 0.5) * 0.6;
    }
    // 0.4-1.2 sn: branda kalkar, katlanıp kaybolur
    const kb = yumusakK((t - 0.4) / 0.8);
    if (t > 0.4 && !a.brandaBitti) {
      if (!a.uzaniyor) { a.uzaniyor = true; ins.userData.insan.oynat('Interact', 0.2); }
      a.ortu.visible = kb < 1;
      a.ortu.position.y = a.d.ortuYer.y + kb * 1.4;
      a.ortu.scale.set(1 - kb * 0.55, Math.max(0.02, 1 - kb), 1 - kb * 0.55);
      a.ortu.rotation.z = kb * 0.35;
      if (kb >= 1) a.brandaBitti = true;
    }
    // 0.9-1.9 sn: mallar sırayla tezgâha dizilir
    if (t > 0.9) {
      a.acikta.forEach((o, i) => {
        const k = Math.max(0, Math.min(1, (t - 0.9 - i * (0.9 / Math.max(1, a.acikta.length))) / 0.35));
        if (k <= 0) return;
        if (!o.userData.introOlcek) o.userData.introOlcek = o.scale.clone();
        o.visible = true;
        const s2 = k < 0.7 ? (k / 0.7) * 1.12 : 1.12 - ((k - 0.7) / 0.3) * 0.12;
        o.scale.copy(o.userData.introOlcek).multiplyScalar(Math.max(0.01, s2));
      });
    }
    // 1.5-2.2 sn: taburesine geçip oturur
    if (t > 1.5) {
      const k = yumusakK((t - 1.5) / 0.5);
      if (!a.gidiyor) { a.gidiyor = true; ins.userData.insan.oynat('Walk_Loop', 0.2, 1); }
      ins.position.x = -1.5 + k * (0.95 + 1.5);
      ins.position.z = -1.65 + k * 0.2;
      ins.rotation.y = Math.PI / 2 * (1 - k);
      if (k >= 1 && !a.oturdu) {
        a.oturdu = true;
        ins.position.set(0.95, 0.02, -1.45);
        ins.rotation.y = 0;
        ins.userData.insan.oynat('Sitting_Idle_Loop', 0.25);
        a.y.ampul.visible = a.y.isik.visible = true;
      }
    }
    if (t > 2.4) a.bitti = true;
  }

  // Sahibi olmayan tezgâh yeri: brandası kapalı bir tezgâh ve üstünde adı, fiyatı, "SATIN AL" yazan levha.
  // Yerdeki yanıp sönen "+" çerçevesi de durur. Kilitli yerde levha gri, seviye yazar.
  // Satın alınmamış tezgâhlarda yalnızca yerdeki yanıp sönen "+" çerçevesi durur (0.14'teki brandalı vitrin kaldırıldı)
  function vitrinGuncelle(y) {
    if (y.vitrin) { y.govde.remove(y.vitrin); bellektenSil(y.vitrin); y.vitrin = null; }
    if (y.levha) { y.grup.remove(y.levha); bellektenSil(y.levha); y.levha = null; }
  }

  // Tezgâh bilgisi sade durur: yalnızca ilerleme halkası. Halkaya tıklayınca (dokununca) süre,
  // çırak ve birikim açılır, halkaya yeniden tıklayınca kapanır; kapatılmazsa 30 saniye sonra kendiliğinden kapanır.
  const ACIK_SURE = 30000;
  function etiketAc(y) {
    y.acikBitis = Date.now() + ACIK_SURE;
    etiketCiz(y);
  }
  function etiketDegistir(y) {
    if ((y.acikBitis || 0) > Date.now()) { y.acikBitis = 0; etiketCiz(y); }
    else etiketAc(y);
  }
  function etiketCiz(y) {
    const is = y.veri;
    const a = y.aktif;
    const acik = (y.acikBitis || 0) > Date.now();
    // (0.37.22) ayrıntı balonu açıkken iş biterse kese yine çizilir; önceden 30 sn boyunca hiçbir şey görünmüyordu
    const temel = durumAnahtari(is, a);
    const d = temel + (acik && temel.startsWith('suruyor') ? '-acik' : '');
    if (d === y.durum) {
      if (d.startsWith('suruyor')) {
        const oran = Math.max(0, Math.min(1, (simdi() - a.baslangic) / (a.bitis - a.baslangic)));
        const daire = y.etiket.querySelectorAll('circle')[1];
        if (daire) daire.setAttribute('stroke-dashoffset', String(Number(daire.getAttribute('stroke-dasharray')) * (1 - oran)));
        if (!acik) return;
        const sayac = y.etiket.querySelector('.sayi');
        if (sayac) sayac.textContent = sureMetni(a.bitis - simdi());
        const bir = y.etiket.querySelector('.birikim');
        if (bir) bir.textContent = '💰 ' + sade(birikim(a)) + ' ₺';
      }
      return;
    }
    y.durum = d;
    const e = y.etiket;
    if (d === 'bitti') {
      e.innerHTML = `<button class="kese" data-kese="${is.kod}" aria-label="${esc(npcSablon`${is.ad} kazancını topla`)}">💰</button>`;
    } else if (d.startsWith('suruyor')) {
      const oran = (simdi() - a.baslangic) / (a.bitis - a.baslangic);
      e.innerHTML = acik ? `<button class="balon" data-yer="${is.kod}">
        <span class="halka" data-halka="${is.kod}" title="${esc(dilMetni('common.close'))}">${halkaSvg(oran, 30, 4, '#1FA25A', '#E3E6EE')}<b>${is.simge}</b></span>
        <span><span class="sayi">${sureMetni(a.bitis - simdi())}</span>${a.calisan === 'cirak' ? `<span class="cirak">${esc(npcMetni('Çırak'))}</span>` : ''}<span class="birikim sayi">💰 ${sade(birikim(a))} ₺</span></span></button>`
        : `<button class="balon mini" data-yer="${is.kod}" data-mini aria-label="${esc(is.ad)}"><span class="halka">${halkaSvg(oran, 30, 4, '#1FA25A', '#E3E6EE')}<b>${is.simge}</b></span></button>`;
    } else {
      // boştaki kendi tezgâhında yerde yanıp sönen ▶, satın alınabilir yerde "+" çerçevesi var; balon yok
      // satın alınabilir ve kilitli yerlerde bilgi tezgâhın üstündeki levhada yazar
      e.innerHTML = '';
    }
  }

  // Kese dokunuşu parmak değer değmez işlenir: etiketler her karede ekranda kaydığı ve durum değişince
  // yeniden çizildiği için "click" bazen hiç oluşmuyor, oyuncu 2-3 kez dokunmak zorunda kalıyordu.
  etiketKutusu.addEventListener('pointerdown', (ev) => {
    const kese = ev.target.closest('[data-kese]');
    if (!kese || (ev.button !== undefined && ev.button !== 0)) return;
    ev.preventDefault();
    keseTik(kese.dataset.kese, kese.getBoundingClientRect());
  });
  etiketKutusu.addEventListener('click', (ev) => {
    const kese = ev.target.closest('[data-kese]');
    if (kese) return;
    const yer = ev.target.closest('[data-yer]');
    const halka = ev.target.closest('[data-halka]');
    const mini = yer && yer.hasAttribute('data-mini') ? yer.dataset.yer : null;
    if (halka || mini) { const y = yerler.get(halka ? halka.dataset.halka : mini); if (y) etiketDegistir(y); return; }
    if (yer) return tiklandi(yer.dataset.yer);
    const dk = ev.target.closest('[data-dukkan]');
    if (dk) dukkanTiklandi(Number(dk.dataset.dukkan));
  });

  // ------------------------------------------------ Sokak olayları (zabıta, polis, ambulans…)
  // Park yerleri: görev aracı yanaşacağı yeri ayırır; ayrılan yere başka araba park etmez
  const REZERVE = { userData: { durum: 'rezerve' } };
  function parkAyir(xIstenen) {
    let en = null;
    for (let kay = 0; kay <= 24; kay += 1.5) {
      for (const x of [xIstenen + kay, xIstenen - kay]) {
        if (x < XB + 8 || x > XD - 8 || Math.abs(x - GECIT_X) < 6) continue;
        const dolu = parkYerleri.some((y) => y.araba && Math.abs(y.x - x) < 6.5) || parkEdenler.some((a) => Math.abs(a.position.x - x) < 7);
        if (!dolu) { en = x; break; }
      }
      if (en !== null) break;
    }
    if (en === null) return null;
    const yer = { x: en, araba: REZERVE, sure: 0, gecici: true };
    parkYerleri.push(yer);
    return en;
  }
  // Oyuncunun en değerli arabası caddenin güney kenarına park eder (üstünde küçük "🔑 Senin" etiketi)
  let arabam = null;
  function arabamAyarla(bilgi) {
    const anahtar = bilgi ? [bilgi.ad, bilgi.renk, bilgi.bitis, bilgi.plaka, bilgi.far, bilgi.jant].join('|') : '';
    if (arabam && arabam.anahtar === anahtar) return;
    if (arabam) {
      sahne.remove(arabam.g); bellektenSil(arabam.g);
      if (arabam.x != null) parkBirak(arabam.x);
      arabam.etiket.remove();
      arabam = null;
    }
    if (!bilgi || !kuruldu) return;
    const yer = [...yerler.values()].find((y) => y.veri && y.veri.sahip);
    const px = parkAyir(yer ? yer.grup.position.x + 3 : DURAK_X - 14);
    if (px == null) return;
    const g = araba(bilgi.govde === 'suv' ? 'suv' : bilgi.govde === 'spor' ? 'spor' : 'sedan', bilgi.renk, { bitis: bilgi.bitis, plaka: bilgi.plaka, far: bilgi.far, jant: bilgi.jant });
    g.position.set(px, 0.02, 7.3);
    sahne.add(g);
    const etiket = document.createElement('div');
    etiket.className = 'etiket gizli';
    etiket.innerHTML = `<div class="olay-balon arabam">🔑 ${esc(bilgi.ad)}${bilgi.plaka ? ` <span class="plaka-mini">${esc(bilgi.plaka)}</span>` : ''}</div>`;
    etiketKutusu.appendChild(etiket);
    arabam = { g, x: px, anahtar, etiket };
  }

  // 0.43: Havai fişek gösterisi — sunucudan gelen programa göre (ilçedeki herkes aynı anda görür).
  // Roketler parkın üstünden yükselir, 28–45 m'de patlayıp renkli kıvılcımlara dağılır. Tek bir Points nesnesi kullanılır.
  const FISEK_EN_COK = 2600;
  let fisekNokta = null, fisekPos, fisekRenk, fisekVeri = [], fisekListe = [], sonFisekAtis = 0, fisekBildirilen = new Set();
  const FISEK_RENKLER = [[1, 0.25, 0.25], [1, 0.8, 0.2], [0.3, 0.7, 1], [0.4, 1, 0.45], [1, 0.4, 0.95], [1, 1, 1], [1, 0.55, 0.15]];
  function fisekHazirla() {
    if (fisekNokta) return;
    const geo = new THREE.BufferGeometry();
    fisekPos = new Float32Array(FISEK_EN_COK * 3);
    fisekRenk = new Float32Array(FISEK_EN_COK * 3);
    for (let i = 0; i < FISEK_EN_COK; i++) fisekPos[i * 3 + 1] = -999;
    geo.setAttribute('position', new THREE.BufferAttribute(fisekPos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(fisekRenk, 3));
    const c = document.createElement('canvas'); c.width = c.height = 32;
    const kx = c.getContext('2d'); const gr = kx.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,0.7)'); gr.addColorStop(0.6, 'rgba(255,255,255,0.12)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    kx.fillStyle = gr; kx.fillRect(0, 0, 32, 32);
    const mat = new THREE.PointsMaterial({ size: 0.9, map: new THREE.CanvasTexture(c), vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true, fog: false });
    fisekNokta = new THREE.Points(geo, mat);
    fisekNokta.frustumCulled = false;
    fisekNokta.renderOrder = 5;
    sahne.add(fisekNokta);
    fisekVeri = [];
  }
  function havaiFisekAyarla(liste) { fisekListe = (liste || []).slice(); }
  const fisekIsin = new THREE.Vector3();
  function fisekRoket() {
    if (fisekVeri.length >= FISEK_EN_COK - 200) return;
    const renk = FISEK_RENKLER[Math.floor(Math.random() * FISEK_RENKLER.length)];
    // patlama noktası ekranın üst yarısında, kameradan uzaklığın ~%55–75'inde seçilir: hangi açıdan bakılırsa bakılsın görünür
    fisekIsin.set(rnd(-0.75, 0.75), rnd(0.05, 0.75), 0.5).unproject(kamera).sub(kamera.position).normalize();
    const uz = Math.max(18, kamera.position.distanceTo(new THREE.Vector3(hedefX, 1.2, hedefZ))) * rnd(0.55, 0.75);
    const px = kamera.position.x + fisekIsin.x * uz, py = Math.max(7, kamera.position.y + fisekIsin.y * uz), pz = kamera.position.z + fisekIsin.z * uz;
    const x = px + rnd(-1.5, 1.5), z = pz + rnd(-1.5, 1.5);
    fisekVeri.push({ x, y: Math.max(0.5, py - 30), z, vx: (px - x) / 1.4, vy: Math.min(30, py - Math.max(0.5, py - 30)) / 1.2, vz: (pz - z) / 1.4, omur: 1.2, yas: 0, roket: true, renk, buyuk: Math.random() < 0.35, hedefY: py, olcek: Math.max(0.3, Math.min(1, uz / 70)) });
    ses.havaiFisek && ses.havaiFisek(Math.max(-1, Math.min(1, (x - hedefX) / 40)), Math.max(0.15, 0.7 - mesafe / 400), true);
  }
  function fisekPatla(r) {
    const adet = r.buyuk ? 110 : 70;
    const ikinci = Math.random() < 0.4 ? FISEK_RENKLER[Math.floor(Math.random() * FISEK_RENKLER.length)] : null;
    for (let i = 0; i < adet && fisekVeri.length < FISEK_EN_COK; i++) {
      // küre üstünde düzgün dağılım
      const u = Math.random() * 2 - 1, a = Math.random() * Math.PI * 2, k = Math.sqrt(1 - u * u);
      const h = (r.buyuk ? 15 : 11) * (0.85 + Math.random() * 0.3) * (r.olcek || 1);
      fisekVeri.push({ x: r.x, y: r.y, z: r.z, vx: k * Math.cos(a) * h, vy: u * h + 2, vz: k * Math.sin(a) * h, omur: rnd(1.4, 2.4), yas: 0, renk: ikinci && i % 2 ? ikinci : r.renk, olcek: r.olcek || 1 });
    }
  }
  function fisekGuncelle(dt) {
    const t = simdi();
    const aktif = fisekListe.filter((f) => t >= f.bas && t < f.bit);
    if (!aktif.length && !fisekVeri.length) { if (fisekNokta) fisekNokta.visible = false; return; }
    fisekHazirla();
    fisekNokta.visible = true;
    fisekNokta.material.blending = gecePayi > 0.35 ? THREE.AdditiveBlending : THREE.NormalBlending;
    fisekNokta.material.size = gecePayi > 0.35 ? 0.55 : 0.7;
    for (const f of aktif) {
      if (!fisekBildirilen.has(f.id)) {
        fisekBildirilen.add(f.id);
        if (fisekBasladi) fisekBasladi(f, () => ucusYap(hedefX, 4, 70));
      }
      const kalan = f.bit - t;
      const aralik = (f.tur === 'buyuk' ? 0.8 : 1.4) / (kalan < 6000 ? 2 : 1);
      // aralık sahne zamanıyla sayılır (yavaş cihazda kıvılcımlar birikip ekranı kaplamasın)
      sonFisekAtis += dt;
      if (sonFisekAtis > aralik) {
        sonFisekAtis = 0;
        // kameranın önünde, binaların ardından
        fisekRoket();
      }
    }
    const G = 9.8;
    let n = 0;
    for (let i = fisekVeri.length - 1; i >= 0; i--) {
      const p = fisekVeri[i];
      p.yas += dt;
      if (p.roket) {
        if (p.yas >= p.omur || p.y >= p.hedefY) { fisekVeri.splice(i, 1); fisekPatla(p); continue; }
      } else {
        p.vy -= G * 0.45 * (p.olcek || 1) * dt;
        p.vx *= 1 - 1.4 * dt; p.vz *= 1 - 1.4 * dt; p.vy *= 1 - 0.8 * dt;
        if (p.yas >= p.omur) { fisekVeri.splice(i, 1); continue; }
      }
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    }
    for (const p of fisekVeri) {
      if (n >= FISEK_EN_COK) break;
      const s = p.roket ? 1 : Math.max(0, 1 - p.yas / p.omur);
      const parilti = p.roket ? 1 : (0.75 + Math.random() * 0.25) * s;
      fisekPos[n * 3] = p.x; fisekPos[n * 3 + 1] = p.y; fisekPos[n * 3 + 2] = p.z;
      fisekRenk[n * 3] = p.renk[0] * parilti; fisekRenk[n * 3 + 1] = p.renk[1] * parilti; fisekRenk[n * 3 + 2] = p.renk[2] * parilti;
      n++;
    }
    for (let i = n; i < (fisekNokta.userData.son || 0); i++) fisekPos[i * 3 + 1] = -999;
    fisekNokta.userData.son = n;
    fisekNokta.geometry.attributes.position.needsUpdate = true;
    fisekNokta.geometry.attributes.color.needsUpdate = true;
    fisekNokta.geometry.setDrawRange(0, Math.max(n, 1));
  }

  // 0.43: mahallede dolaşma — mağazadan alınan 7 günlük süre boyunca oyuncunun arabası ilçedeki herkesin
  // caddesinde trafikte, adıyla birlikte dolaşır (en çok 6 araba).
  const dolasanlar = new Map();
  function dolasanlarAyarla(liste) {
    if (!kuruldu || !SERITLER.length) { bekleyenDolasan = liste; return; }
    const l = (liste || []).slice(0, 6);
    const anahtar = (x) => [x.oyuncuId, x.govde, x.renk, x.bitis, x.plaka, x.far, x.jant, x.ad].join('|');
    for (const [id, d] of dolasanlar) {
      const yeni = l.find((x) => x.oyuncuId === id);
      if (yeni && anahtar(yeni) === d.anahtar) continue;
      const i = arabalar.indexOf(d.a);
      if (i > -1) arabalar.splice(i, 1);
      for (const h of d.a.userData.araba.haleler) gecelik.haleler.delete(h);
      sahne.remove(d.a); bellektenSil(d.a); d.etiket.remove();
      dolasanlar.delete(id);
    }
    const baslangic = SERITLER.filter((s) => s.bas === 'uzak');
    l.forEach((x, n) => {
      if (dolasanlar.has(x.oyuncuId)) return;
      const govde = x.govde === 'suv' ? 'suv' : x.govde === 'spor' ? 'spor' : 'sedan';
      const a = araba(govde, x.renk, { bitis: x.bitis, plaka: x.plaka, far: x.far, jant: x.jant });
      const s = baslangic[(x.oyuncuId + n) % baslangic.length];
      const p = (s.yon > 0 ? s.min : s.max) + s.yon * (40 + n * 23);
      const [px, pz] = seritKonum(s, p);
      a.position.set(px, 0.02, pz);
      a.rotation.y = seritAcisi(s);
      Object.assign(a.userData, { serit: s, p, hiz: rnd(5, 7), azami: s.eksen === 'x' && s.sabit > 0 ? rnd(8, 10) : rnd(6, 8), tur: govde, dolasan: x.oyuncuId });
      a.userData.araba.haleler.forEach((h) => gecelik.haleler.add(h));
      sahne.add(a);
      arabalar.push(a);
      const etiket = document.createElement('div');
      etiket.className = 'etiket gizli';
      etiket.innerHTML = `<div class="olay-balon dolasan">🚘 ${esc(x.ad)}${x.plaka ? ` <span class="plaka-mini">${esc(x.plaka)}</span>` : ''}</div>`;
      etiketKutusu.appendChild(etiket);
      dolasanlar.set(x.oyuncuId, { a, etiket, anahtar: anahtar(x) });
    });
  }
  let bekleyenDolasan = null;

  function parkBirak(x) {
    const i = parkYerleri.findIndex((y) => y.gecici && y.x === x);
    if (i > -1) parkYerleri.splice(i, 1);
  }
  const olaylar = olayMotoru({
    sahne, etiketKutusu, gecelik, bellektenSil, api,
    etiketGoster: (e, x, y, z) => etiketGoster(e, x, y, z),
    kuruldu: () => kuruldu,
    kamera: () => ({ x: hedefX, z: hedefZ, mesafe }),
    saat: () => oyunSaati(),
    yakin: (x, z, sinir = 60) => yakinMi(x, z, sinir),
    ekrandaMi: (p, r) => ekrandaMi(p, r),
    sinirlar: () => ({ XB, XD }),
    parkBilboardX: () => GECIT_X + 6, // 0.46: park yolundaki bilboard (çocuklar önünde oynamasın)
    durakX: () => DURAK_X,
    // sokak müzisyenlerinin sabit yeri: güney sırasındaki son tezgâhın sağı
    muzisyenYeri: () => {
      let mx = -Infinity;
      for (const y of yerler.values()) if (y.guney) mx = Math.max(mx, y.grup.position.x);
      if (!Number.isFinite(mx)) return null;
      return { x: Math.min(XD - 6, mx + 6.2), z: GUNEY_TEZGAH_Z - 0.2 };
    },
    dukkanlar: () => [...dukkanlar.values()],
    trafik: {
      ekle(a, no) {
        const sr = SERITLER[no];
        a.userData.serit = sr;
        a.visible = true;
        if (!arabalar.includes(a)) arabalar.push(a);
      },
      // konvoy geçerken şeride sokağın başından sivil araç girmez
      kapat(no, sn) { SERITLER[no].kapaliBitis = performance.now() + sn * 1000; },
      cikar(a) { const i = arabalar.indexOf(a); if (i > -1) arabalar.splice(i, 1); a.userData.serit = null; },
      // şeritte x'in arkasında (gelen trafik yönünde) pay kadar boşluk var mı
      bosMu(no, x, pay) {
        const sr = SERITLER[no];
        return !arabalar.some((b) => b.userData.serit === sr && b.visible && Math.abs(b.position.x - x) < pay)
          && !parkEdenler.some((b) => b.userData.durum !== 'park' && Math.abs(b.position.z - sr.sabit) < 1.6 && Math.abs(b.position.x - x) < pay);
      },
      // şerit dışında yolda duran/yanaşan görev aracı: arkadan gelenler ona çarpmaz
      engel(a, var_) { if (var_) disEngeller.add(a); else disEngeller.delete(a); },
      direksiyon: (a, aci, dt) => direksiyon(a, aci, dt),
    },
    zeminY: (x, z) => zeminY(x, z),
    konteynerler: () => konteynerler,
    park: { ayir: parkAyir, birak: parkBirak },
    katil: (olay, eylem, rect) => olayKatil ? olayKatil(olay, eylem, rect) : Promise.resolve(null),
    muzisyenIstek: (olay, rect) => muzisyenIstek ? muzisyenIstek(olay, rect) : Promise.resolve(null),
    zabitaSonucu: (kod, sonuc, z) => zabitaSonucu && zabitaSonucu(kod, sonuc, z),
    haber: (olay, metin, x, z) => { if (olayHaberi && (!aktifMi || !yakinMi(x, z, 45))) olayHaberi(olay, metin, () => ucusYap(x, z + 2, 32)); },
    izinVar: () => (izinVar ? izinVar() : false),
    yerBul: (kod) => { const y = yerler.get(kod); return y ? { kod, x: y.grup.position.x, z: y.grup.position.z, guney: y.guney } : null; },
    zabitaZiyaretleri() {
      const l = [];
      for (const [kod, y] of yerler) {
        if (!y.aktif || !y.aktif.zabita) continue;
        for (const z of y.aktif.zabita) l.push({ ...z, yer: { kod, x: y.grup.position.x, z: y.grup.position.z, guney: y.guney } });
      }
      return l;
    },
    calisanTezgah() {
      const c = [...yerler.entries()].filter(([, y]) => y.aktif && y.aktif.bitis > simdi() && yakinMi(y.grup.position.x, y.grup.position.z, 20));
      if (!c.length) return null;
      const [kod, y] = c[Math.floor(Math.random() * c.length)];
      return { kod, x: y.grup.position.x, z: y.grup.position.z };
    },
    kuyrukOlustur(kod, n) {
      const y = yerler.get(kod);
      if (!y) return;
      for (let i = 0; i < n; i++) setTimeout(() => tezgahaGonder(y), i * 700);
    },
  });

  // ------------------------------------------------ Kamera: sokak seviyesinden kuş bakışına
  // Tek parmak sürükle: kaydır. İki parmak: yakınlaştır ve döndür. Fare tekeri: yakınlaştır, sağ tık: döndür.
  let hedefX = 0;
  let hedefZ = ORTA_Z;
  let aci = 0;                // kameranın bakış yönü (0 = kuzeye bakar)
  let mesafe = 30;
  let istenenMesafe = 30;
  let enYakinMesafe = 18;
  // Semt büyüklüğü: 0.24'teki semtin 2 katı alan (yarıçap 470 → 665 m; zayıf cihazda biraz küçük)
  const SEHIR_YARICAP = 300; // Yakın modellerin kalitesi aynı; yalnızca çevredeki alan daraltılır.
  // 0.30: dört kademe daha uzaklaşılabilir (fare tekerleğinin her kademesi ×1,16): bütün semt ve sokak adları görünür
  const ESKI_UZAK = Math.round(Math.max(300, SEHIR_YARICAP * 1.05));
  const EN_UZAK = Math.round(ESKI_UZAK * 1.8);
  // eski en uzak noktaya kadar eğim eskisi gibi; ötesinde kamera iyice tepeden bakar (sokaklar binaların arasından görünür)
  // 0.56: oyuncunun dikey açı ayarı (eğim farkı): yatayca bakmak ya da tepeden bakmak için
  let egimFark = 0, istenenEgimFark = 0, aciHedef = null;
  function egimHesapla(m) {
    const temel = m <= ESKI_UZAK ? THREE.MathUtils.lerp(0.67, 1.3, Math.max(0, Math.min(1, (m - enYakinMesafe) / (ESKI_UZAK - enYakinMesafe))))
      : THREE.MathUtils.lerp(1.3, 1.48, Math.min(1, (m - ESKI_UZAK) / (EN_UZAK - ESKI_UZAK)));
    return Math.max(0.2, Math.min(1.5, temel + egimFark));
  }
  let hizX = 0;
  let hizZ = 0;
  let ucus = null;
  const kanvas = document.getElementById('sahne');
  let aktifMi = false;
  const parmaklar = new Map();
  let ikiParmak = null;

  // en uzak noktadayken daha da uzaklaşmak isteyen oyuncu haritaya (ilçesine) çıkar
  let uzaklasmaPayi = 0;
  let sonCikis = 0;
  function uzaklasmaIstegi(kat) {
    if (mesafe < EN_UZAK * 0.97) { uzaklasmaPayi = 0; return; }
    uzaklasmaPayi += kat;
    if (uzaklasmaPayi > 0.35 && performance.now() - sonCikis > 2500) {
      uzaklasmaPayi = 0;
      sonCikis = performance.now();
      uzaklasti();
    }
  }
  function sinir() {
    // yakındayken sokakta kalır; uzaklaştıkça bütün semtte gezilebilir
    // 0.56: yakınken de bütün semtte gezilir (semtin kenarındaki binaya yakınlaşınca kamera geri çekilmez)
    const pay = 1;
    const genis = SEHIR_YARICAP - 120;
    hedefX = Math.max(XB - 60 - pay * genis, Math.min(XD + 60 + pay * genis, hedefX));
    hedefZ = Math.max(-80 - pay * genis, Math.min(26 + pay * genis * 0.72, hedefZ));
    istenenMesafe = Math.max(enYakinMesafe, Math.min(EN_UZAK, istenenMesafe));
  }

  function ekranaGoreKaydir(dx, dy) {
    const olcek = (mesafe * 1.15) / window.innerHeight;
    const sag = { x: Math.cos(aci), z: -Math.sin(aci) };
    const ileri = { x: -Math.sin(aci), z: -Math.cos(aci) };
    const mx = -dx * olcek * sag.x + dy * olcek * ileri.x;
    const mz = -dx * olcek * sag.z + dy * olcek * ileri.z;
    hedefX += mx;
    hedefZ += mz;
    return [mx, mz];
  }

  // Yakınlaştırma imlecin (iki parmakta parmakların ortasının) altındaki noktaya doğru olur:
  // o nokta ekranda yerinde kalır, kamera ona doğru yaklaşır/uzaklaşır.
  let zumCapa = null;
  const capaIsin = new THREE.Raycaster();
  const capaNdc = new THREE.Vector2();
  const capaYer = new THREE.Plane(new THREE.Vector3(0, 1, 0), -1.2);
  const capaNokta = new THREE.Vector3();
  function zumCapasi(cx, cy) {
    const r = kanvas.getBoundingClientRect();
    capaNdc.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
    capaIsin.setFromCamera(capaNdc, kamera);
    if (!capaIsin.ray.intersectPlane(capaYer, capaNokta)) { zumCapa = null; return; }
    // ufka çok yakın (çok uzak) noktalara doğru ani sıçrama olmasın
    const uz = Math.hypot(capaNokta.x - hedefX, capaNokta.z - hedefZ);
    const en = mesafe * 2.2;
    if (uz > en) { capaNokta.x = hedefX + ((capaNokta.x - hedefX) / uz) * en; capaNokta.z = hedefZ + ((capaNokta.z - hedefZ) / uz) * en; }
    zumCapa = { x: capaNokta.x, z: capaNokta.z };
  }

  kanvas.addEventListener('pointerdown', (e) => {
    if (!aktifMi) return;
    // birincil dokunuş/tık yeni bir hareketin başıdır: kaçırılmış "bırakma"lardan kalan eski parmaklar silinir
    // (yoksa sürükleme iki parmak sanılıp kamera kilitli gibi kalıyordu)
    if (e.isPrimary) { parmaklar.clear(); ikiParmak = null; }
    sinema = null; // oyuncu dokunduysa sinematik kamera bırakılır
    parmaklar.set(e.pointerId, { x: e.clientX, y: e.clientY, sag: e.button === 2 });
    hizX = hizZ = 0;
    ucus = null;
    if (parmaklar.size === 2) {
      const [a, b] = [...parmaklar.values()];
      ikiParmak = { uzaklik: Math.hypot(a.x - b.x, a.y - b.y), aci: Math.atan2(b.y - a.y, b.x - a.x) };
    }
  });
  window.addEventListener('pointermove', (e) => {
    if (!aktifMi || !parmaklar.has(e.pointerId)) return;
    const p = parmaklar.get(e.pointerId);
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;
    if (parmaklar.size === 2 && ikiParmak) {
      const [a, b] = [...parmaklar.values()];
      const uzaklik = Math.hypot(a.x - b.x, a.y - b.y);
      const yeniAci = Math.atan2(b.y - a.y, b.x - a.x);
      if (ikiParmak.uzaklik > 10) {
        const oran = ikiParmak.uzaklik / Math.max(10, uzaklik);
        zumCapasi((a.x + b.x) / 2, (a.y + b.y) / 2);
        istenenMesafe *= oran;
        if (oran > 1) uzaklasmaIstegi(oran - 1);
      }
      // iki parmak saat yönünde dönünce sahne de parmaklarla birlikte döner
      aci += yeniAci - ikiParmak.aci;
      // 0.56: iki parmak birlikte yukarı-aşağı kayınca kamera eğilir
      const ortY = (a.y + b.y) / 2;
      if (ikiParmak.ortY != null) istenenEgimFark = Math.max(-0.5, Math.min(0.35, istenenEgimFark + (ortY - ikiParmak.ortY) * 0.004));
      ikiParmak = { uzaklik, aci: yeniAci, ortY };
      sinir();
      return;
    }
    if (p.sag || e.shiftKey) {
      aci -= dx * 0.008;
      istenenEgimFark = Math.max(-0.5, Math.min(0.35, istenenEgimFark + dy * 0.004)); // 0.56: dikey sürükleme eğimi değiştirir
      return;
    }
    zumCapa = null;
    const [mx, mz] = ekranaGoreKaydir(dx, dy);
    // fareyle sürüklerken bırakınca kayma olmaz (ekran tam istenen yerde durur); parmakla hafif süzülür
    if (e.pointerType === 'touch') { hizX = mx * 40; hizZ = mz * 40; } else { hizX = hizZ = 0; }
    sinir();
  });
  const birak = (e) => {
    parmaklar.delete(e.pointerId);
    if (parmaklar.size < 2) ikiParmak = null;
  };
  window.addEventListener('pointerup', birak);
  window.addEventListener('pointercancel', birak);
  // pencere odağı kaybolunca (başka uygulama, sekme, sistem penceresi) basılı parmaklar unutulur
  const hepsiniBirak = () => { parmaklar.clear(); ikiParmak = null; };
  window.addEventListener('blur', hepsiniBirak);
  document.addEventListener('visibilitychange', () => { if (document.hidden) hepsiniBirak(); });
  kanvas.addEventListener('contextmenu', (e) => e.preventDefault());
  // fare tezgâhın üstündeyken imleç el olur; ayrıntı yalnızca halkaya tıklayınca açılır
  let sonUzerinde = 0;
  const uzerIsin = new THREE.Raycaster();
  kanvas.addEventListener('pointermove', (e) => {
    if (!aktifMi || e.pointerType !== 'mouse' || parmaklar.size || performance.now() - sonUzerinde < 120) return;
    sonUzerinde = performance.now();
    const r = kanvas.getBoundingClientRect();
    uzerIsin.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), kamera);
    const v = uzerIsin.intersectObjects([...yerler.values()].map((y) => y.isabet).concat([...dukkanlar.values()].map(d => d.isabet)), false)[0];
    const y = v && yerler.get(v.object.userData.kod);
    kanvas.style.cursor = v || (y && y.veri) ? 'pointer' : '';
  });
  kanvas.addEventListener('wheel', (e) => {
    if (!aktifMi) return;
    e.preventDefault();
    sinema = null;
    zumCapasi(e.clientX, e.clientY);
    istenenMesafe *= Math.pow(1.0015, e.deltaY);
    if (e.deltaY > 0) uzaklasmaIstegi(Math.min(0.2, e.deltaY / 500));
    ucus = null;
    sinir();
  }, { passive: false });

  function boyut(w, h) {
    kamera.aspect = w / h;
    // telefonda sokak seviyesinde birkaç tezgâh birden görünsün
    const genislik = w < h ? 13 : 30;
    const uygun = genislik / (2 * Math.tan(THREE.MathUtils.degToRad(kamera.fov / 2)) * kamera.aspect);
    enYakinMesafe = Math.max(16, Math.min(uygun * 0.7, 36));
    if (!boyut.ilk) { boyut.ilk = true; mesafe = istenenMesafe = Math.max(24, Math.min(uygun, 52)); }
    kamera.updateProjectionMatrix();
    tumunuGosterUygula();
  }

  // Açılışta tüm tezgâhlar ekrana sığsın (ekran oranı belli olunca uygulanır)
  let tumunuGoster = null;
  function tumunuGosterUygula() {
    if (!tumunuGoster) return;
    // Bitmiş işler de açılış kadrajına dahildir; tek çalışan iş kamerayı kendine çekmesin.
    const hepsi = [...yerler.values()].filter((y) => y.veri && y.veri.sahip);
    const secilen = hepsi;
    let x0, x1, z0, z1;
    if (secilen.length && !ziyaret) {
      x0 = Math.min(...secilen.map((y) => y.grup.position.x)) - 4.5;
      x1 = Math.max(...secilen.map((y) => y.grup.position.x)) + 4.5;
      z0 = Math.min(...secilen.map((y) => y.grup.position.z)) - 3;
      z1 = Math.max(...secilen.map((y) => y.grup.position.z)) + 3;
    } else {
      const g = (Math.ceil((isler.length || 12) / 2) - 1) * ARALIK + 3.6 + 12;
      x0 = -g / 2; x1 = g / 2; z0 = ORTA_Z - 6; z1 = ORTA_Z + 6;
    }
    const tanY = Math.tan(THREE.MathUtils.degToRad(kamera.fov / 2));
    // genişlik yatay görüşe, derinlik (eğik bakışta kısalır) dikey görüşe sığsın; kenarlarda arayüz için pay
    // Tek tezgâhı olan oyuncuda da cadde görünür; dar ekranlarda sabit üst sınır kadrajı kırpmasın.
    const mGen = Math.max(30, x1 - x0) * 1.18 / (2 * tanY * kamera.aspect);
    const mDer = Math.max(18, z1 - z0) * 1.6 / (2 * tanY);
    const uygun = Math.max(enYakinMesafe, Math.min(EN_UZAK, Math.max(mGen, mDer)));
    const cx = (x0 + x1) / 2;
    const cz = (z0 + z1) / 2 + 1;
    aci = 0;
    sinema = null;
    zumCapa = null;
    if (tumunuGoster.aniden) { ucus = null; hizX = hizZ = 0; hedefX = cx; hedefZ = cz; istenenMesafe = mesafe = uygun; } else ucusYap(cx, cz, uygun);
    tumunuGoster = null;
  }

  function ucusYap(x, z, m) {
    aciHedef = null;
    zumCapa = null;
    ucus = { t: 0, bx: hedefX, bz: hedefZ, bm: istenenMesafe, sx: x, sz: z, sm: m || istenenMesafe };
    hizX = hizZ = 0;
  }

  const bakis = new THREE.Vector3();
  const hedef = new THREE.Vector3();
  let sonEtiket = 0;
  let sonSes = 0;
  let gecePayi = 0;
  let tavanKariAcik = false;
  let golgeBoyu = 26;
  const sisGunduz = new THREE.Color('#CDE6FA');
  const sisAksam = new THREE.Color('#E6AE84');
  const sisGece = new THREE.Color('#0E1729');
  // her karede yeni renk nesnesi üretilmesin (çöp toplayıcıyı yormasın)
  const sisRengi = new THREE.Color();
  const RENK_AKSAM = new THREE.Color('#FF9A5A');
  const RENK_GECE_GUNES = new THREE.Color('#8EA6D8');
  const RENK_GECE_YARIM = new THREE.Color('#8899B5');
  const GECE_ISIK_YONU = new THREE.Vector3();
  const AY_YONU = new THREE.Vector3(0.3, 1, 0.4).normalize();

  function gunIsigi(dt = 1/60) {
    const saat = oyunSaati();
    const gun = (saat - 6) / 14;
    const yukseklik = Math.sin(gun * Math.PI) * 58 - (gun < 0 || gun > 1 ? 20 : 0);
    const yon = THREE.MathUtils.lerp(-75, 75, THREE.MathUtils.clamp(gun, 0, 1));
    const el = THREE.MathUtils.degToRad(Math.max(-18, yukseklik));
    const az = THREE.MathUtils.degToRad(yon);
    gunesYonu.set(Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el));
    gu.sunPosition.value.copy(gunesYonu);
    const gece = THREE.MathUtils.clamp((4 - yukseklik) / 12, 0, 1);
    gecePayi = gece;
    const alacakaranlik = THREE.MathUtils.clamp(1 - Math.abs(yukseklik - 4) / 14, 0, 1);

    // bulut yavaşça değişir (sayfa açıkken hava değişirse sahne birden kararmasın)
    bulutPayi += (hedefBulut - bulutPayi) * (1-Math.exp(-Math.min(dt,.25)*1.2));
    const guc = THREE.MathUtils.clamp(Math.sin(el) * 2.7, 0, 2.35) * (1 - bulutPayi * 0.6);
    gunes.intensity = guc + gece * 0.28;
    gunes.color.set('#F9F5EC').lerp(RENK_AKSAM, alacakaranlik * 0.8).lerp(RENK_GECE_GUNES, gece);
    const isikYonu = GECE_ISIK_YONU.copy(gunesYonu).lerp(AY_YONU,THREE.MathUtils.smoothstep(gece,.2,.85)).normalize();
    // gölge alanı 4 m'lik ızgarada kayar: kamera her kaydırıldığında gölge haritası yeniden çizilmez
    const gx = Math.round(hedefX / 4) * 4, gz = Math.round(hedefZ / 4) * 4;
    gunes.position.set(gx + isikYonu.x * 60, Math.max(8, isikYonu.y * 60), gz + isikYonu.z * 60);
    gunes.target.position.set(gx, 0, gz);
    golgeYonAnahtari = Math.round(isikYonu.x * 70) + ',' + Math.round(isikYonu.y * 70) + ',' + Math.round(isikYonu.z * 70) + ',' + gx + ',' + gz;
    // kapalı ve yağışlı havada sahne kasvetlenir: gök ışığı ve yansımalar azalır
    const kasvet = bulutPayi * (hava.tur === 'firtina' ? 1 : hava.tur === 'yagmur' || hava.tur === 'kar' ? 0.8 : 0.55);
    yarim.intensity = (0.28 + (1 - gece) * 0.26 + gece * 0.04) * (1 - kasvet * 0.3);
    yarim.color.set('#DCE5EE').lerp(RENK_GECE_YARIM, gece);

    const sis = sisRengi.copy(sisGunduz).lerp(bulutSis, bulutPayi * 0.8).lerp(sisAksam, alacakaranlik * 0.7 * (1 - bulutPayi * 0.6)).lerp(sisGece, gece);
    sahne.fog.color.copy(sis);
    if (hafifSis > 0) sahne.fog.color.lerp(SIS_GRI, 0.22 * hafifSis * (1 - gece * 0.7)); // hafif sis: pus biraz açık gri
    const bulanik = 5 + bulutPayi * 14;
    if (Math.abs(gu.turbidity.value - bulanik) > 0.8) { gu.turbidity.value = bulanik; sonOrtamYuk = -99; }
    // kapalı havada gölgeler silikleşir
    if ('intensity' in gunes.shadow) gunes.shadow.intensity = 1 - bulutPayi * 0.75;
    yildizlar.material.opacity = gece * 0.9;

    if (Math.abs(yukseklik - sonOrtamYuk) > (K.kod === 'dusuk' ? 8 : 3)) {
      sonOrtamYuk = yukseklik;
      if (ortam) ortam.dispose();
      ortam = pmrem.fromScene(gokSahne, 0.02);
      sahne.environment = ortam.texture;
    }
    sahne.environmentIntensity = (0.35 + (1 - gece) * 0.5) * (1 - kasvet * 0.45);

    const isikAcik = aydinlatmaPayi(saat, THREE.MathUtils.clamp((gece + alacakaranlik * 0.5 - 0.25) * 2, 0, 1));
    isikAcikPayi = isikAcik;
    // far huzmeleri havadaki nemde görünür: yağmur, kar ve siste daha belirgin (ortak malzeme)
    const nem = Math.min(1, havaEf.islaklik * 0.8 + (hava && hava.tur === 'sis' ? 1 : hava && hava.tur === 'kar' ? 0.7 : 0));
    for (const hm of farHuzmesiMalzemeleri()) hm.opacity = isikAcik * (0.07 + nem * 0.13);
    const km = tavanKariMalzemesi();
    const kar = havaEf.karOrtusu;
    if (Math.abs(km.opacity - kar * 0.95) > 0.01) km.opacity = kar * 0.95;
    if ((kar > 0.03) !== !!tavanKariAcik) { tavanKariAcik = kar > 0.03; for (const a of arabalar) { const k = a.userData.araba && a.userData.araba.kar; if (k) k.visible = tavanKariAcik; } }
    for (const h of gecelik.haleler) {
      if (h.userData.huzme) { h.visible = isikAcik > 0.05 && !h.userData.kapali; continue; }
      // ıslak zeminde lamba ve far lekeleri daha parlak (su ışığı yansıtır)
      h.material.opacity = Math.min(1, isikAcik * (h.isSprite ? 0.9 : 0.55 * (h.userData.leke ? 1 + havaEf.islaklik * 0.55 : 1)));
      h.visible = isikAcik > 0.01 && !h.userData.kapali;
    }
    for (const l of lambalar) l.userData.lamba.ampul.material.emissiveIntensity = isikAcik * 3;
    isikliCam().emissiveIntensity = isikAcik * 1.6;
    vitrinIsigi(isikAcik);
    if (sehir) sehir.geceAyarla(isikAcik);
    for (const m of gecelik.tabelalar) m.emissiveIntensity = m.userData.neon ? Math.max(0.3, isikAcik * 1.6) : isikAcik * 1.35; // neon tabela gündüz de hafif parlar
    pozlama.deger = 0.78 + gece * 0.5 - kasvet * 0.1 * (1 - gece);
  }
  const pozlama = { deger: 0.78 };


  // Sinematik kamera (tanıtım için): iki çekim noktası arasında yumuşak hareket.
  // nokta: { x, z, mesafe, aci, egim (isteğe bağlı: kameranın eğimi, radyan) }
  let sinema = null;
  function sinemaKamera(bas, son, sure) {
    sinema = { bas: { ...bas }, son: { ...son }, sure: Math.max(0.01, sure), t: 0 };
    ucus = null;
    hizX = hizZ = 0;
  }
  // 0.40: Serbest film kamerası (yalnızca tanıtım çekimi): her karede konum, bakış noktası, görüş açısı ve yatış
  // verilir. Yolda araba izleme, yerden çekim, vinç ve dron hareketleri bununla yapılır.
  let serbest = null;
  const serbestBak = new THREE.Vector3();
  function sinemaSerbest(fn) { serbest = fn || null; sinema = null; ucus = null; hizX = hizZ = 0; if (!fn && kamera.fov !== 38) { kamera.fov = 38; kamera.updateProjectionMatrix(); } }
  function kameraGuncelle(dt) {
    if (serbest) {
      const r = serbest(dt);
      if (r) {
        kamera.position.set(r.konum[0], r.konum[1], r.konum[2]);
        serbestBak.set(r.bak[0], r.bak[1], r.bak[2]);
        kamera.up.set(0, 1, 0);
        kamera.lookAt(serbestBak);
        if (r.yatis) kamera.rotateZ(r.yatis);
        const fov = r.fov || 38;
        if (Math.abs(kamera.fov - fov) > 0.01) { kamera.fov = fov; kamera.updateProjectionMatrix(); }
        hedefX = r.bak[0]; hedefZ = r.bak[2];
        istenenMesafe = mesafe = Math.max(4, kamera.position.distanceTo(serbestBak));
        gok2.position.copy(kamera.position);
        sahne.fog.near = (110 + mesafe * 0.85) * sisEtkin();
        sahne.fog.far = (360 + mesafe) * (0.4 + sisEtkin() * 0.6);
        const istenenGolge = Math.max(30, Math.min(150, (r.golge || mesafe * 1.1)));
        if (Math.abs(istenenGolge - golgeBoyu) > 4) {
          golgeBoyu = istenenGolge;
          Object.assign(gunes.shadow.camera, { left: -golgeBoyu, right: golgeBoyu, top: golgeBoyu * 0.85, bottom: -golgeBoyu * 0.85, far: 140 + golgeBoyu * 2 });
          gunes.shadow.camera.updateProjectionMatrix();
        }
        return;
      }
    }
    if (sinema) {
      sinema.t = Math.min(1, sinema.t + dt / sinema.sure);
      const k = sinema.t < 0.5 ? 2 * sinema.t * sinema.t : 1 - Math.pow(-2 * sinema.t + 2, 2) / 2; // yumuşak başla, yumuşak dur
      const a = sinema.bas;
      const b = sinema.son;
      const ara = (p, q) => (p ?? q) + ((q ?? p) - (p ?? q)) * k;
      hedefX = ara(a.x, b.x);
      hedefZ = ara(a.z, b.z);
      istenenMesafe = mesafe = ara(a.mesafe, b.mesafe);
      aci = ara(a.aci ?? 0, b.aci ?? 0);
      const egim = a.egim != null || b.egim != null ? ara(a.egim ?? b.egim, b.egim ?? a.egim) : null;
      hedef.set(hedefX, 1.2, hedefZ);
      const e = egim ?? egimHesapla(mesafe);
      kamera.position.set(hedefX + Math.sin(aci) * Math.cos(e) * mesafe, 1.2 + Math.sin(e) * mesafe, hedefZ + Math.cos(aci) * Math.cos(e) * mesafe);
      kamera.lookAt(hedef);
      gok2.position.copy(kamera.position);
      gorusuAc(dt);
      sahne.fog.near = (110 + mesafe * 0.85) * sisEtkin();
      sahne.fog.far = (360 + mesafe) * (0.4 + sisEtkin() * 0.6);
      return;
    }
    if (ucus) {
      ucus.t = Math.min(1, ucus.t + dt * 1.3);
      const k = 1 - Math.pow(1 - ucus.t, 3);
      hedefX = ucus.bx + (ucus.sx - ucus.bx) * k;
      hedefZ = ucus.bz + (ucus.sz - ucus.bz) * k;
      istenenMesafe = ucus.bm + (ucus.sm - ucus.bm) * k;
      if (ucus.t >= 1) ucus = null;
    } else if (parmaklar.size === 0 && (Math.abs(hizX) > 0.01 || Math.abs(hizZ) > 0.01)) {
      hedefX += hizX * dt;
      hedefZ += hizZ * dt;
      const sonum = Math.pow(0.04, dt);
      hizX *= sonum;
      hizZ *= sonum;
      sinir();
    }
    const eskiMesafe = mesafe;
    mesafe += (istenenMesafe - mesafe) * Math.min(1, dt * 8);
    if (zumCapa && !ucus && eskiMesafe > 0.1) {
      // kamera çapa noktasına doğru giden doğru üzerinde kalır: çapa ekranda yerinden oynamaz
      const r = mesafe / eskiMesafe;
      hedefX = zumCapa.x + (hedefX - zumCapa.x) * r;
      hedefZ = zumCapa.z + (hedefZ - zumCapa.z) * r;
      sinir();
      if (Math.abs(istenenMesafe - mesafe) < mesafe * 0.002) zumCapa = null;
    }
    egimFark += (istenenEgimFark - egimFark) * Math.min(1, dt * 8);
    if (aciHedef != null) { const fark = Math.atan2(Math.sin(aciHedef - aci), Math.cos(aciHedef - aci)); aci += fark * Math.min(1, dt * 8); if (Math.abs(fark) < 0.002) { aci = aciHedef; aciHedef = null; } }
    // uzaklaştıkça kamera daha dik bakar (kuş bakışı)
    const egim = egimHesapla(mesafe);
    hedef.set(hedefX, 1.2, hedefZ);
    kamera.position.set(
      hedefX + Math.sin(aci) * Math.cos(egim) * mesafe,
      1.2 + Math.sin(egim) * mesafe,
      hedefZ + Math.cos(aci) * Math.cos(egim) * mesafe,
    );
    kamera.lookAt(hedef);
    gok2.position.copy(kamera.position);
    gorusuAc(dt);
    sahne.fog.near = (110 + mesafe * 0.85) * sisEtkin();
    sahne.fog.far = (360 + mesafe) * (0.4 + sisEtkin() * 0.6);
    // gölge alanı kameranın gördüğü alana göre büyür
    const istenenGolge = Math.max(26, Math.min(150, mesafe * 1.1));
    if (Math.abs(istenenGolge - golgeBoyu) > 4) {
      golgeBoyu = istenenGolge;
      Object.assign(gunes.shadow.camera, { left: -golgeBoyu, right: golgeBoyu, top: golgeBoyu * 0.85, bottom: -golgeBoyu * 0.85, far: 140 + golgeBoyu * 2 });
      gunes.shadow.camera.updateProjectionMatrix();
    }
  }

  // Kamerayla bakılan yer arasında kalan binalar yumuşakça saydamlaşır (birden kaybolup geri gelmez).
  // Karar için ışın binanın kutusunu keser mi diye bakılır; kısa titreşimler için gecikmeli (histerezisli) karar verilir.
  const isin = new THREE.Ray();
  const yon3 = new THREE.Vector3();
  const kesisim = new THREE.Vector3();
  const SAYDAM_EN_AZ = 0; // kesit: engel olan binada yalnızca zemin kat kalır
  const genisKutu = new THREE.Box3();
  function arayaGiriyor(d) {
    // kamera binanın içinde ya da dibindeyse
    genisKutu.copy(d.kutu).expandByVector(new THREE.Vector3(5, 200, 5));
    if (genisKutu.containsPoint(kamera.position)) return true;
    for (const yukseklik of [1.2, 3.5, 6]) {
      yon3.set(hedefX, yukseklik, hedefZ).sub(kamera.position);
      const boy = yon3.length();
      isin.set(kamera.position, yon3.normalize());
      const k = isin.intersectBox(d.kutu, kesisim);
      if (k && kamera.position.distanceTo(k) < boy - 2.5) return true;
    }
    return false;
  }
  // Kamerayı kapatan bina kaybolmaz, "kesit" alınır: üst katlar yumuşakça aşağı iner, zemin kattaki dükkân,
  // vitrini ve tabelası her zaman görünür kalır (oran 1 = bina tam, 0 = yalnızca zemin kat).
  const KESIT_ALT = KALDIRIM_Y + 4.45;
  function saydamlikUygula(d, oran) {
    caddeAraligi(d, oran < 0.999);
    if (oran >= 0.999) {
      if (!d.kopyalar) return;
      d.grup.traverse((o) => {
        if (!o.userData.asilMalzeme) return;
        o.material = o.userData.asilMalzeme;
        delete o.userData.asilMalzeme;
      });
      for (const m of d.kopyalar.values()) { gecelik.tabelalar.delete(m); m.dispose(); }
      d.kopyalar = null;
      golgeKirli = true;
      return;
    }
    if (!d.kopyalar) {
      d.kopyalar = new Map();
      d.kesitDuzlemi = new THREE.Plane(new THREE.Vector3(0, -1, 0), 1000);
      d.grup.traverse((o) => {
        if (!(o.isMesh || o.isSprite) || o.userData.asilMalzeme) return;
        const kopyala = (m) => {
          if (!d.kopyalar.has(m)) {
            const k = m.clone();
            k.clippingPlanes = [d.kesitDuzlemi];
            k.clipShadows = true;
            k.side = o.isMesh ? THREE.DoubleSide : k.side; // kesilen yerden içerisi boş görünmesin
            if (m.userData && m.userData.tabela) gecelik.tabelalar.add(k);
            d.kopyalar.set(m, k);
          }
          return d.kopyalar.get(m);
        };
        o.userData.asilMalzeme = o.material;
        o.material = Array.isArray(o.material) ? o.material.map(kopyala) : kopyala(o.material);
      });
    }
    const tepe = d.kutu ? d.kutu.max.y + 0.5 : KESIT_ALT + 30;
    const yeniSabit = KESIT_ALT + (tepe - KESIT_ALT) * Math.max(0, Math.min(1, oran));
    if (Math.abs(yeniSabit - d.kesitDuzlemi.constant) > 0.5) golgeKirli = true;
    d.kesitDuzlemi.constant = yeniSabit;
  }
  // 0.40: Oyun açıldıktan sonra arka planda gölgelendirici ısıtma: bina kesiti (kamera binaya yaklaşınca) ve sokak
  // olaylarının modelleri ilk kez görüldüklerinde derlenip ekranı dondurmasın. Isıtma malzemeleri serbest bırakılmaz.
  let isitildi = false;
  const isitmaSakla = [];
  async function arkaIsitma() {
    if (isitildi || introCekim) return;
    isitildi = true;
    const r = getRenderer();
    if (!r || !r.compileAsync) return;
    try {
      const d = [...dukkanlar.values()].find((x) => x.grup);
      if (d) {
        const duzlem = new THREE.Plane(new THREE.Vector3(0, -1, 0), 1000);
        const kopyalar = new Map();
        const g = new THREE.Group();
        d.grup.traverse((o) => {
          if (!o.isMesh || !o.geometry) return;
          for (const m of Array.isArray(o.material) ? o.material : [o.material]) {
            if (!m || kopyalar.has(m)) continue;
            const k = m.clone(); k.clippingPlanes = [duzlem]; k.clipShadows = true; k.side = THREE.DoubleSide;
            kopyalar.set(m, k);
            const mesh = new THREE.Mesh(o.geometry, k); mesh.position.y = -60; g.add(mesh);
          }
        });
        isitmaSakla.push(g);
        await r.compileAsync(g, kamera, sahne);
      }
      // 0.47: sonradan gelen kuş sürüsü ve sokak köpeği de önceden derlenir (ilk göründükleri karede takılmasın)
      {
        const g = new THREE.Group();
        for (const tur of ['guvercin', 'sigircik', 'marti']) { const b = kusModeli(tur); b.position.set(0, -60, 0); g.add(b); }
        const kp = kopekModeli('#B07A43'); kp.position.set(0, -60, 0); g.add(kp);
        isitmaSakla.push(g);
        await r.compileAsync(g, kamera, sahne);
      }
      if (olaylar && olaylar.isitmaGrubu) {
        const g = olaylar.isitmaGrubu();
        isitmaSakla.push(g);
        await r.compileAsync(g, kamera, sahne);
      }
    } catch (e) { /* ısıtma olmazsa oyun sürer */ }
  }
  function gorusuAc(dt) {
    if (introCekim) return; // çekimde bina kesitinin kamerada yanıp sönmesi engellenir
    // çok uzaktan (kuş bakışı) binalar zaten engel olmaz; eşik yumuşak geçişle uygulanır
    const acik = mesafe < 120;
    for (const d of dukkanlar.values()) {
      if (!d.grup || !d.kutu) continue;
      const engel = acik && arayaGiriyor(d);
      // engel durumu en az 0,2 sn sürmeden karar değişmez (yakınlaştırırken yanıp sönmesin)
      d.engelSure = engel === !!d.engel ? 0 : (d.engelSure || 0) + dt;
      if (d.engelSure > 0.2) { d.engel = engel; d.engelSure = 0; }
      const hedefOran = d.engel ? SAYDAM_EN_AZ : 1;
      const oran = d.saydamlik ?? 1;
      if (Math.abs(oran - hedefOran) < 0.001) continue;
      const yeni = hedefOran < oran ? Math.max(hedefOran, oran - dt * 2.2) : Math.min(hedefOran, oran + dt * 1.6);
      d.saydamlik = yeni;
      saydamlikUygula(d, yeni);

    }
  }

  // Pencere ışıkları (0.39.0): gece çok seyrek, yakındaki bir binada bir pencerenin ışığı yanar ya da söner,
  // bir süre sonra eski hâline döner. Aynı anda en çok üç pencere; her biri tek küçük çizim.
  const pencereOyunlari = [];
  let sonrakiPencere = 6 + Math.random() * 8;
  const pencereKonum = new THREE.Vector3();
  function pencereIsiklari(t, dt) {
    for (let i = pencereOyunlari.length - 1; i >= 0; i--) {
      const p = pencereOyunlari[i];
      p.t += dt;
      const hedef = p.t < p.sure ? 1 : 0;
      p.a += (hedef - p.a) * Math.min(1, dt * (p.yanan ? 3 : 5));
      p.m.material.opacity = p.a * (p.yanan ? 0.92 * isikAcikPayi : 0.96);
      if (p.t > p.sure && p.a < 0.02) { p.m.parent && p.m.parent.remove(p.m); p.m.geometry.dispose(); p.m.material.dispose(); pencereOyunlari.splice(i, 1); }
    }
    if (t < sonrakiPencere) return;
    sonrakiPencere = t + 7 + Math.random() * 14;
    if (isikAcikPayi < 0.6 || pencereOyunlari.length >= 3) return;
    const adaylar = [...dukkanlar.values()].filter((d) => d.grup && d.grup.parent && d.grup.userData.pencereler && d.grup.userData.pencereler.length && Math.abs(d.merkezX - hedefX) < 45 + mesafe * 0.4);
    if (!adaylar.length) return;
    const d = adaylar[Math.floor(Math.random() * adaylar.length)];
    const l = d.grup.userData.pencereler;
    const [x, y, z, w, h, isikli] = l[Math.floor(Math.random() * l.length)];
    if (pencereOyunlari.some((p) => p.d === d && p.x === x && p.y === y)) return;
    // ışıklı pencere söner (karanlık cam), karanlık pencere yanar (sıcak ışık)
    const yanan = !isikli;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.98, h * 0.98), new THREE.MeshBasicMaterial({ color: yanan ? '#FFD49A' : '#2E3B48', transparent: true, opacity: 0, depthWrite: false, toneMapped: !yanan }));
    m.position.set(x, y, z);
    m.renderOrder = 2;
    m.userData.golgeAsil = false;
    m.userData.pencereIsigi = true;
    d.grup.add(m);
    pencereOyunlari.push({ m, d, x, y, yanan, a: 0, t: 0, sure: 8 + Math.random() * 18 });
  }
  // Kuşlar ve köpekler (0.39.0): kaldırımda bir sokak köpeği ekranın bir ucundan girip öbür ucundan çıkar.
  // 0.46: Kuş sürüleri günde 9 kez geçer (oyun saatiyle): sabah 06-10 arası 3, öğlen 11-15 arası 3, akşam 17-18 arası 3.
  // Geçiş anları güne göre sabittir (bütün oyuncular aynı saatlerde görür). Sürüler gerçekçi: güvercin, martı ya da
  // sığırcık; her kuşun kendi çırpma ritmi, süzülmesi, sürü içinde gevşek hareketi ve dönüşlerde yatışı vardır.
  let kusSuru = null, kopek = null;
  let sonrakiKopek = 40 + Math.random() * 50;
  let kusZorla = false, kusOncekiSaat = null;
  const KUS_PENCERELERI = [[6, 10], [11, 15], [17, 18]];
  function kusSaatleri(gun) {
    // güne göre tohumlu, her pencere üç eşit parçaya bölünür, her parçada bir geçiş
    let t = (gun * 2654435761) >>> 0;
    const r = () => { t = (t + 0x6d2b79f5) >>> 0; let x = Math.imul(t ^ (t >>> 15), 1 | t); x ^= x + Math.imul(x ^ (x >>> 7), 61 | x); return ((x ^ (x >>> 14)) >>> 0) / 4294967296; };
    const l = [];
    for (const [a, b] of KUS_PENCERELERI) for (let k = 0; k < 3; k++) l.push(a + ((k + 0.15 + 0.7 * r()) * (b - a)) / 3);
    return l;
  }
  function kusSuruKur(zorTur = null) {
    const r = Math.random();
    const tur = zorTur || (r < 0.5 ? 'guvercin' : r < 0.78 ? 'sigircik' : 'marti');
    const yon = Math.random() < 0.5 ? 1 : -1;
    // kameranın en az 6 birim altında, caddenin ve çatıların üstünde (yakından geçip ekranı kaplamasın)
    const tavan = Math.max(7, kamera.position.y - 6);
    const y = Math.min(tavan, (tur === 'marti' ? 9 : 6.5) + Math.random() * 4);
    const z = hedefZ - 4 + (Math.random() - 0.5) * 10;
    const n = tur === 'sigircik' ? 22 + Math.floor(Math.random() * 16) : tur === 'marti' ? 4 + Math.floor(Math.random() * 4) : 9 + Math.floor(Math.random() * 7);
    const hiz = tur === 'marti' ? 7 : tur === 'sigircik' ? 11 : 9;
    const baslangicX = hedefX - yon * (window.tezgahDeneme && window.tezgahDeneme.kusYakin ? 18 : 100);
    const kuslar = [];
    for (let i = 0; i < n; i++) {
      const b = kusModeli(tur);
      let ox, oy, oz;
      if (tur === 'sigircik') { // yoğun, nefes alan bulut
        const u = Math.random() * Math.PI * 2, v = Math.acos(2 * Math.random() - 1), rr = Math.cbrt(Math.random());
        ox = Math.sin(v) * Math.cos(u) * 3.2 * rr; oy = Math.cos(v) * 1.4 * rr; oz = Math.sin(v) * Math.sin(u) * 3.2 * rr;
      } else if (tur === 'marti') { ox = -i * (1.6 + Math.random()); oy = (Math.random() - 0.5) * 2.2; oz = (Math.random() - 0.5) * 6; }
      else { const sira = Math.ceil(i / 2), yan = i % 2 ? 1 : -1; ox = -sira * (1.1 + Math.random() * 0.6); oy = (Math.random() - 0.5) * 1.2; oz = yan * sira * (0.8 + Math.random() * 0.5); }
      // oyunun ölçeğinde görünür olsun diye kuşlar gerçeğinin ~2,4 katı (insanlar ve arabalar da biraz iri çizilir)
      b.scale.multiplyScalar(2.4);
      ox *= 1.8; oy *= 1.5; oz *= 1.8;
      b.userData.o = { ox, oy, oz, f1: 0.5 + Math.random(), f2: 0.4 + Math.random() * 0.8, p: Math.random() * 6, hizK: 0.92 + Math.random() * 0.16 };
      b.position.set(baslangicX + yon * ox, y + oy, z + oz);
      b.rotation.y = yon > 0 ? 0 : Math.PI;
      b.traverse((o) => { o.castShadow = false; o.userData.golgeAsil = false; });
      b.userData.golgeDinamik = true; // 0.47: sürü gelip gidince sabit gölge haritası baştan çizilmesin (tablette takılma)
      sahne.add(b); kuslar.push(b);
    }
    kusSuru = { kuslar, yon, y, z, t: 0, cik: 0, tur, hiz, x: baslangicX, egri: (Math.random() - 0.5) * 0.5, eskiZ: z };
  }
  function hayvanlar(t, dt) {
    if (kusSuru) {
      const S = kusSuru;
      S.t += dt;
      S.x += S.yon * S.hiz * dt;
      // sürü hafif bir yay çizer ve dalgalanır
      const zMerkez = S.z + Math.sin(S.t * 0.22) * 4 * S.egri * 4;
      const yMerkez = S.y + Math.sin(S.t * 0.35) * 0.8;
      const yatis = Math.max(-0.45, Math.min(0.45, ((zMerkez - S.eskiZ) / Math.max(dt, 1e-3)) * -0.12 * S.yon));
      S.eskiZ = zMerkez;
      const nefes = S.tur === 'sigircik' ? 1 + 0.35 * Math.sin(S.t * 0.9) : 1;
      for (const b of S.kuslar) {
        const o = b.userData.o;
        const gx = o.ox * nefes + Math.sin(S.t * o.f1 + o.p) * 0.5;
        const gy = o.oy * (S.tur === 'sigircik' ? 1 + 0.5 * Math.sin(S.t * 0.7 + o.p) : 1) + Math.sin(S.t * o.f2 * 1.7 + o.p) * 0.25;
        const gz = o.oz * nefes + Math.cos(S.t * o.f2 + o.p) * 0.4;
        b.position.set(S.x + S.yon * gx, yMerkez + gy, zMerkez + gz);
        b.rotation.set(yatis + Math.sin(S.t * o.f1 + o.p) * 0.08, S.yon > 0 ? 0 : Math.PI, Math.cos(S.t * o.f2 * 1.7 + o.p) * 0.12);
        kusCirp(b, dt, o.hizK);
      }
      // sürü tepeden geçerken cıvıldar (gelirken ve geçerken birer kez)
      const kx = S.x - hedefX;
      if (S.cik < 2 && Math.abs(kx) < (S.cik ? 12 : 40) && (S.cik === 0 || S.yon * kx > 4)) {
        S.cik++;
        if (ses.kusSesi) ses.kusSesi(Math.max(-1, Math.min(1, kx / 25)), Math.max(0.2, 1 - mesafe / 140) * (S.tur === 'sigircik' ? 1.1 : S.tur === 'marti' ? 0.8 : 0.9));
      }
      if (S.yon * kx > 110 || S.t > 40) { for (const b of S.kuslar) sahne.remove(b); kusSuru = null; }
    } else if (!introCekim) {
      // geçiş saati geldi mi (önceki kareden bu kareye saat bir geçiş anını aştıysa)
      const saat = oyunSaati() % 24;
      const gun = Math.floor((Date.now() + 3 * 3600 * 1000) / 86400000);
      let gec = kusZorla;
      if (kusOncekiSaat != null && saat >= kusOncekiSaat && saat - kusOncekiSaat < 0.1) {
        for (const h of kusSaatleri(gun)) if (kusOncekiSaat < h && h <= saat) gec = true;
      }
      kusOncekiSaat = saat;
      if (gec) { const zt = typeof kusZorla === 'string' ? kusZorla : null; kusZorla = false; kusSuruKur(zt); }
    }
    if (kopek) {
      const u = kopek.userData;
      u.t += dt;
      const pan = () => Math.max(-1, Math.min(1, (kopek.position.x - hedefX) / 20));
      const yakinlik = () => Math.max(0, 1 - Math.hypot(kopek.position.x - hedefX, kopek.position.z - hedefZ, mesafe * 0.5) / 60);
      // 0.41.1: kedi görürse havlayarak peşine düşer; kedi kaçar, köpek bir süre kovalayıp vazgeçer
      const kedi = !u.kovala && !u.vazgecti && olaylar && olaylar.kedi ? olaylar.kedi() : null;
      if (kedi && Math.abs(kedi.x - kopek.position.x) < 16 && Math.abs(kedi.z - kopek.position.z) < 3.5) {
        u.kovala = kedi; u.kovalaT = 0; u.havT = 0;
        ses.havla(pan(), yakinlik(), true);
      }
      if (u.kovala) {
        const k = u.kovala;
        const kx = k.x, kz = k.z;
        u.kovalaT += dt;
        u.havT -= dt;
        if (u.havT <= 0) { u.havT = 0.9 + Math.random() * 0.9; ses.havla(pan(), yakinlik(), true); }
        const dx = kx - kopek.position.x, dz = kz - kopek.position.z;
        const d = Math.hypot(dx, dz);
        if (!k.kacti && d < 3) { k.kacti = true; k.kacir(Math.sign(dx || u.yon)); }
        u.hiz = Math.min(4.6, u.hiz + dt * 6);
        if (d > 0.4) {
          kopek.position.x += (dx / d) * u.hiz * dt;
          kopek.position.z += (dz / d) * u.hiz * dt * 0.6;
          kopek.rotation.y = Math.atan2(-dz, dx);
          u.yon = Math.sign(dx) || u.yon;
        }
        if (u.kovalaT > (k.kacti ? 4 : 9) || !k.var()) {
          u.kovala = null; u.vazgecti = true; u.dur = 1.2;
          kopek.rotation.y = u.yon > 0 ? 0 : Math.PI;
        }
      } else {
        if (u.dur > 0) { u.dur -= dt; u.hiz = Math.max(0, u.hiz - dt * 3); }
        else { u.hiz = u.hiz > 1.25 ? Math.max(1.25, u.hiz - dt * 2) : Math.min(1.25, u.hiz + dt * 2); if (Math.random() < dt * 0.08) u.dur = 1.5 + Math.random() * 2.5; }
        kopek.position.x += u.yon * u.hiz * dt;
        // kovalamacadan sonra yavaşça kendi kaldırım çizgisine döner
        kopek.position.z += (u.z - kopek.position.z) * Math.min(1, dt * 0.8);
        // arada bir havlar (yakındaysa duyulur)
        u.havla -= dt;
        if (u.havla <= 0) {
          u.havla = 9 + Math.random() * 16;
          if (Math.random() < 0.55 && ekrandaMi(kopek.position, 1)) { ses.havla(pan(), yakinlik()); u.dur = Math.max(u.dur, 0.8); }
        }
      }
      kopekAdim(kopek, u.hiz, dt);
      if (u.t > 6 && !ekrandaMi(kopek.position, 1) || u.t > 120) { sahne.remove(kopek); kopek = null; }
    } else if (t > sonrakiKopek) {
      sonrakiKopek = t + 60 + Math.random() * 90;
      if (!introCekim && !durus) {
        const yon = Math.random() < 0.5 ? 1 : -1;
        kopek = kopekModeli(['#B07A43', '#E8DCC8', '#3A3027', '#8C8A86'][Math.floor(Math.random() * 4)]);
        const z = Math.random() < 0.6 ? 9.75 : -6.55;
        // görüş alanının hemen dışından girer
        let x = hedefX - yon * 25;
        for (let i = 0; i < 12 && ekrandaMi({ x, y: 0, z }, 1); i++) x -= yon * 8;
        kopek.position.set(x, KALDIRIM_Y, z);
        kopek.rotation.y = yon > 0 ? 0 : Math.PI;
        Object.assign(kopek.userData, { yon, hiz: 0, dur: 0, t: 0, z, havla: 3 + Math.random() * 8, kovala: null, vazgecti: false });
        kopek.traverse((o) => { if (o.isMesh) { o.castShadow = !sabitGolge; o.userData.golgeAsil = o.castShadow; } });
        kopek.userData.golgeDinamik = true; // 0.47
        sahne.add(kopek);
      }
    }
  }
  // Selektör (0.39.0): gece arada bir bir araba uzunları iki kez yakıp söndürür
  // 0.50: korna seyrek ve yerinde çalar (sıkışan, uzun bekleyen, önüne park yerinden çıkılan sürücü); en az 18 sn arayla
  let sonKornaT = -99;
  function kornaCal(a, x, tip = 'kisa') {
    const t = performance.now() / 1000;
    if (t - sonKornaT < 18 || !aktifMi || mesafe > 85) return false;
    sonKornaT = t;
    ses.korna(Math.max(-1, Math.min(1, (x - hedefX) / 15)), a && a.userData.tur === 'dolmus', tip);
    return true;
  }
  // olaya bağlı selektör (sıkışan trafik, önüne park yerinden çıkan araba)
  function selektorTetikle(a) {
    if (selektorAraba || !a || !a.visible || !a.userData.huzmeler || isikAcikPayi < 0.3) return;
    selektorAraba = a;
    selektorBas = selektorSaat;
  }
  // Sollama: önündeki araç uzun süre duruyorsa (kırmızı ışık, kavşak ya da geçit beklemesi değilse) ve karşı şeritte yaklaşan
  // araç yoksa karşı şeride geçip geçer, sonra kendi şeridine döner. Dönen değer: sollama sürerken bu karede kullanılacak boşluk.
  let sollamaToplam = 0;
  function sollamaGuncelle(a, s, liste, j, dt) {
    const u = a.userData;
    const k = s.karsi;
    if (!k || u.acil || u.olay || u.cikis) { if (u.solla) u.solla = null; return null; }
    const yari = u.araba.uzunluk / 2;
    const ondeki = liste[j + 1];
    if (u.solla) {
      const so = u.solla;
      so.t += dt;
      // karşıdan gelen var mı (karşı şeritte, önümüzde ve yaklaşıyor)
      let karsidan = Infinity;
      for (const b of arabalar) {
        if (b.userData.serit !== k || !b.visible) continue;
        const d = (b.userData.p - u.p) * s.yon - yari - b.userData.araba.uzunluk / 2;
        if (d > -1 && d < karsidan) karsidan = d;
      }
      const gectik = (u.p - so.bitis) * s.yon > 0;
      // kendi şeridinde önü boşsa döner; karşıdan araç yaklaşırsa ve henüz yanına girmediyse vazgeçer
      const kendiOn = ondeki && ondeki !== so.hedef ? (ondeki.userData.p - u.p) * s.yon - yari - ondeki.userData.araba.uzunluk / 2 : Infinity;
      if (gectik && kendiOn > 4) { so.kay = 0; if (Math.abs(u.kacis || 0) < 0.15) u.solla = null; return { bosluk: kendiOn }; }
      if (!gectik && karsidan < 18 && Math.abs(u.kacis || 0) < Math.abs(so.kay) * 0.6) { so.kay = 0; so.vazgec = true; }
      if (so.vazgec) { if (Math.abs(u.kacis || 0) < 0.15) u.solla = null; return null; }
      if (so.t > 25) { so.kay = 0; so.vazgec = true; return null; } // takıldıysa vazgeçer
      // yanına girene kadar yavaş, sonra hızlanarak geçer; karşıdan gelen yakınsa durur
      so.hiz = Math.abs(u.kacis || 0) < Math.abs(so.kay) * 0.8 ? 3.5 : 7;
      return { bosluk: Math.min(karsidan - 3, gectik ? kendiOn : Infinity) };
    }
    if (u.hiz > 0.5) { u.sollamaBekle = 0; return null; }
    u.sollamaBekle = (u.sollamaBekle || 0) + dt;
    // önde ne var: şeritte duran araç ya da şeride taşmış duran görev aracı (kaldırıma yanaşmış ambulans, kamyon…)
    let hedefAraba = null, hedefP = null, hedefUzun = 0, engel = false;
    if (ondeki) {
      const ou = ondeki.userData;
      const bosluk = (ou.p - u.p) * s.yon - (yari + ou.araba.uzunluk / 2);
      ou.durma = ou.hiz < 0.3 ? (ou.durma || 0) + dt : 0;
      if (bosluk < 7 && ou.hiz < 0.3) {
        engel = ou.olay ? ou.durma > 2.5 : ou.durma > 10 && yesilMi(s.eksen) && !(ou.cikis && (ou.cikis.pA - ou.p) * s.yon < 3);
        // öndekinin önünde kuyruk varsa (o da birini bekliyorsa) sollanmaz; yalnızca kuyruğun başı geçilir
        const onunOnu = liste[j + 2];
        if (onunOnu && (onunOnu.userData.p - ou.p) * s.yon < ou.araba.uzunluk + 6 && !ou.olay) engel = false;
        if (engel) { hedefAraba = ondeki; hedefP = ou.p; hedefUzun = ou.araba.uzunluk; }
      }
    }
    if (!engel && u.sollamaBekle > 3) {
      for (const e of disEngeller) {
        if (!e.parent || !e.userData || !e.userData.araba) continue;
        const yanFark = (s.eksen === 'x' ? e.position.z : e.position.x) - s.sabit;
        if (Math.abs(yanFark) > eksenYarisi(e, s.eksen === 'x' ? 'z' : 'x') + (u.araba.en || 1.8) / 2) continue;
        const ep = s.eksen === 'x' ? e.position.x : e.position.z;
        const uzun = eksenYarisi(e, s.eksen);
        const ileri = (ep - u.p) * s.yon - yari - uzun;
        if (ileri < -0.5 || ileri > 8) continue;
        engel = true; hedefAraba = e; hedefP = ep; hedefUzun = uzun * 2;
        break;
      }
    }
    if (!engel) return null;
    const bitis = hedefP + s.yon * (hedefUzun / 2 + yari + 4);
    const uzunluk = (bitis - u.p) * s.yon;
    // geçiş boyunca kavşak, yaya geçidi ve durma çizgisi olmamalı
    if (s.dur.some((c) => (c - u.p) * s.yon > -2 && (c - u.p) * s.yon < uzunluk + 6)) return null;
    for (const kv of KAVSAKLAR) {
      const a1 = s.eksen === 'x' ? kv.x1 : kv.z1, a2 = s.eksen === 'x' ? kv.x2 : kv.z2;
      const yan = s.eksen === 'x' ? s.sabit > kv.z1 - 4 && s.sabit < kv.z2 + 4 : s.sabit > kv.x1 - 4 && s.sabit < kv.x2 + 4;
      if (!yan) continue;
      const lo = Math.min(u.p, bitis) - 3, hi = Math.max(u.p, bitis) + 3;
      if (a2 > lo && a1 < hi) return null;
    }
    // karşı şerit boş mu: yaklaşan araba geçiş boyunca ve biraz ötesinde olmamalı
    for (const b of arabalar) {
      if (b.userData.serit !== k || !b.visible) continue;
      const d = (b.userData.p - u.p) * s.yon;
      if (d > -8 && d < uzunluk + 30 + b.userData.hiz * 4) return null;
    }
    for (const d of donenler) if (Math.abs((s.eksen === 'x' ? d.a.position.x : d.a.position.z) - u.p) < uzunluk + 20) return null;
    for (const y of yoldakiler) if (Math.abs((s.eksen === 'x' ? y.x : y.z) - (u.p + s.yon * uzunluk / 2)) < uzunluk / 2 + 6) return null;
    sollamaToplam++;
    u.sollamaBekle = 0;
    u.solla = { hedef: hedefAraba, bitis, kay: k.sabit - s.sabit, hiz: 3.5, t: 0, sinyal: (s.eksen === 'x' ? (s.yon > 0) === (k.sabit < s.sabit) : (s.yon > 0) === (k.sabit > s.sabit)) ? 'sol' : 'sag' };
    // arkadakinin sabrı tükendi: selektör ve kısa korna
    if (Math.random() < 0.5) selektorTetikle(a);
    if (Math.random() < 0.35) kornaCal(a, a.position.x, 'kisa');
    return { bosluk: Infinity };
  }
  let sonrakiSelektor = 8 + Math.random() * 10, selektorAraba = null, selektorBas = 0;
  let selektorSaat = 0;
  function selektorler(t) {
    selektorSaat = t;
    if (selektorAraba) {
      const g = t - selektorBas;
      const acik = g < 0.16 || (g > 0.32 && g < 0.48);
      for (const h of selektorAraba.userData.huzmeler || []) {
        if (!h.userData.taban) { h.userData.taban = h.scale.clone(); h.userData.tabanEgim = h.rotation.z; }
        const b = h.userData.taban;
        // selektör: uzun far bir an yanar; huzme uzar, yukarı kalkar, far haleleri parlar
        h.scale.set(b.x * (acik ? 2.2 : 1), b.y * (acik ? 1.35 : 1), b.z * (acik ? 1.35 : 1));
        h.rotation.z = acik ? -0.02 : h.userData.tabanEgim;
      }
      for (const h of selektorAraba.userData.onHaleler || []) {
        if (!h.userData.taban) h.userData.taban = h.scale.clone();
        h.scale.copy(h.userData.taban).multiplyScalar(acik ? 2.1 : 1);
      }
      if (g > 0.6) selektorAraba = null;
      return;
    }
    if (t < sonrakiSelektor) return;
    // 0.50: trafik sıkışınca (yakında duran araç çok) selektör daha sık; bekleyenlerden biri yapar
    const yakin = arabalar.filter((a) => a.visible && a.userData.huzmeler && a.position.distanceToSquared(kamera.position) < 90 * 90);
    const duran = yakin.filter((a) => a.userData.hiz < 0.5 && (a.userData.bekleme || 0) > 1.5);
    sonrakiSelektor = t + (duran.length >= 3 ? 3 + Math.random() * 5 : 10 + Math.random() * 18);
    if (isikAcikPayi < 0.3) return;
    const adaylar = duran.length >= 2 ? duran : yakin;
    if (!adaylar.length) return;
    selektorAraba = adaylar[Math.floor(Math.random() * adaylar.length)];
    selektorBas = t;
  }
  let uzakSayac = 0;
  // ---- Sabit gölge (0.39.0, telefon ve tablet): gölge haritasını yalnızca binalar, ağaçlar, tezgâhlar gibi duran
  // nesneler çizer ve harita yalnızca ışık yönü, gölge alanı ya da sahne değişince yenilenir (her karede değil).
  // Yürüyen insanlar ve arabalar haritaya girmez; altlarında yumuşak bir zemin gölgesi (tek çizimle) olur.
  // Ekran kartının her karede yaptığı gölge çizimi ortadan kalkar: ısınma ve takılma azalır, görüntü aynı kalır.
  const sabitGolge = !!gunes.castShadow && matchMedia('(pointer: coarse)').matches;
  let golgeYonAnahtari = '', golgeSonAnahtar = null, golgeSonCizim = -99, golgeKirli = true, golgeCocukSayisi = -1;
  // 0.40: Haritayı yalnızca gölge düşüren duran nesneler değiştirir. Yürüyen insan, araba, balon, yer gölgesi gibi
  // gelip giden nesneler sayılmaz (eskiden her yaya ve araba girişinde bütün gölge haritası yeniden çiziliyordu:
  // tablette saniyede birkaç kez takılma). Güneş yönü daha kaba adımla izlenir.
  function sabitSayisi() {
    let n = 0;
    for (const o of sahne.children) { const u = o.userData; if (!(u.insan || u.araba || u.golgeDinamik || o.isLight || o.isSprite || o.isPoints)) n++; }
    return n;
  }
  // 0.47: Kamera kaydırılırken (anahtar sürekli değişirken) gölge haritası her 1,2 sn'de bir baştan çiziliyordu: tablette
  // sürükleme sırasında düzenli küçük takılmalar. Artık kamera durunca (0,35 sn sakin) ya da en geç 2,5 sn'de bir çizilir;
  // güvenlik yenilemesi 20 sn yerine 60 sn'de bir.
  let golgeAnahtarGorulen = '', golgeAnahtarZaman = 0;
  function golgeIstegi() {
    const t = performance.now() / 1000;
    const sayi = sabitSayisi();
    if (sayi !== golgeCocukSayisi) { golgeCocukSayisi = sayi; golgeKirli = true; }
    const anahtar = golgeYonAnahtari + ',' + golgeBoyu;
    if (anahtar !== golgeAnahtarGorulen) { golgeAnahtarGorulen = anahtar; golgeAnahtarZaman = t; }
    const yonDegisti = anahtar !== golgeSonAnahtar && (t - golgeAnahtarZaman > 0.35 || t - golgeSonCizim > 2.5);
    if ((golgeKirli && t - golgeSonCizim > 0.6) || (yonDegisti && t - golgeSonCizim > 1.2) || t - golgeSonCizim > 60) {
      golgeSonAnahtar = anahtar; golgeSonCizim = t; golgeKirli = false;
      return true;
    }
    return false;
  }
  const lekeler = sabitGolge ? (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const x = c.getContext('2d'); const g = x.createRadialGradient(32, 32, 2, 32, 32, 31);
    g.addColorStop(0, 'rgba(0,0,0,0.72)'); g.addColorStop(0.5, 'rgba(0,0,0,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    const doku = new THREE.CanvasTexture(c);
    const m = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: doku, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }), 160);
    m.count = 0; m.frustumCulled = false; m.renderOrder = 1; m.userData.golgeAsil = false;
    sahne.add(m);
    return m;
  })() : null;
  const lekeMat = new THREE.Matrix4(), lekeKonum = new THREE.Vector3(), lekeDon = new THREE.Quaternion(), lekeOlcek = new THREE.Vector3(), lekeEuler = new THREE.Euler();
  function dinamikGolgeleriKapat() {
    if (!sabitGolge) return;
    for (const o of sahne.children) {
      const u = o.userData;
      if (u.golgeDinamik || !(u.insan || u.araba)) continue;
      u.golgeDinamik = true;
      o.traverse((x) => { if (x.isMesh) { x.castShadow = false; x.userData.golgeAsil = false; } });
    }
  }
  function lekeleriGuncelle() {
    if (!lekeler) return;
    let n = 0;
    for (const o of sahne.children) {
      const u = o.userData;
      if (!(u.insan || u.araba) || !o.visible || n >= 160) continue;
      if (u.insan && o.position.y > 0.6) continue;
      o.getWorldPosition(lekeKonum);
      lekeEuler.set(0, o.rotation.y, 0); lekeDon.setFromEuler(lekeEuler);
      if (u.araba) lekeOlcek.set(2.3, 1, 4.9); else lekeOlcek.set(0.8, 1, 0.8);
      lekeKonum.y += 0.018;
      lekeMat.compose(lekeKonum, lekeDon, lekeOlcek);
      lekeler.setMatrixAt(n++, lekeMat);
    }
    lekeler.count = n;
    lekeler.instanceMatrix.needsUpdate = true;
    lekeler.material.opacity = 1 - gecePayi * 0.55;
  }
  // İnsan ayrıntısı 40/50 m histerezisle değişir; görünür gövdeler uzaklık yüzünden yok edilmez.
  const lodKonum = new THREE.Vector3();
  // Gölge ayrıntısı (0.37.22): kamera uzaktayken (kuş bakışı) küçük nesnelerin (çiçek saksısı, levha, ampul, eşya…)
  // gölgesi gölge haritasında bir iki pikseldir, görünmez; bunlar gölge çiziminden çıkarılır. Yaklaşınca geri gelir.
  // Gölge çiziminin yarıdan fazlası bu küçük parçalardı (kuş bakışında 500'ü aşkın ek çizim).
  let golgeUzak = false, golgeTarama = -99;
  const golgeOlcek = new THREE.Vector3();
  function golgeLodu(t) {
    const uzak = mesafe > 110;
    if (uzak === golgeUzak && t - golgeTarama < 3) return;
    golgeUzak = uzak; golgeTarama = t;
    sahne.traverse((o) => {
      if (!o.isMesh || o.isSkinnedMesh || o.isInstancedMesh) return;
      const u = o.userData;
      if (u.golgeAsil === undefined) {
        u.golgeAsil = o.castShadow;
        if (!o.castShadow) return;
        const g = o.geometry;
        if (!g.boundingSphere) g.computeBoundingSphere();
        o.getWorldScale(golgeOlcek);
        u.golgeR = g.boundingSphere.radius * Math.max(golgeOlcek.x, golgeOlcek.y, golgeOlcek.z);
      }
      if (!u.golgeAsil) return;
      o.castShadow = !uzak || u.golgeR >= 1.2;
    });
  }
  const lodKure = new THREE.Sphere();
  const lodGorus = new THREE.Frustum();
  const lodMatris = new THREE.Matrix4();
  function insanLodu(g) {
    if (!g || !g.userData.insan) return;
    g.getWorldPosition(lodKonum);
    const u = lodKonum.distanceTo(kamera.position);
    const onceki = g.userData.insan.lod;
    insanLod(g, u > (onceki === 1 ? 40 : 50) ? 1 : 0);
    // ekranda değilse hareketi seyrek, uzaktaysa iki karede bir güncellenir (görüntü aynı kalır)
    lodKure.center.copy(lodKonum); lodKure.center.y += 0.9; lodKure.radius = 1.6;
    const ekranda = lodGorus.intersectsSphere(lodKure);
    insanAdimAraligi(g, !ekranda ? 6 : u > 45 ? 2 : 1);
  }
  // Binaların uzak kopyası: kameradan 90 m ötedeki binalar balkon, klima, perde gibi küçük ayrıntılar olmadan çizilir
  // (bir binanın çizim sayısı yarıya iner). Kesit alınan (kamerayı kapatan) bina hep asıl haliyle kalır.
  // Kuş bakışında bütün binaların sade kopyaları tek parça olarak (malzeme başına bir çizim) çizilir
  let topluBinalar = null;
  let topluHazirlik = null, topluHazirlikHatasi = false, topluHazirlikIsi = null;
  function topluBinalariSil() {
    topluHazirlik?.abort(); topluHazirlik = null; topluHazirlikIsi = null; topluHazirlikHatasi = false;
    for (const d of dukkanlar.values()) { if (d.grup) d.grup.visible = true; if (d.uzak) d.uzak.visible = false; }
    if (topluBinalar) { sahne.remove(topluBinalar); bellektenSil(topluBinalar); topluBinalar = null; }
  }
  function topluBinalarIste() {
    if (introCekim || topluBinalar || topluHazirlik || topluHazirlikHatasi || !dukkanlar.size) return;
    const kontrol = new AbortController(); topluHazirlik = kontrol;
    const kap = new THREE.Group(), liste = [...dukkanlar.values()]; let i = 0;
    const is = (async () => {
      try {
        const hazir = await parcaliIs(() => {
          if (i >= liste.length) return false;
          const a = liste[i++].uzakAyar;
          if (!a) return true;
          const b = apartman({ genislik: a.genislik, kat: a.kat, derinlik: 9, sade: true, rng: tohumluRastgele(a.tohum), dukkan: a.dukkan });
          b.position.set(a.x, KALDIRIM_Y, a.z); b.rotation.y = a.ry; kap.add(b);
          return true;
        }, {signal:kontrol.signal, bekle:250});
        if (!hazir || !await birlestirParcali(kap, {golge:true, signal:kontrol.signal})) return;
        if (kontrol.signal.aborted) return;
        // Shader hazırlığı görünür modele geçmeden tamamlanır.
        const r = getRenderer();
        if (r?.compileAsync) await r.compileAsync(kap, kamera, sahne);
        if (kontrol.signal.aborted) return;
        kap.visible = false; sahne.add(kap); geceIsiklariniTopla(kap); topluBinalar = kap;
      } catch (e) { if (!kontrol.signal.aborted) { topluHazirlikHatasi = true; console.error('[model hazırlığı]', e); } }
      finally {
        if (topluBinalar !== kap) { sahne.remove(kap); bellektenSil(kap); }
        if (topluHazirlik === kontrol) { topluHazirlik = null; topluHazirlikIsi = null; }
      }
    })();
    topluHazirlikIsi = is;
  }
  function binaLodlari() {
    const toplu = !introCekim && mesafe > 140 && [...dukkanlar.values()].every(d => (d.saydamlik ?? 1) >= 0.999);
    if (toplu && !topluBinalar) topluBinalarIste();
    if (topluBinalar) topluBinalar.visible = toplu;
    const hazir = toplu && !!topluBinalar;
    // Hazırlık bitene kadar mevcut binalar görünür kalır; orta mesafede yeni kopya oluşturulmaz.
    for (const d of dukkanlar.values()) {
      if (d.grup) d.grup.visible = !hazir;
      if (d.uzak) d.uzak.visible = false;
      d.uzakta = false;
    }
    if (cadde) cadde.kap.visible = !hazir;
  }

  // ---- Cadde birleşimi (0.40): bütün binaların duran parçaları malzeme ve 32 m'lik hücre başına tek çizimde toplanır.
  // Bir sokakta 10–12 binanın her biri ayrı ayrı 15–20 çizimdi; birleşince aynı görüntü üçte bir çizimle çıkar
  // (telefon ve tablette işlemcinin kare başına en büyük işi buydu). Kepenk, gece pencere ışıkları, ışık haleleri ayrı
  // kalır. Kamerayı kapatan binanın kesiti alınırken o binanın birleşimdeki payı gizlenir, asıl parçaları görünür.
  const CADDE_HUCRE = 32;
  const BIRLESIM_DISI = ['kepenk', 'hale', 'leke', 'don', 'salla', 'duman', 'faz', 'ayri', 'pencereIsigi'];
  let cadde = null, caddeSurum = 0, caddeZaman = null;
  function caddeBirlesimIste() {
    if (introCekim || cadde) return; // birleşim duruyorsa (hiçbir bina değişmediyse) yeniden kurulmaz
    clearTimeout(caddeZaman);
    caddeZaman = setTimeout(() => { caddeBirlestir().catch((e) => console.warn('[cadde birleşimi]', e)); }, 900);
  }
  function caddeBirlesimSil() {
    caddeSurum++;
    clearTimeout(caddeZaman);
    if (!cadde) return;
    for (const [d, p] of cadde.parcalar) for (const m of p.meshler) m.visible = true;
    sahne.remove(cadde.kap);
    cadde.kap.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
    cadde = null;
    golgeKirli = true;
  }
  function birlesimeGirer(o, kok) {
    if (!o.isMesh || o.isSkinnedMesh || o.isInstancedMesh || Array.isArray(o.material) || !o.material || !o.geometry || !o.geometry.attributes.position) return false;
    if (o.material.clippingPlanes) return false;
    for (let x = o; x && x !== kok; x = x.parent) {
      if (!x.visible) return false;
      for (const k of BIRLESIM_DISI) if (x.userData && x.userData[k] !== undefined && x.userData[k] !== false) return false;
    }
    return true;
  }
  const bm = new THREE.Matrix3();
  async function caddeBirlestir() {
    if (cadde) return;
    const surum = ++caddeSurum;
    const kovalar = new Map(); // malzeme|hücre -> { m, parcalar: [{ d, o }] }
    const secilen = new Map();
    for (const d of dukkanlar.values()) {
      if (!d.grup || !d.grup.parent) continue;
      d.grup.updateMatrixWorld(true);
      const liste = [];
      d.grup.traverse((o) => { if (o !== d.grup && birlesimeGirer(o, d.grup)) liste.push(o); });
      const hucre = Math.floor(d.merkezX / CADDE_HUCRE) + ':' + (d.sira || 0);
      for (const o of liste) {
        const anahtar = o.material.uuid + '|' + hucre + '|' + (o.material.vertexColors ? 1 : 0);
        if (!kovalar.has(anahtar)) kovalar.set(anahtar, { m: o.material, parcalar: [] });
        kovalar.get(anahtar).parcalar.push({ d, o });
      }
      secilen.set(d, liste);
    }
    const kap = new THREE.Group();
    kap.name = 'cadde-birlesimi';
    const parcalar = new Map();
    for (const [d, liste] of secilen) parcalar.set(d, { meshler: liste, araliklar: [], gizli: false });
    let say = 0;
    for (const { m, parcalar: l } of kovalar.values()) {
      let nK = 0, nI = 0;
      for (const { o } of l) { const g = o.geometry; nK += g.attributes.position.count; nI += g.index ? g.index.count : g.attributes.position.count; }
      const vc = !!m.vertexColors;
      const pos = new Float32Array(nK * 3), nor = new Float32Array(nK * 3), uv = new Float32Array(nK * 2), renk = vc ? new Float32Array(nK * 3) : null;
      const ind = nK > 65535 ? new Uint32Array(nI) : new Uint16Array(nI);
      let k = 0, ii = 0, golge = false;
      for (const { d, o } of l) {
        const g = o.geometry, e = o.matrixWorld.elements;
        bm.getNormalMatrix(o.matrixWorld); const n = bm.elements;
        const P = g.attributes.position, N = g.attributes.normal, U = g.attributes.uv, C = g.attributes.color;
        for (let i = 0; i < P.count; i++) {
          const x = P.getX(i), y = P.getY(i), z = P.getZ(i), j = (k + i) * 3;
          pos[j] = e[0] * x + e[4] * y + e[8] * z + e[12]; pos[j + 1] = e[1] * x + e[5] * y + e[9] * z + e[13]; pos[j + 2] = e[2] * x + e[6] * y + e[10] * z + e[14];
          if (N) { const a = N.getX(i), b = N.getY(i), c2 = N.getZ(i); let nx = n[0] * a + n[3] * b + n[6] * c2, ny = n[1] * a + n[4] * b + n[7] * c2, nz = n[2] * a + n[5] * b + n[8] * c2; const ln = Math.hypot(nx, ny, nz) || 1; nor[j] = nx / ln; nor[j + 1] = ny / ln; nor[j + 2] = nz / ln; }
          if (U) { uv[(k + i) * 2] = U.getX(i); uv[(k + i) * 2 + 1] = U.getY(i); }
          if (renk) { if (C) { renk[j] = C.getX(i); renk[j + 1] = C.getY(i); renk[j + 2] = C.getZ(i); } else renk[j] = renk[j + 1] = renk[j + 2] = 1; }
        }
        const bas = ii;
        if (g.index) { const I = g.index; for (let i = 0; i < I.count; i++) ind[ii++] = I.getX(i) + k; }
        else for (let i = 0; i < P.count; i++) ind[ii++] = i + k;
        if (o.matrixWorld.determinant() < 0) for (let t = bas; t < ii; t += 3) { const x = ind[t + 1]; ind[t + 1] = ind[t + 2]; ind[t + 2] = x; }
        parcalar.get(d).araliklar.push({ bas, say: ii - bas, mesh: null });
        k += P.count;
        golge = golge || o.castShadow;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
      geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
      if (renk) geo.setAttribute('color', new THREE.BufferAttribute(renk, 3));
      geo.setIndex(new THREE.BufferAttribute(ind, 1));
      geo.computeBoundingSphere(); geo.computeBoundingBox();
      const mesh = new THREE.Mesh(geo, m);
      mesh.castShadow = golge && !m.transparent; mesh.receiveShadow = true;
      mesh.userData.golgeAsil = mesh.castShadow;
      mesh.userData.golgeR = 99;
      // bu kovadaki aralıklara mesh bağlanır
      for (const { d } of l) { const p = parcalar.get(d); for (const r of p.araliklar) if (!r.mesh) { r.mesh = mesh; break; } }
      kap.add(mesh);
      if (++say % 12 === 0) { await new Promise((r) => setTimeout(r, 0)); if (surum !== caddeSurum) { kap.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); return; } }
    }
    if (surum !== caddeSurum) { kap.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); return; }
    for (const p of parcalar.values()) for (const r of p.araliklar) r.yedek = r.mesh.geometry.index.array.slice(r.bas, r.bas + r.say);
    cadde = { kap, parcalar };
    kap.visible = !(topluBinalar && topluBinalar.visible);
    sahne.add(kap);
    for (const [d, p] of parcalar) {
      for (const o of p.meshler) o.visible = false;
      if ((d.saydamlik ?? 1) < 0.999) caddeAraligi(d, true);
    }
    golgeKirli = true;
  }
  // gizle: true → bu binanın birleşimdeki üçgenleri sönük (dejenere) yapılır, asıl parçaları görünür
  function caddeAraligi(d, gizle) {
    const p = cadde && cadde.parcalar.get(d);
    if (!p || p.gizli === gizle) return;
    p.gizli = gizle;
    for (const r of p.araliklar) {
      const idx = r.mesh.geometry.index;
      if (gizle) idx.array.fill(r.yedek[0], r.bas, r.bas + r.say);
      else idx.array.set(r.yedek, r.bas);
      idx.addUpdateRange(r.bas, r.say);
      idx.needsUpdate = true;
    }
    for (const o of p.meshler) o.visible = gizle;
    golgeKirli = true;
  }

  function insanLodlari() {
    kamera.updateMatrixWorld();
    lodGorus.setFromProjectionMatrix(lodMatris.multiplyMatrices(kamera.projectionMatrix, kamera.matrixWorldInverse));
    for (const y of yayalar) insanLodu(y);
    for (const y of esliCocuklar) insanLodu(y);
    for (const y of gecenler) insanLodu(y);
    for (const m of musteriler) insanLodu(m);
    for (const y of yerler.values()) insanLodu(y.insan);
    for (const k of komsular.values()) insanLodu(k.insan);
    for (const c of copculer) insanLodu(c.g);
    if (olaylar) for (const k of olaylar.insanlar()) insanLodu(k.g);
  }
  // Ekranda mı (0.39.0): yolun ya da kaldırımın ucuna gelen araba ve yaya, ekrandayken birden kaybolmaz; ekranın
  // dışına çıkana kadar yürür/sürer. Ekran boyutu ve yakınlaştırma ne olursa olsun kameranın gerçek görüş alanına bakılır.
  const gorusAlani = new THREE.Frustum(), gorusMat = new THREE.Matrix4(), gorusKure = new THREE.Sphere();
  function gorusGuncelle() { kamera.updateMatrixWorld(); gorusMat.multiplyMatrices(kamera.projectionMatrix, kamera.matrixWorldInverse); gorusAlani.setFromProjectionMatrix(gorusMat); }
  function ekrandaMi(p, r = 2.5) { gorusKure.center.set(p.x, (p.y || 0) + r * 0.5, p.z); gorusKure.radius = r; return gorusAlani.intersectsSphere(gorusKure); }
  function guncelle(dt, t) {
    kameraGuncelle(dt);
    gorusGuncelle();
    // semtin sis ötesinde kalan kareleri (bina, ağaç, lamba) çizme
    // ayrıntı ayarları zamana bağlı (yavaş cihazda da her 0,4 saniyede bir)
    if (t - uzakSayac > 0.4 || t < uzakSayac) { uzakSayac = t; if (sehir && sehir.uzakGizle) sehir.uzakGizle(hedefX, hedefZ, introCekim ? Infinity : sahne.fog.far * (K.kod === 'dusuk' ? 0.75 : 1)); komsuDetaylariAyarla(); insanLodlari(); binaLodlari(); golgeLodu(t); dinamikGolgeleriKapat(); }
    lekeleriGuncelle();
    selektorler(t);
    mitingGuncelle(dt);
    bayraklariDalgalandir(t);
    guvercinSurusu(t, dt);
    geceGosterisi(t);
    pencereIsiklari(t, dt);
    hayvanlar(t, dt);
    gunIsigi(dt);
    {
      // hava efektleri; şimşek çakınca sahne bir anlığına beyaza keser
      const hv = havaEf.guncelle(dt, t, { x: hedefX, z: hedefZ, gunduz: 1 - gecePayi, bulut: bulutPayi, zeminY, yakinlik: Math.max(0, Math.min(1, 1 - (mesafe - 25) / 90)) });
      if (hv.simsek > 0) {
        yarim.intensity += hv.simsek * 4.5;
        yarim.color.lerp(SIMSEK_RENK, hv.simsek * 0.8);
        sahne.fog.color.lerp(SIMSEK_RENK, hv.simsek * 0.45);
      }
    }
    const adimSayisi = Math.max(1, Math.ceil(dt / 0.05));
    const h = dt / adimSayisi;
    if (kuruldu) yoldakileriTopla();
    for (let i = 0; i < adimSayisi; i++) {
      const son = i === adimSayisi - 1 ? dt : 0;
      if (kuruldu) {
        isikGuncelle(h);
        trafikGuncelle(h);
        parkGuncelle(h, t);
        if (son) lambalariGuncelle(t);
        yayaGuncelle(h, son);
        copcuGuncelle(h, son);
      }
      musteriGuncelle(h, t, son);
    }
    suslemeGuncelle(t);
    paraGuncelle();
    panoGuncelle(t);
    fisekGuncelle(Math.min(dt, 0.1));
    yagisGuncelle(Math.min(dt, 0.1), t);
    if (kuruldu) olaylar.guncelle(Math.min(dt, 0.25), t);
    if (kuruldu) itisme(Math.min(dt, 0.1));

    for (const yer of yerler.values()) {
      if (yer.model) {
        if (yer.buyume < 1) {
          yer.buyume = Math.min(1, yer.buyume + dt * 2.5);
          const k = yer.buyume;
          const o = k < 0.7 ? k / 0.7 * 1.1 : 1.1 - (k - 0.7) / 0.3 * 0.1;
          yer.model.scale.setScalar(o);
          if (yer.ortu) yer.ortu.scale.setScalar(o);
        }
        const calisiyor = yer.aktif && yer.aktif.bitis > simdi();
        // modeldeki hareketli parçalar bir kez bulunur (her karede bütün modeli dolaşmamak için)
        if (!yer.hareketliler || yer.hareketliModel !== yer.model) {
          yer.hareketliModel = yer.model;
          yer.hareketliler = [];
          yer.model.traverse((o) => { const u = o.userData; if (u.don || u.salla !== undefined || u.duman || u.faz !== undefined) yer.hareketliler.push(o); });
        }
        const yakinda = yakinMi(yer.grup.position.x, yer.grup.position.z, 30);
        for (const o of yer.hareketliler) {
          if (o.userData.duman) o.visible = !!calisiyor;
          if (!yakinda) continue;
          if (o.userData.don && calisiyor) o.rotation.x += dt * 2;
          if (o.userData.salla !== undefined) o.position.x += Math.sin(t * 1.5 + o.userData.salla) * 0.002;
          if (o.userData.faz !== undefined && o.parent && o.parent.userData.duman) {
            const f = (t * 0.4 + o.userData.faz) % 1;
            o.position.y = 2.2 + f * 1.4;
            o.material.opacity = 0.5 * (1 - f);
            o.scale.setScalar(0.6 + f);
          }
        }
      }
      if (yer.bos) bosYerOynat(yer.bos, t);
      if (yer.insan && yakinMi(yer.grup.position.x, yer.grup.position.z)) insanGuncelle(yer.insan, dt);
    }
    if (introDolgu) introDolguGuncelle(dt);
    for (const k of komsular.values()) {
      if (k.model && k.buyume < 1) { k.buyume = Math.min(1, k.buyume + dt * 2.2); const o = k.buyume < 0.7 ? (k.buyume / 0.7) * 1.1 : 1.1 - ((k.buyume - 0.7) / 0.3) * 0.1; k.model.scale.setScalar(o); }
      if (k.insan && yakinMi(k.grup.position.x, k.grup.position.z)) insanGuncelle(k.insan, dt);
    }
    if (t - sonEtiket > 0.25) {
      sonEtiket = t;
      for (const yer of yerler.values()) if (yer.veri) etiketCiz(yer);
    }
    if (t - sonSes > 1) {
      sonSes = t;
      const kalabalik = Math.min(1, (yayalar.length + musteriler.filter((m) => m.visible).length) / 16) * Math.max(0.2, 1 - mesafe / 200);
      ses.ortamDurumu({ aktif: aktifMi && !document.hidden, gece: gecePayi, kalabalik });
    }
  }

  // Etiketin gizli/görünür durumu bellekte tutulur: her karede yüzlerce etikete sınıf yazmak (değişmese de)
  // tarayıcıya stil yeniden hesaplatıyordu.
  function etiketGizle(etiket, gizli) {
    // (başka yerlerde doğrudan eklenen 'gizli' sınıfı da hesaba katılır; okumak stil hesaplatmaz)
    if (etiket.classList.contains('gizli') === gizli) return;
    etiket.classList.toggle('gizli', gizli);
  }
  function etiketGoster(etiket, x3, y3, z3, gorunur = true) {
    if (!aktifMi || !gorunur) { etiketGizle(etiket, true); return; }
    bakis.set(x3, y3, z3);
    const k = ekranKonumu(bakis, kamera);
    if (!k || k.x < -80 || k.x > window.innerWidth + 80 || k.y < -40 || k.y > window.innerHeight + 40) {
      etiketGizle(etiket, true);
    } else {
      etiketGizle(etiket, false);
      // yalnızca yer değiştiyse yazılır (her karede stil yazmak tablette yavaşlatıyordu)
      // 0.47: konum aynıysa yazı da üretilmez (her karede onlarca geçici metin çöp toplayıcıyı yoruyordu)
      const x = Math.round(k.x), y = Math.round(k.y);
      if (etiket._x !== x || etiket._y !== y) { etiket._x = x; etiket._y = y; etiket.style.transform = `translate(${x}px, ${y}px) translate(-50%, -100%)`; }
    }
  }

  function etiketleriGuncelle() {
    if (sinema || introDolgu) return; // tanıtımda etiketler gizli, konumları hesaplanmaz
    const yakin = mesafe < 75;
    const orta = mesafe < 140;
    for (const yer of yerler.values()) {
      // tezgâhlara bakarken (açılıştaki genel görünüm dahil) etiketler açık kalır
      const tezgahBolgesi = mesafe < 320 && Math.abs(hedefZ - ORTA_Z) < 30 && Math.abs(hedefX) < 60;
      // uzaktan bakarken kilitli tezgâhların etiketi gizlenir, kalabalık olmasın
      const gerekli = yer.veri && (yer.aktif || yer.veri.sahip || !yer.veri.kilitli);
      // biten işin kazanç kesesi uzaktan da görünür (toplanmayı bekleyen para kaybolmasın)
      const kese = yer.durum === 'bitti' && mesafe < 260;
      etiketGoster(yer.etiket, yer.grup.position.x, ETIKET_Y + (yer.veri && yer.veri.kod === 'dondurma' ? 0.8 : 0), yer.grup.position.z, yakin || kese || (tezgahBolgesi && gerekli));
    }
    // semtin caddelerindeki komşular kuş bakışında da görünür: uzaktan küçük bir iğne, yakında tam etiket
    for (const k of komsular.values()) {
      const uzak = mesafe > 120;
      if (k.uzakEtiket !== uzak) { k.uzakEtiket = uzak; k.etiket.classList.toggle('uzak-komsu', uzak); }
      etiketGoster(k.etiket, k.grup.position.x, ETIKET_Y - 0.4, k.grup.position.z, k.mod === 'sehir' ? mesafe < 950 : mesafe < 95);
    }
    for (const d of dukkanlar.values()) {
      const i = d.veri.isletme;
      // Kendi dükkânı ve kiralık yerler için dokunma işareti.
      const kiralik = !i || i.durum === 'kiralik';
      etiketGoster(d.etiket, d.merkezX, 1.6, d.onZ + d.yon * 1.2, (kiralik || !!(i && i.benim)) && orta);
    }
    for (const m of musteriler) if (m.userData.siparis) etiketGoster(m.userData.siparis, m.position.x, 2.3, m.position.z, yakin);
    for (const s of sokakEtiketleri) { const g = mesafe > 100 && sokakEtiketiKonumla(s); etiketGoster(s.e, s.gx, 0.5, s.gz, g); }
    if (arabam) etiketGoster(arabam.etiket, arabam.g.position.x, 2.0, arabam.g.position.z, mesafe < 70);
    for (const d of dolasanlar.values()) etiketGoster(d.etiket, d.a.position.x, 2.0, d.a.position.z, mesafe < 90 && d.a.visible);
  }

  function tikla(raycaster) {
    const hedefler = [...yerler.values()].filter((y) => y.grup.visible).map((y) => y.isabet)
      .concat([...komsular.values()].map((k) => k.isabet), [...dukkanlar.values()].map((d) => d.isabet), panolar.map((p) => p.isabet), bilboardlar.map((b) => b.isabet), devletHedefler, ziyaret ? [] : kamuHedefler, miting && !ziyaret ? [miting.isabet] : []);
    const v = raycaster.intersectObjects(hedefler, false)[0];
    if (!v) return;
    if (v.object.userData.devlet) {
      ses.tik && ses.tik();
      // 0.51: gezilen ilçenin kurumları oyuncunun kendi işlem sayfalarını açmaz; adıyla kısa bilgi verilir
      if (ziyaret) { window.dispatchEvent(new CustomEvent('cirak-ziyaret-kurum', { detail: { ...v.object.userData.devlet, ilce: ziyaret.ilce } })); return; }
      if (!v.object.userData.devlet.rota) { window.dispatchEvent(new CustomEvent('cirak-kurum-bilgi', { detail: v.object.userData.devlet })); return; }
      location.hash = v.object.userData.devlet.rota; return;
    }
    if (v.object.userData.kamu) { ses.tik && ses.tik(); location.hash = '#/bagis/' + v.object.userData.kamu; return; }
    if (v.object.userData.miting) { if (miting && mitingTik) mitingTik(miting.veri); return; }
    if (v.object.userData.komsu) { const k = komsular.get(v.object.userData.komsu); if (k) komsuTiklandi(k.veri); return; }
    if (v.object.userData.bilboard) {
      const b = bilboardlar.find((x) => x.isabet === v.object);
      if (b && bilboardTik) bilboardTik(b.no, b.gosterilen);
      return;
    }
    if (v.object.userData.pano) {
      // panodaki dükkâna uç; reklam yoksa reklam ekranı açılır
      const p = panolar.find((x) => x.isabet === v.object);
      if (p && p.gosterilen && p.gosterilen.kutlama) komsuTiklandi({ oyuncuId: p.gosterilen.oyuncuId, ad: p.gosterilen.oyuncu });
      else if (p && p.gosterilen) dukkanaOdakla(p.gosterilen.yerNo);
      else if (reklamTik) reklamTik();
      return;
    }
    if (v.object.userData.kod) {
      tiklandi(v.object.userData.kod);
    }
    else if (v.object.userData.dukkan) dukkanTiklandi(v.object.userData.dukkan);
  }

  function odakla(kod, aniden) {
    const y = yerler.get(kod);
    if (!y) return;
    const m = Math.min(istenenMesafe, 40);
    const oz = y.grup.position.z + 1.2;
    if (aniden) { hedefX = y.grup.position.x; hedefZ = oz; istenenMesafe = mesafe = Math.max(m, enYakinMesafe); aci = 0; }
    else ucusYap(y.grup.position.x, oz, Math.max(m, enYakinMesafe));
  }
  function dukkanaOdakla(no, aniden) {
    const d = dukkanlar.get(no);
    if (!d) return;
    const z = d.onZ + d.yon * 4;
    const m = Math.max(Math.min(istenenMesafe, 40), enYakinMesafe);
    // arka sokaktaki kuzeye bakan dükkânlara güneyden bakılmalı
    if (d.yon < 0) aci = Math.PI; else if (Math.abs(aci) > Math.PI / 2) aci = 0;
    if (aniden) { hedefX = d.merkezX; hedefZ = z; istenenMesafe = mesafe = m; }
    else ucusYap(d.merkezX, z, m);
  }

  function ekranYeri(kod) {
    const y = yerler.get(kod);
    if (!y) return null;
    bakis.set(y.grup.position.x, 2, y.grup.position.z);
    return ekranKonumu(bakis, kamera);
  }
  function dukkanEkranYeri(no) {
    const d = dukkanlar.get(no);
    if (!d) return null;
    bakis.set(d.merkezX, 2.5, d.onZ);
    return ekranKonumu(bakis, kamera);
  }
  function ilkKiralik() {
    const liste = [...dukkanlar.values()].filter((d) => !d.veri.isletme)
      .sort((a, b) => Math.hypot(a.merkezX - hedefX, a.onZ - hedefZ) - Math.hypot(b.merkezX - hedefX, b.onZ - hedefZ));
    return liste[0] ? liste[0].veri.no : null;
  }

  gunIsigi();

  return {
    async hazirla() { gunIsigi(0); while (topluHazirlikIsi) await topluHazirlikIsi; setTimeout(arkaIsitma, 3500); },
    hazirlikDurumu() { return {binaSayisi:dukkanlar.size, toplu:!!topluBinalar, bekliyor:!!topluHazirlik, hata:topluHazirlikHatasi}; },
    baglamYenilendi() { sonOrtamYuk = -99; },
    sahne, kamera, guncelle, boyut, tikla, etiketleriGuncelle, _dukkanlar: dukkanlar,
    durumGuncelle, caddeGuncelle, caddeHazirla, devletAyarla, kamuAyarla, secimAyarla, reklamlariAyarla, bilboardlariAyarla, dolasanlarAyarla, havaiFisekAyarla, komsulariAyarla, ziyaretBasla, ziyaretBitir, ziyaretteMi: () => !!ziyaret, arabamAyarla, odakla, dukkanaOdakla, ekranYeri, dukkanEkranYeri, ilkKiralik, havaAyarla, ozelGunAyarla, sayginDurus,
    kamuyaOdakla(kod) {
      const y = kamuYerleri.get(kod) || [...kamuYerleri.values()].find((v) => v.kod === kod);
      if (!y || !y.isabet) return;
      aci = 0; ucusYap(y.isabet.position.x, y.isabet.position.z + 4, Math.max(enYakinMesafe, kod === 'millet' ? 95 : /^cami|park/.test(kod) ? 60 : 75));
    },
    // 0.52: kurum binasına (plaza, hastane, emniyet, itfaiye…) kamerayı götürür
    kurumaOdakla(tur) {
      const h = devletHedefler.find((x) => x.userData.devlet && x.userData.devlet.tur === tur);
      if (!h) return false;
      aci = h.userData.ry || 0; ucusYap(h.position.x, h.position.z, Math.max(enYakinMesafe, tur === 'plaza' ? 110 : 80));
      return true;
    },
    camiyeOdakla() { aci = 0; ucusYap(CAMI.x(), CAMI.z + 4, Math.max(enYakinMesafe, 38)); },
    // 0.50.2: caminin özel gün ışıkları ({ tur: ramazan|kandil|bayram|milli, mahya } ya da null)
    camiIsikAyarla(v) { camiIsikVeri = v || null; if (meydanCamisi) meydanCamisi.userData.mod(camiIsikVeri); },
    // geliştirme ve ekran görüntüsü denemeleri için: kamerayı bir noktaya uçurur
    _ucus(x, z, m, a) { aci = a || 0; ucusYap(x, z, m); },
    get _eksen() { return { XB, XD }; },
    _kamuYer(kod) { const y = kamuYerleri.get(kod); return y && y.g ? { x: y.isabet.position.x, z: y.isabet.position.z, ry: y.g.rotation.y } : null; },
    get pozlama() { return pozlama.deger; },
    // gölge haritası kaç karede bir yenilenir: yakında her karede, kuş bakışında seyrek (gölgeler zaten küçük görünür)
    get golgeAralik() { return mesafe < 90 ? 1 : mesafe < 230 ? 3 : 8; },
    // telefon ve tablette gölge haritası yalnızca gerektiğinde yenilenir (sabit gölge)
    golgeIstegi: sabitGolge ? golgeIstegi : undefined,
    golgeYenile() { golgeKirli = true; },
    // deneme: kuş, köpek, selektör ve pencere ışığını hemen başlatır
    denemeCanlilar(kusTuru) { kusZorla = kusTuru || true; sonrakiKopek = sonrakiSelektor = sonrakiPencere = 0; for (const y of yayalar) if (Math.abs(y.userData.serit && y.userData.serit.z - 10.1) < 0.5 && !y.userData.oturma) bankaYonel(y, y.userData.serit); },
    // deneme: trafiğin anlık durumu (şerit başına görünen araba, dönen, park eden) ve yol dışına taşan araba var mı
    // deneme: park şeridindeki ve park eden/çıkan arabalar (çarpışma denetimi için)
    parkDurumu() {
      const l = [];
      for (const y of parkYerleri) if (y.araba && y.araba.userData.durum === 'park') l.push({ x: y.araba.position.x, z: y.araba.position.z, r: y.araba.rotation.y, d: 'park', u: y.araba.userData.araba.uzunluk || 4.4 });
      for (const a of parkEdenler) l.push({ x: a.position.x, z: a.position.z, r: a.rotation.y, d: a.userData.durum, u: a.userData.araba.uzunluk || 4.4 });
      for (const a of arabalar) if (a.visible && a.userData.serit === SERITLER[0]) l.push({ x: a.position.x, z: a.position.z, r: a.rotation.y, d: 'yol', u: a.userData.araba.uzunluk || 4.4 });
      return l;
    },
    trafikDurumu() {
      const seritler = SERITLER.map((s, i) => ({ i, eksen: s.eksen, sabit: +s.sabit.toFixed(1), yon: s.yon, gorunen: arabalar.filter((a) => a.userData.serit === s && a.visible).length, gizli: arabalar.filter((a) => a.userData.serit === s && !a.visible).length }));
      const yolDisi = [];
      for (const a of [...arabalar, ...donenler.map((d) => d.a)]) {
        if (!a.visible) continue;
        const { x, z } = a.position;
        const anaCadde = z > 0 && z < 8.6;
        const arka = z > B_Z - B_YARI - 0.3 && z < B_Z + B_YARI + 0.3 && x > XB - 3.8 && x < XD + 3.8;
        const ara = (Math.abs(x - XB) < 3.8 || Math.abs(x - XD) < 3.8) && z < 8.6;
        if (!anaCadde && !arka && !ara) yolDisi.push([+x.toFixed(1), +z.toFixed(1)]);
      }
      return { seritler, donen: donenler.length, parkEden: parkEdenler.length, yolDisi, XB, XD, sollayan: arabalar.filter((a) => a.userData.solla).length, sollamaToplam, teshis: (() => { const s0 = SERITLER[0]; const l = arabalar.filter((a) => a.visible && a.userData.serit === s0).sort((a, b) => a.userData.p - b.userData.p); return { serit: l.map((a) => [+a.userData.p.toFixed(1), +a.userData.hiz.toFixed(1), +(a.userData.bekleme || 0).toFixed(0), a.userData.cikis ? 'C' : '', a.userData.solla ? 'S' : '', +(a.userData.kacis || 0).toFixed(2)]), park: parkEdenler.map((a) => [a.userData.durum, +a.position.x.toFixed(1), +a.position.z.toFixed(2), +a.userData.hiz.toFixed(1)]), donen: donenler.map((d) => [+d.a.position.x.toFixed(1), +d.a.position.z.toFixed(1), +d.t.toFixed(2)]), isik: [isikEvre, +isikSure.toFixed(1)] }; })(), dis: disEngeller.size, bekleyen: arabalar.filter((a) => a.visible && a.userData.serit && a.userData.hiz < 0.3).map((a) => [SERITLER.indexOf(a.userData.serit), +a.userData.p.toFixed(1), +(a.userData.bekleme || 0).toFixed(1), +(a.userData.sollamaBekle || 0).toFixed(1), !!a.userData.olay]) };
    },
    // açılışta tüm tezgâhlar ekrana sığacak şekilde ortalanır
    tezgahlariGoster(aniden) {
      tumunuGoster = { aniden };
      if (boyut.ilk) tumunuGosterUygula();
    },
    // servis kazancı tezgâhın yığınına anında eklensin
    servisEklendi(kod, tutar) {
      const y = yerler.get(kod);
      if (y && y.aktif) y.aktif.bonus = (y.aktif.bonus || 0) + tutar;
    },
    // tanıtım: bütün tezgâh yerleri oturan satıcılarla dolar, oyuncunun tezgâhında açılış hazırlığı oynar
    introDoldur: (acik, kod) => introDoldur(acik, kod),
    introAcilis: () => introAcilisBaslat(),
    // intro için: kamerayı anında mahallenin kuş bakışına getirir
    sinemaKamera,
    sinemaSerbest,
    // film çekimi için: sahnedeki arabalar ve müzisyen yeri (kamera izlesin diye)
    filmArabalari: () => arabalar.filter((a) => a.visible),
    // film arabası: trafikten bağımsız, çekim senaryosunun sürdüğü araba (farları gece yanar)
    filmArabaHazirla(turler) {
      return turler.map((tur) => {
        const a = tur === 'taksi' ? araba('taksi') : araba(tur);
        a.visible = false;
        a.userData.film = true;
        sahne.add(a);
        geceIsiklariniTopla(a);
        if (a.userData.araba) a.userData.araba.haleler.forEach((h) => gecelik.haleler.add(h));
        return a;
      });
    },
    // çekimde kamerayı kapatan park etmiş/geçen arabalar gizlenir
    filmArabaGizle(x, z, r) { for (const a of sahne.children) if (a.userData.araba && !a.userData.film && Math.hypot(a.position.x - x, a.position.z - z) < r) a.visible = false; },
    filmArabaSur(a, x, z, yon, gorunur) {
      if (!a) return;
      a.visible = !!gorunur;
      if (!gorunur) return;
      const once = a.position.x;
      a.position.set(x, 0.02, z);
      a.rotation.y = yon > 0 ? 0 : Math.PI;
      tekerDondur(a, Math.abs(x - once) < 5 ? Math.abs(x - once) : 0);
    },
    sinemaBitir() { sinema = null; sinemaSerbest(null); },
    // yeni oyuncu rehberi: gösterilecek yerin ekrandaki kutusu (tezgâh, sipariş balonu, kese) ya da null
    // rehberin gösterdiği türden en yakın tezgâhın yeri (ekranda olmasa da)
    rehberYeri(tur) {
      let en = null, enUz = Infinity;
      for (const y of yerler.values()) {
        if (!y.durum || !y.durum.startsWith(tur)) continue;
        const uz = Math.hypot(y.grup.position.x - hedefX, y.grup.position.z - hedefZ);
        if (uz < enUz) { enUz = uz; en = y; }
      }
      return en ? { x: en.grup.position.x, z: en.grup.position.z } : null;
    },
    rehberHedefi(tur) {
      if (!aktifMi || sinema) return null;
      if (tur === 'siparis' || tur === 'kese') {
        const e = document.querySelector(`.etiket:not(.gizli) .${tur}`);
        if (!e) return null;
        const r = e.getBoundingClientRect();
        return r.width ? { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width + 22, h: r.height + 22 } : null;
      }
      let en = null, enUz = Infinity;
      for (const y of yerler.values()) {
        if (!y.durum || !y.durum.startsWith(tur)) continue;
        const uz = Math.hypot(y.grup.position.x - hedefX, y.grup.position.z - hedefZ);
        if (uz < enUz) { enUz = uz; en = y; }
      }
      if (!en) return null;
      const p = en.grup.position;
      const a = ekranKonumu(bakis.set(p.x, 0.2, p.z), kamera);
      const b = ekranKonumu(bakis.set(p.x, 2.6, p.z), kamera);
      const c = ekranKonumu(bakis.set(p.x + 2.1, 1.2, p.z), kamera);
      if (!a || !b || !c) return null;
      const h = Math.max(60, Math.abs(a.y - b.y) + 30);
      const w = Math.max(70, Math.abs(c.x - a.x) * 2 + 30);
      const x = a.x, y = (a.y + b.y) / 2;
      if (x < -w / 2 || x > window.innerWidth + w / 2 || y < -h / 2 || y > window.innerHeight + h / 2) return null;
      return { x, y, w, h, kod: en.veri ? en.veri.kod : null };
    },
    yerKonumu(kod) { const y = kod ? yerler.get(kod) : yerler.values().next().value; return y ? { x: y.grup.position.x, z: y.grup.position.z } : { x: 0, z: TEZGAH_Z }; },
    sinirlar: () => ({ XB, XD, durakX: DURAK_X }),
    // tanıtımda sokakta canlılık: bir sokak olayını hemen başlatır
    olayBaslat(tur) { return olaylar.dene(tur); },
    vakaSahnesi(tur, yerNo) { if (!kuruldu) return false; const dk = yerNo != null ? dukkanlar.get(yerNo) : null; if (dk) dukkanaOdakla(yerNo); if (dk && dk.sira !== 0) return false; return olaylar.vaka(tur, yerNo); }, // 0.55: kamera olayın olduğu dükkâna uçar; sahne (itfaiye, polis, ambulans) yalnızca ana caddede oynar
    // deneme: ana caddede duran bir görev aracı (sollama denemesi)
    _engelDene(x) { const a = araba('kombi'); const s = SERITLER[0]; Object.assign(a.userData, { serit: s, p: x, hiz: 0, azami: 6, olay: true, durHedef: x, tur: 'kombi' }); a.position.set(x, 0.02, s.sabit); sahne.add(a); arabalar.push(a); return true; },
    belediyeCalismasi(calisma, ilce) { return olaylar.belediye(calisma, ilce); }, // 0.49
    teslimat(no, gruplar, sec) { if (!dukkanlar.get(no) || dukkanlar.get(no).sira !== 0) return 0; return olaylar.teslimat(no, gruplar, sec); }, // 0.49
    // deneme: hafif sisi şimdi başlatır (sure ms)
    sisDene(sure = 90000) { const tr = simdi() + 3 * 3600000; sisOlayOnbellek = { gun: Math.floor(tr / 86400000), olaylar: [[tr, tr + sure]] }; sonSisOlcum = 0; },
    muzisyenGuncelle(v) { if (olaylar && olaylar.muzisyenGuncelle) olaylar.muzisyenGuncelle(v); },
    kusBakisiAniden() {
      aci = 0;
      hedefX = (XB + XD) / 2 + 10;
      hedefZ = -22;
      istenenMesafe = mesafe = 200;
      ucus = null;
    },
    // kuş bakışı üç kademe: sokak → mahalle (190 m) → bütün semt (komşu tezgâhlar etiketleriyle) → sokak
    kusBakisi() {
      if (mesafe > 330) ucusYap((XB + XD) / 2, ORTA_Z, Math.max(30, enYakinMesafe));
      else if (mesafe > 100) { aci = 0; ucusYap(0, -40, Math.min(EN_UZAK * 0.8, 780)); }
      else { aci = 0; ucusYap((XB + XD) / 2 + 10, -22, 190); }
    },
    xOdakla(x0) { hedefX = x0; hizX = hizZ = 0; },
    // 0.56: kamera düğmeleri: yatayda 45° döndür, dikeyde eğ, sıfırla
    kameraDondur(yon) { aciHedef = (aciHedef ?? aci) + yon * Math.PI / 4; },
    kameraEg(yon) { istenenEgimFark = Math.max(-0.6, Math.min(0.45, istenenEgimFark + yon * 0.18)); },
    kameraSifirla() { aciHedef = Math.round(aci / (Math.PI * 2)) * Math.PI * 2; istenenEgimFark = 0; },
    hata() {
      return {
        musteriler: musteriler.map((m) => [m.userData.durum, Math.round(m.position.x), Math.round(m.position.z * 10) / 10]),
        hedef: [hedefX, hedefZ, mesafe, aci], XB, XD, dukkan: dukkanlar.size,
        kalabalik: kalabalik.denetle(itisListesi),
        yoldakiler: yoldakiler.length,
      };
    },
    // kamerayı bir noktaya uçurur (deneme ve yönlendirme için)
    bak(x, z, m) { ucusYap(x, z, m || istenenMesafe); },
    basla() { aktifMi = true; },
    durdur() {
      aktifMi = false;
      parmaklar.clear();
      ses.ortamDurumu({ aktif: false });
      for (const y of yerler.values()) y.etiket.classList.add('gizli');
      for (const d of dukkanlar.values()) d.etiket.classList.add('gizli');
      for (const m of musteriler) if (m.userData.siparis) m.userData.siparis.classList.add('gizli');
      for (const s of sokakEtiketleri) s.e.classList.add('gizli');
      for (const e of etiketKutusu.children) e.classList.add('gizli');
    },
    olaylar,
  };
}
