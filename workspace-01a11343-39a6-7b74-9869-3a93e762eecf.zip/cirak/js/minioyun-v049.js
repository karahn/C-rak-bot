import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.49.0';
// Çırak – 0.48: Mini oyunlar. Saatte 1–2 kez ödüllü bir oyun teklifi gelir (mahallede zıplayan davet balonu),
// Oyun Köşesi'nde bütün oyunlar ödülsüz antrenman olarak açıktır, şans oyunları günde birer kez oynanır.
// Ödülü sunucu belirler; oyun bittiğinde puan (0–100) ya da Para Yağmuru'nda dokunulan balonlar gönderilir.
import { api, tl, esc, bildir, simdi, sureMetni } from './yardimci.js?v=0.49.0';
import * as ses from './ses.js?v=0.49.0';
import * as sahne from './sahne.js?v=0.49.0';
import { OYUNLAR } from './oyunlar.js?v=0.49.0';

let h = null; // ana.js yardımcıları: panelAc, videoEylem, videoEylemi, bakiyeUygula, durumYenile, genel
export function miniOyunKur(x) { h = x; }

// Oyun listesi (adlar ve kısa tarifler 10 dilde çevrilir)
export const KATALOG = [
  { kod: 'para', simge: '🎈', grup: 'refleks', ad: () => _autoMetin('Para Yağmuru'), nasil: () => _autoMetin('Gökten para balonları düşüyor: 5, 10, 50 ₺. Dokun, topla! Bombalara dokunma.') },
  { kod: 'misir', simge: '🍿', grup: 'refleks', ad: () => _autoMetin('Mısır Patlat'), nasil: () => _autoMetin('Tavadan fırlayan patlamış mısırları yere düşmeden yakala.') },
  { kod: 'trafik', simge: '🚦', grup: 'refleks', ad: () => _autoMetin('Trafik Lambası'), nasil: () => _autoMetin('Yeşil yanar yanmaz ekrana dokun. Erken dokunan kaybeder!') },
  { kod: 'guvercin', simge: '🕊️', grup: 'refleks', ad: () => _autoMetin('Güvercin Yemle'), nasil: () => _autoMetin('Gri güvercinlere dokunup yem at. Beyaz martılara dokunma!') },
  { kod: 'doner', simge: '🥙', grup: 'refleks', ad: () => _autoMetin('Döner Kes'), nasil: () => _autoMetin('Havaya fırlayan dönerleri parmağını kaydırarak kes. Kemiğe dokunma!') },
  { kod: 'marti', simge: '🥯', grup: 'refleks', ad: () => _autoMetin('Martıya Simit'), nasil: () => _autoMetin('Vapurdan simit at: martının geçeceği yere dokun. 8 simidin var.') },
  { kod: 'zabita', simge: '🏃', grup: 'refleks', ad: () => _autoMetin('Zabıtadan Kaç'), nasil: () => _autoMetin('Sola ya da sağa dokunarak şerit değiştir, engellere çarpmadan 15 saniye dayan.') },
  { kod: 'simit', simge: '🥯', grup: 'beceri', ad: () => _autoMetin('Simit Kulesi'), nasil: () => _autoMetin('Kayan simidi tam üstüne bırak. Taşan kısım düşer, kule yükselsin!') },
  { kod: 'cay', simge: '🍵', grup: 'beceri', ad: () => _autoMetin('Çay Ocağı'), nasil: () => _autoMetin('Siparişteki kadar çay ve şeker koy, sonra servis et. 30 saniye!') },
  { kod: 'ayran', simge: '🥛', grup: 'beceri', ad: () => _autoMetin('Ayran Köpüğü'), nasil: () => _autoMetin('Basılı tut, bardağı doldur. Köpük de kabarır: çizgide bırak!') },
  { kod: 'pide', simge: '🫓', grup: 'beceri', ad: () => _autoMetin('Pide Fırını'), nasil: () => _autoMetin('Pideler kızarınca fırından çıkar. Geç kalırsan yanar!') },
  { kod: 'tost', simge: '🥪', grup: 'beceri', ad: () => _autoMetin('Tost Ustası'), nasil: () => _autoMetin('Bir yüzü kızarınca çevir, öbür yüzü kızarınca servis et.') },
  { kod: 'terazi', simge: '⚖️', grup: 'beceri', ad: () => _autoMetin('Terazi'), nasil: () => _autoMetin('Ağırlıkları koyup istenen kiloyu tam tuttur. Fazlaysa ağırlığa dokunup geri al.') },
  { kod: 'pazarlik', simge: '🤝', grup: 'beceri', ad: () => _autoMetin('Hal Pazarlığı'), nasil: () => _autoMetin('Salınan ibreyi yeşil bölgede durdur, indirimi kap.') },
  { kod: 'dondurma', simge: '🍦', grup: 'beceri', ad: () => _autoMetin('Maraş Dondurmacısı'), nasil: () => _autoMetin('Dondurmacı külahı kaçırıyor: külah elinin üstüne gelince dokun!') },
  { kod: 'hamal', simge: '📦', grup: 'beceri', ad: () => _autoMetin('Hamal Dengesi'), nasil: () => _autoMetin('Hamal sağa yatarsa sola, sola yatarsa sağa basılı tut. 20 saniye dengede kal.') },
  { kod: 'lunapark', simge: '🎯', grup: 'beceri', ad: () => _autoMetin('Lunapark Atışı'), nasil: () => _autoMetin('Kayan balonlara dokunarak vur. 12 atış hakkın var.') },
  { kod: 'ucle', simge: '🍅', grup: 'bulmaca', ad: () => _autoMetin('Pazar Üçle'), nasil: () => _autoMetin('Yan yana iki sebzenin yerini değiştir, aynı üç sebzeyi diz.') },
  { kod: 'lokum', simge: '🍬', grup: 'bulmaca', ad: () => _autoMetin('Lokum Patlat'), nasil: () => _autoMetin('Aynı renk lokum öbeklerine dokun. Büyük öbek, büyük puan!') },
  { kod: 'hafiza', simge: '🪧', grup: 'bulmaca', ad: () => _autoMetin('Tabela Hafızası'), nasil: () => _autoMetin('Kartları çevir, aynı dükkân tabelalarını eşleştir.') },
  { kod: 'kebap', simge: '🍢', grup: 'bulmaca', ad: () => _autoMetin('Kebap Şişi'), nasil: () => _autoMetin('Usta malzemeleri sırayla şişe diziyor. Aynı sırayla sen diz!') },
  { kod: 'okey', simge: '🀄', grup: 'bulmaca', ad: () => _autoMetin('Okey Per'), nasil: () => _autoMetin('Aynı renkten sıralı ya da aynı sayıda farklı renkten en az üç taş seç, per aç.') },
  { kod: 'boru', simge: '🚰', grup: 'bulmaca', ad: () => _autoMetin('Çeşme Boruları'), nasil: () => _autoMetin('Borulara dokunup çevir, çeşmenin suyunu bostana ulaştır.') },
  { kod: 'dolmus', simge: '🚐', grup: 'bulmaca', ad: () => _autoMetin('Dolmuşu Doldur'), nasil: () => _autoMetin('Yolcu gruplarını boş koltuklara yerleştir, dolmuşu doldur.') },
  { kod: 'kayan', simge: '🧩', grup: 'bulmaca', ad: () => _autoMetin('Kayan Tabela'), nasil: () => _autoMetin('Parçaları boşluğa kaydırıp 1’den 8’e sırala.') },
  { kod: 'golge', simge: '👤', grup: 'bulmaca', ad: () => _autoMetin('Gölgeden Bil'), nasil: () => _autoMetin('Gölgesi görünen ürünü bul.') },
  { kod: 'kasa', simge: '💰', grup: 'bulmaca', ad: () => _autoMetin('Kasa Sayımı'), nasil: () => _autoMetin('Kasadaki parayı say, doğru toplamı seç.') },
  { kod: 'cark', simge: '🎡', grup: 'sans', ad: () => _autoMetin('Çarkıfelek'), nasil: () => _autoMetin('Çarkı çevir, ne çıkarsa senin! Günde bir kez.') },
  { kod: 'kese', simge: '👛', grup: 'sans', ad: () => _autoMetin('Sürpriz Kese'), nasil: () => _autoMetin('Üç keseden birini seç. Hangisi dolu? Günde bir kez.') },
  { kod: 'zar', simge: '🎲', grup: 'sans', ad: () => _autoMetin('Tavla Zarı'), nasil: () => _autoMetin('Zarları at: çift gelirse büyük ödül! Günde bir kez.') },
];
const KAT = Object.fromEntries(KATALOG.map((x) => [x.kod, x]));
const GRUPLAR = [['refleks', () => _autoMetin('⚡ Refleks')], ['beceri', () => _autoMetin('🎯 Beceri')], ['bulmaca', () => _autoMetin('🧩 Bulmaca')]];

// İstemci tarafı tohumlu rastgele (sunucuyla aynı: mulberry32)
export function rastgele(tohum) {
  let a = tohum >>> 0;
  return () => { a = (a + 0x6d2b79f5) >>> 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

// ---------- Davet balonu (mahallede) ----------
let davetZaman = 0;
export function davetGuncelle(teklif) {
  let b = document.getElementById('oyun-davet');
  const goster = teklif && teklif.durum === 'acik' && teklif.bitis > simdi() && !document.querySelector('.mo-katman');
  if (!goster) { if (b) b.remove(); clearInterval(davetZaman); return; }
  const k = KAT[teklif.kod];
  if (!k) return;
  if (!b) {
    b = document.createElement('button');
    b.id = 'oyun-davet';
    b.className = 'oyun-davet';
    (document.getElementById('arayuz') || document.body).appendChild(b);
    b.addEventListener('click', () => { ses.tik(); const t = b._teklif; if (t) oyunAc({ kod: t.kod, teklif: t }); });
  }
  b._teklif = teklif;
  b.setAttribute('aria-label', _autoMetin('Ödüllü oyun'));
  const ciz = () => {
    const kalan = teklif.bitis - simdi();
    if (kalan <= 0) { b.remove(); clearInterval(davetZaman); return; }
    b.innerHTML = `<span class="od-simge">${k.simge}</span><span class="od-yazi"><b>${esc(_autoMetin('Ödüllü oyun!'))}</b><small>${esc(k.ad())} · ${sureMetni(kalan)}</small></span>`;
  };
  ciz();
  clearInterval(davetZaman);
  davetZaman = setInterval(ciz, 1000);
}

// ---------- Oyun Köşesi ----------
// 0.49: sekmeler: oyunlar, haftalık sıralama, başarımlar
let koseSekme = 'oyunlar', siraKod = 'genel';
export async function oyunKosesi(sekme = null) {
  if (sekme) koseSekme = sekme;
  const p = h.panelAc({ ikon: '🎮', baslik: _autoMetin('Oyun Köşesi'), rota: 'oyunlar', alt: _autoMetin('Mini oyunlar: saatte bir iki ödüllü teklif, günde üç şans oyunu'), govde: `<p class="soluk">${_autoHtml('Yükleniyor…')}</p>` });
  let d;
  try { d = await api('mini-oyun'); } catch (e) { bildir(e.message, true); return; }
  if (!p.isConnected) return;
  const kutu = p.querySelector('.panel-govde');
  const yeniBasarim = d.basarim ? d.basarim.liste.filter((b) => b.alindi).length : 0;
  const SEK = [['oyunlar', '🎮', _autoMetin('Oyunlar')], ['hafta', '🏆', _autoMetin('Haftalık')], ['basarim', '🎖️', _autoMetin('Başarımlar') + (d.basarim ? ` ${yeniBasarim}/${d.basarim.liste.length}` : '')]];
  kutu.innerHTML = `<div class="sekmeler mo-sekmeler" role="tablist">${SEK.map(([k, i, a]) => `<button role="tab" data-mo-sekme="${k}" aria-selected="${koseSekme === k}">${i} ${esc(a)}</button>`).join('')}</div><div data-mo-icerik></div>`;
  kutu.querySelectorAll('[data-mo-sekme]').forEach((b) => b.addEventListener('click', () => { ses.tik(); koseSekme = b.dataset.moSekme; kutu.querySelectorAll('[data-mo-sekme]').forEach((x) => x.setAttribute('aria-selected', String(x === b))); ciz(); }));
  const icerik = kutu.querySelector('[data-mo-icerik]');
  const ciz = () => {
    if (koseSekme === 'hafta') return haftaCiz(icerik, d);
    if (koseSekme === 'basarim') return basarimCiz(icerik, d);
    return oyunlarCiz(icerik, d);
  };
  ciz();
}

function oyunlarCiz(kutu, d) {
  const t = d.teklif && d.teklif.durum === 'acik' && d.teklif.bitis > simdi() ? d.teklif : null;
  const tas = (k, ek = '', sinif = '') => `<button class="mo-tas ${sinif}" data-mo="${k.kod}"><span class="mo-tas-simge">${k.simge}</span><b>${esc(k.ad())}</b>${ek}</button>`;
  const hb = d.hafta && d.hafta.benim;
  kutu.innerHTML = `
    ${t ? `<div class="kart mo-teklif"><span class="mo-tas-simge buyuk">${KAT[t.kod].simge}</span><div style="flex:1;min-width:0"><b>${esc(_autoMetin('Ödüllü oyun hazır!'))}</b>
      <div class="kucuk">${esc(KAT[t.kod].ad())} · ⏳ <span data-mo-kalan>${sureMetni(t.bitis - simdi())}</span></div></div><button class="dugme yesil kucuk" data-mo-teklif>▶ ${_autoHtml('Oyna')}</button></div>`
      : `<div class="kart"><p class="kucuk" style="margin:0">🎈 ${_autoHtml('Oyundayken saatte bir iki kez ödüllü bir oyun teklifi gelir: mahallede zıplayan balona dokun. Aşağıdaki oyunlarla istediğin zaman antrenman yapabilirsin.')}</p></div>`}
    <button class="kart mo-hafta-ozet" data-mo-git="hafta"><span class="mo-tas-simge">🏆</span><span style="flex:1;min-width:0"><b>${esc(_autoMetin('Haftalık sıralama'))}</b>
      <small>${hb ? esc(_autoSablon`${hb.sira}. sıradasın · ${hb.puan} puan`) : esc(_autoMetin('Antrenmandaki puanların da sayılır. İlk 10\'a ödül!'))}</small></span><span class="mo-ok">›</span></button>
    <h3 class="bolum-baslik">${_autoHtml('🍀 Günün şans oyunları')}</h3>
    <div class="mo-izgara">${KATALOG.filter((k) => k.grup === 'sans').map((k) => tas(k, `<small>${d.sans[k.kod] ? esc(_autoMetin('Bugün oyna!')) : esc(_autoMetin('Yarın yine gel'))}</small>`, d.sans[k.kod] ? 'hazir' : 'kapali')).join('')}</div>
    ${GRUPLAR.map(([g, ad]) => `<h3 class="bolum-baslik">${esc(ad())} <small class="soluk">· ${esc(_autoMetin('antrenman'))}</small></h3>
      <div class="mo-izgara">${KATALOG.filter((k) => k.grup === g).map((k) => tas(k, t && t.kod === k.kod ? `<small class="mo-odullu">${esc(_autoMetin('Ödüllü!'))}</small>` : '')).join('')}</div>`).join('')}`;
  const tb = kutu.querySelector('[data-mo-teklif]');
  if (tb) tb.addEventListener('click', () => { ses.tik(); oyunAc({ kod: t.kod, teklif: t }); });
  kutu.querySelector('[data-mo-git]').addEventListener('click', () => { ses.tik(); const b = document.querySelector('[data-mo-sekme="hafta"]'); if (b) b.click(); });
  kutu.querySelectorAll('[data-mo]').forEach((b) => b.addEventListener('click', () => {
    const k = KAT[b.dataset.mo];
    ses.tik();
    if (k.grup === 'sans') { if (!d.sans[k.kod]) return bildir(_autoMetin('Bu şans oyununu bugün oynadın. Yarın yine gel!'), true); return oyunAc({ kod: k.kod, sans: true }); }
    if (t && t.kod === k.kod) return oyunAc({ kod: k.kod, teklif: t });
    oyunAc({ kod: k.kod, antrenman: true });
  }));
  const kl = kutu.querySelector('[data-mo-kalan]');
  if (kl) h.zamanlayici(() => { if (!kl.isConnected) return; const x = t.bitis - simdi(); if (x <= 0) { oyunKosesi(); return; } kl.textContent = sureMetni(x); }, 1000);
}

function siraMadalya(n) { return n === 1 ? '🥇' : n === 2 ? '🥈' : n === 3 ? '🥉' : `<span class="mo-sira-no">${n}</span>`; }
async function haftaCiz(kutu, d) {
  const secenek = [['genel', '🏆 ' + _autoMetin('Genel')], ...KATALOG.filter((k) => k.grup !== 'sans').map((k) => [k.kod, `${k.simge} ${k.ad()}`])];
  kutu.innerHTML = `<div class="kart mo-hafta-bas"><label class="kucuk soluk" for="mo-sira-sec">${esc(_autoMetin('Sıralama'))}</label>
    <select id="mo-sira-sec" class="mo-sira-sec">${secenek.map(([k, a]) => `<option value="${k}" ${k === siraKod ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></div>
    <div data-mo-sira><p class="soluk">${_autoHtml('Yükleniyor…')}</p></div>`;
  const yer = kutu.querySelector('[data-mo-sira]');
  const yukle = async () => {
    let r;
    try { r = siraKod === 'genel' && d.hafta ? d.hafta : await api('mini-oyun/sira?kod=' + encodeURIComponent(siraKod)); } catch (e) { yer.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; return; }
    if (!yer.isConnected) return;
    const genel = r.kod === 'genel';
    const kalan = Math.max(0, r.bitis - simdi());
    yer.innerHTML = `
      <div class="kart mo-hafta-ben">
        <div class="mo-hafta-ben-sol">${r.benim ? siraMadalya(r.benim.sira) : '🎯'}</div>
        <div style="flex:1;min-width:0"><b>${r.benim ? esc(_autoSablon`Bu hafta ${r.benim.sira}. sıradasın`) : esc(_autoMetin('Bu hafta henüz puanın yok'))}</b>
          <div class="kucuk soluk">${r.benim ? esc(genel ? _autoSablon`${r.benim.puan} puan · ${r.benim.oyun} oyun` : _autoSablon`En iyi puanın: ${r.benim.puan}`) : esc(_autoMetin('Bir oyun oyna, sıralamaya gir.'))}</div></div>
        <div class="mo-hafta-sure kucuk">⏳ ${esc(sureMetni(kalan))}</div>
      </div>
      ${genel ? `<p class="kucuk soluk">${esc(_autoMetin('Genel puan: her oyundaki bu haftaki en iyi puanının toplamı. Ödüllü oyunlar da antrenmanlar da sayılır.'))}</p>
        <div class="mo-odul-serit">${r.odul.slice(0, 3).map((o, i) => `<span>${['🥇', '🥈', '🥉'][i]} ${tl(o)}</span>`).join('')}<span>4–10: ${tl(r.odul[9])}+</span></div>` : ''}
      ${r.liste.length ? `<ol class="mo-sira-liste">${r.liste.map((x) => `<li class="${x.ben ? 'ben' : ''}"><span class="mo-sira-m">${siraMadalya(x.sira)}</span><span class="mo-sira-ad">${esc(x.kullaniciAdi)}</span>
        <b class="mo-sira-p">${x.puan}${genel ? `<small> / ${r.enCok}</small>` : ''}</b></li>`).join('')}</ol>` : `<p class="soluk">${esc(_autoMetin('Bu hafta henüz kimse oynamadı. İlk sen ol!'))}</p>`}`;
  };
  kutu.querySelector('#mo-sira-sec').addEventListener('change', (e) => { siraKod = e.target.value; yukle(); });
  yukle();
}

function basarimCiz(kutu, d) {
  const b = d.basarim;
  if (!b) { kutu.innerHTML = ''; return; }
  const i = b.ist;
  kutu.innerHTML = `<div class="mo-ist">
      <div><b>${i.oynanan}</b><small>${esc(_autoMetin('oyun'))}</small></div>
      <div><b>${i.mukemmel}</b><small>${esc(_autoMetin('100 puan'))}</small></div>
      <div><b>${i.cesit}/${KATALOG.filter((k) => k.grup !== 'sans').length}</b><small>${esc(_autoMetin('farklı oyun'))}</small></div>
      <div><b>${i.seri}</b><small>${esc(_autoMetin('gün seri'))}</small></div></div>
    <div class="mo-basarimlar">${b.liste.map((x) => `<div class="mo-basarim ${x.alindi ? 'alindi' : ''}">
      <span class="mo-basarim-simge">${x.simge}</span>
      <div class="mo-basarim-yazi"><b>${esc(_autoMetin(x.ad))}</b><small>${esc(_autoMetin(x.aciklama))}</small>
        ${x.alindi ? `<span class="mo-basarim-tamam">✓ ${esc(_autoMetin('Kazanıldı'))}</span>` : `<span class="mo-basarim-cubuk"><i style="width:${Math.round((100 * x.n) / x.hedef)}%"></i></span><span class="mo-basarim-n">${x.n}/${x.hedef}</span>`}</div>
      <span class="mo-basarim-odul">${tl(x.odul)}</span></div>`).join('')}</div>`;
}

// ---------- Oyun penceresi ----------
let acik = null;
export function oyunAcikMi() { return !!acik; }
export function oyunAc({ kod, teklif = null, sans = false, antrenman = false }) {
  const k = KAT[kod], O = OYUNLAR[kod];
  if (!k || !O || acik) return;
  const kat = document.createElement('div');
  kat.className = 'mo-katman';
  kat.innerHTML = `<div class="mo-pencere" role="dialog" aria-modal="true" aria-label="${esc(k.ad())}">
      <div class="mo-ust"><span class="mo-baslik">${k.simge} <b>${esc(k.ad())}</b></span><span class="mo-puan" data-mo-puan></span><button class="mo-kapat" data-mo-kapat aria-label="${esc(_autoMetin('Kapat'))}">✕</button></div>
      <div class="mo-sure"><i data-mo-sure></i></div>
      <div class="mo-alan" data-mo-alan></div>
    </div>`;
  document.body.appendChild(kat);
  const davet = document.getElementById('oyun-davet');
  if (davet) davet.hidden = true;
  sahne.ortuluZorla && sahne.ortuluZorla(true); // oyun ekranı tam ekran: arkadaki 3B sahne seyrek çizilir
  const alan = kat.querySelector('[data-mo-alan]');
  const puanYeri = kat.querySelector('[data-mo-puan]');
  const sureCubuk = kat.querySelector('[data-mo-sure]');
  const s = { kat, alan, oturum: null, bitti: false, oynuyor: false, temizle: [], kod, teklif, sans, antrenman };
  acik = s;
  const kapat = () => {
    durdur();
    kat.remove();
    acik = null;
    sahne.ortuluZorla && sahne.ortuluZorla(false);
    if (davet && davet.isConnected) davet.hidden = false;
    if (h.genel && h.genel()) davetGuncelle(h.genel().miniOyun);
  };
  const durdur = () => { for (const f of s.temizle.splice(0)) { try { f(); } catch (e) { /* yok say */ } } };
  kat.querySelector('[data-mo-kapat]').addEventListener('click', async () => {
    if (s.oynuyor && !s.antrenman && !(await (h.onayla ? h.onayla(_autoMetin('Oyundan çıkılsın mı? Bu teklifin ödülünü alamazsın.'), { evet: _autoMetin('Çık'), tehlike: true, ikon: '🎮' }) : true))) return;
    kapat();
  });

  // giriş ekranı
  const odulYazisi = antrenman ? _autoMetin('Antrenman: ödül yok, istediğin kadar oyna.') : sans ? _autoMetin('Şans oyunu: günde bir kez, ödül kesin!') : kod === 'para' ? _autoMetin('Ödül: dokunduğun balonların toplamı (seviyene göre artar).') : _autoMetin('Ödül: puanına göre para. Ne kadar iyi, o kadar çok!');
  const giris = () => {
    durdur();
    puanYeri.textContent = '';
    sureCubuk.style.width = '0';
    alan.innerHTML = `<div class="mo-giris"><div class="mo-giris-simge">${k.simge}</div><h2>${esc(k.ad())}</h2><p>${esc(k.nasil())}</p>
      <p class="kucuk mo-odul-not">${esc(odulYazisi)}</p><button class="dugme yesil buyuk" data-mo-basla>▶ ${_autoHtml('Başla')}</button></div>`;
    alan.querySelector('[data-mo-basla]').addEventListener('click', (e) => baslat(e.currentTarget));
  };

  const baslat = async (b) => {
    if (b) b.disabled = true;
    ses.tik();
    let tohum = Math.floor(Math.random() * 2 ** 31), veri = null;
    s.oturum = null;
    if (!antrenman) {
      try {
        const r = await api('mini-oyun/basla', sans ? { kod } : { id: teklif.id });
        s.oturum = r; tohum = r.tohum; veri = r.veri;
      } catch (e) { bildir(e.message, true); kapat(); return; }
    } else {
      // 0.49: antrenman da sunucuda kaydedilir (haftalık sıralama, başarımlar); bağlantı yoksa çevrimdışı oynanır
      try { const r = await api('mini-oyun/basla', { kod, antrenman: true }); s.oturum = r; tohum = r.tohum; veri = r.veri; } catch (e) { if (b) bildir(e.message, true); }
    }
    alan.innerHTML = '';
    s.bitti = false; s.oynuyor = true;
    const o = oyunArabirimi(s, { tohum, veri, puanYeri, sureCubuk, sonuc });
    // güvenlik: hiçbir oyun 3 dakikadan uzun sürmez (oyuncu ekranı bırakırsa)
    const guvenlik = setTimeout(() => { if (!s.bitti && kat.isConnected) o.bitir(0); }, 180000);
    s.temizle.push(() => clearTimeout(guvenlik));
    try {
      const temiz = O.baslat(alan, o);
      if (typeof temiz === 'function') s.temizle.push(temiz);
    } catch (e) { console.error('[mini oyun]', kod, e); o.bitir(0); }
  };

  // sonuç ekranı
  async function sonuc(puan, ek = {}) {
    s.oynuyor = false;
    let r = null;
    if (s.oturum) {
      try {
        r = await api('mini-oyun/bitir', { id: s.oturum.id, jeton: s.oturum.jeton, puan, tik: ek.tik, secim: ek.secim });
      } catch (e) { bildir(e.message, true); }
      if (r && typeof r.bakiye === 'number' && h.bakiyeUygula) h.bakiyeUygula(r.bakiye);
      if (!antrenman && ek.goster && r) { try { ek.goster(r); } catch (e) { /* yok say */ } }
      if (ek.gecikme) await new Promise((ok) => setTimeout(ok, antrenman ? Math.min(800, ek.gecikme) : ek.gecikme));
    } else if (ek.gecikme) await new Promise((ok) => setTimeout(ok, Math.min(800, ek.gecikme)));
    if (!kat.isConnected) return;
    durdur();
    const p = r ? r.puan : Math.round(puan);
    const odul = r && !antrenman ? r.odul : 0;
    if (odul > 0 || (r && r.basarimlar && r.basarimlar.length)) ses.odul(); else ses.tik();
    const video = !antrenman && r && r.ikinciSans && h.videoEylemi && h.videoEylemi('oyun');
    const yildiz = p >= 90 ? '🌟🌟🌟' : p >= 60 ? '🌟🌟' : p >= 25 ? '🌟' : '';
    alan.innerHTML = `<div class="mo-giris mo-sonuc"><div class="mo-giris-simge">${odul > 0 ? '🎉' : k.simge}</div>
      <h2>${antrenman ? esc(_autoMetin('Antrenman bitti')) : odul > 0 ? esc(_autoSablon`+${tl(odul)} kazandın!`) : r && r.toplamOdul > 0 ? esc(_autoMetin('Önceki ödülün korundu.')) : esc(_autoMetin('Bu sefer olmadı'))}</h2>
      <div class="mo-yildiz">${yildiz}</div>
      <p>${esc(_autoSablon`Puan: ${p}/100`)}${r && r.toplam !== undefined ? ' · ' + esc(_autoSablon`Toplanan: ${r.toplam} ₺`) : ''}</p>
      ${r && r.rekor && r.rekor.yeni ? `<p class="mo-rekor">🏆 ${esc(r.rekor.onceki == null ? _autoMetin('Haftalık sıralamaya girdin!') : _autoSablon`Haftalık rekor! (önceki: ${r.rekor.onceki})`)}</p>` : r && r.rekor ? `<p class="kucuk soluk">${esc(_autoSablon`Bu haftaki en iyin: ${r.rekor.puan}`)}</p>` : ''}
      ${r && r.basarimlar && r.basarimlar.length ? `<div class="mo-yeni-basarim">${r.basarimlar.map((x) => `<div>${x.simge} <b>${esc(_autoMetin(x.ad))}</b> <span>+${tl(x.odul)}</span></div>`).join('')}<small>${esc(_autoMetin('Yeni başarım!'))}</small></div>` : ''}
      ${video ? `<button class="dugme mavi" data-video-oyun>${esc(_autoMetin('📺 Video izle: bir kez daha oyna'))}</button><p class="kucuk soluk">${esc(_autoMetin('İkinci denemede öncekinden fazlasını kazanırsan fark eklenir.'))}</p>` : ''}
      ${antrenman ? `<button class="dugme mavi" data-mo-tekrar>🔁 ${_autoHtml('Tekrar oyna')}</button>` : ''}
      <button class="dugme yesil" data-mo-tamam>${_autoHtml('Tamam')}</button></div>`;
    alan.querySelector('[data-mo-tamam]').addEventListener('click', () => { ses.tik(); kapat(); if (h.durumYenile) h.durumYenile().catch(() => {}); });
    const tk = alan.querySelector('[data-mo-tekrar]');
    if (tk) tk.addEventListener('click', () => giris());
    const vb = alan.querySelector('[data-video-oyun]');
    if (vb) vb.addEventListener('click', async () => {
      const v = await h.videoEylem('oyun', s.oturum.id, vb);
      if (v && v.tamam) { s.teklif = teklif = { ...teklif, id: s.oturum.id }; baslat(null); }
    });
  }

  giris();
  return s;
}

// Oyunlara verilen arabirim
function oyunArabirimi(s, { tohum, veri, puanYeri, sureCubuk, sonuc }) {
  const o = {
    r: rastgele(tohum), tohum, veri, ses,
    bitti: () => s.bitti,
    // oyun biter: puan 0–100; ek: { tik, secim, goster(r), gecikme }
    bitir(puan, ek) {
      if (s.bitti) return;
      s.bitti = true;
      sonuc(Math.max(0, Math.min(100, Math.round(puan || 0))), ek || {});
    },
    puan(metin) { puanYeri.textContent = metin; },
    // geri sayım: süre bitince fn çağrılır; kalan() ms döner
    sure(ms, fn) {
      const bas = performance.now();
      let son = false;
      const id = setInterval(() => {
        if (s.bitti) { clearInterval(id); return; }
        const x = Math.max(0, ms - (performance.now() - bas));
        sureCubuk.style.width = `${(100 * x) / ms}%`;
        sureCubuk.classList.toggle('az', x < ms * 0.2);
        if (x <= 0 && !son) { son = true; clearInterval(id); fn && fn(); }
      }, 100);
      s.temizle.push(() => clearInterval(id));
      return { kalan: () => Math.max(0, ms - (performance.now() - bas)), gecen: () => performance.now() - bas };
    },
    // tuval: alanı kaplar, piksel yoğunluğuna göre keskin
    tuval() {
      const el = document.createElement('canvas');
      el.className = 'mo-tuval';
      s.alan.appendChild(el);
      const w = s.alan.clientWidth, hh = s.alan.clientHeight;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      el.width = Math.round(w * dpr); el.height = Math.round(hh * dpr);
      el.style.width = w + 'px'; el.style.height = hh + 'px';
      const c = el.getContext('2d');
      c.scale(dpr, dpr);
      c.textAlign = 'center'; c.textBaseline = 'middle';
      return { el, c, w, h: hh };
    },
    // kare döngüsü: fn(dt sn, t sn); oyun bitince durur
    dongu(fn) {
      let son = performance.now(), id = 0;
      const adim = (t) => {
        if (s.bitti || !s.kat.isConnected) return;
        const dt = Math.min(0.05, (t - son) / 1000);
        son = t;
        try { fn(dt, t / 1000); } catch (e) { console.error('[mini oyun]', e); o.bitir(0); return; }
        id = requestAnimationFrame(adim);
      };
      id = requestAnimationFrame(adim);
      s.temizle.push(() => cancelAnimationFrame(id));
    },
    // dokunma: fn(x, y, olay) alan içi koordinatla
    dokun(el, fn, olay = 'pointerdown') {
      const f = (e) => { if (s.bitti) return; const r = el.getBoundingClientRect(); fn(e.clientX - r.left, e.clientY - r.top, e); };
      el.addEventListener(olay, f);
      s.temizle.push(() => el.removeEventListener(olay, f));
    },
    zamanla(fn, ms) { const id = setTimeout(() => { if (!s.bitti) fn(); }, ms); s.temizle.push(() => clearTimeout(id)); return id; },
    t: _autoMetin,
  };
  return o;
}
