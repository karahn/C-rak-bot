const ANA_BOLUMLER = ['Ana Geliştirici Stüdyo Ekibi', 'Oyuncular ve Performans', 'Kalite Kontrol ve Test', 'Yerelleştirme ve Çeviri', 'Üçüncü Parti ve Dış Kaynaklar', 'Kullanılan Teknolojiler ve Lisanslar', 'Özel Teşekkür ve Kapanış'];
const DEPARTMANLAR = [
  ['Yönetim', 0, ['Oyun Yönetmeni', 'Kreatif Direktör', 'Baş Yapımcı']],
  ['Tasarım', 0, ['Bölüm Tasarımcısı', 'Sistem ve Ekonomi Tasarımcısı', 'Hikâye ve Yazım']],
  ['Programlama ve Yazılım', 0, ['Baş Programcı', 'Oynanış Programcısı', 'Yapay Zekâ Programcısı', 'Ağ ve Online Mühendisi']],
  ['Sanat ve Animasyon', 0, ['Konsept Sanatçısı', '3D Karakter Sanatçısı', '3D Çevre Sanatçısı', 'UI/UX Tasarımcısı', 'Animatör']],
  ['Ses ve Müzik', 0, ['Besteci', 'Ses Tasarımcısı']],
  ['Seslendirme Sanatçıları', 1, ['Seslendirme Sanatçısı']], ['Hareket ve Performans Yakalama', 1, ['Performans Sanatçısı', 'Dublör']],
  ['Kalite Kontrol ve Test', 2, ['Test Lideri', 'QA Test Uzmanı', 'Alfa/Beta Topluluk Testçisi']],
  ['Yerelleştirme ve Çeviri', 3, ['Çevirmen', 'Yerelleştirme Testçisi (LQA)']],
  ['Dış Sanat Stüdyoları', 4, ['Dış Sanat Stüdyosu', 'Bağımsız Sanatçı']], ['Hazır Varlıklar ve Paketler', 4, ['Paket Yapımcısı']],
  ['Motor ve Açık Kaynak Kütüphaneler', 5, ['Motor', 'Kütüphane']], ['Yazı Tipleri ve Harita Verileri', 5, ['Yazı Tipi', 'Harita Verisi']], ['Lisanslı Müzikler ve Efektler', 5, ['Sanatçı', 'Lisans Sağlayıcısı']],
  ['Destekçiler', 6, ['Destekçi', 'Yatırımcı']], ['Aileler ve Arkadaşlar', 6, []], ['Topluluk', 6, []],
];
const BOLUMLER = DEPARTMANLAR.map(x => x[0]);
const ESKI = { 'Yapımcı': 'Yönetim', 'Oyun Tasarımı': 'Tasarım', 'Grafik ve Görsel Tasarım': 'Sanat ve Animasyon', 'Kodlama': 'Programlama ve Yazılım', 'Test ve Kalite': 'Kalite Kontrol ve Test', 'Topluluk Katkıları': 'Topluluk' };

export function jenerikDuzenle(veri) {
  // Güncel sunucu başlık sırasını belirler; istemci hazır şablonu yeniden dayatmaz.
  if (veri?.surum >= 3 && Array.isArray(veri.bolumler) && Array.isArray(veri.anaBolumler)) {
    return { ...veri, manuel: Array.isArray(veri.manuel) ? veri.manuel : [], eskiSurum: false };
  }
  const kaynak = Array.isArray(veri) ? veri : Array.isArray(veri?.bolumler) ? veri.bolumler : [];
  const map = new Map(DEPARTMANLAR.map(([ad, grup, gorevler]) => [ad, { ad, anaBolum: ANA_BOLUMLER[grup], gorevler, kayitlar: [] }]));
  for (const b of kaynak) {
    if (!b || typeof b.ad !== 'string') continue;
    const ad = ESKI[b.ad] || b.ad;
    if (!map.has(ad)) map.set(ad, { ad, anaBolum: ANA_BOLUMLER.includes(b.anaBolum) ? b.anaBolum : ANA_BOLUMLER[0], gorevler: [], kayitlar: [] });
    const dst = map.get(ad);
    const rows = Array.isArray(b.kayitlar) ? b.kayitlar : (Array.isArray(b.kisiler) ? b.kisiler.map(adSoyad => ({adSoyad})) : []);
    dst.kayitlar.push(...rows.filter(x => x && typeof x.adSoyad === 'string').map(x => ({ ...x, gorev: x.gorev || '', lider: !!Number(x.lider), aciklama: x.aciklama || '', baglanti: x.baglanti || '' })));
  }
  const bolumler = [...map.values()].map(b => {
    const seen = new Set();
    b.kayitlar = b.kayitlar.filter(x => { const k = [x.adSoyad.trim().toLocaleLowerCase('tr'), x.gorev, x.aciklama, x.baglanti].join('\0'); if (seen.has(k)) return false; seen.add(k); return true; }).sort((a,b) => Number(b.lider)-Number(a.lider));
    b.kisiler = [...new Set(b.kayitlar.map(x => x.adSoyad))];
    return b;
  }).sort((a,b) => ANA_BOLUMLER.indexOf(a.anaBolum)-ANA_BOLUMLER.indexOf(b.anaBolum));
  const manuel = (Array.isArray(veri?.manuel) ? veri.manuel : []).map(x => ({ ...x, bolum: ESKI[x.bolum] || x.bolum }));
  return { bolumler, manuel, anaBolumler: ANA_BOLUMLER, eskiSurum: !Array.isArray(veri?.anaBolumler) };
}
