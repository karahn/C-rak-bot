import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.38.0';
// Oyunun kendi 3B motoruyla çekilmiş özgün intro filmi; sahne ve ses tek dosyada sabit kalitede.
import * as sahne from './sahne.js?v=0.38.0';
import * as ses from './ses.js?v=0.38.0';

const bekle = (ms) => new Promise((r) => setTimeout(r, ms));
const TONLAR = ['#FF3FA4', '#19D3E6', '#FFB23F', '#9A4DFF', '#FF6B5A'];
// H.264 (mp4) her yerde donanımla çözülür; desteklemeyen tarayıcıda VP9 (webm)
const VIDEO = (() => {
  let mp4 = true;
  try { mp4 = !!document.createElement('video').canPlayType('video/mp4; codecs="avc1.640028, mp4a.40.2"'); } catch (e) { /* yok say */ }
  return new URL(`../video/intro.${mp4 ? 'mp4' : 'webm'}?v=0.32.0`, import.meta.url).href;
})();

// Video tarayıcının kendi akış oynatıcısıyla yüklenir. Tam dosyayı Blob'a
// çevirip belleğe almamak mobilde başlangıç gecikmesini ve bellek yükünü azaltır.
let hazirVideo = null;
export function introOnYukle() {
  if (!hazirVideo) {
    hazirVideo = document.createElement('video');
    hazirVideo.className = 'gx-video';
    hazirVideo.playsInline = true;
    hazirVideo.muted = true;
    hazirVideo.preload = 'auto';
    hazirVideo.disablePictureInPicture = true;
    hazirVideo.src = VIDEO;
    hazirVideo.load();
  }
  return Promise.resolve(VIDEO);
}

export async function introOynat({ mahalle, oyuncu, isimler, isimleriGetir }) {
  let gecildi = false;
  const ekran = document.createElement('div');
  ekran.id = 'sinema';
  ekran.className = 'gx film hazirlaniyor';
  ekran.innerHTML = `
    <div class="gx-kadraj">
      <div class="gx-film"></div>
      <div class="gx-donuk"><div class="gx-donuk-ton"></div></div>
      <div class="gx-yer"><b></b><span></span></div>
      <div class="gx-kart"><small class="gx-ust"></small><div class="gx-baslik"></div><div class="gx-alt"></div></div>
      <div class="gx-kelime"></div>
      <div class="gx-logo">
        <div class="gx-gunes"></div>
        <small class="gx-logo-ust">${_autoHtml("Tezgâhtan holdinge")}</small>
        <div class="gx-logo-yazi">${_autoHtml("ÇIRAK")}</div>
        <div class="gx-logo-alt">${_autoHtml("Çıraklıktan Patronluğa")}</div>
      </div>
      <div class="gx-flas"></div>
      <div class="gx-bolum" aria-hidden="true">${_autoHtml("01 / ÇIRAK")}</div>
    </div>
    <div class="sinema-bant ust"></div><div class="sinema-bant alt"></div>
    <div class="gx-hazirlik"><small>${_autoHtml("Tanıtım yükleniyor")}</small></div>
    <div class="gx-akis" aria-hidden="true"><i></i></div>
    <button class="sinema-gec">${_autoHtml("Geç ›")}</button>`;
  document.body.appendChild(ekran);
  document.body.classList.add('sinemada');
  const $ = (s) => ekran.querySelector(s);
  introOnYukle();
  const video = hazirVideo;
  $('.gx-film').appendChild(video);
  video.muted = true;
  if (video.readyState >= 1) video.currentTime = 0;
  const bolum = $('.gx-bolum');
  const akis = $('.gx-akis i');
  const kart = $('.gx-kart');
  const flas = $('.gx-flas');
  const kelime = $('.gx-kelime');
  const yerYazisi = $('.gx-yer');
  let bitir = null;
  let oynatmaIptal = false;
  let kartBitis = 0;
  let gecSozu = null;
  const gecildiSozu = new Promise((r) => { gecSozu = r; });
  $('.sinema-gec').addEventListener('click', () => { gecildi = true; gecSozu(null); if (bitir) bitir(); });
  let tamponZamani = null;
  const tampon = () => {
    if (!video.currentTime) return;
    ekran.classList.add('tampon');
    clearTimeout(tamponZamani);
    tamponZamani = setTimeout(() => { oynatmaIptal = true; if (bitir) bitir(); else gecSozu(null); }, 10000);
  };
  const devam = () => { clearTimeout(tamponZamani); ekran.classList.remove('tampon'); };
  const oynatmaHatasi = () => { oynatmaIptal = true; if (bitir) bitir(); else gecSozu(null); };
  video.addEventListener('waiting', tampon);
  video.addEventListener('stalled', tampon);
  video.addEventListener('playing', devam);
  video.addEventListener('error', oynatmaHatasi);
  requestAnimationFrame(() => ekran.classList.add('acik'));

  // 3B sahne tanıtım boyunca durur: ekran kartı yalnızca filmi oynatır
  try { sahne.elleMod(true); } catch (e) { /* yok say */ }
  let oynadi = false;
  try {
    // Yerel fontlar isteğe bağlıdır; film açılışını ağ veya font indirme bekletmez.
    if (document.fonts) Promise.allSettled(['400 40px Anton', '800 20px Montserrat', '400 30px "Kaushan Script"'].map((f) => document.fonts.load(f))).catch(() => {});
    if (isimleriGetir && (!isimler || isimler.kaynak !== 'osm')) isimleriGetir().then((x) => { if (x) isimler = x; }).catch(() => {});
    if (gecildi || oynatmaIptal) throw new Error(_autoMetin('atlandı'));
    await Promise.race([
      new Promise((ok, hata) => {
        if (video.error) return hata(new Error(_autoMetin('film açılamadı')));
        if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) return ok();
        video.addEventListener('loadeddata', ok, { once: true });
        video.addEventListener('error', () => hata(new Error(_autoMetin('film açılamadı'))), { once: true });
      }),
      bekle(12000).then(() => { throw new Error(_autoMetin('film yüklenemedi')); }),
      gecildiSozu,
    ]);
    if (gecildi || oynatmaIptal) throw new Error(_autoMetin('atlandı'));
    // Önce sessiz oynat: telefonlarda otomatik başlatma engeline takılmaz.
    await Promise.race([video.play(), gecildiSozu, bekle(5000).then(() => { throw new Error(_autoMetin('film başlatılamadı')); })]);
    if (gecildi || oynatmaIptal) throw new Error(_autoMetin('atlandı'));
    let duzey = 0;
    try { duzey = ses.introVideo(true); } catch (e) { /* video sessiz çalar */ }
    if (duzey > 0) {
      video.volume = duzey;
      video.muted = false;
    }
    oynadi = true;
    ekran.classList.remove('hazirlaniyor');
    await filmZamanlamasi();
  } catch (e) {
    if (!oynadi && !gecildi) console.warn('[tanıtım]', e.message);
  } finally {
    clearTimeout(tamponZamani);
    try { ses.introVideo(false); } catch (e) { /* yok say */ }
    ekran.classList.remove('acik');
    ekran.classList.add('kapaniyor');
    try { video.pause(); } catch (e) { /* yok say */ }
    video.removeEventListener('waiting', tampon);
    video.removeEventListener('stalled', tampon);
    video.removeEventListener('playing', devam);
    video.removeEventListener('error', oynatmaHatasi);
    await bekle(250);
    ekran.remove();
    document.body.classList.remove('sinemada');
    hazirVideo = null;
    try { sahne.elleMod(false); } catch (e) { /* yok say */ }
    try { mahalle?.sinemaBitir?.(); mahalle?.tezgahlariGoster?.(true); } catch (e) { /* oyun sürer */ }
  }

  // ---- Filmin üstündeki yazılar: filmin zamanına (video.currentTime) bağlıdır, film nerede ise yazı oradadır
  function filmZamanlamasi() {
    const O = (60 / 104) * 4;
    const B = O / 4;
    const mahalleAdi = () => ((isimler && isimler.mahalle) || (oyuncu.mahalle && oyuncu.mahalle.ad) || 'Mahallen').replace(/ Mahallesi$/, '');
    const saatMetni = () => { const s2 = new Date(); return `${String(s2.getHours()).padStart(2, '0')}:${String(s2.getMinutes()).padStart(2, '0')}`; };
    const KELIMELER = [_autoMetin('ÇALIŞ'), _autoMetin('KAZAN'), _autoMetin('BÜYÜ'), _autoMetin('PATRON OL')];
    const olaylar = [
      [0.2 * O, () => kartGoster(_autoMetin('Çırak'), _autoMetin('SIFIRDAN'), _autoMetin('Kendi hikâyeni yaz'), O * 0.6, { ton: TONLAR[2] })],
      [0.85 * O, () => kartGoster(_autoMetin('Hikâyenin başladığı yer'), _autoMetin('TÜRKİYE'), _autoMetin('81 şehir · Sınırsız ihtimal'), O * 1.05, { ton: TONLAR[0] })],
      [1.95 * O, () => kes()],
      [2.35 * O, () => kartGoster(_autoMetin('Bir şehir seçtin'), oyuncu.il.ad.toLocaleUpperCase('tr'), _autoSablon`${oyuncu.ilce.ad} · İlk fırsat burada`, O * 1.4, { sol: true, ton: TONLAR[1] })],
      [4 * O, () => kes(true)],
      [4.5 * O, () => kartGoster(_autoMetin('Senin mahallen'), mahalleAdi().toLocaleUpperCase('tr'), isimler ? isimler.anaCadde : _autoMetin('Mahallesi'), O * 1.35, { sol: true, ton: TONLAR[2] })],
      [6 * O, () => { kes(); yerGoster(`${oyuncu.il.ad} · ${oyuncu.ilce.ad}`.toLocaleUpperCase('tr'), `${(isimler && isimler.anaCadde) || _autoHtml('Ana cadde')} — ${saatMetni()}`); }],
      [6.4 * O, () => kartGoster(_autoMetin('Küçük bir tezgâhla başla'), _autoMetin('KENDİ YOLUNU ÇİZ'), _autoMetin('Üret · Ticaret yap · Şehrini büyüt'), O * 1.15, { sol: true, ton: TONLAR[3] })],
      [7 * O, () => kes()],
      ...KELIMELER.map((k, i) => [8 * O + B * i, () => { if (i === 0) yerYazisi.classList.remove('gorunur'); kes(i === 3); kelimeGoster(k, TONLAR[i]); }]),
      [9 * O, () => { kelime.classList.remove('vur'); kes(true); ekran.classList.add('final'); }],
      [9 * O + B * 2, () => {
        ekran.classList.add('logo', 'sars');
        flas.classList.remove('patla', 'guclu');
        requestAnimationFrame(() => flas.classList.add('patla', 'guclu'));
        setTimeout(() => ekran.classList.remove('sars'), 600);
      }],
    ];
    const SON = video.duration || 11 * O;
    let sira = 0;
    return new Promise((ok) => {
      let bitti = false;
      let kare = 0;
      bitir = () => { if (!bitti) { bitti = true; cancelAnimationFrame(kare); ok(); } };
      video.addEventListener('ended', bitir, { once: true });
      const dongu = () => {
        if (bitti) return;
        const t = video.currentTime;
        akis.style.transform = `scaleX(${Math.min(1, t / (video.duration || SON))})`;
        bolum.textContent = t < 4 * O ? _autoMetin('01 / BAŞLANGIÇ') : t < 8 * O ? _autoMetin('02 / SOKAKLAR') : _autoMetin('03 / SENİN HİKÂYEN');
        while (sira < olaylar.length && t >= olaylar[sira][0]) {
          // çok geride kalan yazı atlanır (sekme arka plandaydı vb.), yalnızca yakın olanlar gösterilir
          if (t - olaylar[sira][0] < 2.5) { try { olaylar[sira][1](); } catch (e) { /* yok say */ } }
          sira++;
        }
        if (kartBitis && t >= kartBitis) { kartBitis = 0; kart.classList.add('gidiyor'); }
        if (t >= SON - 0.08 || gecildi) { bitir(); return; }
        kare = requestAnimationFrame(dongu);
      };
      kare = requestAnimationFrame(dongu);
    });
  }

  // kesme: filmdeki kesmeye denk gelen kısa ışık patlaması
  function kes(guclu = false) {
    flas.classList.remove('patla', 'guclu');
    requestAnimationFrame(() => { if (!gecildi) flas.classList.add('patla', ...(guclu ? ['guclu'] : [])); });
  }
  // başlık kartı gelirken film akmaya devam eder; arkada kısa süre saydam renk perdesi belirir
  // (zamanlayıcı yok: perde tek bir CSS animasyonuyla gelip gider)
  function tonla(ton) {
    ekran.style.setProperty('--ton', ton);
  }
  function kartGoster(ust, baslik, alt, sure, { sol = false, ton = TONLAR[0] } = {}) {
    kart.classList.remove('gorunur', 'gidiyor', 'sol');
    if (sol) kart.classList.add('sol');
    kart.querySelector('.gx-ust').textContent = ust || '';
    kart.querySelector('.gx-baslik').textContent = baslik || '';
    kart.querySelector('.gx-alt').textContent = alt || '';
    kart.style.setProperty('--boy', String(Math.min(1, 9 / Math.max(6, (baslik || '').length))));
    kart.style.setProperty('--ton', ton);
    ekran.style.setProperty('--ton', ton);
    requestAnimationFrame(() => { if (!gecildi) kart.classList.add('gorunur'); });
    kartBitis = video.currentTime + sure; // kart filmin zamanına göre gider
    tonla(ton);
  }
  function yerGoster(ust, alt) {
    yerYazisi.querySelector('b').textContent = ust;
    const sp = yerYazisi.querySelector('span');
    sp.textContent = '';
    yerYazisi.classList.add('gorunur');
    let i = 0;
    const yaz = () => { if (gecildi || i > alt.length) return; sp.textContent = alt.slice(0, i++); setTimeout(yaz, 34); };
    yaz();
  }
  function kelimeGoster(metin, ton) {
    kelime.textContent = metin;
    kelime.style.setProperty('--ton', ton);
    kelime.classList.remove('vur');
    requestAnimationFrame(() => { if (!gecildi) kelime.classList.add('vur'); });
  }
}
