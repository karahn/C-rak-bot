import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.38.0';
// Çırak – Yaşam: keyif, etkinlikler (sinema, tiyatro, konser… 36 etkinlik), eğlence mekânlarında buluşma,
// yurt içi / yurt dışı tatil ve davetler. Türkiye'nin her yerinden arkadaş davet edilir; davet edilen kabul ya da
// reddeder, davetteki herkes birbirini görür. Her buluşmanın mesajlaşma ekranı düzeninde kendi sohbeti vardır.
import { api, tl, esc, sureMetni, simdi, bildir, onayla } from './yardimci.js?v=0.38.0';

let h = null;
let sekme = 'etkinlik';
let acikOda = null;      // açık etkinlik odası (sohbet görünümü)
let katalogFiltre = 'Tümü';
export function yasamKur(y) { h = y; }
const hala = (kutu) => kutu.isConnected && ['yasam', 'tatil', 'eglence'].includes(h.aktifRota());

const SEKMELER = [['etkinlik', '🎟️', 'Etkinlikler'], ['mekan', '🍸', 'Mekânlar'], ['tatil', '🏖️', 'Tatil'], ['davetler', '✉️', 'Davetler'], ['keyif', '😊', 'Keyif']];
const DURUM = { sahip: ['👑', 'Düzenleyen'], kabul: ['✅', 'Geliyor'], davetli: ['⏳', 'Yanıt bekleniyor'], red: ['❌', 'Gelemiyor'], ayrildi: ['🚪', 'Ayrıldı'] };
const GONDER_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.4 20.4 21 12 3.4 3.6 3.4 10l12.6 2-12.6 2z"/></svg>';

function keyifHalkasi(y) {
  const r = 34;
  const c = 2 * Math.PI * r;
  return `<div class="keyif-halka" style="--renk:${y.renk}"><svg viewBox="0 0 80 80" aria-hidden="true"><circle cx="40" cy="40" r="${r}" class="iz"/><circle cx="40" cy="40" r="${r}" class="dolu" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - y.keyif / 100)}"/></svg>
    <div><span>${y.simge}</span><b>${y.keyif}</b></div></div>`;
}
function keyifSeridi(y) {
  const etki = Math.round((y.carpan - 1) * 100);
  return `<div class="keyif-serit">${keyifHalkasi(y)}<div><b>${esc(_autoMetin(y.seviye))}</b><small>${_autoSablon`Keyif ${y.keyif}/100 · tezgâh kazancı ${etki > 0 ? '+' : ''}${etki}%${y.dincBitis ? _autoHtml(' · 🌴 tatil dinçliği +%10') : ''}`}</small></div></div>`;
}
const saatYaz = (ms) => new Date(ms).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Istanbul' });
function zamanMetni(o) {
  const t = simdi();
  if (o.bitti) return _autoMetin('Bitti · sohbet bir saat daha açık');
  if (!o.basladi) return _autoSablon`Başlangıç ${saatYaz(o.bas).replace(':', '.')} · ${sureMetni(o.bas - t)} sonra`;
  return _autoSablon`Sürüyor · ${sureMetni(o.bitis - t)} kaldı`;
}
function uyeCipleri(uyeler, sinir = 12) {
  return `<div class="ek-uyeler">${uyeler.slice(0, sinir).map((u) => `<span class="ek-uye d-${u.durum}" title="${esc(u.ad)} · ${DURUM[u.durum] ? _autoMetin(DURUM[u.durum][1]) : ''}">${h.avatar(u.foto, u.ad, 30)}<i aria-hidden="true">${DURUM[u.durum] ? DURUM[u.durum][0] : ''}</i></span>`).join('')}${uyeler.length > sinir ? `<em>+${uyeler.length - sinir}</em>` : ''}</div>`;
}
function uyeOzeti(uyeler) {
  const n = (d) => uyeler.filter((u) => u.durum === d).length;
  const gel = n('kabul') + n('sahip');
  return _autoSablon`${gel} kişi geliyor${n('davetli') ? _autoSablon` · ${n('davetli')} yanıt bekleniyor` : ''}${n('red') ? _autoSablon` · ${n('red')} gelemiyor` : ''}`;
}

export async function yasamPaneli(yeniSekme) {
  if (yeniSekme && SEKMELER.some(([k]) => k === yeniSekme)) { sekme = yeniSekme; acikOda = null; }
  const davetN = Number((h.genel() || {}).davetSayisi) || 0;
  const p = h.panelAc({
    ikon: '🎉', baslik: _autoMetin('Keyif ve tatil'), rota: 'yasam', alt: _autoMetin('Arkadaşlarınla etkinliğe git, mekânda buluş, tatile çık'),
    govde: `<div class="sekmeler kaydir yasam-sekmeler" role="tablist">${SEKMELER.map(([k, i, a]) => `<button role="tab" data-yasam-sekme="${k}" aria-selected="${sekme === k}">${i} ${_autoHtml(a)}${k === 'davetler' && davetN ? ` <span class="sekme-rozet">${davetN}</span>` : ''}</button>`).join('')}</div>
      <div id="yasam-icerik"><div class="ms-yukleniyor"><span></span><span></span><span></span></div></div>`,
  });
  p.querySelectorAll('[data-yasam-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); yasamPaneli(b.dataset.yasamSekme); }));
  const kutu = p.querySelector('#yasam-icerik');
  try {
    if (acikOda) {
      const e = await api('etkinlikler');
      const o = e.odalar.find((x) => x.id === acikOda) || e.davetler.find((x) => x.id === acikOda);
      if (!o) { acikOda = null; return yasamPaneli(); }
      if (hala(kutu)) odaCiz(kutu, o);
    } else if (sekme === 'tatil') {
      const [t, y, e] = await Promise.all([api('tatil'), api('yasam'), api('etkinlikler')]);
      if (hala(kutu)) tatilCiz(kutu, t, y, e);
    } else if (sekme === 'keyif') {
      const y = await api('yasam');
      if (hala(kutu)) keyifCiz(kutu, y);
    } else if (sekme === 'mekan') {
      const [m, e] = await Promise.all([api('mekanlar'), api('etkinlikler')]);
      if (hala(kutu)) mekanCiz(kutu, m, e);
    } else if (sekme === 'davetler') {
      const e = await api('etkinlikler');
      if (hala(kutu)) davetlerCiz(kutu, e);
    } else {
      const [e, y] = await Promise.all([api('etkinlikler'), api('yasam')]);
      if (hala(kutu)) etkinlikCiz(kutu, e, y);
    }
  } catch (err) { kutu.innerHTML = `<p class="soluk">${esc(err.message)}</p>`; }
}

// ---------- Ortak: davet seçici ----------
function davetAlani(yer, { ipucu = _autoMetin('Arkadaşının adını yaz (Türkiye\'nin her yerinden)'), dugme = _autoMetin('📨 Davet et'), gonder } = {}) {
  yer.innerHTML = `<div class="ek-davet"><div data-secici></div><button type="button" class="dugme mavi kucuk" data-davet-gonder>${dugme}</button></div>`;
  const s = h.oyuncuSecici(yer.querySelector('[data-secici]'), { ipucu, sinir: 20 });
  yer.querySelector('[data-secici]').classList.add('acik');
  yer.querySelector('[data-davet-gonder]').addEventListener('click', async (e) => {
    const l = s.secilenler();
    if (!l.length) return bildir(_autoMetin("Önce davet edeceğin kişileri seç."), true);
    const r = await h.eylem(e.currentTarget, () => gonder(l));
    if (r === undefined) return;
    s.temizle();
    const n = (r.davetEdilen || []).length;
    bildir(n ? _autoSablon`${n} kişiye davet gitti: ${r.davetEdilen.join(', ')}` : _autoMetin("Seçtiklerin zaten davetli ya da davet edilemiyor."), !n);
    if (n) h.ses.mesaj && h.ses.mesaj();
  });
  return s;
}

// ---------- Ortak: buluşma sohbeti (mesajlaşma ekranı düzeninde) ----------
function sohbetBolumu(kutu, { baslik, alt, simge, oku, gonder, bos, yazabilir = true, kapali = '' }) {
  const yer = kutu.querySelector('[data-oda-sohbet]');
  yer.innerHTML = `<div class="oda-sohbet ms">
      <div class="ms-sohbet-bas"><span class="ms-ilce-ikon" aria-hidden="true">${simge}</span><span class="ms-sohbet-ad"><b>${esc(baslik)}</b><small>${esc(alt)}</small></span></div>
      <div class="ms-akis-kutu"><div class="ms-akis" data-akis><div class="sy-bos">${bos}</div></div></div>
      ${yazabilir ? `<form class="ms-yaz" data-yaz><textarea name="metin" rows="1" maxlength="300" placeholder="Mesaj yaz…" aria-label="Mesaj" enterkeyhint="send"></textarea>
        <button type="submit" class="ms-gonder" aria-label="Gönder" disabled>${GONDER_SVG}</button></form>` : `<div class="ms-engel-serit"><span>${kapali}</span></div>`}
    </div>`;
  const akis = yer.querySelector('[data-akis]');
  let sonId = 0;
  let calisiyor = false;
  const yukle = async () => {
    if (calisiyor || !akis.isConnected) return;
    calisiyor = true;
    try {
      const l = await oku(sonId);
      const yeni = (l || []).filter((x) => x.id > sonId);
      if (yeni.length) {
        const altta = akis.scrollHeight - akis.scrollTop - akis.clientHeight < 80;
        if (!sonId) akis.innerHTML = '';
        h.sohbetEkle(akis, yeni);
        sonId = Math.max(sonId, ...yeni.map((x) => x.id));
        if (altta || yeni.some((x) => x.benden)) akis.scrollTop = akis.scrollHeight;
      }
    } catch (e) { /* sessiz */ }
    calisiyor = false;
  };
  const f = yer.querySelector('[data-yaz]');
  if (f) {
    const alan = f.elements.metin;
    const btn = f.querySelector('button');
    const boyutla = () => { alan.style.height = 'auto'; alan.style.height = Math.min(132, alan.scrollHeight) + 'px'; btn.disabled = !alan.value.trim(); };
    alan.addEventListener('input', boyutla);
    alan.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); f.requestSubmit(); } });
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const metin = alan.value.trim();
      if (!metin) return;
      alan.value = ''; boyutla();
      const r = await h.eylem(null, () => gonder(metin));
      if (r === undefined) { alan.value = metin; boyutla(); return; }
      h.ses.tik();
      yukle();
    });
  }
  yukle();
  return yukle;
}

// ---------- Etkinlikler ----------
function odaKarti(o) {
  return `<li class="ek-oda"><button type="button" data-oda="${o.id}">
    <span class="ek-simge" aria-hidden="true">${o.simge}</span>
    <span class="ek-bilgi"><b>${esc(o.ad)}</b><small>${esc(o.turAdi)}${o.yer ? ` · ${esc(o.yer)}` : ''} · ${esc(zamanMetni(o))}</small>${uyeCipleri(o.uyeler, 8)}</span>
    <span class="ek-ok" aria-hidden="true">›</span></button></li>`;
}
function etkinlikCiz(kutu, e, y) {
  const kategoriler = ['Tümü', ...new Set(e.katalog.map((x) => x.kategori))];
  const liste = e.katalog.filter((x) => katalogFiltre === 'Tümü' || x.kategori === katalogFiltre);
  kutu.innerHTML = `${keyifSeridi(y)}
    ${e.davetler.length ? `<button class="kart ek-davet-serit" data-davetlere>${_autoSablon`✉️ <b>${e.davetler.length} davetin</b> yanıt bekliyor`} <span>${_autoHtml("Gör ›")}</span></button>` : ''}
    ${e.odalar.length ? `<h3 class="ek-baslik">${_autoHtml("Buluşmaların")}</h3><ul class="ek-odalar">${e.odalar.map(odaKarti).join('')}</ul>` : ''}
    <h3 class="ek-baslik">${_autoHtml("Etkinlik düzenle")}</h3>
    <p class="kucuk soluk" style="margin:-4px 0 8px">${_autoHtml("Bir etkinlik seç, arkadaşlarını davet et. Davet edilenler kabul ederse kendi biletini alır; herkes kimin geldiğini görür ve etkinliğin sohbetinde konuşur.")}</p>
    <div class="ek-filtre" role="group">${kategoriler.map((k) => `<button type="button" data-kategori="${esc(k)}" aria-pressed="${katalogFiltre === k}">${_autoHtml(k)}</button>`).join('')}</div>
    <div class="ek-katalog">${liste.map((x) => `<button type="button" class="ek-kart" data-etkinlik="${x.kod}">
      <span class="ek-kart-simge" aria-hidden="true">${x.simge}</span><b>${esc(x.ad)}</b><small>${esc(x.aciklama)}</small>
      <span class="ek-kart-alt">${_autoSablon`<em>${tl(x.fiyat)}</em><i>+${x.keyif} keyif · ${Math.round(x.sure / 60 * 10) / 10} sa</i>`}</span></button>`).join('')}</div>
    <div class="ek-kur" data-kur hidden></div>`;
  kutu.querySelectorAll('[data-oda]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); acikOda = Number(b.dataset.oda); yasamPaneli(); }));
  const dv = kutu.querySelector('[data-davetlere]');
  if (dv) dv.addEventListener('click', () => yasamPaneli('davetler'));
  kutu.querySelectorAll('[data-kategori]').forEach((b) => b.addEventListener('click', () => { katalogFiltre = b.dataset.kategori; h.ses.tik(); etkinlikCiz(kutu, e, y); }));
  kutu.querySelectorAll('[data-etkinlik]').forEach((b) => b.addEventListener('click', () => {
    h.ses.tik();
    kutu.querySelectorAll('.ek-kart.secili').forEach((x) => x.classList.remove('secili'));
    b.classList.add('secili');
    kurFormu(kutu, e.katalog.find((x) => x.kod === b.dataset.etkinlik));
  }));
}
function kurFormu(kutu, x) {
  const yer = kutu.querySelector('[data-kur]');
  yer.hidden = false;
  yer.innerHTML = `<div class="kart ek-form"><div class="ek-form-bas"><span>${x.simge}</span><div><b>${esc(x.ad)}</b><small>${_autoSablon`${esc(x.aciklama)} · kişi başı ${tl(x.fiyat)}`}</small></div></div>
    <label class="alan"><span>${_autoHtml("Ne zaman?")}</span></label>
    <div class="segment genis ek-plan" role="group">${[['simdi', _autoMetin('Şimdi')], ['yarim', _autoMetin('30 dk sonra')], ['bir', _autoMetin('1 saat sonra')], ['iki', _autoMetin('2 saat sonra')], ['aksam', _autoMetin('Akşam 20.00')]].map(([k, a], i) => `<button type="button" data-plan="${k}" aria-pressed="${i === 0}">${_autoHtml(a)}</button>`).join('')}</div>
    <label class="alan"><span>${_autoHtml("Başlık (isteğe bağlı)")}</span><input name="not" maxlength="60" placeholder="${_autoHtml("ör. Cuma akşamı film keyfi")}"></label>
    <label class="alan"><span>${_autoHtml("Kimleri çağıralım?")}</span></label><div data-secici></div>
    <button class="dugme yesil" data-kur-gonder>${_autoSablon`${x.simge} Düzenle ve davet et · ${tl(x.fiyat)}`}</button>
    <p class="kucuk soluk" style="margin:6px 0 0">${_autoSablon`Kendi biletini şimdi alırsın (+${x.keyif} keyif). Davet ettiklerin kabul edince kendi biletlerini alır.`}</p></div>`;
  let plan = 'simdi';
  yer.querySelectorAll('[data-plan]').forEach((b) => b.addEventListener('click', () => { plan = b.dataset.plan; yer.querySelectorAll('[data-plan]').forEach((z) => z.setAttribute('aria-pressed', z === b)); }));
  const s = h.oyuncuSecici(yer.querySelector('[data-secici]'), { ipucu: _autoMetin('Arkadaşının adını yaz…'), sinir: 20 });
  yer.querySelector('[data-secici]').classList.add('acik');
  yer.querySelector('[data-kur-gonder]').addEventListener('click', async (ev) => {
    const r = await h.eylem(ev.currentTarget, () => api('etkinlik', { kod: x.kod, plan, not: yer.querySelector('[name=not]').value, davetliler: s.secilenler() }));
    if (r === undefined) return;
    h.ses.kasa && h.ses.kasa();
    bildir(_autoSablon`${x.simge} ${x.ad} ayarlandı${r.davetEdilen.length ? _autoSablon`, ${r.davetEdilen.length} kişi davet edildi` : ''}. Keyfin ${r.keyif}.`);
    await h.durumYenile();
    acikOda = r.id;
    yasamPaneli();
  });
  yer.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Buluşma odası: kim geliyor, davet et, sohbet
function odaCiz(kutu, o) {
  const katildim = ['sahip', 'kabul'].includes(o.durumum);
  kutu.innerHTML = `<button class="ek-geri" data-geri>‹ ${o.tur === 'mekan' ? _autoMetin("Mekânlar") : o.tur === 'tatil' ? _autoMetin("Tatil") : _autoMetin("Etkinlikler")}</button>
    <div class="ek-oda-bas"><span class="ek-simge buyuk" aria-hidden="true">${o.simge}</span><div><h3>${esc(o.ad)}</h3>
      <small>${_autoSablon`${esc(o.turAdi)}${o.yer ? ` · ${esc(o.yer)}` : ''} · düzenleyen ${esc(o.sahip)}`}</small><small class="ek-zaman" data-oda-zaman>${esc(zamanMetni(o))}</small></div></div>
    <div class="ek-katilimcilar"><div class="ek-kat-bas"><b>${_autoHtml("Katılanlar")}</b><small>${esc(uyeOzeti(o.uyeler))}</small></div>
      <ul>${o.uyeler.map((u) => `<li class="d-${u.durum}">${h.avatar(u.foto, u.ad, 36)}<span><b>${esc(u.ad)}</b><small>${_autoSablon`${u.seviye}. sv · ${esc(u.il)}`}</small></span><em>${DURUM[u.durum] ? DURUM[u.durum][0] + ' ' + _autoHtml(DURUM[u.durum][1]) : ''}</em>
        ${u.ad !== h.oyuncu().kullaniciAdi ? `<button type="button" class="ek-yaz" data-yaz-kisi="${esc(u.ad)}" aria-label="${esc(u.ad)} kişisine özel mesaj">💬</button>` : ''}</li>`).join('')}</ul></div>
    ${o.durumum === 'davetli' ? `<div class="kart ek-yanit"><b>${_autoSablon`${esc(o.sahip)} seni davet etti.`}</b><div class="dugme-satiri"><button class="dugme yesil" data-kabul>${_autoSablon`✅ Kabul et${o.fiyat ? ` · ${tl(o.fiyat)}` : ''}`}</button><button class="dugme gri" data-red>${_autoHtml("Gelemem")}</button></div></div>` : ''}
    ${katildim && !o.bitti ? `<details class="ek-davet-kutu"><summary>➕ ${_autoHtml("Başka arkadaşlarını da çağır")}</summary><div data-davet-yeri></div></details>` : ''}
    <div data-oda-sohbet></div>
    ${katildim ? `<button class="dugme gri kucuk" data-ayril style="margin-top:10px">🚪 ${o.benimMi ? _autoMetin("Etkinliği bırak") : _autoMetin("Etkinlikten ayrıl")}</button>` : ''}`;
  kutu.querySelector('[data-geri]').addEventListener('click', () => { acikOda = null; yasamPaneli(o.tur === 'mekan' ? 'mekan' : o.tur === 'tatil' ? 'tatil' : 'etkinlik'); });
  kutu.querySelectorAll('[data-yaz-kisi]').forEach((b) => b.addEventListener('click', () => h.mesajYaz(b.dataset.yazKisi)));
  const dy = kutu.querySelector('[data-davet-yeri]');
  if (dy) davetAlani(dy, { gonder: (l) => api(`etkinlik/${o.id}/davet`, { davetliler: l }) });
  const yanit = async (kabul, btn) => {
    const r = await h.eylem(btn, () => api(`etkinlik/${o.id}/${kabul ? 'kabul' : 'red'}`, {}));
    if (r === undefined) return;
    if (kabul) { h.ses.odul && h.ses.odul(); bildir(r.tatil ? _autoMetin("İyi tatiller! Ekip seni bekliyor.") : r.mekan ? _autoMetin("Masaya katıldın, afiyet olsun!") : _autoSablon`Harika! ${o.ad} için yerin ayrıldı.`); }
    await h.durumYenile();
    if (!kabul) acikOda = null;
    yasamPaneli(kabul ? undefined : 'davetler');
  };
  const kb = kutu.querySelector('[data-kabul]');
  if (kb) kb.addEventListener('click', (e) => yanit(true, e.currentTarget));
  const rd = kutu.querySelector('[data-red]');
  if (rd) rd.addEventListener('click', (e) => yanit(false, e.currentTarget));
  const ay = kutu.querySelector('[data-ayril]');
  if (ay) ay.addEventListener('click', async (e) => {
    if (!(await onayla(o.benimMi ? _autoMetin('Etkinliği bırakırsan sen ayrılırsın, diğerleri sohbette kalabilir. Bilet ücreti iade edilmez.') : _autoMetin('Etkinlikten ayrılmak istiyor musun? Bilet ücreti iade edilmez.'), { evet: _autoMetin('Ayrıl'), ikon: '🚪' }))) return;
    const r = await h.eylem(e.currentTarget, () => api(`etkinlik/${o.id}/ayril`, {}));
    if (r !== undefined) { acikOda = null; yasamPaneli(); }
  });
  const yukle = sohbetBolumu(kutu, {
    baslik: `${o.ad} sohbeti`, alt: uyeOzeti(o.uyeler), simge: o.simge,
    oku: async (son) => (await api(`etkinlik/${o.id}/sohbet${son ? `?son=${son}` : ''}`)).mesajlar,
    gonder: (metin) => api(`etkinlik/${o.id}/sohbet`, { metin }),
    bos: _autoMetin('Henüz kimse yazmadı. Buluşma yerini, saati konuşun! 👋'), yazabilir: katildim,
    kapali: o.durumum === 'davetli' ? _autoMetin('Sohbete yazmak için daveti kabul et.') : _autoMetin('Bu sohbete yazamazsın.'),
  });
  odaYenile = () => yukle();
  h.zamanlayici(() => {
    if (!kutu.isConnected) return;
    const z = kutu.querySelector('[data-oda-zaman]');
    if (z) z.textContent = zamanMetni({ ...o, bitti: o.bitis <= simdi(), basladi: o.bas <= simdi() });
    yukle();
  }, 6000);
}
let odaYenile = null;
// canlı olay: davet, kabul/red, yeni mesaj
export function etkinlikHaberi(v) {
  if (!h || !['yasam', 'tatil', 'eglence'].includes(h.aktifRota())) return;
  if (acikOda && v.oda === acikOda) {
    if (v.tur === 'mesaj' && odaYenile) odaYenile();
    else if (v.tur !== 'mesaj') yasamPaneli();
  } else if (!acikOda && v.tur !== 'mesaj' && ['davetler', 'etkinlik'].includes(sekme)) yasamPaneli();
}

// ---------- Davetler ----------
function davetlerCiz(kutu, e) {
  if (!e.davetler.length) {
    kutu.innerHTML = `<div class="ms-secilmedi acik-zemin"><span aria-hidden="true">✉️</span><b>${_autoHtml("Bekleyen davetin yok")}</b><small>${_autoHtml("Arkadaşların seni bir etkinliğe, mekân masasına ya da tatile çağırınca burada görünür.")}</small>
      <button class="dugme mavi kucuk" data-etkinliklere>🎟️ ${_autoHtml("Sen bir etkinlik düzenle")}</button></div>`;
    kutu.querySelector('[data-etkinliklere]').addEventListener('click', () => yasamPaneli('etkinlik'));
    return;
  }
  kutu.innerHTML = `<ul class="ek-davetler">${e.davetler.map((o) => `<li class="kart">
      <div class="ek-oda-bas"><span class="ek-simge buyuk" aria-hidden="true">${o.simge}</span><div><b>${esc(o.ad)}</b>
        <small>${_autoSablon`${esc(o.turAdi)}${o.yer ? ` · ${esc(o.yer)}` : ''} · <b>${esc(o.sahip)}</b> davet etti`}</small><small>${esc(zamanMetni(o))}</small></div></div>
      ${uyeCipleri(o.uyeler)}<small class="soluk">${esc(uyeOzeti(o.uyeler))}</small>
      <p class="kucuk">${o.tur === 'etkinlik' ? `${_autoSablon`Bilet: <b>${tl(o.fiyat)}</b> · +${o.keyif} keyif`}` : o.tur === 'mekan' ? _autoHtml('Kabul edersen mekâna gidersin (giriş ücreti mekânın fiyatıdır).') : _autoHtml('Kabul edersen aynı yere aynı paketle tatile çıkarsın (kendi tatilini ödersin).')}</p>
      <div class="dugme-satiri"><button class="dugme yesil kucuk" data-kabul="${o.id}">✅ ${_autoHtml("Kabul et")}</button><button class="dugme gri kucuk" data-red="${o.id}">${_autoHtml("Gelemem")}</button><button class="dugme gri kucuk" data-oda="${o.id}">${_autoHtml("Ayrıntı ›")}</button></div></li>`).join('')}</ul>`;
  const yanit = async (id, kabul, btn) => {
    const r = await h.eylem(btn, () => api(`etkinlik/${id}/${kabul ? 'kabul' : 'red'}`, {}));
    if (r === undefined) return;
    if (kabul) { h.ses.odul && h.ses.odul(); bildir(r.tatil ? _autoMetin("İyi tatiller! Ekip seni bekliyor.") : r.mekan ? _autoMetin("Masaya katıldın, afiyet olsun!") : _autoMetin("Harika, yerin ayrıldı!")); acikOda = id; }
    await h.durumYenile();
    yasamPaneli();
  };
  kutu.querySelectorAll('[data-kabul]').forEach((b) => b.addEventListener('click', (ev) => yanit(Number(b.dataset.kabul), true, ev.currentTarget)));
  kutu.querySelectorAll('[data-red]').forEach((b) => b.addEventListener('click', (ev) => yanit(Number(b.dataset.red), false, ev.currentTarget)));
  kutu.querySelectorAll('[data-oda]').forEach((b) => b.addEventListener('click', () => { acikOda = Number(b.dataset.oda); yasamPaneli(); }));
}

// ---------- Mekânlar ----------
function mekanCiz(kutu, m, e) {
  const y = m.durum;
  const su = y.mekan;
  if (su) return mekandaCiz(kutu, su, y, e);
  const saat = (s) => `${String(s[0] % 24).padStart(2, '0')}.00–${String(s[1] % 24).padStart(2, '0')}.00`;
  const masalar = e.odalar.filter((o) => o.tur === 'mekan' && !o.bitti);
  kutu.innerHTML = `${keyifSeridi(y)}
    ${y.tatil ? `<div class="kart basari">${_autoSablon`🏖️ Şu an ${esc(y.tatil.yerAd)} tatilindesin. Dönünce mahallenin mekânlarına uğrayabilirsin.`}</div>` : ''}
    ${masalar.length ? `<h3 class="ek-baslik">${_autoHtml("Davetli olduğun masalar")}</h3><ul class="ek-odalar">${masalar.map(odaKarti).join('')}</ul>` : ''}
    <p class="kucuk soluk">${_autoSablon`İlçendeki kafe, sinema, bar, disko ve gece kulüplerinde buluş. <b>👥 ${_autoHtml("Git ve çağır")}</b> ile gitmeden önce arkadaşlarını masana davet edebilirsin; başka ilçeden de gelebilirler. Mekânda 45 dakika kalırsın.`}</p>
    ${m.mekanlar.length ? `<ul class="mekan-liste">${m.mekanlar.map((x) => `<li class="${x.acik ? '' : 'kapali'}">
      <span class="mekan-simge">${x.simge}</span>
      <div class="mekan-bilgi"><b>${esc(x.ad)}</b><small>${esc(x.turAdi)} · ${esc(x.sahip)}${x.benim ? ' (senin)' : ''} · ${saat(x.saat)}</small>
        ${x.kisi ? `<div class="mekan-kisiler">${x.kisiler.slice(0, 6).map((k) => h.avatar(k.foto, k.ad, 24)).join('')}<em>${_autoSablon`${x.kisi} kişi burada`}</em></div>` : `<div class="kucuk soluk">${_autoHtml("Şu an kimse yok")}</div>`}</div>
      <div class="mekan-sag"><small>${_autoSablon`+${x.keyif} keyif`}</small><button class="dugme ${x.acik ? 'yesil' : 'gri'} kucuk" data-git-mekan="${x.id}" ${x.acik && !y.tatil ? '' : 'disabled'}>${x.acik ? _autoSablon`Git · ${tl(x.fiyat)}` : _autoMetin("Kapalı")}</button>
        ${x.acik && !y.tatil ? `<button class="dugme mavi kucuk" data-git-davet="${x.id}">👥 ${_autoHtml("Git ve çağır")}</button>` : ''}</div></li>`).join('')}</ul>`
      : `<div class="kart"><p style="margin:0">${_autoMetin("İlçende henüz açık bir eğlence mekânı yok. <b>Kafe, bar ya da sinema</b> açarak mahallenin buluşma yeri sen olabilirsin!")}</p></div>`}
    <div data-git-davet-yeri></div>`;
  kutu.querySelectorAll('[data-oda]').forEach((b) => b.addEventListener('click', () => { acikOda = Number(b.dataset.oda); yasamPaneli(); }));
  const git = async (id, btn) => {
    const r = await h.eylem(btn, () => api(`mekan/${id}/git`, {}));
    if (r === undefined) return null;
    h.ses.kasa && h.ses.kasa();
    bildir(`${r.metin} Keyfin +${r.kazanc}.`);
    return r;
  };
  kutu.querySelectorAll('[data-git-mekan]').forEach((b) => b.addEventListener('click', async () => {
    if (await git(b.dataset.gitMekan, b)) { await h.durumYenile(); yasamPaneli('mekan'); }
  }));
  kutu.querySelectorAll('[data-git-davet]').forEach((b) => b.addEventListener('click', () => {
    const x = m.mekanlar.find((z) => String(z.id) === b.dataset.gitDavet);
    const yer = kutu.querySelector('[data-git-davet-yeri]');
    yer.innerHTML = `<div class="kart ek-form"><div class="ek-form-bas"><span>${x.simge}</span><div><b>${esc(x.ad)}</b><small>${_autoHtml("Önce arkadaşlarını seç; sen mekâna geçince davet gider.")}</small></div></div><div data-secici></div>
      <button class="dugme yesil" data-git-gonder>${_autoSablon`🚶 ${esc(x.ad)} mekânına git ve davet et · ${tl(x.fiyat)}`}</button></div>`;
    const s = h.oyuncuSecici(yer.querySelector('[data-secici]'), { ipucu: _autoMetin('Arkadaşının adını yaz…'), sinir: 20 });
    yer.querySelector('[data-secici]').classList.add('acik');
    yer.querySelector('[data-git-gonder]').addEventListener('click', async (ev) => {
      const l = s.secilenler();
      if (!l.length) return bildir(_autoMetin("Önce çağıracağın arkadaşlarını seç."), true);
      const r = await git(x.id, ev.currentTarget);
      if (!r) return;
      const d = await h.eylem(null, () => api('etkinlik/mekan-davet', { davetliler: l }));
      if (d && d.davetEdilen && d.davetEdilen.length) bildir(_autoSablon`${d.davetEdilen.length} arkadaşın masana çağrıldı.`);
      await h.durumYenile();
      yasamPaneli('mekan');
    });
    yer.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }));
}

function mekandaCiz(kutu, m, y, e) {
  const masa = e.odalar.find((o) => o.tur === 'mekan' && String(o.hedef) === String(m.id) && !o.bitti);
  kutu.innerHTML = `<div class="mekan-sahne tur-${esc(m.tur)}">
      <div class="mekan-baslik"><span>${m.simge}</span><div><b>${esc(m.ad)}</b><small>${esc(m.turAdi)} · <span data-mekan-kalan>${sureMetni(m.bitis - simdi())}</span> ${_autoHtml("daha buradasın")}</small></div></div>
      <div class="mekan-masa">${m.kisiler.map((k) => `<div class="mekan-kisi ${k.ben ? 'ben' : ''}">${h.avatar(k.foto, k.ad, 44)}<b>${esc(k.ad)}</b><small>${_autoSablon`${k.seviye}. sv`}</small></div>`).join('')}</div>
      <div class="dugme-satiri"><button class="dugme sari kucuk" data-ikram ${m.kisiler.length > 1 ? '' : 'disabled'}>${_autoSablon`🥂 Herkese ikram et (${tl(m.ikram)}/kişi)`}</button><button class="dugme gri kucuk" data-cik>🚪 ${_autoHtml("Mekândan çık")}</button></div>
    </div>
    ${masa ? `<div class="kart ek-masa">${_autoSablon`<b>👥 Masana çağırdıkların</b>${uyeCipleri(masa.uyeler)}`}<small class="soluk">${esc(uyeOzeti(masa.uyeler))}</small></div>` : ''}
    <details class="ek-davet-kutu" ${masa ? '' : 'open'}><summary>${_autoHtml("👥 Arkadaşlarını masana çağır (Türkiye'nin her yerinden)")}</summary><div data-davet-yeri></div></details>
    <div data-oda-sohbet></div>
    ${keyifSeridi(y)}`;
  davetAlani(kutu.querySelector('[data-davet-yeri]'), { gonder: async (l) => { const r = await api('etkinlik/mekan-davet', { davetliler: l }); setTimeout(() => yasamPaneli('mekan'), 600); return r; } });
  const yukle = sohbetBolumu(kutu, {
    baslik: _autoSablon`${m.ad} masası`, alt: _autoSablon`${m.kisiler.length} kişi mekânda`, simge: m.simge,
    oku: async (son) => { const r = await api('mekan/sohbet' + (son ? `?son=${son}` : '')); if (!r.mekan) { yasamPaneli('mekan'); return []; } return r.mesajlar; },
    gonder: (metin) => api('mekan/sohbet', { metin }),
    bos: _autoMetin('Masada sessizlik… ilk sen yaz! 🥂'),
  });
  h.zamanlayici(() => {
    if (!kutu.isConnected) return;
    const k = kutu.querySelector('[data-mekan-kalan]');
    if (k) k.textContent = sureMetni(Math.max(0, m.bitis - simdi()));
    if (m.bitis <= simdi()) { yasamPaneli('mekan'); return; }
    yukle();
  }, 5000);
  kutu.querySelector('[data-ikram]').addEventListener('click', async (ev) => {
    const r = await h.eylem(ev.currentTarget, () => api('mekan/ikram', {}));
    if (r === undefined) return;
    h.ses.kasa && h.ses.kasa();
    bildir(_autoSablon`${r.kisi} kişiye ikram ettin (${tl(r.tutar)}). Masada keyifler yerinde!`);
    await h.durumYenile();
  });
  kutu.querySelector('[data-cik]').addEventListener('click', async (ev) => {
    const r = await h.eylem(ev.currentTarget, () => api('mekan/cik', {}));
    if (r !== undefined) yasamPaneli('mekan');
  });
}
// canlı olay: biri mekâna geldi ya da ikram etti
export function mekanHaberi(v) {
  if (v.tur === 'ikram') bildir(_autoSablon`🥂 ${v.ad} masadakilere ikram etti! Keyfin +5.`);
  else if (v.tur === 'geldi') bildir(_autoSablon`👋 ${v.ad} mekâna geldi.`);
  if (h && ['yasam', 'eglence'].includes(h.aktifRota()) && sekme === 'mekan' && !acikOda) yasamPaneli('mekan');
}

// ---------- Tatil ----------
const tatilSecim = { yer: null, paket: 'kisa', filtre: 'yurtici' };
function tatilCiz(kutu, t, y, e) {
  const ekip = e.odalar.filter((o) => o.tur === 'tatil' && !o.bitti);
  if (t.tatilde) {
    kutu.innerHTML = `<div class="tatil-kartpostal"><div class="tk-ust">${esc(t.tatilde.yer.simge || '🧳')}</div><h3>${_autoSablon`${esc(t.tatilde.yer.ad)} tatilindesin`}</h3>
      <p>${_autoSablon`Dönüşüne <b data-tatil-kalan>${sureMetni(t.tatilde.bitis - simdi())}</b> var. Bu sürede tezgâhlarında çıraklar çalışır.`}</p>
      <button class="dugme gri kucuk" data-erken>🧳 ${_autoHtml("Erken dön")}</button></div>
      ${ekip.length ? `<h3 class="ek-baslik">${_autoHtml("Tatil ekibin")}</h3><ul class="ek-odalar">${ekip.map(odaKarti).join('')}</ul>` : ''}
      <details class="ek-davet-kutu" ${ekip.length ? '' : 'open'}><summary>👥 ${_autoHtml("Arkadaşlarını buraya çağır")}</summary><p class="kucuk soluk" style="margin:6px 0">${_autoSablon`Kabul edenler ${esc(t.tatilde.yer.ad)} tatiline aynı paketle gelir (kendi tatilini öder). Ekibin kendi sohbeti olur.`}</p><div data-davet-yeri></div></details>
      ${keyifSeridi(y)}`;
    davetAlani(kutu.querySelector('[data-davet-yeri]'), { gonder: async (l) => { const r = await api('etkinlik/tatil-davet', { davetliler: l }); setTimeout(() => yasamPaneli('tatil'), 600); return r; } });
    kutu.querySelectorAll('[data-oda]').forEach((b) => b.addEventListener('click', () => { acikOda = Number(b.dataset.oda); yasamPaneli(); }));
    h.zamanlayici(() => {
      const k = kutu.querySelector('[data-tatil-kalan]');
      if (!k) return;
      const kalan = t.tatilde.bitis - simdi();
      if (kalan <= 0) { h.durumYenile().then(() => yasamPaneli('tatil')); return; }
      k.textContent = sureMetni(kalan);
    }, 1000);
    kutu.querySelector('[data-erken]').addEventListener('click', async (ev) => {
      if (!(await onayla(_autoMetin('Tatilden erken dönersen tatil dinçliği (+%10 kazanç) verilmez. Yine de dönmek istiyor musun?'), { evet: _autoMetin('Erken dön'), ikon: '🧳' }))) return;
      const r = await h.eylem(ev.currentTarget, () => api('tatil/don', {}));
      if (r !== undefined) { await h.durumYenile(); yasamPaneli('tatil'); }
    });
    return;
  }
  const davetler = e.davetler.filter((o) => o.tur === 'tatil');
  const liste = t.yerler.filter((x) => (tatilSecim.filtre === 'yurtdisi') === x.yurtdisi);
  kutu.innerHTML = `${keyifSeridi(y)}
    ${davetler.length ? `<button class="kart ek-davet-serit" data-davetlere>${_autoSablon`🧳 <b>${davetler.length} tatil daveti</b> var`} <span>${_autoHtml("Gör ›")}</span></button>` : ''}
    ${t.dincBitis ? `<div class="kart basari">${_autoSablon`🌴 Tatil dinçliği sürüyor: kendi çalıştığın işlerde +%10 kazanç (${sureMetni(t.dincBitis - simdi())}).`}</div>` : ''}
    <div class="segment genis" role="group"><button data-filtre="yurtici" aria-pressed="${tatilSecim.filtre === 'yurtici'}">🇹🇷 ${_autoHtml("Yurt içi")}</button><button data-filtre="yurtdisi" aria-pressed="${tatilSecim.filtre === 'yurtdisi'}">🌍 ${_autoHtml("Yurt dışı")}</button></div>
    ${tatilSecim.filtre === 'yurtdisi' && !t.pasaport ? `<p class="kucuk soluk">${_autoSablon`🛂 İlk yurt dışı tatilinde bir kez pasaport ücreti (${tl(t.pasaportUcreti)}) ödenir.`}</p>` : ''}
    <div class="tatil-izgara">${liste.map((x) => `<button class="tatil-kart ${tatilSecim.yer === x.kod ? 'secili' : ''}" data-yer="${x.kod}">
      <span class="tk-simge">${x.simge}</span><b>${esc(x.ad)}</b><small>${esc(x.ulke)}${x.sezonda ? ` · <em>${_autoHtml("sezon")}</em>` : ''}</small>
      <span class="tk-aciklama">${esc(x.aciklama)}</span><span class="tk-fiyat">${tl(x.fiyat.kisa)}<small>${_autoHtml("'den")}</small></span></button>`).join('')}</div>
    <div class="kart tatil-satin" ${tatilSecim.yer ? '' : 'hidden'}>
      <div class="segment" role="group">${t.paketler.map((p) => `<button data-paket="${p.kod}" aria-pressed="${tatilSecim.paket === p.kod}">${esc(p.ad)}</button>`).join('')}</div>
      <div data-ozet></div>
      <label class="alan"><span>${_autoHtml("Birlikte gideceklerin (isteğe bağlı)")}</span></label><div data-secici></div>
      <button class="dugme yesil" data-rezervasyon>✈️ ${_autoHtml("Rezervasyon yap")}</button>
      <p class="kucuk soluk">${t.acente ? `${_autoSablon`İlçendeki <b>${esc(t.acente.ad)}</b> (${esc(t.acente.sahip)}) acentesinden alınır; %10 komisyon ona gider.`}` : _autoHtml('İlçende bir oyuncunun seyahat acentesi olsaydı tatilini ondan alırdın.')} ${_autoHtml("Seçtiğin arkadaşlarına davet gider; kabul edenler aynı yere gelir ve kendi tatilini öder. Tatildeyken kendin çalışamazsın, çırakların çalışır. Dönüşte keyfin 100 olur ve 24 saat +%10 kazanırsın.")}</p>
    </div>
    ${t.gecmis.length ? `<div class="kart"><h3>${_autoSablon`🧳 Anılar (${t.gidilenler} farklı yer)`}</h3><div class="ani-rozetler">${t.gecmis.map((g) => `<span title="${esc(g.ad)}">${g.simge}<small>${esc(g.ad)}</small></span>`).join('')}</div></div>` : ''}`;
  const dv = kutu.querySelector('[data-davetlere]');
  if (dv) dv.addEventListener('click', () => yasamPaneli('davetler'));
  const secYeri = kutu.querySelector('[data-secici]');
  const secici = tatilSecim.yer ? h.oyuncuSecici(secYeri, { ipucu: _autoMetin('Arkadaşının adını yaz…'), sinir: 20 }) : null;
  if (secici) secYeri.classList.add('acik');
  const ozetYaz = () => {
    const x = t.yerler.find((z) => z.kod === tatilSecim.yer);
    const o = kutu.querySelector('[data-ozet]');
    if (!x || !o) return;
    const fiyat = x.fiyat[tatilSecim.paket];
    const pas = x.yurtdisi && !t.pasaport ? t.pasaportUcreti : 0;
    o.innerHTML = `<div class="tatil-ozet"><span>${x.simge} <b>${esc(x.ad)}</b> · ${esc(t.paketler.find((p) => p.kod === tatilSecim.paket).ad)}</span><b>${tl(fiyat + pas)}</b></div>${pas ? `<small class="soluk">${_autoSablon`Pasaport ${tl(pas)} dahil`}</small>` : ''}${x.sezonda ? `<small class="soluk"> · ${_autoHtml("Sezon fiyatı")}</small>` : ''}`;
  };
  ozetYaz();
  kutu.querySelectorAll('[data-filtre]').forEach((b) => b.addEventListener('click', () => { tatilSecim.filtre = b.dataset.filtre; tatilSecim.yer = null; h.ses.tik(); tatilCiz(kutu, t, y, e); }));
  kutu.querySelectorAll('[data-yer]').forEach((b) => b.addEventListener('click', () => { tatilSecim.yer = b.dataset.yer; h.ses.tik(); tatilCiz(kutu, t, y, e); kutu.querySelector('.tatil-satin').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }));
  kutu.querySelectorAll('[data-paket]').forEach((b) => b.addEventListener('click', () => { tatilSecim.paket = b.dataset.paket; tatilCiz(kutu, t, y, e); }));
  const rz = kutu.querySelector('[data-rezervasyon]');
  if (rz) rz.addEventListener('click', async (ev) => {
    const x = t.yerler.find((z) => z.kod === tatilSecim.yer);
    if (!x) return;
    const arkadaslar = secici ? secici.secilenler() : [];
    if (!(await onayla(_autoSablon`${x.ad} tatili (${t.paketler.find((p) => p.kod === tatilSecim.paket).ad}) için ödeme yapılsın mı?${arkadaslar.length ? _autoSablon` ${arkadaslar.length} arkadaşına davet gidecek.` : ''}`, { evet: _autoMetin('Tatile çık'), ikon: x.simge }))) return;
    const r = await h.eylem(ev.currentTarget, () => api('tatil', { yer: x.kod, paket: tatilSecim.paket }));
    if (r === undefined) return;
    if (arkadaslar.length) await h.eylem(null, () => api('etkinlik/tatil-davet', { davetliler: arkadaslar }));
    h.ses.odul && h.ses.odul();
    bildir(_autoSablon`İyi tatiller! ${r.yer} seni bekliyor.`);
    tatilSecim.yer = null;
    await h.durumYenile();
    yasamPaneli('tatil');
  });
}

// ---------- Keyif ----------
function keyifCiz(kutu, y) {
  kutu.innerHTML = `<div class="kart keyif-buyuk">${keyifHalkasi(y)}<div><h3>${esc(_autoMetin(y.seviye))}</h3><p class="kucuk">${_autoHtml("Keyfin tezgâhta kendi çalıştığın işlerin kazancını etkiler.")}</p></div></div>
    <div class="kart"><h3>${_autoHtml("Keyif ve kazanç")}</h3><ul class="keyif-tablo">
      <li style="--r:#1FA055"><b>80–100</b><span>😄 ${_autoHtml("Dinç")}</span><em>+%8</em></li>
      <li style="--r:#3A86FF"><b>50–79</b><span>🙂 ${_autoHtml("Keyfi yerinde")}</span><em>±0</em></li>
      <li style="--r:#F08A24"><b>25–49</b><span>😮‍💨 ${_autoHtml("Yorgun")}</span><em>−%5</em></li>
      <li style="--r:#D7263D"><b>0–24</b><span>🥵 ${_autoHtml("Tükenmiş")}</span><em>−%12</em></li></ul>
      <ul class="kural-liste"><li>${_autoHtml("🛠️ Kendi çalıştığın her iş keyfini biraz düşürür (çırak çalışırsa düşmez).")}</li>
      <li>${_autoHtml("⏳ Boş zamanda keyif saatte 1 puan 60'a doğru döner.")}</li>
      <li>${_autoHtml("🎟️ Etkinliğe gitmek ve arkadaşlarını çağırmak keyfi yükseltir; davetini kabul eden olunca senin keyfin de artar.")}</li>
      <li>${_autoHtml("🍸 Mekâna gitmek keyfi hemen yükseltir; arkadaşlarına ikram etmek onlara da keyif verir.")}</li>
      <li>${_autoHtml("🏖️ Tatil dönüşü keyfin 100 olur ve 24 saat ek +%10 kazanırsın.")}</li></ul></div>`;
}
