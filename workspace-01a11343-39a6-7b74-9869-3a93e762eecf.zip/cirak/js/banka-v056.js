import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon, birimAdi as _bankBirim } from './dil.js?v=0.56.1';
import { t as _oyunMetni, htmlDil as _oyunHtml } from './dil.js?v=0.56.1';
// Çırak – Tefon Bank: vadesiz hesap, vadeli mevduat, krediler, döviz ve altın
import { api, tl, tamTl, esc, sayiDili, sayiCoz, sureMetni, simdi, bildir, onayla, sor } from './yardimci.js?v=0.56.1';

let h = null; // ana.js'den gelen yardımcılar
let sekme = 'hesap';
export function bankaKur(y) { h = y; }

// 0.41: Hesap Hareketleri, Kart Ekstresi ve Ödemeler sekmeleri eklendi
const SEKMELER = [['hesap', '🏦', 'bank.tab.hesap'], ['hareket', '📜', 'bank.tab.hareket'], ['odeme', '🧾', 'bank.tab.odeme'], ['havale', '💸', 'bank.tab.havale'], ['vadeli', '📈', 'bank.tab.vadeli'],
  ['kart', '💳', 'bank.tab.kart'], ['ekstre', '📑', 'bank.tab.ekstre'], ['kredi', '💼', 'bank.tab.kredi'], ['not', '📊', 'bank.tab.not'], ['doviz', '🥇', 'bank.tab.doviz']];
// 0.41: numara göster/gizle (IBAN ve kart numarası). Tercih bu oturumda hatırlanır.
let numaraAcik = false;
const ibanMaske = (s) => { const d = String(s || '').replace(/\s+/g, ''); return d ? `${d.slice(0, 4)} •••• •••• •••• •••• ${d.slice(-2)}`.replace(/^(.{4})/, '$1') : ''; };
const kartMaske = (no) => `${no.slice(0, 4)} •••• •••• ${no.slice(-4)}`;
const kartBicim = (no) => no.replace(/(\d{4})(?=\d)/g, '$1 ');
function numaraHtml(acik, gizli, etiket) {
  return `<span class="numara-goster" data-numara><span data-numara-yazi data-acik="${esc(acik)}" data-gizli="${esc(gizli)}">${esc(numaraAcik ? acik : gizli)}</span>
    <button type="button" class="goz-dugme" data-numara-goz aria-pressed="${numaraAcik}" aria-label="${esc(etiket)}" title="${esc(etiket)}">${numaraAcik ? '🙈' : '👁'}</button></span>`;
}
function numaraBagla(kok) {
  kok.querySelectorAll('[data-numara-goz]').forEach((b) => b.addEventListener('click', (e) => {
    e.stopPropagation(); h.ses.tik();
    numaraAcik = !numaraAcik;
    kok.querySelectorAll('[data-numara-yazi]').forEach((y) => { y.textContent = numaraAcik ? y.dataset.acik : y.dataset.gizli; });
    kok.querySelectorAll('[data-numara-goz]').forEach((x) => { x.textContent = numaraAcik ? '🙈' : '👁'; x.setAttribute('aria-pressed', numaraAcik); });
  }));
}
const yuzde = (x) => `%${Number(x).toLocaleString(sayiDili(), { maximumFractionDigits: 2 })}`;
// "12.500" ya da "12500,50" gibi yazılan tutarı kuruşa çevirir
function tutarOku(s) {
  const t = sayiCoz(s);
  return Number.isFinite(t) && t > 0 ? Math.round(t * 100) : 0;
}
const hala = (kutu) => kutu.isConnected && h.aktifRota() === 'banka';

export async function bankaPaneli(yeniSekme) {
  if (yeniSekme && SEKMELER.some(([k]) => k === yeniSekme)) sekme = yeniSekme;
  const p = h.panelAc({
    ikon: '🏦', baslik: _autoMetin('Tefon Bank'), rota: 'banka', alt: _oyunMetni("bank.subtitle"),
    govde: `<div class="banka-sekmeler" role="tablist">${SEKMELER.map(([k, i, a]) => `<button role="tab" data-sekme="${k}" aria-selected="${sekme === k}"><span aria-hidden="true">${i}</span>${_oyunHtml(a)}</button>`).join('')}</div>
      <div id="banka-icerik" class="banka"><p class="soluk">${_oyunHtml("auth.loading")}</p></div>`,
  });
  p.querySelectorAll('[data-sekme]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); bankaPaneli(b.dataset.sekme); }));
  const kutu = p.querySelector('#banka-icerik');
  try {
    if (sekme === 'doviz') {
      const y = await api('yatirim');
      if (hala(kutu)) dovizCiz(kutu, y);
      return;
    }
    if (sekme === 'hareket') {
      const [d, r] = await Promise.all([api('banka'), api('banka/hareketler')]);
      if (hala(kutu)) hareketCiz(kutu, d, r);
      return;
    }
    if (sekme === 'odeme') {
      const r = await api('banka/odemeler');
      if (hala(kutu)) odemeCiz(kutu, r);
      return;
    }
    if (sekme === 'ekstre') {
      const r = await api('finans/ekstre');
      if (hala(kutu)) ekstreCiz(kutu, r);
      return;
    }
    if (sekme === 'kart' || sekme === 'not') {
      const f = await api('finans');
      if (!hala(kutu)) return;
      if (sekme === 'kart') kartCiz(kutu, f); else notCiz(kutu, f);
      return;
    }
    // 0.38: açık icrada mevduat donuk uyarısı
    const donukUyari = (d) => {
      if (d && d.masak) {
        // 0.49.7: nedeni açıklanmaz; oyuncu açıklamasıyla itiraz edebilir
        const it = d.masak.itiraz;
        const itirazHtml = it && it.durum === 'bekliyor' ? `<p class="kucuk" style="margin:8px 0 0">📨 ${_autoHtml('İtirazın inceleniyor. Yanıt gelince bildirim alacaksın.')}</p>`
          : `${it && it.yanit ? `<div class="masak-yanit"><small>${_autoHtml('Yönetimin yanıtı')}</small><p>${esc(it.yanit)}</p></div>` : ''}<button class="dugme kucuk mavi" data-masak-itiraz style="margin-top:8px">✍️ ${_autoHtml('İtiraz et')}</button>`;
        kutu.insertAdjacentHTML('afterbegin', `<div class="kart uyari masak-uyari">🛑 ${_autoHtml('Banka hesabın inceleme nedeniyle geçici olarak kısıtlandı. İnceleme bitene kadar para çekemez, havale gönderemez, vadeli hesap bozamazsın.')}${itirazHtml}</div>`);
        const b = kutu.querySelector('[data-masak-itiraz]');
        if (b) b.addEventListener('click', async () => {
          const metin = await sor(_autoMetin('İtirazını açıkla: bu para hareketleri neydi, kiminle ve neden yapıldı? (en az 20 karakter)'), { baslik: _autoMetin('MASAK incelemesine itiraz'), ikon: '✍️', uzunluk: 1000, evet: _autoMetin('İtirazı gönder') });
          if (!metin || !metin.trim()) return;
          if (metin.trim().length < 20) return bildir(_autoMetin('İtirazını en az 20 karakterle açıkla.'), true);
          const r = await h.eylem(b, () => api('banka/masak-itiraz', { metin: metin.trim() }));
          if (r === undefined) return;
          bildir(_autoMetin('İtirazın gönderildi. İncelenip yanıtlanacak.'));
          bankaPaneli(sekme);
        });
      }
      if (d && d.donuk) kutu.insertAdjacentHTML('afterbegin', `<div class="kart uyari">${_autoHtml("⚖️ Hakkında açık icra dosyası olduğu için mevduatların donduruldu: para çekemez, havale gönderemez, vadeli hesap bozamazsın. İcra açıldıktan 3 ekonomi günü sonra borç mevduatından otomatik tahsil edilir.")} <a href="#/banka/kart">${_autoHtml("İcra dosyası")} ›</a></div>`);
    };
    if (sekme === 'havale') {
      const [hv, d] = await Promise.all([api('banka/havale'), api('banka')]);
      if (hala(kutu)) { havaleCiz(kutu, hv, d); donukUyari(d); }
      return;
    }
    const d = await api('banka');
    if (!hala(kutu)) return;
    if (sekme === 'hesap') hesapCiz(kutu, d);
    else if (sekme === 'vadeli') vadeliCiz(kutu, d);
    else krediCiz(kutu, d);
    donukUyari(d);
  } catch (e) { kutu.innerHTML = `<p class="soluk">${esc(e.message)}</p>`; }
}

function ekonomiGunuMetni(d, gun) {
  return sureMetni(gun * d.ekonomiGunuMs);
}
const tarihYaz = (ms) => new Date(ms + 3 * 3600000).toISOString().slice(0, 10).split('-').reverse().join('.');
// hızlı tutar düğmeleri: girdiye tutar yazar (son düğme "tümü")
function hizliTutarlar(girdi, tumu, cagri) {
  const l = [100000, 1000000, 10000000];
  return {
    html: `<div class="hizli-tutar">${l.map((k) => `<button type="button" data-hizli="${k}">${tl(k)}</button>`).join('')}${tumu ? `<button type="button" data-hizli="tumu">${_oyunHtml("finance.all")}</button>` : ''}</div>`,
    bagla(kok) {
      kok.querySelectorAll('[data-hizli]').forEach((b) => b.addEventListener('click', () => {
        const k = b.dataset.hizli === 'tumu' ? tumu() : Number(b.dataset.hizli);
        girdi().value = (Math.floor(k / 100)).toLocaleString(sayiDili());
        if (cagri) cagri();
      }));
    },
  };
}

// ---------- Hesaplarım ----------
function hesapCiz(kutu, d) {
  const vadeliToplam = d.vadeliler.reduce((s, v) => s + v.anapara, 0);
  const borc = d.krediler.reduce((s, k) => s + k.kalan + k.gecikmeFaizi, 0);
  const o = h.oyuncu ? h.oyuncu() : null;
  const hizli = hizliTutarlar(() => kutu.querySelector('[name=tutar]'), null);
  kutu.innerHTML = `
    <div class="tefon-kart">
      <div class="tefon-ust"><span class="tefon-logo">${_autoMetin("TEFON<b>BANK</b>")}</span><span class="tefon-cip" aria-hidden="true"></span></div>
      <small>${_oyunHtml("bank.balance")}</small>
      <div class="tefon-bakiye">${tl(d.vadesiz)}</div>
      <div class="tefon-alt"><span>${esc(o ? o.kullaniciAdi : '')}</span>${numaraHtml(d.hesapNo, ibanMaske(d.hesapNo), _autoMetin('IBAN\'ı göster / gizle'))}</div>
      <div class="tefon-iban"><small>IBAN</small><button type="button" class="kopya-dugme" data-iban-kopya>📋 ${_autoHtml("Kopyala")}</button></div>
    </div>
    <div class="banka-ozet">
      <div><small>💵 ${_oyunHtml("bank.cash")}</small><b>${tl(d.nakit)}</b></div>
      <div><small>📈 ${_oyunHtml("bank.deposits")}</small><b>${tl(vadeliToplam)}</b></div>
      <div><small>💼 ${_oyunHtml("bank.loanDebt")}</small><b class="${borc ? 'eksi' : ''}">${tl(borc)}</b></div>
      <div><small>🏦 ${_oyunHtml("bank.net")}</small><b>${tl(d.net)}</b></div>
    </div>
    ${d.krediNotu ? `<button class="not-serit" data-git="not" style="--renk:${d.krediNotu.renk}"><span>📊 ${_oyunHtml("bank.yourScore")}</span><b>${d.krediNotu.puan}</b><em>${esc(_autoMetin(d.krediNotu.bant))}</em><i aria-hidden="true">›</i></button>` : ''}
    ${d.krediler.some((k) => k.geciken) ? `<div class="kart uyari"><b>⚠️ ${_oyunHtml("bank.overdue")}</b> ${_oyunHtml("bank.overdueHint")}</div>` : ''}
    <div class="kart banka-islem"><h3>${_oyunHtml("bank.depositWithdraw")}</h3>
      <label class="alan"><span>${_oyunHtml("bank.amount")}</span><input name="tutar" inputmode="decimal" placeholder="${_oyunHtml("finance.example", {value:"10.000"})}" autocomplete="off"></label>
      ${hizli.html}
      <div class="dugme-satiri"><button class="dugme yesil" data-yatir>⬇️ ${_oyunHtml("bank.deposit")}</button><button class="dugme mavi" data-cek>⬆️ ${_oyunHtml("bank.withdraw")}</button></div>
      <p class="kucuk soluk">${_oyunHtml("bank.currentHint")} <a href="#" data-git="vadeli">${_oyunHtml("bank.interestHint")}</a></p>
    </div>`;
  hizli.bagla(kutu);
  numaraBagla(kutu);
  kutu.querySelector('[data-iban-kopya]').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(d.hesapNo.replace(/\s+/g, '')); bildir(_autoMetin('IBAN kopyalandı.')); } catch (e) { bildir(d.hesapNo); }
  });
  const girdi = kutu.querySelector('[name=tutar]');
  kutu.querySelector('[data-yatir]').addEventListener('click', async (e) => {
    const t = tutarOku(girdi.value);
    if (!t) return bildir(_oyunMetni("bank.enterAmount"), true);
    if ((await h.eylem(e.currentTarget, () => api('banka/yatir', { tutar: t }))) === undefined) return;
    h.ses.para && h.ses.para();
    bildir(_oyunMetni("bank.deposited", {amount:tamTl(t)}));
    await h.durumYenile();
    bankaPaneli();
  });
  kutu.querySelector('[data-cek]').addEventListener('click', async (e) => {
    const t = tutarOku(girdi.value);
    if (!t) return bildir(_oyunMetni("bank.enterAmount"), true);
    if ((await h.eylem(e.currentTarget, () => api('banka/cek', { tutar: t }))) === undefined) return;
    bildir(_oyunMetni("bank.withdrawn", {amount:tamTl(t)}));
    await h.durumYenile();
    bankaPaneli();
  });
  kutu.querySelector('[data-git=vadeli]').addEventListener('click', (e) => { e.preventDefault(); bankaPaneli('vadeli'); });
  const ns = kutu.querySelector('[data-git=not]');
  if (ns) ns.addEventListener('click', () => { h.ses.tik(); bankaPaneli('not'); });
}

// ---------- Kredi kartı ----------
const KART_HAREKET = { harcama: ['🛍️', ''], odeme: ['✅', 'arti'], faiz: ['📈', 'eksi'], ekstre: ['🧾', ''], acilis: ['🎉', ''], limit: ['⬆️', ''], icra: ['⚖️', 'eksi'], kapanis: ['🔒', ''] };
function kartGorseli(k, ad, { bos = false, durum = '' } = {}) {
  return `<div class="kredi-kart ${bos ? 'bos' : ''} ${durum}">
    <div class="kk-ust"><span class="tefon-logo">${_autoMetin("TEFON<b>BANK</b>")}</span><span class="kk-tur">${bos ? _autoMetin("KREDİ KARTI") : durum === 'icra' ? _autoMetin("İCRADA") : k.gecikme ? _autoMetin("KAPALI") : 'PLATINUM'}</span></div>
    <div class="kk-cip" aria-hidden="true"></div><span class="kk-temassiz" aria-hidden="true">)))</span>
    <div class="kk-no">${bos ? '•••• •••• •••• ••••' : k.no ? numaraHtml(kartBicim(k.no), kartMaske(k.no), _autoMetin('Kart numarasını göster / gizle')) : esc(k.maskeli)}</div>
    <div class="kk-alt"><div><small>${_autoHtml("Kart sahibi")}</small><b>${esc(ad || '')}</b></div><div><small>${_autoHtml("Limit")}</small><b>${tl(k.limit)}</b></div></div>
  </div>`;
}
function kartCiz(kutu, f) {
  const o = h.oyuncu ? h.oyuncu() : null;
  const ad = o ? o.kullaniciAdi.toLocaleUpperCase('tr') : '';
  const icra = f.icralar.find((x) => x.durum === 'acik');
  const icraHtml = icra ? `<div class="kart icra-kart"><h3>⚖️ ${_autoHtml("İcra takibi")}</h3>
      <div class="bilgi-izgara"><div><small>${_autoHtml("Dosya no")}</small><b>${esc(icra.dosyaNo)}</b></div><div><small>${_autoHtml("Alacaklı")}</small><b>${esc(icra.alacakli)}</b></div>
      <div><small>${_autoSablon`Borç + %${f.kurallar.icraMasraf} masraf`}</small><b>${tl(icra.anapara + icra.masraf)}</b></div><div><small>${_autoHtml("Kalan")}</small><b class="eksi">${tl(icra.kalan)}</b></div></div>
      <div class="cubuk"><div style="width:${Math.min(100, Math.round((100 * icra.odenen) / Math.max(1, icra.anapara + icra.masraf)))}%"></div></div>
      <p class="kucuk">${_autoSablon`Dosya kapanana kadar gelen kazançlarının <b>%${f.kurallar.icraKesinti}</b>'i kendiliğinden kesilir. Kredi ve kart verilmez.`}</p>
      ${!icra.otoTahsil && icra.tahsilZamani > simdi() ? `<p class="kucuk kirmizi">${_autoSablon`🧊 Mevduatların donduruldu. ${sureMetni(icra.tahsilZamani - simdi())} içinde ödemezsen borç mevduatından otomatik tahsil edilir.`}</p>` : ''}
      <label class="alan"><span>${_autoHtml("Ödenecek tutar (₺)")}</span><input name="icra" inputmode="decimal" placeholder="${_oyunHtml("finance.example", {value:"5.000"})}"></label>
      <div class="dugme-satiri"><button class="dugme kirmizi" data-icra-ode>⚖️ ${_oyunHtml("finance.pay")}</button><button class="dugme gri" data-icra-tumu>${_autoSablon`Tamamını öde (${tl(icra.kalan)})`}</button></div></div>` : '';
  if (!f.kart) {
    kutu.innerHTML = `${icraHtml}
      <div class="kart-teklif">${kartGorseli({ limit: f.teklif.limit }, ad, { bos: true })}
        <div><h3>${_autoHtml("Tefon Bank kredi kartı")}</h3>
        <p class="kucuk">${_autoSablon`Limitin kredi notuna göre belirlenir: <b>${tl(f.kurallar.enAzLimit)}</b> ile <b>${tl(f.kurallar.enCokLimit)}</b> arası. Alışverişlerini kartla yap, ekstren gelince öde.`}</p>
        ${f.teklif.limit ? `<div class="teklif-limit"><small>${_autoHtml("Sana önerilen limit")}</small><b>${tl(f.teklif.limit)}</b></div>` : ''}
        ${f.teklif.engel ? `<div class="kart uyari kucuk">🔒 ${esc(f.teklif.engel)}</div>` : `<button class="dugme yesil" data-basvur>💳 ${_autoHtml("Hemen başvur")}</button>`}</div></div>
      <div class="kart"><h3>${_autoHtml("Nasıl çalışır?")}</h3><ul class="kural-liste">
        <li>${_autoMetin("🧾 Her ay (30 ekonomi günü) hesap kesilir, <b>10 gün</b> içinde ödersin.")}</li>
        <li>${_autoMetin("✅ Ekstrenin tamamını ödersen <b>faiz yok</b>, kredi notun yükselir.")}</li>
        <li>${_autoSablon`💡 En az asgari tutarı öde (limit 50.000 ₺'ye kadar %20, üstünde %40). Kalana aylık <b>%${f.kurallar.akdi.toLocaleString(sayiDili())}</b> faiz işler.`}</li>
        <li>${_autoSablon`⚠️ Asgari ödenmezse <b>%${f.kurallar.gecikme.toLocaleString(sayiDili())}</b> gecikme faizi işler, kart harcamaya kapanır, notun düşer.`}</li>
        <li>${_autoSablon`⚖️ <b>${f.kurallar.icraDonem} dönem</b> üst üste asgari ödenmezse borç icraya gider.`}</li></ul></div>`;
    const b = kutu.querySelector('[data-basvur]');
    if (b) b.addEventListener('click', async (e) => {
      const r = await h.eylem(e.currentTarget, () => api('finans/kart/basvur', {}));
      if (r === undefined) return;
      h.ses.odul && h.ses.odul();
      bildir(_autoSablon`Kartın hazır! Limitin ${tl(r.limit)}.`);
      bankaPaneli('kart');
    });
    icraBagla(kutu, icra);
    return;
  }
  const k = f.kart;
  const kullanim = Math.min(100, Math.round((100 * k.borc) / Math.max(1, k.limit)));
  const sonOdemeVar = k.sonOdeme > 0 && k.ekstreKalan > 0;
  const hizlilar = [['asgari', _autoMetin('Asgari'), k.asgariKalan], ['ekstre', _autoMetin('Ekstre'), k.ekstreKalan], ['tum', _autoMetin('Tüm borç'), k.borc]].filter(([, , v]) => v > 0);
  kutu.innerHTML = `${icraHtml}
    ${kartGorseli(k, ad, { durum: k.durum })}
    ${k.gecikme ? `<div class="kart uyari">${_autoSablon`<b>⚠️ ${k.gecikme}. dönem asgari ödeme yapılmadı.</b> Kartın harcamaya kapalı. ${f.kurallar.icraDonem - k.gecikme} dönem daha ödenmezse borç icraya gider. Bir sonraki ekstrenin asgarisini zamanında ödeyince kart açılır.`}</div>` : ''}
    <div class="kart kk-limit"><div class="kk-limit-ust"><div><small>${_autoHtml("Kullanılabilir limit")}</small><b>${tl(k.kullanilabilir)}</b></div><div class="sag"><small>${_autoHtml("Toplam borç")}</small><b class="${k.borc ? 'eksi' : ''}">${tl(k.borc)}</b></div></div>
      <div class="kk-cubuk"><div style="width:${kullanim}%" class="${kullanim > 70 ? 'yuksek' : ''}"></div></div>
      <div class="kucuk soluk">${_autoSablon`Limitin %${kullanim}'i kullanılıyor · Limit ${tl(k.limit)}`}</div></div>
    <div class="banka-ozet">
      <div><small>🛍️ ${_autoHtml("Dönem içi harcama")}</small><b>${tl(k.donem)}</b></div>
      <div><small>🧾 ${_autoHtml("Ekstre borcu")}</small><b>${tl(k.ekstreKalan)}</b></div>
      <div><small>💡 ${_autoHtml("Asgari ödeme")}</small><b>${tl(k.asgariKalan)}</b></div>
      <div><small>✂️ ${_autoHtml("Hesap kesimi")}</small><b>${tarihYaz(k.kesim)}</b></div>
    </div>
    ${sonOdemeVar ? `<div class="kart son-odeme"><div><small>${_autoHtml("Son ödeme")}</small><b>${tarihYaz(k.sonOdeme)}</b></div><div class="sag"><small>${_autoHtml("Kalan süre")}</small><b data-geri-kart="${k.sonOdeme}">${sureMetni(k.sonOdeme - simdi())}</b></div></div>` : ''}
    <div class="kart banka-islem"><h3>💳 ${_autoHtml("Kart borcu öde")}</h3>
      <label class="alan"><span>${_oyunHtml("bank.amount")}</span><input name="tutar" inputmode="decimal" placeholder="${_oyunHtml("finance.example", {value:"2.500"})}" autocomplete="off"></label>
      ${hizlilar.length ? `<div class="hizli-tutar">${hizlilar.map(([kd, a, v]) => `<button type="button" data-kk-hizli="${v}">${_autoHtml(a)}: ${tl(v)}</button>`).join('')}</div>` : ''}
      <button class="dugme yesil" data-kk-ode ${k.borc ? '' : 'disabled'}>✅ ${_oyunHtml("finance.pay")}</button>
      <p class="kucuk soluk">${_autoHtml("Ödeme önce vadesiz hesabından, yetmezse nakdinden çekilir.")}</p></div>
    <div class="kart"><h3>⚙️ ${_autoHtml("Kart ayarları")}</h3>
      <div class="ayar-satir"><div><b>${_autoHtml("Ödeme tercihi")}</b><small>${_autoHtml("Ekipman, stok, kurulum, lüks, tatil ve eğlence ödemeleri")}</small></div>
        <div class="segment" role="group"><button data-tercih="nakit" aria-pressed="${f.odemeTercihi === 'nakit'}">${_autoHtml("💵 Nakit")}</button><button data-tercih="kart" aria-pressed="${f.odemeTercihi === 'kart'}" ${k.harcamaya ? '' : 'disabled'}>💳 ${_autoHtml("Kart")}</button></div></div>
      <div class="ayar-satir"><div><b>${_autoHtml("Otomatik ödeme talimatı")}</b><small>${_autoHtml("Son ödeme gününde kendiliğinden çekilir")}</small></div>
        <select data-otomatik>${[['yok', _autoMetin('Talimat yok')], ['asgari', _autoMetin('Asgari tutar')], ['tamami', _autoMetin('Ekstrenin tamamı')]].map(([v, a]) => `<option value="${v}" ${k.otomatik === v ? 'selected' : ''}>${_autoHtml(a)}</option>`).join('')}</select></div>
      ${f.limitArtis ? `<div class="ayar-satir vurgu"><div><b>🎉 ${_autoHtml("Limit artırımı hazır")}</b><small>${_autoHtml("Kredi notun yükseldi")}</small></div><button class="dugme mavi kucuk" data-limit>${tl(k.limit)} → ${tl(f.limitArtis)}</button></div>` : ''}
      <p class="kucuk soluk">${_autoSablon`Nakit yetmediğinde de ödeme karttan yapılabilir. Faiz: aylık akdi %${k.akdiFaiz.toLocaleString(sayiDili())}, gecikme %${k.gecikmeFaizi.toLocaleString(sayiDili())}. Bugüne kadar ödenen faiz: ${tl(k.faizToplam)}.`}</p>
    </div>
    <div class="kart"><h3>🧾 ${_autoHtml("Kart hareketleri")}</h3>${f.hareketler.length ? `<ul class="kk-hareketler">${f.hareketler.map((x) => {
      const [ik, sinif] = KART_HAREKET[x.tur] || ['•', ''];
      return `<li><span class="kk-ik">${ik}</span><span class="kk-ac">${esc(x.aciklama || x.tur)}<small>${tarihYaz(x.zaman)}</small></span><b class="${sinif}">${x.tutar ? (x.tutar < 0 ? '−' : '') + tl(Math.abs(x.tutar)) : ''}</b></li>`;
    }).join('')}</ul>` : `<p class="soluk kucuk">${_autoHtml("Henüz hareket yok.")}</p>`}
      ${k.durum !== 'icra' ? `<button class="dugme gri kucuk" data-kart-kapat ${k.borc ? _autoHtml('disabled title="Önce borcu kapat"') : ''}>🔒 ${_autoHtml("Kartı kapat")}</button>` : ''}</div>`;
  numaraBagla(kutu);
  const girdi = kutu.querySelector('[name=tutar]');
  kutu.querySelectorAll('[data-kk-hizli]').forEach((b) => b.addEventListener('click', () => { girdi.value = (Math.ceil(Number(b.dataset.kkHizli) / 100)).toLocaleString(sayiDili()); }));
  kutu.querySelector('[data-kk-ode]').addEventListener('click', async (e) => {
    const t = tutarOku(girdi.value);
    if (!t) return bildir(_oyunMetni("bank.enterAmount"), true);
    const r = await h.eylem(e.currentTarget, () => api('finans/kart/ode', { tutar: t }));
    if (r === undefined) return;
    h.ses.kasa && h.ses.kasa();
    bildir(_autoSablon`Kart borcuna ${tl(r.odenen)} ödendi.`);
    await h.durumYenile();
    bankaPaneli('kart');
  });
  kutu.querySelectorAll('[data-tercih]').forEach((b) => b.addEventListener('click', async () => {
    if (b.getAttribute('aria-pressed') === 'true') return;
    const r = await h.eylem(b, () => api('finans/ayar', { tercih: b.dataset.tercih }));
    if (r === undefined) return;
    bildir(b.dataset.tercih === 'kart' ? _autoMetin("Alışverişlerin artık kredi kartından çekilecek.") : _autoMetin("Alışverişlerin nakitten ödenecek."));
    bankaPaneli('kart');
  }));
  kutu.querySelector('[data-otomatik]').addEventListener('change', async (e) => {
    const r = await h.eylem(null, () => api('finans/ayar', { otomatik: e.target.value }));
    if (r !== undefined) bildir(_autoMetin("Otomatik ödeme talimatın kaydedildi."));
  });
  const lim = kutu.querySelector('[data-limit]');
  if (lim) lim.addEventListener('click', async (e) => {
    const r = await h.eylem(e.currentTarget, () => api('finans/kart/limit', {}));
    if (r === undefined) return;
    h.ses.odul && h.ses.odul();
    bildir(_autoSablon`Yeni limitin ${tl(r.limit)}.`);
    bankaPaneli('kart');
  });
  const kp = kutu.querySelector('[data-kart-kapat]');
  if (kp) kp.addEventListener('click', async (e) => {
    if (!(await onayla(_autoMetin("Kredi kartını kapatmak istediğine emin misin?"), { evet: _autoMetin('Kartı kapat'), tehlike: true, ikon: '💳' }))) return;
    const r = await h.eylem(e.currentTarget, () => api('finans/kart/kapat', {}));
    if (r !== undefined) { bildir(_autoMetin("Kartın kapatıldı.")); bankaPaneli('kart'); }
  });
  icraBagla(kutu, icra);
}
function icraBagla(kutu, icra) {
  if (!icra) return;
  const g = kutu.querySelector('[name=icra]');
  const ode = async (btn, t) => {
    const r = await h.eylem(btn, () => api('finans/icra/ode', { tutar: t }));
    if (r === undefined) return;
    bildir(r.kalan > 0 ? _autoSablon`İcra dosyasına ${tl(r.odenen)} ödendi. Kalan ${tl(r.kalan)}.` : _autoMetin("İcra dosyan kapandı!"));
    await h.durumYenile();
    bankaPaneli('kart');
  };
  kutu.querySelector('[data-icra-ode]').addEventListener('click', (e) => { const t = tutarOku(g.value); if (!t) return bildir(_oyunMetni("bank.enterAmount"), true); ode(e.currentTarget, t); });
  kutu.querySelector('[data-icra-tumu]').addEventListener('click', (e) => ode(e.currentTarget, icra.kalan));
}

// ---------- Kredi notu ----------
function notGostergesi(not) {
  // yarım daire gösterge: 1–1900, beş renkli bant
  const r = 90, cx = 110, cy = 110;
  const aci = (p) => Math.PI * (1 - (p - not.enAz) / (not.enCok - not.enAz));
  const nokta = (p, rr = r) => [cx + rr * Math.cos(aci(p)), cy - rr * Math.sin(aci(p))];
  const yay = (a, b, renk) => { const [x1, y1] = nokta(a); const [x2, y2] = nokta(b); return `<path d="M${x1.toFixed(1)} ${y1.toFixed(1)} A${r} ${r} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}" stroke="${renk}" stroke-width="18" fill="none"/>`; };
  const [ix, iy] = nokta(not.puan, r - 26);
  return `<svg viewBox="0 0 220 130" class="not-gosterge" aria-hidden="true">
    ${not.bantlar.map((b) => yay(b.alt, b.ust, b.renk)).join('')}
    <line x1="${cx}" y1="${cy}" x2="${ix.toFixed(1)}" y2="${iy.toFixed(1)}" stroke="#1B2437" stroke-width="5" stroke-linecap="round"/>
    <circle cx="${cx}" cy="${cy}" r="9" fill="#1B2437"/></svg>`;
}
function notCiz(kutu, f) {
  const n = f.not;
  kutu.innerHTML = `<div class="kart not-kart">${notGostergesi(n)}
      <div class="not-puan" style="color:${n.renk}">${n.puan}</div><div class="not-bant" style="background:${n.renk}">${esc(_autoMetin(n.bant))}</div>
      <p class="kucuk soluk">${_autoHtml("Kredi notun 1 ile 1900 arasındadır. Not yükseldikçe kredi faizin düşer, kart limitin artar.")}</p></div>
    <div class="kart"><h3>${_autoHtml("Notunu oluşturanlar")}</h3><ul class="not-bilesen">${n.bilesenler.map((b) => `<li><span><b>${esc(_autoMetin(b.ad))}</b><small>${esc(_autoMetin(b.aciklama))}</small></span><em class="${b.puan < 0 ? 'eksi' : 'arti'}">${b.puan > 0 ? '+' : ''}${b.puan}</em></li>`).join('')}</ul></div>
    <div class="kart"><h3>${_autoHtml("Risk bantları")}</h3><ul class="not-bantlar">${n.bantlar.map((b) => `<li class="${b.ad === n.bant ? 'secili' : ''}"><i style="background:${b.renk}"></i>${b.alt}–${b.ust}<b>${esc(_autoMetin(b.ad))}</b></li>`).join('')}</ul>
      <h3>${_autoHtml("Notunu yükseltmek için")}</h3><ul class="kural-liste">
        <li>${_autoHtml("✅ Kredi taksitlerini ve kart ekstreni zamanında öde (tamamını ödemek en iyisi).")}</li>
        <li>${_autoHtml("📉 Kart limitinin %30'undan azını kullan.")}</li>
        <li>${_autoHtml("📈 Seviye atla, servetini büyüt; hesabın eskidikçe notun güçlenir.")}</li>
        <li>${_autoHtml("⚖️ Gecikme, haciz ve icra notunu uzun süre düşürür.")}</li></ul></div>
    <div class="kart vergi-kart"><div><small>${_autoHtml("Vergi kimlik numaran")}</small><b>${esc(f.vergiNo)}</b></div><div><small>${_autoHtml("Vergi dairesi")}</small><b>${esc((h.oyuncu && h.oyuncu() && h.oyuncu().vergiDairesi) || '')}</b></div></div>`;
}

// ---------- Havale ----------
function havaleCiz(kutu, hv, d) {
  const hizli = hizliTutarlar(() => kutu.querySelector('[name=tutar]'), () => d.vadesiz);
  const tarihSaat = (ms) => new Date(ms + 3 * 3600000).toISOString().replace('T', ' ').slice(0, 16).split(' ').map((p, i) => (i ? p : p.split('-').reverse().join('.'))).join(' ');
  kutu.innerHTML = `
    <div class="kart havale-no"><div><small>${_autoHtml("IBAN'ın")}</small><b class="iban-yazi">${esc(hv.hesapNo)}</b></div><button class="dugme gri kucuk" data-kopyala>📋 ${_autoHtml("Kopyala")}</button></div>
    ${hv.engel ? `<div class="kart"><p class="kucuk" style="margin:0">${/seviye/.test(hv.engel) ? `${_autoHtml("Havale göndermek için")} <span class="kilit-rozet">${esc(hv.engel)}</span> ${_autoHtml("gerekir.")}` : esc(hv.engel)} ${_autoHtml("Sana gönderilen havaleler yine de hesabına geçer.")}</p></div>` : `
    <div class="kart"><h3>💸 ${_autoHtml("Para gönder")}</h3>
      <label class="alan"><span>${_autoHtml("Alıcının IBAN'ı")}</span><input name="alici" autocomplete="off" autocapitalize="characters" inputmode="text" placeholder="TR12 0077 7…"></label>
      <p class="kucuk soluk" style="margin:-6px 0 10px">${_autoHtml("Güvenliğin için havale ve EFT yalnızca IBAN ile yapılır. IBAN'ı alıcıdan iste.")}</p>
      <p class="kucuk havale-alici" data-alici hidden></p>
      <label class="alan"><span>${_autoHtml("Tutar (₺, en az 100)")}</span><input name="tutar" inputmode="decimal" placeholder="${_oyunHtml("finance.example", {value:"5.000"})}" autocomplete="off"></label>
      ${hizli.html}
      <label class="alan"><span>${_autoHtml("Açıklama (isteğe bağlı)")}</span><input name="aciklama" maxlength="80" placeholder="${_oyunHtml("finance.example", {value:_autoMetin("Ortakl\u0131k pay\u0131")})}"></label>
      <button class="dugme yesil" data-gonder>💸 ${_oyunHtml("finance.send")}</button>
      <div class="banka-ozet ikili" style="margin:12px 0 0"><div><small>${_autoHtml("Vadesiz bakiyen")}</small><b>${tl(d.vadesiz)}</b></div><div><small>${_autoHtml("Bugün gönderebileceğin")}</small><b>${tl(Math.max(0, hv.sinir - hv.bugun))}</b></div></div>
      <p class="kucuk soluk" style="margin:8px 0 0">${_autoSablon`Havale vadesiz hesabından gönderilir, anında ve ücretsizdir. Günlük sınırın ${tl(hv.sinir)}; seviye atladıkça artar. Gönderilen para geri alınamaz.`}</p>
    </div>`}
    <div class="kart"><div class="bk-baslik"><h3>${_autoHtml("Havale geçmişi")}</h3></div>
      ${hv.gecmis.length ? `<ul class="havale-listesi">${hv.gecmis.map((x) => `<li>
        <span class="hv-ikon ${x.giden ? 'giden' : 'gelen'}">${x.giden ? '↗' : '↙'}</span>
        <span class="hv-yazi"><b>${x.giden ? _autoSablon`${esc(x.kim || '?')} kişisine` : _autoSablon`${esc(x.kim || '?')} gönderdi`}</b><small>${tarihSaat(x.zaman)}${x.aciklama ? ` · ${esc(x.aciklama)}` : ''}</small></span>
        <span class="hv-tutar ${x.giden ? 'eksi' : 'arti'}">${x.giden ? '−' : '+'}${tl(x.tutar)}</span></li>`).join('')}</ul>` : `<p class="soluk" style="margin:0">${_autoHtml("Henüz havale yok.")}</p>`}
    </div>`;
  kutu.querySelector('[data-kopyala]').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(hv.hesapNo.replace(/\s+/g, '')); bildir(_autoMetin('IBAN kopyalandı.')); } catch (e) { bildir(hv.hesapNo); }
  });
  if (hv.engel) return;
  hizli.bagla(kutu);
  const aliciGirdi = kutu.querySelector('[name=alici]');
  const aliciYazi = kutu.querySelector('[data-alici]');
  let aliciBilgi = null;
  const aliciKontrol = async () => {
    const v = aliciGirdi.value.trim();
    aliciBilgi = null;
    if (v.replace(/\s+/g, '').length < 10) { aliciYazi.hidden = true; return; }
    try {
      aliciBilgi = await api('banka/havale/alici?ad=' + encodeURIComponent(v));
      aliciYazi.innerHTML = `✅ <b>${esc(aliciBilgi.ad)}</b> · ${esc(aliciBilgi.hesapNo)}`;
      aliciYazi.className = 'kucuk havale-alici iyi';
    } catch (e) {
      aliciYazi.textContent = '⚠️ ' + e.message;
      aliciYazi.className = 'kucuk havale-alici kotu';
    }
    aliciYazi.hidden = false;
  };
  let zamanlayici = null;
  aliciGirdi.addEventListener('input', () => { clearTimeout(zamanlayici); zamanlayici = setTimeout(aliciKontrol, 450); });
  kutu.querySelector('[data-gonder]').addEventListener('click', async (e) => {
    const t = tutarOku(kutu.querySelector('[name=tutar]').value);
    if (!aliciGirdi.value.trim()) return bildir(_autoMetin("Alıcının IBAN'ını yaz."), true);
    if (!t) return bildir(_oyunMetni("bank.enterAmount"), true);
    if (!aliciBilgi) await aliciKontrol();
    if (!aliciBilgi) return;
    const aciklama = kutu.querySelector('[name=aciklama]').value;
    if (!(await onayla(_autoSablon`${aliciBilgi.ad} (${aliciBilgi.hesapNo}) hesabına ${tamTl(t)} gönderilsin mi?${aciklama ? _autoSablon`\nAçıklama: ${aciklama}` : ''}\nGönderilen para geri alınamaz.`, { baslik: _oyunMetni("bank.tab.havale"), evet: _oyunMetni("finance.send"), ikon: '💸' }))) return;
    const r = await h.eylem(e.currentTarget, () => api('banka/havale', { alici: aliciGirdi.value.trim(), tutar: t, aciklama }));
    if (r === undefined) return;
    h.ses.para && h.ses.para();
    if (r.masak === 'durduruldu') bildir(_autoMetin('Havale gönderildi. Banka işlemlerin inceleme nedeniyle geçici olarak kısıtlandı.'), true);
    else bildir(_autoSablon`${tamTl(t)} ${r.alici} hesabına gönderildi.`);
    await h.durumYenile();
    bankaPaneli('havale');
  });
}

// ---------- Vadeli ----------
function vadeliCiz(kutu, d) {
  const toplam = d.vadeliler.reduce((s, v) => s + v.anapara, 0);
  const birikmis = d.vadeliler.reduce((s, v) => s + v.birikmis, 0);
  const kullanilabilir = d.vadesiz + d.nakit;
  const hizli = hizliTutarlar(() => kutu.querySelector('[name=tutar]'), () => kullanilabilir, () => hesapla());
  const enYakin = d.vadeliler.filter((v) => v.kalanMs > 0).sort((a, b) => a.kalanMs - b.kalanMs)[0];
  kutu.innerHTML = `
    <div class="tefon-kart vadeli-kart">
      <div class="tefon-ust"><span class="tefon-logo">${_autoMetin("TEFON<b>BANK</b>")}</span><span class="doviz-rozet">📈 ${_autoHtml("Vadeli")}</span></div>
      <small>${_autoHtml("Vadeli hesaplar toplam bakiye")}</small>
      <div class="tefon-bakiye">${tl(toplam + birikmis)}</div>
      <div class="tefon-alt"><span>${_autoSablon`${d.vadeliler.length} hesap · anapara ${tl(toplam)}`}</span><span class="arti-acik">+${tl(birikmis)} ${_autoHtml("faiz")}</span></div>
      ${enYakin ? `<div class="tefon-alt" style="margin-top:6px"><span>${_autoSablon`İlk vade: ${sureMetni(enYakin.kalanMs)} sonra`}</span></div>` : ''}
    </div>
    <div class="kart"><h3>📈 ${_autoHtml("Yeni vadeli hesap")}</h3>
      <div class="vade-secimi">${d.vadeler.map((v, i) => `<button data-gun="${v.gun}" aria-pressed="${i === 1}"><b>${esc(_autoMetin(v.ad))}</b><span class="vade-faiz">%${Number(v.faiz).toLocaleString(sayiDili())}</span><small class="soluk">${_autoSablon`yıllık · ${ekonomiGunuMetni(d, v.gun)}`}</small></button>`).join('')}</div>
      <label class="alan"><span>${_autoHtml("Tutar (₺, en az 1.000)")}</span><input name="tutar" inputmode="decimal" placeholder="${_oyunHtml("finance.example", {value:"50.000"})}" autocomplete="off"></label>
      ${hizli.html}
      <div class="vade-hesap" id="vade-hesap" hidden></div>
      <button class="dugme yesil" data-ac>📈 ${_autoHtml("Vadeli hesap aç")}</button>
      <p class="kucuk soluk">${_autoSablon`Para önce vadesiz hesabından, yetmezse nakitten alınır. Faizden %${d.stopaj} stopaj (vergi) kesilir. Vade dolmadan bozarsan faiz yanar, anapara vadesiz hesabına döner. Oyunda 1 ekonomi günü gerçekte ${sureMetni(d.ekonomiGunuMs)} sürer.`}</p>
    </div>
    <div class="kart"><div class="bk-baslik"><h3>${_autoHtml("Vadeli hesaplarım")}</h3>${d.vadeliler.length ? `<span class="rozetcik bilgi">${_autoSablon`${d.vadeliler.length} hesap`}</span>` : ''}</div>
      ${d.vadeliler.length ? `<div class="banka-ozet ikili"><div><small>${_autoHtml("Toplam anapara")}</small><b>${tl(toplam)}</b></div><div><small>${_autoHtml("Şimdiye kadar biriken net faiz")}</small><b class="arti">+${tl(birikmis)}</b></div></div>
      <ul class="hesap-kartlari">${d.vadeliler.map((v) => {
        const vad = d.vadeler.find((x) => x.gun === v.gun);
        const doldu = v.kalanMs <= 0;
        return `<li class="hesap-karti${doldu ? ' doldu' : ''}">
          <div class="hk-ust"><b class="hk-tutar">${tl(v.anapara)}</b><span class="rozetcik">${esc(vad ? _autoMetin(vad.ad) : _oyunMetni("notify.daysHours",{days:v.gun,hours:0}))} · %${Number(v.faiz).toLocaleString(sayiDili())}</span></div>
          <div class="ilerleme"><i style="width:${Math.round(v.oran * 100)}%"></i></div>
          <div class="hk-izgara">
            <div><small>${_autoHtml("Net faiz")}</small><b class="arti">+${tl(v.net)}</b></div>
            <div><small>${_autoHtml("Vade sonunda")}</small><b>${tl(v.anapara + v.net)}</b></div>
            <div><small>${doldu ? _autoMetin("Durum") : _autoMetin("Kalan süre")}</small><b>${doldu ? _autoMetin("Vade doldu") : sureMetni(v.kalanMs)}</b></div>
            <div><small>${_autoHtml("Bitiş")}</small><b>${tarihYaz(v.bitis)}</b></div>
          </div>
          ${doldu ? '' : `<button class="dugme gri kucuk" data-boz="${v.id}">${_autoHtml("Vadeyi boz")}</button>`}
        </li>`;
      }).join('')}</ul>` : `<p class="soluk" style="margin:0">${_autoHtml("Henüz vadeli hesabın yok. Yukarıdan bir vade seçip aç; paran faiz kazansın.")}</p>`}
    </div>`;
  hizli.bagla(kutu);
  let gun = d.vadeler[1].gun;
  const girdi = kutu.querySelector('[name=tutar]');
  function hesapla() {
    const t = tutarOku(girdi.value);
    const v = d.vadeler.find((x) => x.gun === gun);
    const brut = Math.round(t * (v.faiz / 100) * (gun / 365));
    const net = Math.round(brut * (1 - d.stopaj / 100));
    const el = kutu.querySelector('#vade-hesap');
    el.hidden = !t;
    el.innerHTML = t ? `<div><small>${_autoHtml("Vade sonunda")}</small><b>${tl(t + net)}</b></div><div><small>${_autoHtml("Net faiz")}</small><b class="arti">+${tl(net)}</b></div><div><small>${_autoHtml("Stopaj")}</small><b>${tl(brut - net)}</b></div>` : '';
  }
  kutu.querySelectorAll('[data-gun]').forEach((b) => b.addEventListener('click', () => {
    gun = Number(b.dataset.gun);
    kutu.querySelectorAll('[data-gun]').forEach((x) => x.setAttribute('aria-pressed', x === b));
    hesapla();
  }));
  girdi.addEventListener('input', hesapla);
  kutu.querySelector('[data-ac]').addEventListener('click', async (e) => {
    const t = tutarOku(girdi.value);
    if (!t) return bildir(_oyunMetni("bank.enterAmount"), true);
    if ((await h.eylem(e.currentTarget, () => api('banka/vadeli', { tutar: t, gun }))) === undefined) return;
    bildir(_autoMetin("Vadeli hesabın açıldı. Vade dolunca para faiziyle vadesiz hesabına geçer."));
    await h.durumYenile();
    bankaPaneli();
  });
  kutu.querySelectorAll('[data-boz]').forEach((b) => b.addEventListener('click', async () => {
    if (!(await onayla(_autoMetin("Vadeyi bozarsan bu hesabın faizini kaybedersin. Anapara vadesiz hesabına döner."), { baslik: _autoMetin('Vadeyi boz'), evet: _autoMetin('Boz'), tehlike: true, ikon: '⚠️' }))) return;
    if ((await h.eylem(b, () => api(`banka/vadeli/${b.dataset.boz}/boz`, {}))) === undefined) return;
    bankaPaneli();
  }));
}

// ---------- Kredi ----------
function krediCiz(kutu, d) {
  const taksitHesapla = (P, yillik, n) => { const r = yillik / 100 / 12; return Math.ceil((P * r) / (1 - Math.pow(1 + r, -n))); };
  // 0.41: üst özet: toplam kredi limiti, kullanılan ve kullanılabilir
  const kullanilan = d.krediler.reduce((t, k) => t + k.kalan + k.gecikmeFaizi, 0);
  const kullanilabilir = Math.max(0, ...d.krediTurleri.filter((t) => !t.engel || /yetmiyor/.test(t.engel)).map((t) => t.limit), 0);
  const limit = kullanilan + kullanilabilir;
  const oran = limit ? Math.min(100, Math.round((100 * kullanilan) / limit)) : 0;
  kutu.innerHTML = `
    <div class="kart kk-limit kredi-limit-ozet"><div class="kk-limit-ust"><div><small>${_autoHtml("Kredi limitin")}</small><b>${tl(limit)}</b></div><div class="sag"><small>${_autoHtml("Kullanılan")}</small><b class="${kullanilan ? 'eksi' : ''}">${tl(kullanilan)}</b></div></div>
      <div class="kk-cubuk"><div style="width:${oran}%" class="${oran > 70 ? 'yuksek' : ''}"></div></div>
      <div class="kucuk soluk">${_autoSablon`Kullanılabilir ${tl(kullanilabilir)} · ${d.krediler.length} açık kredi`}</div></div>
    ${d.krediler.length ? `<div class="kart"><div class="bk-baslik"><h3>${_autoHtml("Kredilerim")}</h3><span class="rozetcik bilgi">${_autoSablon`${d.krediler.length} kredi`}</span></div>
      <ul class="hesap-kartlari">${d.krediler.map((k) => `<li class="hesap-karti${k.geciken ? ' gecikmis' : ''}">
        <div class="hk-ust"><b class="hk-tutar">${esc(_autoMetin(k.ad))}</b><span class="rozetcik">${_autoSablon`%${Number(k.faiz).toLocaleString(sayiDili())} · ${k.taksitSayisi} ay`}</span></div>
        <div class="ilerleme"><i style="width:${Math.round((k.odenen / k.taksitSayisi) * 100)}%"></i></div>
        <div class="hk-izgara">
          <div><small>${_autoHtml("Çekilen")}</small><b>${tl(k.anapara)}</b></div>
          <div><small>${_autoHtml("Kalan borç")}</small><b class="eksi">${tl(k.kalan)}</b></div>
          <div><small>${_autoHtml("Aylık taksit")}</small><b>${tl(k.taksit)}</b></div>
          <div><small>${_autoHtml("Ödenen")}</small><b>${k.odenen}/${k.taksitSayisi}</b></div>
          <div><small>${_autoHtml("Sonraki taksit")}</small><b>${_autoSablon`${sureMetni(Math.max(0, k.sonrakiTaksit - simdi()))} sonra`}</b></div>
          ${k.geciken ? `<div><small>${_autoHtml("Gecikme")}</small><b class="eksi">${_autoSablon`${k.geciken} taksit (+${tl(k.gecikmeFaizi)})`}</b></div>` : ''}
        </div>
        <button class="dugme gri kucuk" data-kapat-kredi="${k.id}">${_autoHtml("Krediyi erken kapat")}</button></li>`).join('')}</ul>
      <p class="kucuk soluk">${_autoHtml("Taksitler her ay (30 ekonomi günü) önce vadesiz hesabından, yetmezse nakitten kendiliğinden çekilir. Erken kapatırsan kalan faizi ödemezsin (%1 erken ödeme ücreti).")}</p></div>` : ''}
    ${d.karaListe ? `<div class="kart uyari">${_autoSablon`⚖️ Haciz nedeniyle ${sureMetni(d.karaListe - simdi())} daha kredi alamazsın.`}</div>` : ''}
    ${d.krediTurleri.map((t) => `<div class="kart kredi-karti${t.engel ? ' kilitli' : ''}" data-tur="${t.kod}">
      <div class="kredi-ust"><span class="tesis-simge">${t.simge}</span><div class="kredi-ad"><b>${esc(_autoMetin(t.ad))}</b><small class="soluk">${esc(_autoMetin(t.aciklama))}</small></div><div class="kredi-faiz"><b>%${Number(t.faiz).toLocaleString(sayiDili())}</b><small>${_autoHtml("yıllık")}</small></div></div>
      ${t.engel ? `<p class="kucuk" style="margin:10px 0 0">${/seviye/.test(t.engel) ? `<span class="kilit-rozet">${esc(t.engel.replace('de açılır.', '').replace('da açılır.', ''))}</span> ${_autoHtml("gerekli")}` : `🔒 ${esc(t.engel)}`}</p>` : `
      <div class="banka-ozet ikili"><div><small>${_autoHtml("Kredi limitin")}</small><b>${tl(t.limit)}</b></div><div><small>${_autoHtml("En az")}</small><b>${tl(t.enAz)}</b></div></div>
      <label class="alan"><span>${_oyunHtml("bank.amount")}</span><input name="tutar" inputmode="decimal" placeholder="en az ${tl(t.enAz)}" autocomplete="off"></label>
      <div class="vade-secimi">${t.taksitler.map((n, i) => `<button data-taksit="${n}" aria-pressed="${i === 1}"><b>${_autoSablon`${n} ay`}</b></button>`).join('')}</div>
      <div class="vade-hesap" data-ozet hidden></div>
      <button class="dugme yesil" data-cek>💼 ${_autoHtml("Krediyi kullan")}</button>`}
    </div>`).join('')}
    <div class="kart"><h3>${_autoHtml("Kurallar")}</h3><ul class="kural-listesi">
      <li>${_autoSablon`Kredi tutarından binde ${(d.tahsis * 10).toLocaleString(sayiDili())} tahsis ücreti kesilir.`}</li>
      <li>${_autoHtml("Ödenemeyen taksit gecikmeye düşer, her ekonomi günü binde 2 gecikme faizi işler.")}</li>
      <li>${_autoMetin("<b>3 taksit üst üste ödenmezse haciz:</b> nakit ve vadeli hesaplar, sonra ambardaki mal, sonra tesislerin satılarak borç kapatılır; bir süre kredi alamazsın.")}</li>
      <li>${_autoHtml("Kredi borcu servetinden düşülür.")}</li></ul></div>`;
  kutu.querySelectorAll('.kredi-karti').forEach((k) => {
    const t = d.krediTurleri.find((x) => x.kod === k.dataset.tur);
    if (t.engel) return;
    let n = t.taksitler[1];
    const girdi = k.querySelector('[name=tutar]');
    const ozet = () => {
      const P = tutarOku(girdi.value);
      const ts = P ? taksitHesapla(P, t.faiz, n) : 0;
      const el = k.querySelector('[data-ozet]');
      el.hidden = !P;
      el.innerHTML = P ? `<div><small>${_autoHtml("Aylık taksit")}</small><b>${tl(ts)}</b></div><div><small>${_autoHtml("Toplam geri ödeme")}</small><b>${tl(ts * n)}</b></div><div><small>${_autoHtml("Toplam faiz")}</small><b class="eksi">${tl(ts * n - P)}</b></div>` : '';
    };
    k.querySelectorAll('[data-taksit]').forEach((b) => b.addEventListener('click', () => {
      n = Number(b.dataset.taksit);
      k.querySelectorAll('[data-taksit]').forEach((x) => x.setAttribute('aria-pressed', x === b));
      ozet();
    }));
    girdi.addEventListener('input', ozet);
    k.querySelector('[data-cek]').addEventListener('click', async (e) => {
      const P = tutarOku(girdi.value);
      if (!P) return bildir(_oyunMetni("bank.enterAmount"), true);
      const ts = taksitHesapla(P, t.faiz, n);
      if (!(await onayla(_autoSablon`${tamTl(P)} ${t.ad.toLocaleLowerCase('tr')}\n${n} ay × ${tamTl(ts)}\nToplam geri ödeme: ${tamTl(ts * n)}`, { baslik: _oyunMetni("ui.939dca4baf65"), evet: _oyunMetni("finance.confirm"), ikon: '🏦' }))) return;
      if ((await h.eylem(e.currentTarget, () => api('banka/kredi', { tur: t.kod, tutar: P, taksit: n }))) === undefined) return;
      h.ses.seviye && h.ses.seviye();
      bildir(_autoMetin("Kredi hesabına geçti. İyi işler!"));
      await h.durumYenile();
      bankaPaneli();
    });
  });
  kutu.querySelectorAll('[data-kapat-kredi]').forEach((b) => b.addEventListener('click', async () => {
    if (!(await onayla(_autoMetin("Krediyi şimdi kapatmak istiyor musun? Kalan anapara ve %1 erken ödeme ücreti alınır."), { baslik: _autoMetin('Krediyi kapat'), evet: _oyunMetni("finance.close"), ikon: '🏦' }))) return;
    if ((await h.eylem(b, () => api(`banka/kredi/${b.dataset.kapatKredi}/kapat`, {}))) === undefined) return;
    bildir(_autoMetin("Kredin kapandı."));
    await h.durumYenile();
    bankaPaneli();
  }));
}

// ---------- 0.41: Hesap hareketleri (vadesiz hesap) ----------
const HAREKET_IKON = { yatir: '⬇️', cek: '⬆️', havale: '💸', vadeli: '📈', faiz: '💰', odeme: '🧾', haciz: '⚖️', iade: '↩️', diger: '•' };
const tarihSaatYaz = (ms) => { const s = new Date(ms + 3 * 3600000).toISOString(); return s.slice(0, 10).split('-').reverse().join('.') + ' ' + s.slice(11, 16); };
function hareketCiz(kutu, d, r) {
  let liste = r.liste, devam = r.devam;
  const ciz = () => {
    let sonGun = '';
    const giris = liste.filter((x) => x.tutar > 0).reduce((t, x) => t + x.tutar, 0), cikis = liste.filter((x) => x.tutar < 0).reduce((t, x) => t - x.tutar, 0);
    kutu.innerHTML = `
      <div class="tefon-kart"><div class="tefon-ust"><span class="tefon-logo">${_autoMetin("TEFON<b>BANK</b>")}</span><span class="doviz-rozet">📜 ${_oyunHtml('bank.tab.hareket')}</span></div>
        <small>${_oyunHtml("bank.balance")}</small><div class="tefon-bakiye">${tl(d.vadesiz)}</div>
        <div class="tefon-alt"><span>${numaraHtml(d.hesapNo, ibanMaske(d.hesapNo), _autoMetin('IBAN\'ı göster / gizle'))}</span></div></div>
      <div class="banka-ozet"><div><small>⬇️ ${_autoHtml("Giriş (listede)")}</small><b class="arti">+${tl(giris)}</b></div><div><small>⬆️ ${_autoHtml("Çıkış (listede)")}</small><b class="eksi">−${tl(cikis)}</b></div></div>
      <div class="kart">${liste.length ? `<ul class="bh-liste">${liste.map((x) => {
        const g = tarihYaz(x.zaman);
        const bas = g !== sonGun ? `<li class="gun-baslik">${g}</li>` : '';
        sonGun = g;
        return `${bas}<li class="bh-satir"><span class="bh-ik">${HAREKET_IKON[x.tur] || '•'}</span><span class="bh-ac"><b>${esc(_autoMetin(x.aciklama))}</b><small>${tarihSaatYaz(x.zaman).slice(11)} · ${_autoSablon`Bakiye ${tl(x.bakiye)}`}</small></span>
          <b class="bh-tutar ${x.tutar >= 0 ? 'arti' : 'eksi'}">${x.tutar >= 0 ? '+' : '−'}${tl(Math.abs(x.tutar))}</b></li>`;
      }).join('')}</ul>${devam ? `<button class="dugme gri kucuk" data-daha style="width:100%">${_autoHtml("Daha eski hareketler")}</button>` : ''}`
        : `<p class="soluk" style="margin:0">${_autoHtml("Henüz hesap hareketi yok. Para yatırınca, çekince, havale ya da ödeme yapınca burada görünür.")}</p>`}</div>
      <p class="kucuk soluk">${_autoHtml("Vadesiz hesabındaki tüm giriş ve çıkışlar. Nakit cüzdan hareketleri Bildirimler → Hesap hareketleri'nde.")}</p>`;
    numaraBagla(kutu);
    const daha = kutu.querySelector('[data-daha]');
    if (daha) daha.addEventListener('click', async () => {
      daha.disabled = true;
      try { const y = await api('banka/hareketler?once=' + liste[liste.length - 1].id); liste = liste.concat(y.liste); devam = y.devam; ciz(); } catch (e) { bildir(e.message, true); daha.disabled = false; }
    });
  };
  ciz();
}

// ---------- 0.41: Ödemeler (kira, fatura, vergi, kart, kredi, icra) ----------
function odemeCiz(kutu, r) {
  const satir = ({ ik, ad, alt, tutar, eylem, veri, etiket, tehlike }) => `<li class="odeme-satir${tehlike ? ' tehlike' : ''}"><span class="od-ik">${ik}</span>
      <span class="od-ac"><b>${esc(ad)}</b><small>${alt}</small></span>
      <span class="od-sag"><b class="${tutar > 0 ? 'eksi' : ''}">${tl(tutar)}</b>${eylem ? `<button class="dugme ${tehlike ? 'kirmizi' : 'yesil'} kucuk" data-ode="${eylem}" data-veri="${esc(veri || '')}">${esc(etiket || _oyunMetni('finance.pay'))}</button>` : ''}</span></li>`;
  const kiralar = r.dukkanlar.map((dk) => satir({
    ik: dk.simge || '🏪', ad: dk.ad,
    alt: dk.kasa < 0 ? _autoSablon`Kira, maaş ve fatura borcu · ${dk.borcGun} gündür` : dk.mulk ? _autoSablon`Mülk senin · günlük gider ${tl(dk.gunlukGider)} (fatura ve maaş)` : _autoSablon`Aylık kira ${tl(dk.kira)} · günlük gider ${tl(dk.gunlukGider)} · kasadan ödeniyor`,
    tutar: Math.max(0, -dk.kasa), eylem: dk.kasa < 0 ? 'dukkan' : '', veri: dk.id, tehlike: dk.kasa < 0 && dk.borcGun >= 3,
  }));
  const vergiler = r.vergiler.map((v) => satir({ ik: '🧾', ad: _autoSablon`Vergi · ${v.donem}`, alt: v.gecikti ? _autoHtml('Gecikti, ceza işliyor') : _autoSablon`Son ödeme ${tarihYaz(v.sonOdeme)}`, tutar: v.kalan, eylem: 'vergi', veri: v.id, tehlike: v.gecikti }));
  const kart = r.kart && r.kart.ekstreKalan > 0 ? [
    satir({ ik: '💳', ad: _autoHtml('Kredi kartı ekstresi'), alt: r.kart.sonOdeme ? _autoSablon`Son ödeme ${tarihYaz(r.kart.sonOdeme)} · asgari ${tl(r.kart.asgariKalan)}` : '', tutar: r.kart.ekstreKalan, eylem: 'kart', veri: r.kart.ekstreKalan, etiket: _autoMetin('Tamamını öde'), tehlike: r.kart.gecikme > 0 }),
    ...(r.kart.asgariKalan > 0 && r.kart.asgariKalan < r.kart.ekstreKalan ? [satir({ ik: '💡', ad: _autoHtml('Kart asgari ödeme'), alt: _autoHtml('En az bu kadarını ödersen gecikme olmaz'), tutar: r.kart.asgariKalan, eylem: 'kart', veri: r.kart.asgariKalan, etiket: _autoMetin('Asgariyi öde') })] : []),
  ] : [];
  const krediler = r.krediler.map((k) => satir({
    ik: '💼', ad: _autoMetin(k.ad),
    alt: k.geciken ? _autoSablon`${k.geciken} taksit gecikti (gecikme faiziyle)` : _autoSablon`Sonraki taksit ${sureMetni(Math.max(0, k.sonraki - simdi()))} sonra · kendiliğinden çekilir`,
    tutar: k.geciken ? k.gecikenTutar : k.taksit, eylem: k.geciken ? 'kredi' : '', veri: k.id, tehlike: !!k.geciken,
  }));
  const icralar = r.icralar.map((x) => satir({ ik: '⚖️', ad: _autoSablon`İcra dosyası ${x.dosyaNo}`, alt: esc(x.alacakli || ''), tutar: x.kalan, eylem: 'icra', veri: x.kalan, tehlike: true }));
  const grup = (baslik, l, bos) => `<div class="kart"><h3>${baslik}</h3>${l.length ? `<ul class="odeme-liste">${l.join('')}</ul>` : `<p class="soluk kucuk" style="margin:0">${bos}</p>`}</div>`;
  kutu.innerHTML = `
    <div class="kart kk-limit"><div class="kk-limit-ust"><div><small>${_autoHtml("Ödenmesi gereken")}</small><b class="${r.odenecek ? 'eksi' : 'arti'}">${tl(r.odenecek)}</b></div><div class="sag"><small>${_autoHtml("Vadesiz + nakit")}</small><b>${tl(r.vadesiz + r.nakit)}</b></div></div>
      <p class="kucuk soluk" style="margin:6px 0 0">${_autoHtml("Ödemeler önce vadesiz hesabından, yetmezse nakdinden çekilir.")}</p></div>
    ${grup(_autoMetin('🏪 Kira ve faturalar'), kiralar, _autoHtml('Kiraladığın dükkân yok.'))}
    ${grup(_autoMetin('🧾 Vergi'), vergiler, _autoHtml('Ödenecek vergi borcun yok.'))}
    ${grup(_autoMetin('💳 Kredi kartı'), kart, r.kart ? _autoHtml('Ödenecek ekstre borcun yok.') : _autoHtml('Kredi kartın yok.'))}
    ${grup(_autoMetin('💼 Kredi taksitleri'), krediler, _autoHtml('Açık kredin yok.'))}
    ${icralar.length ? grup(_autoMetin('⚖️ İcra'), icralar, '') : ''}`;
  kutu.querySelectorAll('[data-ode]').forEach((b) => b.addEventListener('click', async () => {
    const tur = b.dataset.ode, v = b.dataset.veri;
    const yol = { dukkan: () => api(`isletme/${v}/borc-ode`, {}), vergi: () => api('vergi/ode', { id: Number(v) }), kart: () => api('finans/kart/ode', { tutar: Number(v) }),
      kredi: () => api(`banka/kredi/${v}/geciken`, {}), icra: () => api('finans/icra/ode', { tutar: Number(v) }) }[tur];
    if (!yol) return;
    const r2 = await h.eylem(b, yol);
    if (r2 === undefined) return;
    h.ses.kasa && h.ses.kasa();
    bildir(_autoMetin('Ödeme yapıldı.'));
    await h.durumYenile();
    bankaPaneli('odeme');
  }));
}

// ---------- 0.41: Kart ekstresi ----------
function ekstreCiz(kutu, r) {
  const o = h.oyuncu ? h.oyuncu() : null;
  if (!r.kart) {
    kutu.innerHTML = `<div class="bos-durum"><span>💳</span><b>${_autoHtml("Kredi kartın yok")}</b><small>${_autoHtml("Kart sekmesinden başvurabilirsin.")}</small><button class="dugme yesil" data-git-kart>💳 ${_oyunHtml('bank.tab.kart')}</button></div>`;
    kutu.querySelector('[data-git-kart]').addEventListener('click', () => { h.ses.tik(); bankaPaneli('kart'); });
    return;
  }
  const k = r.kart;
  let secili = 0;
  const ciz = () => {
    const dn = r.donemler[secili] || r.donemler[0];
    kutu.innerHTML = `
      ${kartGorseli(k, o ? o.kullaniciAdi.toLocaleUpperCase('tr') : '', { durum: k.durum })}
      <div class="cipler ekstre-donemler">${r.donemler.map((x, i) => `<button class="cip ${i === secili ? 'secili' : ''}" data-donem="${i}">${x.guncel ? _autoHtml('Güncel dönem') : tarihYaz(x.kesim)}</button>`).join('')}</div>
      <div class="kart ekstre-ozet"><h3>${dn.guncel ? _autoSablon`Güncel dönem · kesim ${tarihYaz(dn.kesim)}` : _autoSablon`${tarihYaz(dn.kesim)} tarihli ekstre`}</h3>
        <div class="banka-ozet">
          ${dn.guncel ? '' : `<div><small>🧾 ${_autoHtml("Ekstre tutarı")}</small><b>${tl(dn.ekstre || 0)}</b></div>`}
          <div><small>🛍️ ${_autoHtml("Harcamalar")}</small><b>${tl(dn.harcama)}</b></div>
          <div><small>✅ ${_autoHtml("Ödemeler")}</small><b class="arti">${tl(dn.odeme)}</b></div>
          <div><small>📈 ${_autoHtml("Faiz")}</small><b class="${dn.faiz ? 'eksi' : ''}">${tl(dn.faiz)}</b></div>
          ${dn.guncel ? `<div><small>💡 ${_autoHtml("Asgari (son ekstre)")}</small><b>${tl(k.asgariKalan)}</b></div>` : ''}
        </div>
        ${dn.hareketler.length ? `<ul class="kk-hareketler">${dn.hareketler.map((x) => {
          const [ik, sinif] = KART_HAREKET[x.tur] || ['•', ''];
          return `<li><span class="kk-ik">${ik}</span><span class="kk-ac">${esc(_autoMetin(x.aciklama || x.tur))}<small>${tarihSaatYaz(x.zaman)}</small></span><b class="${sinif}">${x.tutar ? (x.tutar < 0 ? '−' : '') + tl(Math.abs(x.tutar)) : ''}</b></li>`;
        }).join('')}</ul>` : `<p class="soluk kucuk" style="margin:0">${_autoHtml("Bu dönemde hareket yok.")}</p>`}
      </div>
      ${k.ekstreKalan > 0 ? `<button class="dugme yesil" data-git-odeme style="width:100%">🧾 ${_autoSablon`Ekstreyi öde (${tl(k.ekstreKalan)})`}</button>` : ''}`;
    numaraBagla(kutu);
    kutu.querySelectorAll('[data-donem]').forEach((b) => b.addEventListener('click', () => { h.ses.tik(); secili = Number(b.dataset.donem); ciz(); }));
    const go = kutu.querySelector('[data-git-odeme]');
    if (go) go.addEventListener('click', () => { h.ses.tik(); bankaPaneli('odeme'); });
  };
  ciz();
}

// ---------- Döviz, altın, gümüş ----------
function kucukGrafik(dizi) {
  if (!dizi || dizi.length < 2) return '';
  const en = Math.min(...dizi), ek = Math.max(...dizi);
  const g = 120, y = 34;
  const nokta = dizi.map((v, i) => `${(i / (dizi.length - 1)) * g},${ek === en ? y / 2 : y - ((v - en) / (ek - en)) * (y - 4) - 2}`).join(' ');
  const artis = dizi[dizi.length - 1] >= dizi[0];
  return `<svg class="mini-grafik" viewBox="0 0 ${g} ${y}" width="${g}" height="${y}" aria-hidden="true"><polyline points="${nokta}" fill="none" stroke="${artis ? '#1F8F52' : '#C0392B'}" stroke-width="2" stroke-linejoin="round"/></svg>`;
}
function fiyatYaz(k) { return (k / 100).toLocaleString(sayiDili(), { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₺'; }
function dovizCiz(kutu, y) {
  const kaynaklar = [...new Set(y.liste.map((x) => x.kaynak))].join(', ');
  const son = Math.max(...y.liste.map((x) => x.guncelleme || 0));
  kutu.innerHTML = `
    <div class="tefon-kart altin-kart"><div class="tefon-ust"><span class="tefon-logo">${_autoMetin("TEFON<b>BANK</b>")}</span><span class="doviz-rozet">🥇 ${_autoHtml("Döviz · Altın")}</span></div>
      <small>${_autoHtml("Döviz ve altın varlığın")}</small><div class="tefon-bakiye">${tl(y.toplamDeger)}</div>
      <p class="kucuk" style="margin:4px 0 0">${y.toplamMaliyet ? `${_autoSablon`Maliyet ${tl(y.toplamMaliyet)} · <b class="${y.toplamDeger >= y.toplamMaliyet ? 'arti' : 'eksi'}">${y.toplamDeger >= y.toplamMaliyet ? '+' : ''}${tl(y.toplamDeger - y.toplamMaliyet)}</b>`}` : _autoMetin("Henüz döviz ya da altının yok.")}</p></div>
    <ul class="satirlar doviz-listesi">${y.liste.map((x) => `<li data-kod="${x.kod}">
      <button class="doviz-satir" data-ac>
        <span class="doviz-simge">${x.simge}</span>
        <span class="doviz-ad"><b>${esc(_autoMetin(x.ad))}</b><small class="soluk">${_autoSablon`Al ${fiyatYaz(x.satis)} · Sat ${fiyatYaz(x.alis)}`}</small>${x.miktar ? `<small>${_autoHtml("Elinde")} <b>${x.miktar.toLocaleString(sayiDili())} ${esc(_bankBirim(x.birim))}</b> = ${tl(x.deger)} <span class="${x.karZarar >= 0 ? 'arti' : 'eksi'}">(${x.karZarar >= 0 ? '+' : ''}${tl(x.karZarar)})</span></small>` : ''}</span>
        <span class="doviz-sag">${kucukGrafik(x.gecmis)}${x.degisim != null ? `<small class="${x.degisim >= 0 ? 'arti' : 'eksi'}">${x.degisim >= 0 ? '▲' : '▼'} %${Math.abs(x.degisim).toLocaleString(sayiDili())}</small>` : ''}</span>
      </button>
      <div class="doviz-islem" hidden>
        <label class="alan"><span>${_autoSablon`Miktar (${esc(_bankBirim(x.birim))})`}</span><input name="miktar" inputmode="decimal" placeholder="${_oyunHtml("finance.example", {value:x.ondalik ? "10" : "1"})}"></label>
        <p class="kucuk" data-ozet></p>
        <div class="dugme-satiri"><button class="dugme yesil" data-al>${_oyunHtml("finance.buy")}</button><button class="dugme" data-sat ${x.miktar ? '' : 'disabled'}>${_oyunHtml("ui.fdeb71b569e0")}</button></div>
      </div></li>`).join('')}</ul>
    <p class="kucuk soluk">${_autoSablon`Kurlar gerçek piyasadan gelir (${esc(kaynaklar)}), yarım saatte bir yenilenir${son ? _autoSablon`; son güncelleme ${new Date(son).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}` : ''}. Bankanın işlem payı %${y.islemPayi.toLocaleString(sayiDili())}. Elindeki döviz ve altın servetine sayılır. Gerçek kurlar düşebilir de, yükselebilir de.`}</p>`;
  kutu.querySelectorAll('[data-kod]').forEach((li) => {
    const x = y.liste.find((z) => z.kod === li.dataset.kod);
    const islem = li.querySelector('.doviz-islem');
    li.querySelector('[data-ac]').addEventListener('click', () => { islem.hidden = !islem.hidden; });
    const girdi = li.querySelector('[name=miktar]');
    const oku = () => Number(String(girdi.value).replace(',', '.'));
    girdi.addEventListener('input', () => {
      const m = oku();
      li.querySelector('[data-ozet]').innerHTML = m > 0 ? _autoSablon`Alırsan ${tamTl(m * x.satis)} öder, satarsan ${tamTl(m * x.alis)} alırsın.` : '';
    });
    li.querySelector('[data-al]').addEventListener('click', async (e) => {
      const m = oku();
      if (!(m > 0)) return bildir(_oyunMetni("bank.enterQuantity"), true);
      const r = await h.eylem(e.currentTarget, () => api('yatirim/al', { kod: x.kod, miktar: m }));
      if (r === undefined) return;
      bildir(_autoSablon`${r.miktar.toLocaleString(sayiDili())} ${x.birim} ${x.ad.toLocaleLowerCase('tr')} aldın (${tamTl(r.tutar)}).`);
      await h.durumYenile();
      bankaPaneli();
    });
    li.querySelector('[data-sat]').addEventListener('click', async (e) => {
      const m = oku();
      if (!(m > 0)) return bildir(_oyunMetni("bank.enterQuantity"), true);
      const r = await h.eylem(e.currentTarget, () => api('yatirim/sat', { kod: x.kod, miktar: m }));
      if (r === undefined) return;
      bildir(_autoSablon`Sattın: ${tamTl(r.tutar)} (${r.karZarar >= 0 ? _autoHtml('kâr') : 'zarar'} ${tamTl(Math.abs(r.karZarar))}).`);
      await h.durumYenile();
      bankaPaneli();
    });
  });
}
