<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#06152f">
  <title>Çırak – Çıraklıktan Patronluğa | Ücretsiz Online Ticaret ve İşletme Oyunu</title>
  <meta name="description" content="Çırak, Türkiye'nin 81 ilinde gerçek mahalle ve sokaklarda geçen ücretsiz online ticaret oyunu. Simit tezgâhıyla başla, bakkal aç, fabrika kur, holding patronu ol. Tarayıcıda ve telefonda, indirmeden oyna.">
  <meta name="keywords" content="Çırak, çırak oyunu, ticaret oyunu, online ticaret oyunu, işletme oyunu, tarayıcı oyunu, ücretsiz online oyun, Türk oyunu, simülasyon oyunu, esnaf oyunu, dükkan oyunu, bakkal oyunu, simitçi oyunu, patron oyunu, holding oyunu, ekonomi oyunu, strateji oyunu, mobil oyun, çok oyunculu oyun, MMO">
  <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
  <meta name="author" content="Çırak">
  <meta name="application-name" content="Çırak">
  <meta name="format-detection" content="telephone=no">
  <link rel="canonical" href="https://oyunsitem.com/cirak/">
  <link rel="alternate" hreflang="tr" href="https://oyunsitem.com/cirak/">
  <link rel="alternate" hreflang="x-default" href="https://oyunsitem.com/cirak/">
  <!-- Open Graph (Facebook, WhatsApp, LinkedIn, Telegram) -->
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Çırak">
  <meta property="og:locale" content="tr_TR">
  <meta property="og:url" content="https://oyunsitem.com/cirak/">
  <meta property="og:title" content="Çırak – Çıraklıktan Patronluğa">
  <meta property="og:description" content="Simit tezgâhıyla başla, bakkal aç, fabrika kur, holding patronu ol. Türkiye'nin gerçek sokaklarında geçen ücretsiz online ticaret oyunu.">
  <meta property="og:image" content="https://oyunsitem.com/cirak/paylasim.jpg">
  <meta property="og:image:secure_url" content="https://oyunsitem.com/cirak/paylasim.jpg">
  <meta property="og:image:type" content="image/jpeg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="628">
  <meta property="og:image:alt" content="Çırak – Çıraklıktan Patronluğa: tezgâhını kur, işletme kur, üret, ticaret yap, patron ol">
  <!-- X (Twitter) -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Çırak – Çıraklıktan Patronluğa">
  <meta name="twitter:description" content="Simitçilikten holdinge: Türkiye'nin 81 ilinde geçen ücretsiz online ticaret oyunu.">
  <meta name="twitter:image" content="https://oyunsitem.com/cirak/paylasim.jpg">
  <meta name="twitter:image:alt" content="Çırak oyununun kapak görseli">
  <!-- Yapılandırılmış veri: arama motorları oyunu "video oyunu" olarak tanır -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "VideoGame",
        "@id": "https://oyunsitem.com/cirak/#oyun",
        "name": "Çırak",
        "alternateName": "Çırak – Çıraklıktan Patronluğa",
        "description": "Türkiye'nin 81 ilinde gerçek mahalle ve sokaklarda geçen ücretsiz online ticaret ve işletme oyunu. Simit tezgâhıyla başla, bakkal aç, fabrika kur, holding patronu ol.",
        "url": "https://oyunsitem.com/cirak/",
        "image": "https://oyunsitem.com/cirak/paylasim.jpg",
        "inLanguage": "tr",
        "genre": ["Ticaret", "İşletme", "Simülasyon", "Strateji"],
        "gamePlatform": ["Web tarayıcı", "Android", "iOS", "Windows", "macOS"],
        "applicationCategory": "Game",
        "operatingSystem": "Tarayıcı",
        "playMode": ["SinglePlayer", "MultiPlayer"],
        "numberOfPlayers": { "@type": "QuantitativeValue", "minValue": 1 },
        "isAccessibleForFree": true,
        "offers": { "@type": "Offer", "price": "0", "priceCurrency": "TRY", "availability": "https://schema.org/InStock" },
        "publisher": { "@type": "Organization", "name": "Çırak", "url": "https://oyunsitem.com/cirak/" }
      },
      {
        "@type": "WebSite",
        "@id": "https://oyunsitem.com/cirak/#site",
        "name": "Çırak",
        "url": "https://oyunsitem.com/cirak/",
        "inLanguage": "tr"
      }
    ]
  }
  </script>
  <link rel="icon" href="favicon.ico?v=0.55.1" sizes="any">
  <link rel="icon" type="image/png" sizes="32x32" href="simge/favicon-32x32.png?v=0.55.1">
  <link rel="icon" type="image/png" sizes="16x16" href="simge/favicon-16x16.png?v=0.55.1">
  <link rel="icon" type="image/png" sizes="192x192" href="simge/android-chrome-192x192.png?v=0.55.1">
  <link rel="manifest" href="manifest.webmanifest?v=0.55.1">
  <link rel="apple-touch-icon" sizes="180x180" href="simge/apple-touch-icon.png?v=0.55.1">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Çırak">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Anton&family=Baloo+2:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="oyun.css?v=0.55.1">
  <script type="importmap">
    { "imports": { "three": "./lib/three.module.min.js?v=0.36.7", "three/addons/": "./lib/jsm/" } }
  </script>
</head>
<body>
  <noscript>
    <main style="font-family:sans-serif;max-width:720px;margin:40px auto;padding:0 16px;color:#222">
      <h1>Çırak – Çıraklıktan Patronluğa</h1>
      <p>Çırak, Türkiye'nin 81 ilinde ve 973 ilçesinde, gerçek mahalle ve sokak adlarıyla geçen ücretsiz online ticaret ve işletme oyunudur. Tarayıcıda ve telefonda indirmeden oynanır.</p>
      <h2>Oyunda neler var?</h2>
      <ul>
        <li>Simitçi, mısırcı, kestaneci, kokoreççi gibi seyyar tezgâhlarla başla.</li>
        <li>Bakkal, fırın, kafe, kuaför gibi 50'den fazla dükkân türü aç.</li>
        <li>Gerçek hava durumu: yağmurda şemsiyeci, sıcakta dondurmacı kazanır.</li>
        <li>Canlı sokaklar: zabıta, polis, ambulans, otobüs, düğün konvoyu.</li>
        <li>Günlük görevler, toplu siparişler, oyuncularla mesajlaşma ve sıralama.</li>
      </ul>
      <p>Oynamak için tarayıcınızda JavaScript'i açın.</p>
    </main>
  </noscript>
  <canvas id="sahne" aria-hidden="true"></canvas>
  <div id="etiketler"></div>
  <div id="arayuz"></div>
  <div id="panel-katman" hidden></div>
  <div id="bildirim" role="status" aria-live="assertive"></div>
  <div id="acilis">
    <!-- sinematik yükleme ekranı: çapraz kesilmiş üç çizim panosu, nokta dokusu, eğik logo -->
    <div class="acilis-paneller" aria-hidden="true">
      <div class="acilis-pano pano-a">
        <svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice">
          <defs><linearGradient id="gA" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF5E7E"/><stop offset=".55" stop-color="#FF9A3C"/><stop offset="1" stop-color="#FFD166"/></linearGradient></defs>
          <rect width="400" height="300" fill="url(#gA)"/>
          <circle cx="300" cy="120" r="58" fill="#FFF1B8"/>
          <path d="M0 300V190h40v-30h30v20h30v-50h40v40h20v-70h8v-14h6v14h8v70h30v-30h40v40h36v-60h50v50h30v-20h40v120z" fill="#6B2D5C"/>
          <g stroke="#1A1030" stroke-width="5" stroke-linejoin="round">
            <ellipse cx="150" cy="118" rx="62" ry="12" fill="#C98A3A"/>
            <g fill="none" stroke="#8C4A12" stroke-width="7"><circle cx="118" cy="108" r="11"/><circle cx="146" cy="104" r="11"/><circle cx="174" cy="108" r="11"/><circle cx="132" cy="96" r="10"/><circle cx="160" cy="95" r="10"/></g>
            <circle cx="150" cy="148" r="20" fill="#2A1B3D"/>
            <path d="M118 300l6-100c2-22 14-32 26-32s24 10 26 32l6 100z" fill="#2A1B3D"/>
            <path d="M126 196l-18-60M174 196l18-60" stroke="#2A1B3D" stroke-width="13" stroke-linecap="round"/>
          </g>
        </svg>
      </div>
      <div class="acilis-pano pano-b">
        <svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice">
          <defs><linearGradient id="gB" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0B1B4A"/><stop offset=".7" stop-color="#1B6E8C"/><stop offset="1" stop-color="#2FD3C6"/></linearGradient>
            <pattern id="pB" width="14" height="16" patternUnits="userSpaceOnUse"><rect x="3" y="4" width="6" height="7" fill="#FFD166"/></pattern></defs>
          <rect width="400" height="300" fill="url(#gB)"/>
          <path d="M320 40a26 26 0 1 0 22 40 22 22 0 1 1-22-40z" fill="#FFF3C4"/>
          <path d="M0 300V170h50v-50h40v60h30v-40h14V60l4-20 4 20v80h14v30h30a50 50 0 0 1 100 0h24v-60l5-24 5 24v60h30v-80h40v70h50v130z" fill="#0A1030"/>
          <path d="M0 300V170h50v-50h40v60h30v-40h14V60l4-20 4 20v80h14v30h30a50 50 0 0 1 100 0h24v-60l5-24 5 24v60h30v-80h40v70h50v130z" fill="url(#pB)" opacity=".75"/>
          <rect x="120" y="222" width="160" height="40" rx="8" fill="none" stroke="#FF4FD8" stroke-width="5" style="filter:drop-shadow(0 0 8px #FF4FD8)"/>
          <text x="200" y="252" text-anchor="middle" font-family="Anton, Impact, sans-serif" font-size="28" fill="#FFB8F2" style="filter:drop-shadow(0 0 6px #FF4FD8)">7/24 AÇIK</text>
        </svg>
      </div>
      <div class="acilis-pano pano-c">
        <svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice">
          <rect width="400" height="300" fill="#FFC42E"/>
          <g fill="#FFE07A">
            <path d="M200 170L0 0h60z"/><path d="M200 170L120 0h60z"/><path d="M200 170L240 0h60z"/><path d="M200 170L360 0h40v20z"/>
            <path d="M200 170L400 120v60z"/><path d="M200 170L0 110v60z"/>
          </g>
          <g stroke="#1A1030" stroke-width="5" stroke-linejoin="round">
            <rect x="60" y="120" width="190" height="180" fill="#FF7B54"/>
            <path d="M50 120h210l-12 44H62z" fill="#fff"/>
            <path d="M68 120l-6 44M104 120l-4 44M140 120v44M176 120l4 44M212 120l6 44" stroke="#E63946" stroke-width="14"/>
            <rect x="85" y="84" width="140" height="34" rx="6" fill="#1B2F5B"/>
            <rect x="92" y="186" width="126" height="84" fill="#9AD0F5"/>
            <path d="M300 300c-40 0-50-40-40-70s30-40 40-58l-12-16h48l-12 16c10 18 30 28 40 58s0 70-40 70z" fill="#1FA25A"/>
            <text x="320" y="258" text-anchor="middle" font-family="Anton, Impact, sans-serif" font-size="46" fill="#FFE07A" stroke="#1A1030" stroke-width="3">₺</text>
          </g>
          <text x="155" y="109" text-anchor="middle" font-family="Anton, Impact, sans-serif" font-size="24" fill="#FFC42E">BAKKAL</text>
        </svg>
      </div>
    </div>
    <div class="acilis-noktalar" aria-hidden="true"></div>
    <div class="acilis-karart" aria-hidden="true"></div>
    <div class="acilis-baslik">
      <div class="acilis-logo"><span>Çırak</span></div>
      <div class="acilis-slogan">Çıraklıktan Patronluğa</div>
    </div>
    <div class="acilis-alt-serit">
      <div class="acilis-ipucu" id="acilis-ipucu"></div>
      <div class="acilis-durum"><span class="acilis-cark" aria-hidden="true"></span><span id="acilis-mesaj">Yükleniyor…</span> <span id="acilis-yuzde">0%</span></div>
    </div>
    <div class="acilis-yol"><div class="acilis-yol-dolgu" id="acilis-dolgu"></div></div>
  </div>
  <script type="module" src="js/baslangic.js?v=0.55.1"></script>
  <script>
  // Hesap hareketi ikonları, eski oyun modülü önbellekten gelse de görünür.
  (() => {
    const panel = document.getElementById('panel-katman');
    const turler = {
      seyyar:'🧺', ekipman:'🧺', stok:'📦', oto_tedarik:'📦', kasa:'🏪', depozito:'🏪', kurulum:'🔧', ruhsat:'📄', kapanis:'🏪', iade:'↩️',
      pazar:'📈', uretim:'🏭', tesis:'🏭', enerji:'⚡', sigorta:'🛡️', banka:'🏦', yatirim:'🥇', tedarik:'🤝', odul:'🏆', bonus:'🎁',
      davet:'🎉', davet_hediye:'🎁', davet_odul:'🏆', referans:'🤝', paylasim:'🔗', duzeltme:'🛠️', secim:'🗳️', sirket:'🏛️', gorev:'🎯',
      izin:'📄', ceza:'🚨', bahsis:'💵', borsa:'📈', reklam:'📣', ihale:'📑', mulk:'🏠', isletme_gider:'🏪', kupon:'🎟️', kart:'💳', icra:'⚖️',
      hosgeldin:'👋', ekipman_satis:'🧺', seyyar_malzeme:'🥖', cirak:'👷', seyyar_ciro:'💵', seyyar_servis:'🛵', eglence:'🎟️', tatil:'🏖️',
      yetenek:'✨', vergi:'🧾', havale:'💸', kredi:'🏦', faiz:'🏦'
    };
    const ipuclari = [
      [/servis/i,'🛵'], [/bahşiş|bahsis/i,'💵'], [/pazar|satıldı/i,'📈'], [/mahalleye yardım|yardım ödülü/i,'🤝'],
      [/davet|referans/i,'🎉'], [/paylaşım/i,'🔗'], [/tezgâh|tezgah/i,'🧺'], [/kasa|dükkân|dukkan/i,'🏪'],
      [/banka|kredi|faiz/i,'🏦'], [/vergi/i,'🧾'], [/elektrik/i,'⚡'], [/fabrika|üretim|uretim/i,'🏭'],
      [/tatil/i,'🏖️'], [/stok|tedarik/i,'📦']
    ];
    let bekleyen = false;
    function uygula() {
      bekleyen = false;
      for (const satir of panel.querySelectorAll('.hareket-liste > li.hareket:not([data-hareket-ikon])')) {
        const aciklama = satir.querySelector('.h-yazi')?.firstChild?.textContent?.trim() || satir.textContent;
        const ipucu = ipuclari.find(([desen]) => desen.test(aciklama));
        const simge = turler[satir.dataset.tur] || ipucu?.[1] || (satir.querySelector('.h-tutar.eksi') ? '💸' : '💰');
        satir.dataset.hareketIkon = simge;
      }
    }
    new MutationObserver(() => { if (!bekleyen) { bekleyen = true; requestAnimationFrame(uygula); } }).observe(panel, { childList: true, subtree: true });
    uygula();
  })();
  </script>
</body>
</html>
