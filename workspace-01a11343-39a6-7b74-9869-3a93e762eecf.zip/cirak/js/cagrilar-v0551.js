import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.55.1';
// İbadete çağrılar: ezan (oyuncunun ilinin namaz vakitlerinde), kilise çanı, şofar, Budist tapınak çanı ve şankha.
// Hepsi varsayılan olarak kapalıdır; oyuncu Ayarlar > Ses bölümünden istediğini açar (tercih bu tarayıcıda saklanır).
// Çağrı sürerken sokak müzisyenleri ve müzik susar; ekranın üstünde küçük bir şerit çıkar, oradan susturulabilir.
import * as ses from './ses.js?v=0.55.1';
import { api, esc, simdi } from './yardimci.js?v=0.55.1';

export const CAGRILAR = [
  { kod: 'ezan', ad: 'Ezan', ikon: '🕌', aciklama: 'Beş vakitte, ilinin namaz vakitlerine göre. Her vakit için iki müezzinden biri okur.' },
  { kod: 'kilise', ad: 'Kilise çanı', ikon: '⛪', aciklama: 'Hristiyanlık: her gün 12.00 ve 18.00\'de, pazar 10.00\'da ayin çanı.' },
  { kod: 'sofar', ad: 'Şofar', ikon: '🕎', aciklama: 'Yahudilik: cuma akşamı Şabat girerken (gün batımından 18 dk önce).' },
  { kod: 'budist', ad: 'Tapınak çanı', ikon: '🔔', aciklama: 'Budizm: gün doğumunda ve gün batımında büyük tapınak çanı.' },
  { kod: 'sankha', ad: 'Şankha', ikon: '🐚', aciklama: 'Hinduizm: gün doğumu ve batımındaki puja için deniz kabuğu borusu.' },
];
const VAKIT_ADI = { sabah: 'Sabah', ogle: 'Öğle', ikindi: 'İkindi', aksam: 'Akşam', yatsi: 'Yatsı' };
const ANAHTAR = 'tezgah_cagri';

let tercih = {};
try { tercih = JSON.parse(localStorage.getItem(ANAHTAR) || '{}') || {}; } catch (e) { tercih = {}; }
export function cagriAcik(kod) { return tercih[kod] === true; }
function kaydet() { try { localStorage.setItem(ANAHTAR, JSON.stringify(tercih)); } catch (e) { /* yok say */ } }

let vakit = null, vakitZamani = 0, zamanlayici = null;
const TR = 3 * 3600000;
async function vakitleriAl(zorla = false) {
  if (!zorla && vakit && Date.now() - vakitZamani < 3 * 3600000) return vakit;
  try { vakit = await api('vakitler'); vakitZamani = Date.now(); } catch (e) { /* sonra yine denenir */ }
  return vakit;
}
// Türkiye saatiyle o günün hh:mm'si (epoch ms)
function yerelSaat(gunMs, saat, dk = 0) {
  const g = new Date(gunMs + TR);
  return Date.UTC(g.getUTCFullYear(), g.getUTCMonth(), g.getUTCDate(), saat, dk) - TR;
}
// Önümüzdeki iki günün çağrı listesi: { kod, vakit, zaman, ad }
function takvim() {
  const l = [];
  if (!vakit || !vakit.gunler) return l;
  for (const g of vakit.gunler) {
    if (cagriAcik('ezan')) {
      for (const [k, v] of [['sabah', g.imsak], ['ogle', g.ogle], ['ikindi', g.ikindi], ['aksam', g.aksam], ['yatsi', g.yatsi]]) l.push({ kod: 'ezan', vakit: k, zaman: v, ad: _autoSablon`${_autoMetin(VAKIT_ADI[k])} ezanı` });
    }
    if (cagriAcik('kilise')) {
      const haftaGunu = new Date(g.ogle + TR).getUTCDay();
      l.push({ kod: 'kilise', zaman: yerelSaat(g.ogle, 12), ad: _autoMetin('Öğle çanı') });
      l.push({ kod: 'kilise', zaman: yerelSaat(g.ogle, 18), ad: _autoMetin('Akşam çanı') });
      if (haftaGunu === 0) l.push({ kod: 'kilise', zaman: yerelSaat(g.ogle, 10), ad: _autoMetin('Pazar ayini çanı') });
    }
    if (cagriAcik('sofar') && new Date(g.ogle + TR).getUTCDay() === 5) l.push({ kod: 'sofar', zaman: g.batis - 18 * 60000, ad: _autoMetin('Şabat şofarı') });
    if (cagriAcik('budist')) { l.push({ kod: 'budist', zaman: g.dogus, ad: _autoMetin('Sabah tapınak çanı') }); l.push({ kod: 'budist', zaman: g.batis, ad: _autoMetin('Akşam tapınak çanı') }); }
    if (cagriAcik('sankha')) { l.push({ kod: 'sankha', zaman: g.dogus + 60000, ad: _autoMetin('Sabah pujası') }); l.push({ kod: 'sankha', zaman: g.batis + 60000, ad: _autoMetin('Akşam pujası') }); }
  }
  return l.sort((a, b) => a.zaman - b.zaman);
}
const calinanlar = new Set();
function denetle() {
  if (document.hidden || !CAGRILAR.some((c) => cagriAcik(c.kod))) return;
  const t = simdi();
  if (vakit && vakit.gunler && vakit.gunler[1] && t > vakit.gunler[1].imsak - 3600000) vakitleriAl(true);
  if (ses.cagriCaliyor()) return;
  // vaktinden en çok 2 dakika sonrasına kadar başlar (sekme o sırada açılmadıysa kaçırılır; sonradan okunmaz)
  const c = takvim().find((x) => t >= x.zaman && t - x.zaman < 120000 && !calinanlar.has(x.kod + x.zaman));
  if (!c) return;
  calinanlar.add(c.kod + c.zaman);
  ses.cagriCal(c.kod, { vakit: c.vakit });
  seritAd = _autoMetin(c.ad);
}

// Ekranın üstündeki şerit; ezan için iki saygılı kapatma seçeneği.
let serit = null, seritAd = '';
function seritGoster(d) {
  if (!d) { if (serit) { serit.classList.add('gidiyor'); const s = serit; serit = null; setTimeout(() => s.remove(), 350); } return; }
  const c = CAGRILAR.find((x) => x.kod === d.tur) || { ikon: '🔔', ad: '' };
  const ad = seritAd || (d.tur === 'ezan' ? _autoSablon`${_autoMetin(VAKIT_ADI[d.vakit] || '')} ezanı` : _autoMetin(c.ad));
  seritAd = '';
  if (!serit) { serit = document.createElement('div'); serit.className = 'cagri-serit'; serit.setAttribute('role', 'status'); document.body.appendChild(serit); }
  serit.innerHTML = `<span class="cs-ikon" aria-hidden="true">${c.ikon}</span><span class="cs-ad"><b>${esc(ad)}</b><small>${d.tur === 'ezan' ? _autoHtml('okunuyor · müzik ve müzisyenler sustu') : _autoHtml('çalıyor · müzik ve müzisyenler sustu')}</small></span><span class="cs-eylemler">${d.tur === 'ezan' ? `<button type="button" data-durdur>${_autoHtml("Aziz Allah")}</button><button type="button" data-cami>${_autoHtml("Camiye Git")}</button>` : `<button type="button" data-durdur>${_autoHtml("Sustur")}</button>`}</span>`;
  serit.querySelector('[data-durdur]').addEventListener('click', () => ses.cagriDurdur());
  serit.querySelector('[data-cami]')?.addEventListener('click', () => { ses.cagriDurdur(); window.dispatchEvent(new Event('camiye-git')); });
}

export function cagrilariBaslat() {
  if (zamanlayici) return;
  ses.cagriDinle(seritGoster);
  zamanlayici = setInterval(denetle, 10000);
  if (CAGRILAR.some((c) => cagriAcik(c.kod))) vakitleriAl().then(denetle);
}

// Ayarlar kartı
export function cagriKarti() {
  return `<div class="kart cagri-kart"><h3>${_autoHtml("🕊️ İbadete çağrılar")}</h3>
    <p class="kucuk soluk" style="margin:0 0 10px">${_autoHtml("Açtığın çağrılar vaktinde oyunda duyulur; o sırada müzik ve sokak müzisyenleri susar. Hepsi başta kapalıdır.")}</p>
    <ul class="cagri-liste">${CAGRILAR.map((c) => `<li>
      <span class="cl-ikon" aria-hidden="true">${c.ikon}</span>
      <span class="cl-bilgi"><b>${_autoHtml(c.ad)}</b><small>${_autoHtml(c.aciklama)}</small></span>
      <button type="button" class="cl-dinle" data-cagri-dinle="${c.kod}" aria-label="${_autoSablon`${_autoHtml(c.ad)} dinle`}">▶</button>
      <button type="button" class="anahtar${cagriAcik(c.kod) ? ' acik' : ''}" role="switch" aria-checked="${cagriAcik(c.kod)}" data-cagri="${c.kod}" aria-label="${_autoHtml(c.ad)}"><span></span><i>${cagriAcik(c.kod) ? _autoMetin("Açık") : _autoMetin("Kapalı")}</i></button>
    </li>`).join('')}</ul>
    <p class="kucuk soluk" data-cagri-vakit style="margin:8px 0 0"></p></div>`;
}
export async function cagriKartiBagla(g) {
  const yazi = g.querySelector('[data-cagri-vakit]');
  const vakitYaz = async () => {
    if (!cagriAcik('ezan') || !yazi) { if (yazi) yazi.textContent = ''; return; }
    const v = await vakitleriAl();
    if (!v || !v.gunler || !v.gunler.length) return;
    const s = (ms) => new Date(ms + TR).toISOString().slice(11, 16);
    const b = v.gunler[0];
    yazi.innerHTML = `${_autoSablon`📍 ${esc(v.il || '')} bugün: Sabah <b>${s(b.imsak)}</b> · Öğle <b>${s(b.ogle)}</b> · İkindi <b>${s(b.ikindi)}</b> · Akşam <b>${s(b.aksam)}</b> · Yatsı <b>${s(b.yatsi)}</b>`}`;
  };
  g.querySelectorAll('[data-cagri]').forEach((b) => b.addEventListener('click', () => {
    const k = b.dataset.cagri;
    tercih[k] = !cagriAcik(k);
    kaydet();
    b.classList.toggle('acik', tercih[k]);
    b.setAttribute('aria-checked', tercih[k]);
    b.querySelector('i').textContent = tercih[k] ? _autoMetin('Açık') : _autoMetin('Kapalı');
    if (!tercih[k] && ses.cagriCaliyor() === k) ses.cagriDurdur();
    if (tercih[k]) vakitleriAl().then(denetle);
    ses.tik();
    vakitYaz();
  }));
  g.querySelectorAll('[data-cagri-dinle]').forEach((b) => b.addEventListener('click', () => {
    const k = b.dataset.cagriDinle;
    if (ses.cagriCaliyor() === k) { ses.cagriDurdur(); return; }
    const vakitler = ['sabah', 'ogle', 'ikindi', 'aksam', 'yatsi'];
    const v = vakitler[Math.floor(Math.random() * vakitler.length)];
    seritAd = k === 'ezan' ? _autoSablon`${_autoMetin(VAKIT_ADI[v])} ezanı (deneme)` : _autoSablon`${_autoMetin(CAGRILAR.find((x) => x.kod === k).ad)} (deneme)`;
    ses.cagriCal(k, { vakit: v });
  }));
  vakitYaz();
}
