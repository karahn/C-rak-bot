// Canlı bağlantı: sunucu bakiye, mesaj ve dükkân haberlerini beklemeden gönderir.
// Bağlantı koparsa tarayıcı kendisi yeniden bağlanır; tamamen kapanırsa (ör. sunucu yeniden başlarken) biz tekrar deneriz.

let kaynak = null;
let acik = false;
let tekrarZamani = null;
let bekleme = 4000;
let isleyici = null;
let ilkBaglanti = true;

const OLAYLAR = ['oturum-kapat', 'merhaba', 'bakiye', 'mesaj', 'sohbet', 'yenile', 'gorev', 'bildirim'];

function ac() {
  clearTimeout(tekrarZamani);
  if (kaynak) kaynak.close();
  if (typeof EventSource === 'undefined') return;
  kaynak = new EventSource('api/canli', { withCredentials: true });
  for (const tur of OLAYLAR) {
    kaynak.addEventListener(tur, (e) => {
      let veri = {};
      try { veri = JSON.parse(e.data || '{}'); } catch (x) { /* bozuk veri */ }
      if (tur === 'merhaba') {
        acik = true;
        bekleme = 4000;
        // kopukken kaçan olaylar olabilir: ilk bağlantı dışında her yeniden bağlanışta durumu tazele
        if (!ilkBaglanti && isleyici) isleyici('yenile', { neden: 'yeniden-baglandi' });
        ilkBaglanti = false;
        return;
      }
      if (isleyici) isleyici(tur, veri);
    });
  }
  kaynak.onerror = () => {
    acik = false;
    // tarayıcı yeniden deneyemeyecek durumdaysa (oturum kapandı, sunucu 502 verdi) biraz bekleyip biz deneriz
    if (kaynak && kaynak.readyState === EventSource.CLOSED) {
      kaynak = null;
      tekrarZamani = setTimeout(ac, bekleme);
      bekleme = Math.min(bekleme * 2, 60000);
    }
  };
}

export function canliBaslat(fn) {
  isleyici = fn;
  ilkBaglanti = true;
  ac();
}

export function canliKapat() {
  clearTimeout(tekrarZamani);
  isleyici = null;
  acik = false;
  if (kaynak) kaynak.close();
  kaynak = null;
}

export function canliAcik() {
  return acik;
}
