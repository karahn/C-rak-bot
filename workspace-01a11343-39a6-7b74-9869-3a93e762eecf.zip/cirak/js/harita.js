import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.38.0';
// 3D harita: dünya haritasının üstünde odaklanmış Türkiye. 81 il kabartma olarak, hareketli iller daha yüksek;
// çevresinde komşu ülkeler, denizler ve bütün dünya (Natural Earth, kamu malı) sade atlas tonlarında.
// İzdüşüm: x = (boylam − 35) · 10 · cos 39°, y = (enlem − 39) · 10 (Türkiye verisiyle aynı).
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { ekranKonumu } from './sahne.js?v=0.38.0';
import { esc, api } from './yardimci.js?v=0.38.0';

// Bölge renkleri: atlas tonları (yumuşak, birbirinden ayırt edilir)
export const BOLGE_RENGI = {
  'Marmara': '#9CC9E6',
  'Ege': '#A8D5A2',
  'Akdeniz': '#F2D38B',
  'İç Anadolu': '#E9C29B',
  'Karadeniz': '#7FC3A0',
  'Doğu Anadolu': '#BFB0DE',
  'Güneydoğu Anadolu': '#E6AAA0',
};
const BUYUK_SEHIRLER = new Set([34, 6, 35]);

export function haritaOlustur({ ilSecildi, ilceSecildi = () => {}, mahalleyeGit = () => {} }) {
  const sahne = new THREE.Scene();
  // arka plan: üstte koyu, ufka doğru açılan deniz mavisi
  sahne.background = (() => {
    const c = document.createElement('canvas');
    c.width = 4; c.height = 256;
    const x = c.getContext('2d');
    const g = x.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, '#0E2E52'); g.addColorStop(0.55, '#1F5E93'); g.addColorStop(1, '#3E8CC8');
    x.fillStyle = g; x.fillRect(0, 0, 4, 256);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  })();
  sahne.fog = new THREE.Fog('#2A6FA8', 300, 620);
  const kamera = new THREE.PerspectiveCamera(40, 1, 1, 9000);
  kamera.position.set(0, 120, 110);

  sahne.add(new THREE.HemisphereLight('#FFFFFF', '#3C6E9E', 1.25));
  const gunes = new THREE.DirectionalLight('#FFF1D6', 1.5);
  gunes.position.set(-60, 120, 80);
  sahne.add(gunes);

  // Deniz
  // deniz: kıyıya yakın açık, açıkta koyu (merkezden dışa doğru renk geçişi)
  const denizDoku = (() => {
    const c = document.createElement('canvas');
    c.width = c.height = 512;
    const x = c.getContext('2d');
    const g = x.createRadialGradient(256, 256, 30, 256, 256, 256);
    g.addColorStop(0, '#4FA3DE'); g.addColorStop(0.45, '#3A8BCB'); g.addColorStop(1, '#1D5A92');
    x.fillStyle = g; x.fillRect(0, 0, 512, 512);
    // ince dalga dokusu
    x.globalAlpha = 0.05; x.strokeStyle = '#FFFFFF';
    for (let i = 0; i < 180; i++) { const px = Math.random() * 512, py = Math.random() * 512; x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + 6, py - 3, px + 12, py); x.stroke(); }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  })();
  const deniz = new THREE.Mesh(new THREE.PlaneGeometry(1400, 1000), new THREE.MeshStandardMaterial({ map: denizDoku, roughness: 0.35, metalness: 0.1 }));
  deniz.rotation.x = -Math.PI / 2;
  deniz.position.y = -0.6;
  sahne.add(deniz);
  // açık okyanus: bütün dünyayı kaplayan, Türkiye'den uzaklaştıkça koyulaşan derin mavi
  const okyanusDoku = (() => {
    const c = document.createElement('canvas');
    c.width = c.height = 512;
    const x = c.getContext('2d');
    const g = x.createRadialGradient(290, 190, 10, 290, 190, 420);
    g.addColorStop(0, '#2F7DBE'); g.addColorStop(0.35, '#215F99'); g.addColorStop(1, '#0C2C52');
    x.fillStyle = g; x.fillRect(0, 0, 512, 512);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  })();
  const okyanus = new THREE.Mesh(new THREE.PlaneGeometry(4200, 2800), new THREE.MeshStandardMaterial({ map: okyanusDoku, roughness: 0.5, metalness: 0.05 }));
  okyanus.rotation.x = -Math.PI / 2;
  okyanus.position.set(-230, -0.9, 400);
  sahne.add(okyanus);
  deniz.material.transparent = true;
  deniz.material.opacity = 0.92;
  // enlem-boylam çizgileri (her 15°): atlas havası verir
  (() => {
    const C = Math.cos((39 * Math.PI) / 180) * 10;
    const pts = [];
    for (let lon = -180; lon <= 180; lon += 15) { const x = (lon - 35) * C; pts.push(x, -0.55, -(-80 - 39) * 10, x, -0.55, -(85 - 39) * 10); }
    for (let lat = -75; lat <= 75; lat += 15) { const z = -(lat - 39) * 10; pts.push((-180 - 35) * C, -0.55, z, (180 - 35) * C, -0.55, z); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    sahne.add(new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: '#9CC7EE', transparent: true, opacity: 0.14 })));
  })();
  // Deniz üstünde hafif dalga halkaları
  const dalgalar = [];
  for (let i = 0; i < 0; i++) { // (dünya haritasıyla dalga halkaları kaldırıldı: karaya düşüyordu)
    const d = new THREE.Mesh(new THREE.RingGeometry(1.5, 1.8, 24), new THREE.MeshBasicMaterial({ color: '#FFFFFF', transparent: true, opacity: 0.15 }));
    d.rotation.x = -Math.PI / 2;
    const k = [[-60, 30], [-20, 40], [30, 42], [70, 44], [-80, -10], [-75, 20], [0, -45], [40, -46], [-40, -40], [80, -40], [-90, 5], [10, 50], [-50, 45], [55, -48], [-30, -50], [90, 40], [-95, -30], [20, -52]][i];
    d.position.set(k[0], -0.5, k[1]);
    d.userData.faz = Math.random();
    sahne.add(d);
    dalgalar.push(d);
  }

  const kontrol = new OrbitControls(kamera, document.getElementById('sahne'));
  kontrol.enableDamping = true;
  kontrol.dampingFactor = 0.08;
  kontrol.minDistance = 8;
  kontrol.maxDistance = 1500;
  kontrol.minPolarAngle = 0.15;
  kontrol.maxPolarAngle = 1.2;
  kontrol.screenSpacePanning = false;
  kontrol.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_ROTATE };
  kontrol.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.ROTATE };
  kontrol.autoRotateSpeed = 0.35;
  kontrol.enabled = false;
  kontrol.target.set(0, 0, 0);

  const iller = new Map(); // id -> { grup, ust, yan, merkez, veri, yukseklik, hedefYukseklik, etiket }
  const etiketKutusu = document.getElementById('etiketler');
  const hedefler = [];
  let benimIl = null;
  let secili = null;
  let ucus = null;

  function yukle(geo) {
    for (const il of geo) {
      const renk = '#DDDDDD';
      const ust = new THREE.MeshStandardMaterial({ color: renk, roughness: 0.8 });
      const yan = new THREE.MeshStandardMaterial({ color: renk, roughness: 0.95 });
      const grup = new THREE.Group();
      for (const poligon of il.p) {
        const sekil = new THREE.Shape(poligon[0].map(([x, y]) => new THREE.Vector2(x, y)));
        const geo3 = new THREE.ExtrudeGeometry(sekil, { depth: 1, bevelEnabled: false });
        geo3.rotateX(-Math.PI / 2);
        const m = new THREE.Mesh(geo3, [ust, yan]);
        m.userData.il = il.id;
        grup.add(m);
        hedefler.push(m);
        // il sınırı çizgisi
        const noktalar = poligon[0].map(([x, y]) => new THREE.Vector3(x, 1.001, -y));
        const cizgi = new THREE.Line(new THREE.BufferGeometry().setFromPoints(noktalar), new THREE.LineBasicMaterial({ color: '#FFFFFF', transparent: true, opacity: 0.8 }));
        grup.add(cizgi);
      }
      grup.scale.y = 0.01;
      sahne.add(grup);
      const etiket = document.createElement('div');
      etiket.className = 'etiket gizli';
      etiketKutusu.appendChild(etiket);
      iller.set(il.id, {
        grup, ust, yan, etiket,
        merkez: new THREE.Vector3(il.m[0], 0, -il.m[1]),
        ad: il.ad, veri: null, yukseklik: 0.01, hedefYukseklik: 1.2, etiketMetni: '',
      });
    }
  }

  // ------------------------------------------------ Dünya: komşu ülkeler ve bütün kıtalar (sade atlas tonları)
  const ulkeEtiketleri = [];
  const DENIZLER = [['Karadeniz', 34.5, 43.3, 1], ['Akdeniz', 30.5, 34.4, 1], ['Ege Denizi', 25.2, 38.2, 1], ['Hazar Denizi', 50.6, 41.8, 1], ['Kızıldeniz', 38.5, 20.5, 2],
    ['Basra Körfezi', 51, 27, 2], ['Atlas Okyanusu', -38, 30, 3], ['Hint Okyanusu', 75, -12, 3], ['Büyük Okyanus', 170, 10, 3], ['Kuzey Buz Denizi', 40, 78, 3]];
  function izdusum(lon, lat) { return [(lon - 35) * Math.cos((39 * Math.PI) / 180) * 10, (lat - 39) * 10]; }
  async function dunyaYukle(adres = 'veri/dunya.json') {
    let liste;
    try { liste = await fetch(adres).then((r) => r.json()); } catch (e) { return; }
    const TONLAR = ['#EAE3CF', '#E2DBC4', '#E7DDC9', '#DDD7C2', '#E5E0CB'];
    const kovalar = TONLAR.map(() => []);
    const kenar = [];
    liste.forEach((u, i) => {
      for (const halka of u.p) {
        const nok = [];
        for (let j = 0; j < halka.length; j += 2) nok.push(new THREE.Vector2(halka[j], halka[j + 1]));
        kovalar[(u.k.charCodeAt(0) + u.k.charCodeAt(1) * 3 + i) % TONLAR.length].push(new THREE.Shape(nok));
        for (let j = 0; j < halka.length; j += 2) {
          const k2 = (j + 2) % halka.length;
          kenar.push(halka[j], 0.36, -halka[j + 1], halka[k2], 0.36, -halka[k2 + 1]);
        }
      }
      if (u.y || u.n <= 2) {
        const e = document.createElement('div');
        e.className = 'etiket gizli';
        e.innerHTML = `<span class="ulke-etiket${u.y ? ' komsu' : ''}">${esc(u.ad)}</span>`;
        etiketKutusu.appendChild(e);
        ulkeEtiketleri.push({ e, m: new THREE.Vector3(u.m[0], 0.5, -u.m[1]), komsu: !!u.y, deniz: false });
      }
    });
    kovalar.forEach((sekiller, i) => {
      if (!sekiller.length) return;
      const g = new THREE.ExtrudeGeometry(sekiller, { depth: 0.35, bevelEnabled: false, curveSegments: 1 });
      g.rotateX(-Math.PI / 2);
      const m = new THREE.Mesh(g, [new THREE.MeshStandardMaterial({ color: TONLAR[i], roughness: 0.95 }), new THREE.MeshStandardMaterial({ color: new THREE.Color(TONLAR[i]).multiplyScalar(0.78), roughness: 1 })]);
      m.position.y = -0.4;
      sahne.add(m);
    });
    const kg = new THREE.BufferGeometry();
    kg.setAttribute('position', new THREE.Float32BufferAttribute(kenar, 3));
    const kc = new THREE.LineSegments(kg, new THREE.LineBasicMaterial({ color: '#A89C80', transparent: true, opacity: 0.75 }));
    kc.position.y = -0.4;
    sahne.add(kc);
    {
      const e = document.createElement('div');
      e.className = 'etiket gizli';
      e.innerHTML = `<span class="turkiye-etiket">${_autoHtml("TÜRKİYE")}</span>`;
      etiketKutusu.appendChild(e);
      ulkeEtiketleri.push({ e, m: new THREE.Vector3(4, 3, 0), turkiye: true });
    }
    for (const [ad, lon, lat, sira] of DENIZLER) {
      const [x, y] = izdusum(lon, lat);
      const e = document.createElement('div');
      e.className = 'etiket gizli';
      e.innerHTML = `<span class="deniz-etiket">${esc(ad)}</span>`;
      etiketKutusu.appendChild(e);
      ulkeEtiketleri.push({ e, m: new THREE.Vector3(x, 0, -y), komsu: sira === 1, deniz: true, sira });
    }
    const oncelik = (x) => (x.turkiye ? 0 : x.komsu && !x.deniz ? 1 : x.deniz && x.sira === 1 ? 2 : x.deniz ? 4 : 3);
    ulkeEtiketleri.sort((a, b) => oncelik(a) - oncelik(b));
  }
  const yerlesen = [];
  function ulkeEtiketleriGuncelle(uzak) {
    // üst üste binen etiketlerden önemsiz olan gizlenir (önce Türkiye, sonra komşular, denizler, diğerleri)
    yerlesen.length = 0;
    for (const x of ulkeEtiketleri) {
      // yakında komşular ve denizler, uzaklaştıkça büyük ülkeler ve okyanuslar
      const goster = x.turkiye ? uzak > 330 : x.deniz ? (x.sira === 1 ? uzak > 60 && uzak < 700 : x.sira === 2 ? uzak > 180 && uzak < 1200 : uzak > 500)
        : x.komsu ? uzak > 70 && uzak < 800 : uzak > 420;
      if (!goster) { x.e.classList.add('gizli'); continue; }
      const p = ekranKonumu(x.m, kamera);
      if (!p || p.x < -60 || p.y < -30 || p.x > window.innerWidth + 60 || p.y > window.innerHeight + 30) { x.e.classList.add('gizli'); continue; }
      const g = (x.yaziUzunlugu || (x.yaziUzunlugu = x.e.textContent.length)) * (x.turkiye ? 13 : 8) + 10;
      const kutu = [p.x - g / 2, p.y - 10, p.x + g / 2, p.y + 10];
      if (yerlesen.some((b) => kutu[0] < b[2] && kutu[2] > b[0] && kutu[1] < b[3] && kutu[3] > b[1])) { x.e.classList.add('gizli'); continue; }
      yerlesen.push(kutu);
      x.e.classList.remove('gizli');
      const tr = `translate(${Math.round(p.x)}px, ${Math.round(p.y)}px) translate(-50%, -50%)`;
      if (x.e._tr !== tr) { x.e._tr = tr; x.e.style.transform = tr; }
    }
  }

  function istatistik(liste) {
    for (const v of liste) {
      const il = iller.get(v.id);
      if (!il) continue;
      il.veri = v;
      il.ad = v.ad;
      const renk = new THREE.Color(BOLGE_RENGI[v.bolge] || '#DDDDDD');
      if (v.id === benimIl) renk.set('#FFC42E');
      il.ust.color.copy(renk);
      il.yan.color.copy(renk).multiplyScalar(0.62);
      il.hedefYukseklik = 1.2 + Math.log2(1 + v.oyuncu) * 1.1 + Math.log2(1 + v.tezgah) * 0.5 + (v.id === benimIl ? 0.8 : 0);
    }
  }

  function benimIliAyarla(id) {
    benimIl = id;
    for (const [k, il] of iller) {
      il.ust.emissive.set(k === id ? '#6B4A00' : '#000000');
    }
  }

  function sec(id) {
    if (secili && iller.get(secili)) iller.get(secili).ust.emissive.set(secili === benimIl ? '#6B4A00' : '#000000');
    secili = id;
    if (id && iller.get(id)) iller.get(id).ust.emissive.set('#3A3A3A');
  }

  function odakla(id, mesafe) {
    const il = iller.get(id);
    if (!il) return;
    const hedef = il.merkez.clone();
    const yon = kamera.position.clone().sub(kontrol.target).normalize();
    const m = mesafe || Math.min(kamera.position.distanceTo(kontrol.target), 110);
    ucus = {
      t: 0,
      bas: kontrol.target.clone(),
      son: hedef,
      basK: kamera.position.clone(),
      sonK: hedef.clone().addScaledVector(yon, m),
    };
  }

  function odaklaNokta(nokta, m) {
    const yon = kamera.position.clone().sub(kontrol.target).normalize();
    ucus = { t: 0, bas: kontrol.target.clone(), son: nokta.clone(), basK: kamera.position.clone(), sonK: nokta.clone().addScaledVector(yon, m) };
  }
  const benimIlceBilgi = { ilId: null, id: null, mahalle: '' };

  function genelBakis(dar) {
    kontrol.target.set(4, 0, 0);
    kamera.position.set(4, dar ? 190 : 120, dar ? 140 : 100);
  }

  // Giriş ekranında harita kartın üstünde görünsün diye görüntüyü yukarı kaydırır
  let kaydirma = 0;
  let sonW = 1;
  let sonH = 1;
  function boyut(w, h) {
    sonW = w; sonH = h;
    kamera.aspect = w / h;
    if (kaydirma) kamera.setViewOffset(w, h, 0, h * kaydirma, w, h);
    else kamera.clearViewOffset();
    kamera.updateProjectionMatrix();
  }
  function gorusKaydir(oran) {
    kaydirma = oran;
    boyut(sonW, sonH);
  }

  function guncelle(dt, t) {
    if (ucus) {
      ucus.t = Math.min(1, ucus.t + dt * (ucus.hiz || 1.4));
      // yumuşak: başta ve sonda yavaş (sinematik), değilse hızlı başlayıp yavaşlar
      const k = ucus.yumusak ? ucus.t * ucus.t * (3 - 2 * ucus.t) : 1 - Math.pow(1 - ucus.t, 3);
      kontrol.target.lerpVectors(ucus.bas, ucus.son, k);
      kamera.position.lerpVectors(ucus.basK, ucus.sonK, k);
      if (ucus.t >= 1) ucus = null;
    }
    kontrol.update();
    // sis kameranın uzaklığına göre: yakında Türkiye net, uzaklaşınca dünya görünür
    const uz = kamera.position.distanceTo(kontrol.target);
    sahne.fog.near = Math.max(300, uz * 1.6);
    sahne.fog.far = Math.max(620, uz * 3.6);
    for (const [id, il] of iller) {
      il.yukseklik += (il.hedefYukseklik - il.yukseklik) * Math.min(1, dt * 3);
      let y = il.yukseklik;
      if (id === benimIl) y += Math.sin(t * 3) * 0.25 + 0.25;
      il.grup.scale.y = y;
    }
    const k = ilceKatmani;
    if (k.grup && iller.get(k.ilId)) {
      k.grup.position.y = iller.get(k.ilId).grup.scale.y - 0.02;
      if (k.igne) k.igne.children[0].position.y = 2.2 + Math.sin(t * 3) * 0.25;
      // kendi ilçesinde iyice yakınlaşan oyuncu mahalleye iner
      if (k.igne && kontrol.enabled && !ucus) {
        const u = kamera.position.distanceTo(kontrol.target);
        const yakin = kontrol.target.distanceTo(k.igne.position) < 6;
        if (u < 9.5 && yakin && !k.indi) { k.indi = true; mahalleyeGit(); }
        if (u > 14) k.indi = false;
      }
    }
    // canlı ilçe sütunları hafifçe nefes alır, dibindeki halka dalgalanır
    for (const c of k.canli || []) {
      c.sutun.scale.y = 1 + Math.sin(t * 2 + c.h) * 0.04;
      const f = (t * 0.6 + c.halka.userData.faz) % 1;
      c.halka.scale.setScalar(0.8 + f * 1.8);
      c.halka.material.opacity = 0.55 * (1 - f);
    }
    for (const d of dalgalar) {
      const f = (t * 0.15 + d.userData.faz) % 1;
      d.scale.setScalar(0.6 + f * 1.6);
      d.material.opacity = 0.08 * (1 - f);
    }
  }

  const nokta = new THREE.Vector3();
  function etiketleriGuncelle() {
    const uzak = kamera.position.distanceTo(kontrol.target);
    ilceEtiketleri(uzak);
    ulkeEtiketleriGuncelle(uzak);
    for (const [id, il] of iller) {
      if (id === ilceKatmani.ilId && uzak < 75) { il.etiket.classList.add('gizli'); continue; }
      const v = il.veri;
      const benim = id === benimIl;
      const sec = id === secili;
      const goster = benim || sec || (v && v.oyuncu > 0 && uzak < 170) || (BUYUK_SEHIRLER.has(id) && uzak < 230) || uzak < 70;
      if (!goster) { il.etiket.classList.add('gizli'); continue; }
      nokta.copy(il.merkez);
      nokta.y = il.grup.scale.y + 0.5;
      const k = ekranKonumu(nokta, kamera);
      if (!k) { il.etiket.classList.add('gizli'); continue; }
      const metin = `<span class="il-etiket${benim ? ' benim' : sec ? ' secili' : ''}">${esc(il.ad)}${v && v.oyuncu ? `<em>${v.oyuncu}</em>` : ''}</span>`;
      if (metin !== il.etiketMetni) { il.etiket.innerHTML = metin; il.etiketMetni = metin; }
      il.etiket.classList.remove('gizli');
      il.etiket.style.transform = `translate(${k.x}px, ${k.y}px) translate(-50%, -100%)`;
    }
  }

  // ------------------------------------------------ İlçeler: seçilen ilin ilçe sınırları ve oyuncunun mahallesi
  // Türkiye → il → ilçe → mahalle: yakınlaştıkça ayrıntı artar; kendi ilçende iğneye dokununca ya da
  // iyice yakınlaşınca mahalleye (3D sokağa) inilir.
  const ilceKatmani = { ilId: null, grup: null, hedefler: [], etiketler: [], igne: null, igneEtiket: null, benimIlce: null, secili: null, yukleniyor: null, mahalleAdi: '' };
  const ilceOnbellek = new Map();
  async function ilceVerisi(ilId) {
    if (!ilceOnbellek.has(ilId)) ilceOnbellek.set(ilId, fetch(`veri/ilce/${ilId}.json`).then((r) => (r.ok ? r.json() : [])).catch(() => []));
    return ilceOnbellek.get(ilId);
  }
  function ilceKapat() {
    const k = ilceKatmani;
    if (k.grup) {
      sahne.remove(k.grup);
      k.grup.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material && !o.material.userData.ortak) o.material.dispose(); });
    }
    for (const e of k.etiketler) e.e.remove();
    if (k.igneEtiket) k.igneEtiket.remove();
    Object.assign(k, { ilId: null, grup: null, hedefler: [], etiketler: [], igne: null, igneEtiket: null, secili: null, canli: [] });
  }
  async function ilceGoster(ilId, { benimIlce = null, mahalleAdi = '' } = {}) {
    const k = ilceKatmani;
    if (k.ilId === ilId && k.grup) { k.benimIlce = benimIlce ?? k.benimIlce; return; }
    const istek = Symbol('ilce');
    k.yukleniyor = istek;
    const liste = await ilceVerisi(ilId);
    if (k.yukleniyor !== istek) return;
    ilceKapat();
    const il = iller.get(ilId);
    if (!il || !liste.length) return;
    k.ilId = ilId;
    k.benimIlce = benimIlce;
    k.mahalleAdi = mahalleAdi;
    const grup = new THREE.Group();
    // ilçeler bölge renginin açık-koyu tonlarıyla boyanır; oyuncunun ilçesi altın sarısı
    const taban = new THREE.Color(BOLGE_RENGI[il.veri && il.veri.bolge] || '#9FC7A8');
    liste.forEach((ilce, i) => {
      const benim = ilce.id === benimIlce;
      const renk = benim ? new THREE.Color('#FFC42E') : taban.clone().offsetHSL(((i * 37) % 11 - 5) * 0.008, ((i * 29) % 5 - 2) * 0.04, ((i * 53) % 9 - 4) * 0.035);
      const ust = new THREE.MeshStandardMaterial({ color: renk, roughness: 0.7, flatShading: true, emissive: benim ? '#5A3D00' : '#000000' });
      const yan = new THREE.MeshStandardMaterial({ color: renk.clone().multiplyScalar(0.7), roughness: 0.9, flatShading: true });
      const alt = new THREE.Group();
      for (const poligon of ilce.p) {
        const sekil = new THREE.Shape(poligon[0].map(([x, y]) => new THREE.Vector2(x, y)));
        const geo3 = new THREE.ExtrudeGeometry(sekil, { depth: 1, bevelEnabled: false });
        geo3.rotateX(-Math.PI / 2);
        const m = new THREE.Mesh(geo3, [ust, yan]);
        m.userData.ilce = ilce.id;
        alt.add(m);
        k.hedefler.push(m);
        const noktalar = poligon[0].map(([x, y]) => new THREE.Vector3(x, 1.002, -y));
        alt.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(noktalar), new THREE.LineBasicMaterial({ color: '#FFFFFF', transparent: true, opacity: 0.8 })));
      }
      alt.scale.y = benim ? 0.5 : 0.18;
      alt.userData = { ilce, ust, benim };
      grup.add(alt);
      const e = document.createElement('div');
      e.className = 'etiket gizli';
      e.innerHTML = `<span class="ilce-etiket${benim ? ' benim' : ''}">${esc(ilce.ad)}</span>`;
      etiketKutusu.appendChild(e);
      k.etiketler.push({ e, m: new THREE.Vector3(ilce.m[0], 0, -ilce.m[1]), alt, id: ilce.id });
    });
    // kendi ilçende mahalle iğnesi
    const benimki = liste.find((x) => x.id === benimIlce);
    if (benimki) {
      const igne = new THREE.Group();
      const kirmizi = new THREE.MeshStandardMaterial({ color: '#E63946', emissive: '#5A0A10', roughness: 0.4 });
      const bas = new THREE.Mesh(new THREE.SphereGeometry(0.55, 16, 12), kirmizi);
      bas.position.y = 2.2;
      const uc = new THREE.Mesh(new THREE.ConeGeometry(0.28, 1.7, 12), kirmizi);
      uc.rotation.x = Math.PI;
      uc.position.y = 1.1;
      igne.add(bas, uc);
      igne.position.set(benimki.m[0], 0, -benimki.m[1]);
      igne.userData.igne = true;
      bas.userData.igne = true;
      uc.userData.igne = true;
      k.hedefler.push(bas, uc);
      grup.add(igne);
      k.igne = igne;
      const e = document.createElement('div');
      e.className = 'etiket gizli';
      e.innerHTML = `<button class="mahalle-igne">📍 ${esc(mahalleAdi || _autoMetin('Mahallen'))}<small>${_autoHtml("Sokağına in")}</small></button>`;
      e.querySelector('button').addEventListener('click', () => mahalleyeGit());
      etiketKutusu.appendChild(e);
      k.igneEtiket = e;
    }
    sahne.add(grup);
    k.grup = grup;
    canliKatman(ilId, liste, grup, istek);
  }
  // Canlı il: her ilçede açık tezgâh ve dükkân sayısına göre yükselen ışıklı sütun, üstünde sayılar.
  // Kalabalık ilçeler uzaktan belli olur; dokununca ilçe kartı açılır, oradan caddesi gezilir.
  async function canliKatman(ilId, liste, grup, istek) {
    let veri;
    try { veri = await api(`iller/${ilId}/canli`); } catch (e) { return; }
    const k = ilceKatmani;
    if (k.yukleniyor !== istek || k.grup !== grup) return;
    const say = new Map(veri.map((x) => [x.id, x]));
    k.canli = [];
    const sutunMat = new THREE.MeshStandardMaterial({ color: '#FFC42E', emissive: '#FF9A1A', emissiveIntensity: 0.9, roughness: 0.35, transparent: true, opacity: 0.92 });
    const halkaMat = new THREE.MeshBasicMaterial({ color: '#FFD86B', transparent: true, opacity: 0.5, depthWrite: false, side: THREE.DoubleSide });
    for (const ilce of liste) {
      const c = say.get(ilce.id);
      const e = k.etiketler.find((x) => x.id === ilce.id);
      if (!c) continue;
      if (e) {
        const rozet = [c.tezgah ? `🧺${c.tezgah}` : '', c.dukkan ? `🏪${c.dukkan}` : '', !c.tezgah && !c.dukkan && c.oyuncu ? `👤${c.oyuncu}` : ''].filter(Boolean).join(' ');
        if (rozet) e.e.querySelector('.ilce-etiket').insertAdjacentHTML('beforeend', `<em class="ilce-canli">${rozet}</em>`);
      }
      const guc = c.tezgah * 2 + c.dukkan;
      if (!guc) continue;
      const h = 0.8 + Math.log2(1 + guc) * 1.1;
      const sutun = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.34, h, 12), sutunMat);
      sutun.position.set(ilce.m[0], 1 + h / 2, -ilce.m[1]);
      sutun.userData.ilce = ilce.id;
      grup.add(sutun);
      k.hedefler.push(sutun);
      const halka = new THREE.Mesh(new THREE.RingGeometry(0.5, 0.75, 24), halkaMat.clone());
      halka.rotation.x = -Math.PI / 2;
      halka.position.set(ilce.m[0], 1.05, -ilce.m[1]);
      halka.userData.faz = Math.random();
      grup.add(halka);
      k.canli.push({ sutun, halka, h });
    }
  }
  function ilceSec(id) {
    const k = ilceKatmani;
    for (const a of k.grup ? k.grup.children : []) {
      if (!a.userData.ilce) continue;
      const sec = a.userData.ilce.id === id;
      a.userData.ust.emissive.set(sec ? '#3A3A3A' : a.userData.benim ? '#5A3D00' : '#000000');
    }
    k.secili = id;
  }
  // kendi ilçesine yakından bakar (mahalleden uzaklaşınca buraya gelinir)
  function ilceyeYaklas(mesafe = 26) {
    const k = ilceKatmani;
    const hedef = k.igne ? k.igne.position.clone() : iller.get(k.ilId) ? iller.get(k.ilId).merkez.clone() : null;
    if (!hedef) return;
    kontrol.target.copy(hedef);
    kamera.position.copy(hedef).add(new THREE.Vector3(0, mesafe * 0.8, mesafe * 0.6));
    ucus = null;
  }

  function ilceEtiketleri(uzak) {
    const k = ilceKatmani;
    const gorunur = k.grup && uzak < 110;
    for (const x of k.etiketler) {
      const benim = x.id === k.benimIlce;
      if (!gorunur || (!benim && uzak > 75 && x.id !== k.secili)) { x.e.classList.add('gizli'); continue; }
      nokta.copy(x.m);
      nokta.y = k.grup.position.y + x.alt.scale.y + 0.3;
      const p = ekranKonumu(nokta, kamera);
      if (!p) { x.e.classList.add('gizli'); continue; }
      x.e.classList.remove('gizli');
      x.e.style.transform = `translate(${p.x}px, ${p.y}px) translate(-50%, -50%)`;
    }
    if (k.igneEtiket) {
      if (!gorunur || !k.igne) { k.igneEtiket.classList.add('gizli'); return; }
      nokta.copy(k.igne.position);
      nokta.y = k.grup.position.y + 3.2;
      const p = ekranKonumu(nokta, kamera);
      if (!p) { k.igneEtiket.classList.add('gizli'); return; }
      k.igneEtiket.classList.remove('gizli');
      k.igneEtiket.style.transform = `translate(${p.x}px, ${p.y}px) translate(-50%, -100%)`;
    }
  }

  function tikla(raycaster) {
    const ic = ilceKatmani.hedefler.length ? raycaster.intersectObjects(ilceKatmani.hedefler, false)[0] : null;
    if (ic && ic.object.userData.igne) { mahalleyeGit(); return; }
    if (ic && ic.object.userData.ilce) {
      ilceSec(ic.object.userData.ilce);
      const e = ilceKatmani.etiketler.find((x) => x.id === ic.object.userData.ilce);
      if (e) odaklaNokta(e.m, Math.min(kamera.position.distanceTo(kontrol.target), 45));
      ilceSecildi(ic.object.userData.ilce, ilceKatmani.ilId);
      return;
    }
    const v = raycaster.intersectObjects(hedefler, false)[0];
    if (v) {
      sec(v.object.userData.il);
      odakla(v.object.userData.il, Math.min(kamera.position.distanceTo(kontrol.target), 70));
      ilceGoster(v.object.userData.il, { benimIlce: ilceKatmani.ilId === v.object.userData.il ? ilceKatmani.benimIlce : benimIlceBilgi.ilId === v.object.userData.il ? benimIlceBilgi.id : null, mahalleAdi: benimIlceBilgi.mahalle });
      ilSecildi(v.object.userData.il);
    } else {
      sec(null);
      ilSecildi(null);
    }
  }

  return {
    sahne, kamera, guncelle, boyut, tikla, etiketleriGuncelle,
    yukle, istatistik, benimIliAyarla, sec, odakla, genelBakis,
    gorusKaydir,
    otomatikDon(acik) { kontrol.autoRotate = acik; },
    etkilesim(acik) { kontrol.enabled = acik; },
    basla() { },
    durdur() {
      kontrol.enabled = false;
      for (const il of iller.values()) il.etiket.classList.add('gizli');
      for (const x of ilceKatmani.etiketler) x.e.classList.add('gizli');
      if (ilceKatmani.igneEtiket) ilceKatmani.igneEtiket.classList.add('gizli');
      for (const x of ulkeEtiketleri) x.e.classList.add('gizli');
    },
    // oyuncunun ilçesi ve mahallesi: il haritasında ilçeler ve mahalle iğnesi gösterilir
    benimIlceAyarla(ilId, ilceId, mahalle) { Object.assign(benimIlceBilgi, { ilId, id: ilceId, mahalle }); },
    ilceGoster(ilId) {
      const benim = ilId === benimIlceBilgi.ilId;
      return ilceGoster(ilId, { benimIlce: benim ? benimIlceBilgi.id : null, mahalleAdi: benimIlceBilgi.mahalle });
    },
    ilceKapat,
    ilceyeYaklas,
    // + / − düğmeleri
    yakinlas(kat) {
      const yon = kamera.position.clone().sub(kontrol.target);
      const u = Math.max(kontrol.minDistance, Math.min(kontrol.maxDistance, yon.length() * kat));
      ucus = { t: 0, bas: kontrol.target.clone(), son: kontrol.target.clone(), basK: kamera.position.clone(), sonK: kontrol.target.clone().add(yon.setLength(u)) };
    },
    turkiye(dar) {
      ucus = { t: 0, bas: kontrol.target.clone(), son: new THREE.Vector3(4, 0, 0), basK: kamera.position.clone(), sonK: new THREE.Vector3(4, dar ? 190 : 120, dar ? 140 : 100) };
    },
    // bütün dünya (Türkiye ortada)
    dunya(dar) {
      ucus = { t: 0, hiz: 0.8, bas: kontrol.target.clone(), son: new THREE.Vector3(-60, 0, 60), basK: kamera.position.clone(), sonK: new THREE.Vector3(-60, dar ? 1350 : 900, dar ? 700 : 520) };
    },
    dunyaYukle,
    // tanıtım için: dünyadan Türkiye'ye yavaş iniş (sure sn)
    dunyadanTurkiyeye(sure, dar) {
      kontrol.target.set(-40, 0, 30);
      kamera.position.set(-40, dar ? 1500 : 1050, dar ? 820 : 600);
      ucus = { t: 0, hiz: 1 / sure, yumusak: true, bas: kontrol.target.clone(), son: new THREE.Vector3(4, 0, 0), basK: kamera.position.clone(), sonK: new THREE.Vector3(4, dar ? 190 : 120, dar ? 140 : 100) };
    },
    // sinematik çekim: hedefe ve kamera noktasına yumuşak süzülüş (sure sn)
    sinemaUcus(son, sonK, sure) {
      ucus = { t: 0, hiz: 1 / Math.max(0.05, sure), yumusak: true, bas: kontrol.target.clone(), son: new THREE.Vector3(son.x, son.y, son.z), basK: kamera.position.clone(), sonK: new THREE.Vector3(sonK.x, sonK.y, sonK.z) };
    },
    kameraKonum: () => ({ hedef: kontrol.target.clone(), kamera: kamera.position.clone() }),
    // sinematik çekim: kimsenin ili vurgulanmaz (herkese aynı tanıtım)
    sinemaSade() {
      benimIl = null; secili = null;
      istatistik([...iller.values()].map((il) => il.veri).filter(Boolean));
      for (const il of iller.values()) il.ust.emissive.set('#000000');
    },
    iller: () => [...iller.entries()].map(([id, il]) => ({ id, ad: il.ad })),
    uzaklik: () => kamera.position.distanceTo(kontrol.target),
    ilAdi(id) { const il = iller.get(id); return il ? il.ad : ''; },
  };
}
