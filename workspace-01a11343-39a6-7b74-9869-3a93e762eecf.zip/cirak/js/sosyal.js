import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.41.0';
// Çırak – profil fotoğrafı seçme, avatarlar ve paylaşım yardımcıları
import { esc } from './yardimci.js?v=0.41.0';

// Dosya seçtirir, fotoğrafı ortadan kare kırpıp 320×320 JPEG'e küçültür (sunucu 256'ya indirir).
// Vazgeçilirse null döner.
export function fotoSec() {
  return new Promise((tamam, hata) => {
    const girdi = document.createElement('input');
    girdi.type = 'file';
    girdi.accept = 'image/jpeg,image/png,image/webp,image/heic,image/*';
    girdi.style.display = 'none';
    document.body.appendChild(girdi);
    let bitti = false;
    const temizle = () => { bitti = true; girdi.remove(); };
    // seçim penceresi kapatılırsa (vazgeçildi)
    window.addEventListener('focus', () => setTimeout(() => { if (!bitti && !girdi.files.length) { temizle(); tamam(null); } }, 1200), { once: true });
    girdi.addEventListener('change', async () => {
      const dosya = girdi.files[0];
      temizle();
      if (!dosya) return tamam(null);
      if (dosya.size > 15 * 1024 * 1024) return hata(new Error(_autoMetin('Fotoğraf çok büyük (en fazla 15 MB).')));
      try { tamam(await kareKirp(dosya, 320)); } catch (e) { hata(new Error(_autoMetin('Bu dosya açılamadı. JPEG ya da PNG bir fotoğraf seç.'))); }
    });
    girdi.click();
  });
}

async function resimAc(dosya) {
  if (window.createImageBitmap) {
    try { return await createImageBitmap(dosya, { imageOrientation: 'from-image' }); } catch (e) { /* aşağıdaki yol */ }
  }
  const url = URL.createObjectURL(dosya);
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    return img;
  } finally { setTimeout(() => URL.revokeObjectURL(url), 1000); }
}

export async function kareKirp(dosya, boyut = 320) {
  const r = await resimAc(dosya);
  const w = r.width, h = r.height;
  const k = Math.min(w, h);
  const c = document.createElement('canvas');
  c.width = c.height = boyut;
  const g = c.getContext('2d');
  g.imageSmoothingQuality = 'high';
  // portrelerde yüz genelde üst yarıdadır: dikey fotoğrafta kırpma biraz yukarıdan yapılır
  const sy = h > w ? Math.round((h - k) * 0.3) : Math.round((h - k) / 2);
  g.drawImage(r, Math.round((w - k) / 2), sy, k, k, 0, 0, boyut, boyut);
  if (r.close) r.close();
  return c.toDataURL('image/jpeg', 0.86);
}

// Fotoğrafı olmayanlar için baş harf ve adından türeyen renk
const RENKLER = ['#E4572E', '#F3A712', '#29A36A', '#2E86DE', '#8E44AD', '#D35400', '#16A085', '#C0392B', '#2C3E50', '#E84393'];
function renk(ad) {
  let h = 0;
  for (const c of String(ad)) h = (h * 31 + c.codePointAt(0)) >>> 0;
  return RENKLER[h % RENKLER.length];
}
export function avatarHtml(foto, ad, boyut = 36, sinif = '') {
  const s = `width:${boyut}px;height:${boyut}px`;
  if (foto) return `<img class="avatar ${sinif}" src="${esc(foto)}" alt="" width="${boyut}" height="${boyut}" loading="lazy" style="${s}">`;
  const harf = String(ad || '?').trim().charAt(0).toLocaleUpperCase('tr') || '?';
  return `<span class="avatar harf ${sinif}" aria-hidden="true" style="${s};background:${renk(ad)};font-size:${Math.round(boyut * 0.45)}px">${esc(harf)}</span>`;
}

// Sosyal ağ paylaşım pencereleri
export function paylasimPenceresi(ag, { metin, link }) {
  const ADRES = {
    whatsapp: ['https://api.whatsapp.com/send', { text: `${metin} ${link}` }],
    telegram: ['https://t.me/share/url', { url: link, text: metin }],
    facebook: ['https://www.facebook.com/sharer/sharer.php', { u: link }],
    x: ['https://twitter.com/intent/tweet', { text: metin, url: link }],
    linkedin: ['https://www.linkedin.com/sharing/share-offsite/', { url: link }],
  };
  const [taban, param] = ADRES[ag];
  const u = new URL(taban);
  for (const [k, v] of Object.entries(param)) u.searchParams.set(k, v);
  window.open(u.toString(), '_blank', 'noopener');
}

// Resmi dosya olarak paylaşır (telefonda Instagram hikâyesi, WhatsApp durum vb. için).
// Tarayıcı desteklemiyorsa false döner.
export async function resimPaylas(resimAdresi, dosyaAdi, { metin, link }) {
  if (!navigator.canShare) return false;
  const blob = await fetch(resimAdresi).then((r) => r.blob());
  const dosya = new File([blob], dosyaAdi, { type: 'image/jpeg' });
  if (!navigator.canShare({ files: [dosya] })) return false;
  try { await navigator.share({ files: [dosya], title: _autoMetin('Çırak'), text: `${metin} ${link}` }); } catch (e) { /* vazgeçildi */ }
  return true;
}
