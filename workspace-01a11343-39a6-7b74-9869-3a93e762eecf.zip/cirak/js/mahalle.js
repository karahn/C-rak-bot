import { sistemMetni as npcMetni, sistemSablonu as npcSablon } from './dil.js?v=0.38.0';
import { t as dilMetni } from './dil.js?v=0.38.0';
// "Mahallem" 3D sahnesi: ana cadde, arka sokak, ara sokaklar ve meydandan oluşan mahalle.
// Kiralanabilir dükkânlar, seyyar tezgâhlar, kavşaklarda ışıkta duran arabalar, yayalar ve müşteriler.
// Kamera sokak seviyesinden kuş bakışına kadar yakınlaşıp uzaklaşır ve döner.
import * as THREE from 'three';
import { parcaliIs } from './parcali-is.js?v=0.38.0';
import { araliklariBol, aydinlatmaPayi } from './sehir-duzen.js?v=0.38.0';
import { Sky } from 'three/addons/objects/Sky.js';
import { ekranKonumu, getRenderer } from './sahne.js?v=0.38.0';
import {
  dogalCimMalzemesi, tezgahModeli, bosYer, bosYerOynat, apartman, araba, sokakLambasi, bayrakZinciri, birlestir, birlestirParcali, agac, bank, copKutusu, copKonteyneri, supurge, copArabasi, asiliBayrak, pankart, isikZinciri, vitrinIsigi, durak, cami, isikliCam, hale, isikLekesi,
  trafikLambasi, tabure, ortu, semsiyeTutacak, babaModeli, reklamPanosu, farHuzmesiMalzemesi, tavanKariMalzemesi, kopekModeli, kopekAdim, kusModeli, kusCirp,
} from './modeller.js?v=0.38.0';
import { insanUret, insanGuncelle, insanSaydamlik, mevsimAyarla, kiyafetYenile, hizCarpani, insanLod, insanAdimAraligi } from './insanlar.js?v=0.38.0';
import { dokuAl } from './varliklar.js?v=0.38.0';
import { sehirKur } from './sehir.js?v=0.38.0';
import { olayMotoru } from './olaylar.js?v=0.38.0';
import { havaEfektleri } from './hava.js?v=0.38.0';
import { kalite } from './kalite.js?v=0.38.0';
import * as kalabalik from './kalabalik.js?v=0.38.0';
import * as ses from './ses.js?v=0.38.0';
import { esc, sade, sureMetni, simdi, halkaSvg, api } from './yardimci.js?v=0.38.0';

const ARALIK = 7.2;          // aynı sıradaki tezgâh yerleri arası mesafe
const TEZGAH_Z = -3.4;       // kuzey kaldırımındaki tezgâh sırası (bina önü)
const GUNEY_TEZGAH_Z = 13.2; // güney kaldırımındaki tezgâh sırası (park gezinti yolu), yüzleri güneye
const MUSTERI_SERIDI_G = 15.35;
const ORTA_Z = (TEZGAH_Z + GUNEY_TEZGAH_Z) / 2; // iki sıranın ortası: kamera buraya bakar
const OLCEK = 1.2;
const ETIKET_Y = 4.2;
const KALDIRIM_Y = 0.2;
const SOKAK = 90;            // sokağın yarı uzunluğu (sahne sınırı)
const BINA_ON = -8.2;        // bina cephesinin z konumu
const GECIT_X = 31;          // yaya geçidi
const DUKKAN_KAPI_Z = BINA_ON + 0.25;

const ARABA_SERITLERI = [{ z: 5.3, yon: 1 }, { z: 2.4, yon: -1 }];
const YAYA_SERITLERI = [{ z: -6.9, yon: 1 }, { z: -6.2, yon: -1 }, { z: -0.95, yon: 1 }, { z: -0.35, yon: -1 }];
const MUSTERI_SERIDI = -1.25;
// Tezgâhlar yolun iki yanına sırayla dağılır: çift sıradakiler kuzeyde, tekler güneyde (etiketler üst üste binmesin)
function yerKonumu(sira, adet) {
  const guney = sira % 2 === 1;
  const sutun = Math.floor(sira / 2);
  const sutunSayisi = Math.ceil(adet / 2);
  const x = (sutun - (sutunSayisi - 1) / 2) * ARALIK + (guney ? 1.8 : -1.8);
  return { x, z: guney ? GUNEY_TEZGAH_Z : TEZGAH_Z, guney };
}
const DUKKAN_SERIDI = -6.55;

const rnd = (a, b) => a + Math.random() * (b - a);

function tohumluRastgele(tohum) {
  let t = tohum >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

// Tezgâh başındaki müşterilerin siparişleri
const SIPARISLER = {
  ayakkabi: ['Boyar mısın?', 'Siyah cila lütfen', 'Parlat şunu!', 'Şu çizikleri de kapatır mısın?', 'Kahverengi cila var mı?', 'Bugün parlasınlar usta', 'İki çift kaç olur?', 'Önce tozunu alalım', 'Cilayı biraz daha parlat', 'Bugün toplantım var', 'İki ayakkabı da aynı olsun', 'Kolay gelsin usta'],
  su: ['Bir su alayım', 'Soğuk su var mı?', 'Mendil alayım', 'İki küçük su lütfen', 'Buz gibi olsun', 'Bir paket mendil de ver', 'Su kaç lira?', 'Susuz kaldım, yetiştin', 'İki su da soğuk olsun', 'Büyük şişe var mı?', 'Bir tane de arkadaşıma', 'Yürüyüşten sonra iyi geldi'],
  semsiye: ['Şemsiye kaç para?', 'Büyüğünden bir tane', 'Kırmızı olsun', 'Rüzgâra dayanıklı mı?', 'Katlanır var mı?', 'Yağmur bastırmadan alayım', 'Siyah olanı gösterir misin?', 'İki kişi sığar mı?', 'Sapı sağlam mı?', 'Küçük çantama sığar mı?', 'Lacivert olanı alayım', 'Bir tane paketler misin?'],
  pamuk: ['Pembe olsun!', 'Bir balon!', 'Pamuk şeker!', 'Mavi balon var mı?', 'Çocuğa bir tane alayım', 'Büyük pamuk şeker olsun', 'İki tane hazırlayabilir misin?', 'Şu kırmızı balon çok güzel', "Bir tane de kardeşine", "Beyaz pamuk şeker var mı?", "Balonun ipini uzun bırak", "Paketleyebilir misin?"],
  simit: ['İki simit lütfen', 'Bir simit alayım', 'Taze çıktı mı?', 'Susamı bol olsun', 'Yanına çay iyi giderdi', 'Çıtır olanından ver', 'Üç tane paketler misin?', 'Sabah simidi gibisi yok', "İki simit paket yapar mısın?", "Biraz çıtır olsun", "Ofise götüreceğim", "Kolay gelsin, bir simit alayım"],
  pazar: ['Çorap kaç lira?', 'Üç tişört alayım', 'Bunu alayım', 'Başka renk var mı?', 'Bir beden büyüğü var mı?', 'İkisini birlikte alıyorum', 'Pamuklu mu?', 'Şu modeli gösterebilir misin?', "Kumaşına bakabilir miyim?", "Küçük boyu da var mı?", "İki çift çorap alayım", "Hediye edeceğim"],
  misir: ['Közlenmiş olsun', 'Haşlama olsun', 'Bol tuzlu', 'Tereyağı ekler misin?', 'Sıcacık bir mısır', 'İki tane hazırlarsın', 'Tuzu az olsun', 'Kokusu çok güzel geldi', "Tuzsuz bir tane lütfen", "İki tane paket olsun", "Biraz soğusun da alayım", "Büyük boy var mı?"],
  kestane: ['Yarım kilo', 'Sıcak kestane!', 'Bir külah', 'İyi pişmiş olsun', 'Çocuklara iki külah', 'Biraz daha koyar mısın?', 'Taze kavruldu mu?', 'Kokusu sokağı sardı', "Küçük bir paket yap", "İki kişilik olsun", "Kabukları kolay açılıyor mu?", "Birazdan sıcak sıcak alayım"],
  midye: ['On midye lütfen', 'Limonlu olsun', 'Beş tane daha', 'Acı sos var mı?', 'Bir porsiyon hazırla', 'Bol limon sık', 'Tane tane sayalım', 'Arkadaşıma da götüreceğim', "Bir porsiyon paket yap", "Limonu ayrı koyar mısın?", "İki kişiye yeter mi?", "Beş tane deneyelim"],
  dondurma: ['Çikolatalı olsun', 'Maraş usulü', 'Külahta üç top', 'Bir top fıstık ekle', 'Külah yerine kap olsun', 'Çilekli kaldı mı?', 'Çocuk için küçük boy', 'Sıcak havaya iyi gider', "Vanilyalı da ekleyelim", "İki küçük külah olsun", "Fıstıklı var mı?", "Birini kapta alayım"],
  gozleme: ['Peynirli olsun', 'Patatesli olsun', 'Bir ıspanaklı', 'Yanına ayran var mı?', 'İyice kızarsın lütfen', 'İki gözleme paket yap', 'Sıcakken yemek lazım', 'Karışık hazırlayabilir misin?', "Patatesle peyniri karıştır", "Bölüp paketler misin?", "Bir tane de eve götüreyim", "Çayı da hazırlayalım"],
  kokorec: ['Yarım ekmek', 'Çeyrek, acılı', 'Bol kekikli', 'Az acılı olsun', 'Domatesi bol olsun', 'İki yarım hazırla', 'Ekmeği kızartır mısın?', 'Mis gibi kokuyor', "Baharatı az olsun", "Birini acısız yap", "Paket alabilir miyim?", "İnce kıyılmış olsun"],
};

export function mahalleOlustur({ tiklandi, keseTik, dukkanTiklandi, servisTik, oyunSaati, olayKatil, zabitaSonucu, izinVar, olayHaberi, uzaklasti = () => {}, reklamTik = null, komsuTiklandi = () => {} }) {
  const introCekim = typeof window !== 'undefined' && window.CIRAK_INTRO_CEKIM === true;
  const K = kalite();
  const sahne = new THREE.Scene();
  const kamera = new THREE.PerspectiveCamera(38, 1, 0.5, 4200);
  sahne.fog = new THREE.Fog('#B8D4E8', 110, 420);

  // ------------------------------------------------ Gökyüzü ve ışık
  const gokSahne = new THREE.Scene();
  const gok = new Sky();
  gok.scale.setScalar(150);
  const gu = gok.material.uniforms;
  // berrak ve mavi gökyüzü
  gu.turbidity.value = 2.6;
  gu.rayleigh.value = 2.2;
  gu.mieCoefficient.value = 0.003;
  gu.mieDirectionalG.value = 0.8;
  gokSahne.add(gok);
  const gok2 = new Sky();
  gok2.scale.setScalar(3000);
  gok2.material = gok.material;
  sahne.add(gok2);

  const yildizGeo = new THREE.BufferGeometry();
  const yp = [];
  for (let i = 0; i < 900; i++) {
    const t = Math.random() * Math.PI * 2;
    const y = rnd(0.08, 1);
    const r = Math.sqrt(1 - y * y);
    yp.push(Math.cos(t) * r * 800, y * 800, Math.sin(t) * r * 800);
  }
  yildizGeo.setAttribute('position', new THREE.Float32BufferAttribute(yp, 3));
  const yildizlar = new THREE.Points(yildizGeo, new THREE.PointsMaterial({ color: '#FFFFFF', size: 1.6, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false }));
  sahne.add(yildizlar);

  // ------------------------------------------------ Gerçek hava: yağmur, kar, bulut ve sis
  // ıslak zemin, sıçrayan damlalar, şimşek, kar örtüsü ve bulut gölgeleri hava.js'de
  const havaEf = havaEfektleri({ sahne, kalite: K.kod });
  havaEf.gokGurultusuAyarla((uzak) => ses.gokGurultusu && ses.gokGurultusu(1.1 - uzak * 0.6));
  // Parçacıklar kameranın baktığı noktanın çevresindeki bir kutuda döner (ekranda hep yağıyormuş gibi görünür)
  const HAVA_KUTU = { x: 110, y: 46, z: 110 };
  const havaSayisi = { dusuk: 500, orta: 1000, yuksek: 1700 }[K.kod] || 800;
  let hava = { tur: 'acik', bulut: 0 };
  let bulutPayi = 0;   // 0 açık, 1 kapalı
  let hedefBulut = 0;
  let sisCarpani = 1;
  let yagis = null;    // { nesne, tur, poz, hiz }
  function yagisKur(tur) {
    if (yagis) { sahne.remove(yagis.nesne); yagis.nesne.geometry.dispose(); yagis.nesne.material.dispose(); yagis = null; }
    if (tur !== 'yagmur' && tur !== 'firtina' && tur !== 'ciseleme' && tur !== 'kar') return;
    const kar = tur === 'kar';
    const n = Math.round(havaSayisi * (tur === 'ciseleme' ? 0.4 : tur === 'firtina' ? 1.3 : 1));
    const poz = new Float32Array(n * (kar ? 3 : 6));
    const hiz = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = rnd(-HAVA_KUTU.x / 2, HAVA_KUTU.x / 2), y = rnd(0, HAVA_KUTU.y), z = rnd(-HAVA_KUTU.z / 2, HAVA_KUTU.z / 2);
      hiz[i] = kar ? rnd(1.2, 2.4) : rnd(22, 30);
      if (kar) poz.set([x, y, z], i * 3);
      else poz.set([x, y, z, x - 0.18, y + 0.8, z], i * 6);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(poz, 3));
    if (!kar) {
      // damla izinin alt ucu belirgin, üst ucu saydam
      const alfa = new Float32Array(n * 2);
      for (let i = 0; i < n; i++) { alfa[i * 2] = rnd(0.6, 1); alfa[i * 2 + 1] = 0; }
      geo.setAttribute('alfa', new THREE.BufferAttribute(alfa, 1));
    }
    const nesne = kar
      ? new THREE.Points(geo, new THREE.PointsMaterial({ color: '#FFFFFF', map: havaEf.karTanesi(), size: 0.16, sizeAttenuation: true, transparent: true, opacity: 0.95, depthWrite: false }))
      : new THREE.LineSegments(geo, havaEf.yagmurMalzemesi(tur === 'firtina' ? '#71869E' : '#8195AC', tur === 'ciseleme' ? 0.5 : 0.85));
    nesne.frustumCulled = false;
    nesne.renderOrder = 5;
    sahne.add(nesne);
    yagis = { nesne, kar, poz, hiz, n };
  }
  function yagisGuncelle(dt, t) {
    if (!yagis) return;
    yagis.nesne.position.set(hedefX, 0, hedefZ);
    const p = yagis.poz;
    const yX = HAVA_KUTU.x / 2, yZ = HAVA_KUTU.z / 2;
    for (let i = 0; i < yagis.n; i++) {
      const dy = yagis.hiz[i] * dt;
      if (yagis.kar) {
        const k = i * 3;
        p[k + 1] -= dy;
        p[k] += Math.sin(t * 0.8 + i) * dt * 0.6;
        if (p[k + 1] < 0) { p[k + 1] += HAVA_KUTU.y; p[k] = rnd(-yX, yX); p[k + 2] = rnd(-yZ, yZ); }
      } else {
        const k = i * 6;
        p[k + 1] -= dy; p[k + 4] -= dy;
        p[k] -= dy * 0.22; p[k + 3] -= dy * 0.22;
        if (p[k + 1] < 0) {
          const x = rnd(-yX, yX), z = rnd(-yZ, yZ), y = HAVA_KUTU.y + p[k + 1];
          p[k] = x; p[k + 1] = y; p[k + 2] = z; p[k + 3] = x - 0.18; p[k + 4] = y + 0.8; p[k + 5] = z;
        }
      }
    }
    yagis.nesne.geometry.attributes.position.needsUpdate = true;
  }
  let kiyafetAnahtari = '';
  function havaAyarla(h, mevsim) {
    const yeni = h || { tur: 'acik', bulut: 0 };
    // kıyafetler mevsime ve sıcaklığa uysun: sıcaklık kuşağı değişince sokaktakiler yeniden giyinir
    const derece = h && Number.isFinite(h.hissedilen) ? h.hissedilen : h && Number.isFinite(h.sicaklik) ? h.sicaklik : { kis: 5, ilkbahar: 16, yaz: 28, sonbahar: 14 }[mevsim] ?? 18;
    const anahtar = `${mevsim}|${derece <= 10 ? 'soguk' : derece >= 24 ? 'sicak' : 'ilik'}`;
    if (anahtar !== kiyafetAnahtari) {
      kiyafetAnahtari = anahtar;
      mevsimAyarla(mevsim, derece);
      for (const k of [...yayalar, ...gecenler, ...musteriler]) kiyafetYenile(k);
    }
    const degisti = !yagis !== !['yagmur', 'firtina', 'ciseleme', 'kar'].includes(yeni.tur) || (yagis && hava.tur !== yeni.tur);
    hava = yeni;
    hedefBulut = { acik: 0, parcali: 0.25, bulutlu: 0.6, sis: 0.55, ciseleme: 0.65, yagmur: 0.8, kar: 0.75, firtina: 0.95 }[yeni.tur] || 0;
    sisCarpani = yeni.tur === 'sis' ? 0.3 : yeni.tur === 'kar' || yeni.tur === 'firtina' ? 0.6 : yeni.tur === 'yagmur' ? 0.75 : 1;
    if (degisti) yagisKur(yeni.tur);
    havaEf.ayarla(yeni.tur);
    semsiyeleriAyarla(['yagmur', 'firtina', 'ciseleme', 'kar'].includes(yeni.tur));
  }
  // Yağmurda yayaların çoğu şemsiye açar
  let semsiyeAcik = false;
  const SEMSIYE_RENK = ['#1C1C1C', '#C0392B', '#2F80D1', '#8E44AD', '#1FA25A', '#F2C14E', '#E67E22', '#34495E'];
  function semsiyeleriAyarla(acik) {
    if (acik === semsiyeAcik) return;
    semsiyeAcik = acik;
    for (const y of [...yayalar, ...gecenler, ...musteriler]) {
      if (acik && Math.random() < 0.7) {
        const s2 = semsiyeTutacak(SEMSIYE_RENK[Math.floor(Math.random() * SEMSIYE_RENK.length)]);
        s2.position.set(0.18, 0, 0.1);
        y.add(s2);
        y.userData.semsiye = s2;
      } else if (!acik && y.userData.semsiye) {
        y.remove(y.userData.semsiye);
        bellektenSil(y.userData.semsiye);
        y.userData.semsiye = null;
      }
    }
  }
  const bulutSis = new THREE.Color('#9AA4AF');
  const SIMSEK_RENK = new THREE.Color('#E8EEFF');

  const yarim = new THREE.HemisphereLight('#D6ECFF', '#9C8B6E', 0.45);
  sahne.add(yarim);
  const gunes = new THREE.DirectionalLight('#FFF4DE', 2.8);
  gunes.castShadow = K.golge;
  if (K.golge) {
    gunes.shadow.mapSize.set(K.golgeBoyut, K.golgeBoyut);
    Object.assign(gunes.shadow.camera, { left: -26, right: 26, top: 22, bottom: -22, near: 1, far: 140 });
    gunes.shadow.bias = -0.0004;
    gunes.shadow.normalBias = 0.03;
  }
  sahne.add(gunes);
  sahne.add(gunes.target);

  const pmrem = new THREE.PMREMGenerator(getRenderer());
  let ortam = null;
  let sonOrtamYuk = -99;
  const gunesYonu = new THREE.Vector3();

  // ------------------------------------------------ Mahalle düzeni
  // Ana cadde (z=4.3) ile arka sokak (z=-42) paralel, iki ara sokak (XB ve XD) bunları dik keser.
  const A_Z = 4.3;          // ana cadde orta çizgisi
  const B_Z = -42;          // arka sokak orta çizgisi
  const B_YARI = 3.5;       // arka sokak yarı genişliği
  const SIRA = {
    0: { on: BINA_ON, yon: 1, serit: DUKKAN_SERIDI },         // ana cadde, bina yüzü güneye
    1: { on: -34.5, yon: -1, serit: -35.3 },                  // arka sokağın güney sırası, yüzü kuzeye
    2: { on: -49.5, yon: 1, serit: -48.7 },                   // arka sokağın kuzey sırası, yüzü güneye
  };
  let DURAK_X = 55;         // otobüs durağı (güney kaldırımı)
  let XB = -85;             // batıdaki ara sokak
  let XD = 85;              // doğudaki ara sokak
  let kuruldu = false;
  let sehir = null;       // çevredeki semt (uzaktan görünür)
  const sokakEtiketleri = [];
  let sokakAdlari = null;

  const zemin = new THREE.Mesh(new THREE.PlaneGeometry(2400, 2400), dogalCimMalzemesi(480,480));
  havaEf.zeminEkle(zemin.material, 'cim');
  zemin.rotation.x = -Math.PI / 2;
  zemin.position.y = -0.01;
  zemin.receiveShadow = true;
  sahne.add(zemin);

  const beyazBoya = new THREE.MeshStandardMaterial({ color: '#FFFFFF', roughness: 0.6, emissive: '#FFFFFF', emissiveIntensity: 0.08 });
  const bordurMat = new THREE.MeshStandardMaterial({ color: '#C8C5BF', roughness: 0.9, map: dokuAl('siva', 40, 1) });
  // kavşak ve geçit başlarında kırmızı-beyaz boyalı bordür (araç park etmesin diye)
  const cizgiliBordurMat = (() => {
    const c = document.createElement('canvas');
    c.width = 128; c.height = 16;
    const x = c.getContext('2d');
    x.fillStyle = '#F2F0EA'; x.fillRect(0, 0, 128, 16);
    x.fillStyle = '#C8201E'; x.fillRect(0, 0, 64, 16);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return (uzunluk) => {
      const k = t.clone();
      k.repeat.set(uzunluk / 1.0, 1);
      k.needsUpdate = true;
      return new THREE.MeshStandardMaterial({ map: k, roughness: 0.7 });
    };
  })();
  function cizgiliBordur(x1, x2, z1, z2) {
    const parcalar = z1 < 1 ? araliklariBol(x1, x2, [XB, XD]) : [[x1, x2]];
    if (parcalar.length !== 1 || parcalar[0][0] !== x1 || parcalar[0][1] !== x2) {
      for (const [a, b] of parcalar) cizgiliBordur(a, b, z1, z2);
      return;
    }
    const b = new THREE.Mesh(new THREE.BoxGeometry(x2 - x1, 0.27, z2 - z1), cizgiliBordurMat(x2 - x1));
    b.position.set((x1 + x2) / 2, 0.135, (z1 + z2) / 2);
    b.receiveShadow = true;
    sahne.add(b);
  }

  // Kaldırım: kilitli parke taşı dokusu (açık gri taşlar, aralıklarla kiremit rengi bantlar), hafif kabartma.
  // Doku bir kez çizilir; her kaldırım kendi ölçüsünde tekrar eder.
  const kaldirimDokulari = (() => {
    const B = 512; // 4 m × 4 m
    const renkC = document.createElement('canvas');
    renkC.width = renkC.height = B;
    const kabC = document.createElement('canvas');
    kabC.width = kabC.height = B;
    const r = renkC.getContext('2d');
    const k = kabC.getContext('2d');
    r.fillStyle = '#9C958C';
    r.fillRect(0, 0, B, B);
    k.fillStyle = '#000';
    k.fillRect(0, 0, B, B);
    const tas = 32;        // 0,25 m
    // Türkiye kaldırımları: gri-bej kilit parke, aralarda kırmızı-kahve bant
    const TONLAR = ['#CFCBC3', '#C5C1B9', '#D6D2CA', '#C9C4BB', '#BEB9B0', '#D1CCC2'];
    const BANT = ['#A45544', '#98503F', '#AD5E4B'];
    // balıksırtı dizilim: 2:1 taşlar
    for (let y = -2; y < B / tas + 2; y++) {
      for (let x = -2; x < B / tas + 2; x++) {
        // Şaşırtmalı derzler: taşlar üst üste binmez.
        const px = x * tas * 2 + (y % 2 ? tas : 0);
        const py = y * tas;
        const w = tas * 2 - 3;
        const h = tas - 3;
        // her 4 m'de bir 0,5 m genişliğinde kiremit bant
        const bant = ((py % B) + B) % B < 64;
        const renk = bant ? BANT[Math.abs(x * 7 + y * 3) % 3] : TONLAR[Math.abs(x * 13 + y * 7) % TONLAR.length];
        r.fillStyle = renk;
        r.beginPath(); r.roundRect(px + 1.5, py + 1.5, w, h, 4); r.fill();
        // Fırınlanmış taş gözenekleri: ek geometri ve kare başına iş yok.
        r.fillStyle = 'rgba(55,45,35,.09)';
        for (let t = 0; t < 7; t++) { const tx = 3 + ((x * 17 + y * 23 + t * 13) % 53 + 53) % 53, ty = 3 + ((x * 7 + y * 11 + t * 9) % 23 + 23) % 23; r.fillRect(px + tx, py + ty, 1, 1); }
        const gr = k.createLinearGradient(px, py, px + w, py + h);
        gr.addColorStop(0, '#E6E6E6'); gr.addColorStop(1, '#BDBDBD');
        k.fillStyle = gr;
        k.beginPath(); k.roundRect(px + 1.5, py + 1.5, w, h, 5); k.fill();
      }
    }
    const renk = new THREE.CanvasTexture(renkC);
    renk.colorSpace = THREE.SRGBColorSpace;
    const kabartma = new THREE.CanvasTexture(kabC);
    for (const t of [renk, kabartma]) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8; }
    return { renk, kabartma };
  })();
  function kaldirimX(x1, x2, z1, z2) {
    const w = x2 - x1;
    const d = z2 - z1;
    const harita = kaldirimDokulari.renk.clone();
    harita.repeat.set(w / 4, d / 4);
    harita.needsUpdate = true;
    const kab = kaldirimDokulari.kabartma.clone();
    kab.repeat.set(w / 4, d / 4);
    kab.needsUpdate = true;
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, KALDIRIM_Y, d), new THREE.MeshStandardMaterial({
      color: '#FFFFFF', map: harita, bumpMap: kab, bumpScale: 0.025, roughness: 0.88,
    }));
    m.position.set((x1 + x2) / 2, KALDIRIM_Y / 2, (z1 + z2) / 2);
    m.receiveShadow = true;
    havaEf.zeminEkle(m.material, 'kaldirim');
    sahne.add(m);
  }
  // Görme engelliler için sarı kabartmalı kılavuz şerit (kaldırım boyunca)
  const kilavuzMat = (() => {
    const c = document.createElement('canvas');
    c.width = 64; c.height = 64;
    const x = c.getContext('2d');
    x.fillStyle = '#F2C230';
    x.fillRect(0, 0, 64, 64);
    x.strokeStyle = '#D9A91C';
    x.lineWidth = 5;
    for (const yy of [16, 48]) { x.beginPath(); x.moveTo(4, yy); x.lineTo(60, yy); x.stroke(); }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return (uzunluk) => {
      const k = t.clone();
      k.repeat.set(uzunluk / 0.6, 1);
      k.needsUpdate = true;
      return new THREE.MeshStandardMaterial({ map: k, roughness: 0.7 });
    };
  })();
  function kilavuz(x1, x2, z) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(x2 - x1, 0.4), kilavuzMat(x2 - x1));
    m.rotation.x = -Math.PI / 2;
    m.position.set((x1 + x2) / 2, KALDIRIM_Y + 0.004, z);
    m.receiveShadow = true;
    sahne.add(m);
  }
  // Kaldırım ağacı çukuru: dökme demir ızgara
  const izgaraMat = new THREE.MeshStandardMaterial({ color: '#3B3F46', roughness: 0.5, metalness: 0.6 });
  function agacCukuru(x, z) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.02, 1.3), izgaraMat);
    m.position.set(x, KALDIRIM_Y + 0.01, z);
    sabitler.add(m);
  }
  function asfalt(x1, x2, z1, z2, y = 0.02) {
    const w = x2 - x1;
    const d = z2 - z1;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({
      color: '#B4BAC6', map: dokuAl('asfalt', w / 8, d / 8), normalMap: dokuAl('asfalt_n', w / 4, d / 4), roughness: 0.92,
    }));
    m.rotation.x = -Math.PI / 2;
    m.position.set((x1 + x2) / 2, y, (z1 + z2) / 2);
    m.receiveShadow = true;
    havaEf.zeminEkle(m.material, 'asfalt');
    sahne.add(m);
  }
  // Hareket etmeyen süs ve çevre nesneleri: mahalle kurulunca malzemelerine göre birleştirilir (az çizim, akıcı oyun)
  const sabitler = new THREE.Group();
  sahne.add(sabitler);
  function cizgi(x, z, w, d) {
    const s = new THREE.Mesh(new THREE.PlaneGeometry(w, d), beyazBoya);
    s.rotation.x = -Math.PI / 2;
    s.position.set(x, 0.035, z);
    sabitler.add(s);
  }
  function bordur(x1, x2, z1, z2) {
    if (z1 < 1) {
      const parcalar = araliklariBol(x1, x2, [XB, XD]);
      if (parcalar.length !== 1 || parcalar[0][0] !== x1 || parcalar[0][1] !== x2) {
        for (const [a, b] of parcalar) bordur(a, b, z1, z2);
        return;
      }
    }
    const b = new THREE.Mesh(new THREE.BoxGeometry(x2 - x1, 0.26, z2 - z1), bordurMat);
    b.position.set((x1 + x2) / 2, 0.13, (z1 + z2) / 2);
    b.receiveShadow = true;
    sahne.add(b);
  }

  const lambalar = [];
  const isiklar = [];        // { grup, eksen }
  const gecelik = { haleler: new Set(), tabelalar: new Set() };
  // Sahneden kaldırılan bir nesnenin GPU belleğini boşaltır ve gece ışıkları listesinden çıkarır.
  // Malzemeler modeller arasında paylaşıldığı için silinmez; yalnızca binaya özel tabela dokusu silinir.
  // geometri=false: şekli başka kopyalarla paylaşılan nesneler (insanlar) için
  function bellektenSil(kok, { geometri = true } = {}) {
    if (!kok) return;
    kok.traverse((o) => {
      gecelik.haleler.delete(o);
      if (geometri && o.geometry && !o.geometry.userData.paylasimli) o.geometry.dispose();
      if (o.material) {
        for (const m of Array.isArray(o.material) ? o.material : [o.material]) {
          if (m.userData && m.userData.tabela) {
            gecelik.tabelalar.delete(m);
            if (m.map) m.map.dispose();
            if (m.emissiveMap && m.emissiveMap !== m.map) m.emissiveMap.dispose();
            m.dispose();
          } else if (!geometri && m.userData && m.userData.kisisel) m.dispose();
        }
      }
    });
  }
  function geceIsiklariniTopla(kok) {
    kok.traverse((o) => {
      if (o.userData.hale || o.userData.leke) gecelik.haleler.add(o);
      if (o.isMesh) {
        const liste = Array.isArray(o.material) ? o.material : [o.material];
        for (const m of liste) if (m.userData && m.userData.tabela && !gecelik.tabelalar.has(m)) { if (!m.emissiveMap) m.emissiveMap = m.map; gecelik.tabelalar.add(m); }
      }
    });
  }
  function lambaKoy(x, z, ry) {
    const l = sokakLambasi();
    l.position.set(x, KALDIRIM_Y, z);
    l.rotation.y = ry;
    sahne.add(l);
    lambalar.push(l);
    geceIsiklariniTopla(l);
  }
  function isikKoy(x, z, ry, eksen) {
    const t = trafikLambasi();
    t.position.set(x, KALDIRIM_Y, z);
    t.rotation.y = ry;
    sahne.add(t);
    isiklar.push({ grup: t, eksen });
  }

  // Satır genişliklerine göre bütün mahalleyi kurar (ilk cadde verisi gelince bir kez)
  // çöp konteynerleri (mahalleKur yerleştirir; çöp kamyonu ve çöpçüler kullanır)
  const konteynerler = [];
  // Yürünen zeminin yüksekliği: asfaltta yol seviyesi, kaldırımda kaldırım seviyesi (inen biner kaldırıma adım atar)
  function zeminY(x, z) {
    if (z > 0.2 && z < 8.4) return 0.02;
    if (z > B_Z - B_YARI && z < B_Z + B_YARI && x > XB - 3.5 && x < XD + 3.5) return 0.02;
    if (z < 0.2 && (Math.abs(x - XB) < 3.5 || Math.abs(x - XD) < 3.5)) return 0.02;
    return KALDIRIM_Y;
  }
  // reklam panoları (aşağıda: panoCiz, reklamlariAyarla)
  const panolar = [];
  let reklamlar = [];
  let panoSira = 0;
  let sonPano = 0;
  function mahalleKur(genislikler) {
    kuruldu = true;
    const yari = Math.max(60, ...genislikler.map((g) => g / 2));
    XB = -(yari + 6.5);
    XD = yari + 6.5;
    const S = { x1: XB - 70, x2: XD + 70 };

    // Ana cadde: yol, iki yanda kaldırım (kuzeydeki tezgâh kaldırımı ara sokaklar arasında)
    asfalt(S.x1, S.x2, 0.2, 8.4);
    kaldirimX(XB + 3.5, XD - 3.5, BINA_ON, 0.2);
    kaldirimX(S.x1, XB - 3.5, BINA_ON, 0.2);
    kaldirimX(XD + 3.5, S.x2, BINA_ON, 0.2);
    // güney kaldırımı geniş bir gezinti yolu: yol kenarında lambalar ve durak, ortada tezgâh sırası, parka doğru çiçek tarhları
    // Ara sokaklar ana caddede biter; karşı kaldırım kesintisiz devam eder.
    kaldirimX(S.x1, S.x2, 8.4, 17.8);
    kilavuz(S.x1, S.x2, 11.4);
    kilavuz(XB + 3.5, XD - 3.5, -1.55);
    bordur(S.x1, S.x2, -0.04, 0.24);
    bordur(S.x1, S.x2, 17.7, 17.95);
    bordur(S.x1, S.x2, 8.36, 8.64);
    // geçit ve kavşak başlarında boyalı bordür ve siyah-sarı babalar
    for (const [ax, bx] of [[GECIT_X - 6, GECIT_X + 6], [XB - 12, XB + 12], [XD - 12, XD + 12]]) {
      cizgiliBordur(ax, bx, -0.05, 0.25);
      cizgiliBordur(ax, bx, 8.35, 8.65);
    }
    for (const [bx, bz] of [[GECIT_X - 2.6, -0.5], [GECIT_X + 2.6, -0.5], [GECIT_X - 2.6, 9.1], [GECIT_X + 2.6, 9.1], [XB + 4.2, -0.5], [XB + 5.6, -0.5], [XD - 4.2, -0.5], [XD - 5.6, -0.5], [XB + 4.2, 9.1], [XD - 4.2, 9.1]]) {
      const b = babaModeli();
      b.position.set(bx, KALDIRIM_Y, bz);
      sabitler.add(b);
      kalabalik.engelEkle(bx, bz, 0.25, 0.25);
    }
    for (let x = S.x1; x < S.x2; x += 6) if (Math.abs(x - GECIT_X) > 8 && Math.abs(x - XB) > 6 && Math.abs(x - XD) > 6) cizgi(x, 3.85, 3, 0.14);
    for (let z = 0.95; z < 7.8; z += 0.9) cizgi(GECIT_X, z, 3.2, 0.5);
    cizgi(GECIT_X - 2.6, 5.9, 0.3, 3.4);
    cizgi(GECIT_X + 2.6, 2.1, 0.3, 3.4);

    // Arka sokak
    asfalt(XB - 3.5, XD + 3.5, B_Z - B_YARI, B_Z + B_YARI);
    kaldirimX(XB + 3.5, XD - 3.5, B_Z + B_YARI, SIRA[1].on);
    kaldirimX(XB + 3.5, XD - 3.5, SIRA[2].on, B_Z - B_YARI);
    bordur(XB + 3.5, XD - 3.5, B_Z + B_YARI - 0.14, B_Z + B_YARI + 0.14);
    bordur(XB + 3.5, XD - 3.5, B_Z - B_YARI - 0.14, B_Z - B_YARI + 0.14);
    for (let x = XB + 8; x < XD - 6; x += 6) cizgi(x, B_Z, 3, 0.14);

    // Ara sokaklar (kuzey-güney)
    for (const X of [XB, XD]) {
      asfalt(X - 3.5, X + 3.5, -75, 8.4, 0.021);
      for (const kx of [X - 5.5, X + 5.5]) {
        for (const [a, b] of araliklariBol(-75, BINA_ON, [B_Z], B_YARI)) kaldirimX(kx - 2, kx + 2, a, b);
      }
      for (let z = -72; z < 0; z += 6) if (Math.abs(z - B_Z) > 7) cizgi(X, z, 0.14, 3);
      // köşe ışıkları: biri ana cadde trafiğine, biri ara sokak trafiğine bakar
      isikKoy(X - 4.3, 9.2, -Math.PI / 2, 'x');
      isikKoy(X + 4.3, -0.6, 0, 'z');
      isikKoy(X - 4.3, B_Z + B_YARI + 0.6, -Math.PI / 2, 'x');
      isikKoy(X + 4.3, B_Z - B_YARI - 0.6, 0, 'z');
      for (let z = 1; z < 8; z += 0.9) cizgi(X - 5.2, z, 1.6, 0.4);
    }
    // yaya geçidindeki ışıklar
    isikKoy(GECIT_X - 2.2, 8.85, -Math.PI / 2, 'x');
    isikKoy(GECIT_X + 2.2, -0.15, Math.PI / 2, 'x');

    // Lambalar ve eşyalar (0.38.0: kaldırımın farklı yerlerinde en az üç bank; yayalar arada oturup dinlenir)
    let lambaSira = 0;
    for (let lx = S.x1 + 10; lx <= S.x2 - 10; lx += 13.8) {
      if (Math.abs(lx - XB) < 6 || Math.abs(lx - XD) < 6) continue;
      lambaKoy(lx, 8.95, Math.PI / 2);
      if (Math.abs(lx - GECIT_X) < 5) continue;
      lambaSira++;
      if (lambaSira % 3 === 1 || Math.random() < 0.3) {
        const b = bank();
        b.position.set(lx + 3.2, KALDIRIM_Y, 10.6);
        b.rotation.y = Math.PI;
        sabitler.add(b);
        kalabalik.engelEkle(lx + 3.2, 10.65, 1.7, 0.5);
        banklar.push({ x: lx + 3.2, z: 10.6, oturan: [] });
      } else {
        const k = copKutusu();
        k.position.set(lx + 2.5, KALDIRIM_Y, 9.4);
        sabitler.add(k);
        kalabalik.engelEkle(lx + 2.5, 9.4, 0.45, 0.45);
      }
    }
    for (let lx = XB + 12; lx <= XD - 12; lx += 16) {
      lambaKoy(lx, B_Z + B_YARI + 0.6, -Math.PI / 2);
    }
    // ana caddenin üstünde renkli bayrak zincirleri (şenlikli çarşı havası)
    for (let bx = S.x1 + 17; bx <= S.x2 - 17; bx += 27.6) {
      if (Math.abs(bx - XB) < 8 || Math.abs(bx - XD) < 8) continue;
      sabitler.add(bayrakZinciri([bx - 3, 6.6, BINA_ON + 0.4], [bx + 3, 5.4, 8.9], 1.1));
    }
    const d = durak();
    DURAK_X = Math.min(55, XD - 12);
    d.position.set(DURAK_X, KALDIRIM_Y, 10.4);
    d.rotation.y = Math.PI;
    sabitler.add(d);
    kalabalik.engelEkle(DURAK_X, 10.95, 3.4, 0.45);
    // kaldırımdaki ışıklı reklam panoları: reklam kampanyası süren dükkânların adı sırayla döner
    for (const px of [DURAK_X - 4.2, XB + 16]) {
      const pano = reklamPanosu();
      pano.position.set(px, KALDIRIM_Y, 10.25);
      sahne.add(pano);
      kalabalik.engelEkle(px, 10.25, 1.5, 0.45);
      const isabet = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.6, 0.6), new THREE.MeshBasicMaterial({ visible: false }));
      isabet.position.set(px, 1.5, 10.25);
      isabet.userData.pano = true;
      sahne.add(isabet);
      panolar.push({ g: pano, isabet, sira: panolar.length });
    }
    panoCiz();
    // Belediye çöp konteynerleri: güney kaldırımında yol kenarında ve arka sokakta (çöp kamyonu bunları boşaltır)
    const yasak = [[DURAK_X, 4.2], [DURAK_X - 4.2, 2], [XB + 16, 2.2], [GECIT_X, 7], [XB, 6], [XD, 6]];
    for (let lx = S.x1 + 10; lx <= S.x2 - 10; lx += 13.8) yasak.push([lx, 1.1], [lx + 2.5, 1.2], [lx + 3.2, 1.6]);
    const serbest = (x) => yasak.every(([yx, pay]) => Math.abs(x - yx) > pay + 0.8);
    const konteynerKoy = (x, z, ry, yolZ) => {
      const k = copKonteyneri();
      k.position.set(x, KALDIRIM_Y, z);
      k.rotation.y = ry;
      sahne.add(k);
      kalabalik.engelEkle(x, z, 1.5, 1.15);
      konteynerler.push({ g: k, x, z, ry, yolZ, kapak: k.userData.kapak });
    };
    for (const hedef of [XB + 24, (XB + XD) / 2 - 9, XD - 24]) {
      let x = hedef;
      for (let i = 0; i < 30 && !serbest(x); i++) x += (i % 2 ? -1 : 1) * (i + 1) * 0.7;
      if (serbest(x) && x > XB + 8 && x < XD - 8) konteynerKoy(x, 9.5, 0, 7.3);
    }
    konteynerKoy(XB + 9.5, B_Z + B_YARI + 0.95, Math.PI, B_Z + 1.7);
    konteynerKoy(XD - 9.5, B_Z - B_YARI - 0.95, 0, B_Z - 1.7);
    const cali = new THREE.MeshStandardMaterial({ color: '#547349', roughness: 0.95, flatShading: false });
    havaEf.zeminEkle(cali, 'cim');
    for (let cx = S.x1; cx < S.x2; cx += 2.2) {
      if (Math.abs(cx - XB) < 5 || Math.abs(cx - XD) < 5) continue;
      const m = new THREE.Mesh(new THREE.IcosahedronGeometry(rnd(0.7, 1), 1), cali);
      m.scale.y = 0.6;
      m.position.set(cx, 0.45, 18.5 + rnd(-0.15, 0.15));
      m.castShadow = true;
      sabitler.add(m);
    }
    // İki sıra binanın arasındaki avlulara ağaç
    for (let ax = XB + 10; ax < XD - 8; ax += rnd(9, 15)) {
      const a = agac();
      a.position.set(ax, 0, rnd(-25, -21));
      sabitler.add(a);
    }
    // kaldırım ağaçları (tezgâh bölgesi ve geçit dışında)
    for (let ax = XB + 8; ax <= XD - 6; ax += ARALIK * 2.5) {
      if (Math.abs(ax) < 29 || Math.abs(ax - GECIT_X) < 5) continue;
      const a = agac();
      a.scale.setScalar(0.8);
      a.position.set(ax, KALDIRIM_Y, -0.6);
      sabitler.add(a);
      agacCukuru(ax, -0.6);
      kalabalik.engelEkle(ax, -0.6, 0.7, 0.7);
    }

    // Doğuda meydan ve cami, batıda park
    const meydanX = XD + 40;
    kaldirimX(XD + 7.5, XD + 72, -60, -12);
    const c = cami();
    c.position.set(meydanX + 8, KALDIRIM_Y, -40);
    c.scale.setScalar(1.2);
    sabitler.add(c);
    for (let i = 0; i < 10; i++) {
      const a = agac();
      a.position.set(XD + 12 + (i % 5) * 11, KALDIRIM_Y, -18 - Math.floor(i / 5) * 8);
      sabitler.add(a);
    }
    for (let i = 0; i < 4; i++) {
      const b = bank();
      b.position.set(meydanX - 10 + i * 6, KALDIRIM_Y, -26);
      sabitler.add(b);
    }
    const havuz = new THREE.Mesh(new THREE.CylinderGeometry(3.5, 3.8, 0.6, 32), new THREE.MeshStandardMaterial({ color: '#C9C6BE', roughness: 0.8 }));
    havuz.position.set(meydanX - 6, 0.3, -48);
    sabitler.add(havuz);
    const su = new THREE.Mesh(new THREE.CircleGeometry(3.2, 32), new THREE.MeshStandardMaterial({ color: '#4A8FC2', roughness: 0.1, metalness: 0.3 }));
    su.rotation.x = -Math.PI / 2;
    su.position.set(meydanX - 6, 0.55, -48);
    sabitler.add(su);
    for (let i = 0; i < 26; i++) {
      const a = agac();
      a.position.set(XB - 12 - rnd(0, 55), 0, rnd(-70, -12));
      sabitler.add(a);
    }
    // Çevredeki mahalle: cadde ızgarası, apartman blokları, parklar ve camiler (uzaklaşınca bütün semt görünür)
    sehir = sehirKur({
      cekirdek: { x1: S.x1, x2: S.x2, zK: -75, zG: 42 },
      araSokaklar: [XB, 0, XD],
      anaCadde: { z1: 0.2, z2: 8.4 },
      tohum: 7,
      yaricap: SEHIR_YARICAP,
    });
    sahne.add(sehir.grup);
    // Semtin dışı boş bir zeminle kesilmez: dünya konumuna bağlı sis kenarı.
    // Merkezdeki modeller ve dokular değişmez; dış bloklar havanın rengine karışır.
    const kenarMalzemeleri = new Set([zemin.material]);
    sehir.grup.traverse((o) => { if (o.material) for (const m of Array.isArray(o.material) ? o.material : [o.material]) kenarMalzemeleri.add(m); });
    for (const m of kenarMalzemeleri) {
      if (!m.fog || m.isShaderMaterial) continue;
      const derle = m.onBeforeCompile, anahtar = m.customProgramCacheKey.bind(m);
      const eskiAnahtar = anahtar();
      m.onBeforeCompile = function (shader, renderer) {
        derle.call(this, shader, renderer);
        shader.vertexShader = 'varying vec2 vCirakKenar;\n' + shader.vertexShader;
        shader.vertexShader = shader.vertexShader.replace('#include <worldpos_vertex>', `#include <worldpos_vertex>
          vec4 cirakYer = vec4(transformed, 1.0);
          #ifdef USE_INSTANCING
            cirakYer = instanceMatrix * cirakYer;
          #endif
          vCirakKenar = (modelMatrix * cirakYer).xz;`);
        shader.fragmentShader = 'varying vec2 vCirakKenar;\n' + shader.fragmentShader;
        shader.fragmentShader = shader.fragmentShader.replace('#include <fog_fragment>', `#include <fog_fragment>
          #ifdef USE_FOG
            float cirakSinir = length(vec2(vCirakKenar.x / 300.0, vCirakKenar.y / (vCirakKenar.y > 0.0 ? 225.0 : 300.0)));
            gl_FragColor.rgb = mix(gl_FragColor.rgb, fogColor, smoothstep(0.72, 1.0, cirakSinir));
          #endif`);
      };
      m.customProgramCacheKey = () => eskiAnahtar + '|cirak-semt-sisi-0359';
      m.needsUpdate = true;
    }
    if (sehir.malzemeler) { havaEf.zeminEkle(sehir.malzemeler.asfalt, 'asfalt'); havaEf.zeminEkle(sehir.malzemeler.kaldirim, 'kaldirim'); havaEf.zeminEkle(sehir.malzemeler.cim, 'cim'); }

    // Ana caddenin güneyi: ağaçlı park şeridi, çiçek tarhları, yürüyüş yolu ve banklar
    kaldirimX(S.x1, S.x2, 20.2, 22.6);
    const tarhRenk = ['#C37D87', '#D8B467', '#AD6D83', '#C08F63', '#9B8AAC', '#E3DED3'];
    const toprak = new THREE.MeshStandardMaterial({ color: '#8B5A3C', roughness: 1 });
    for (let px = S.x1 + 6; px < S.x2 - 6; px += rnd(9, 13)) {
      const a = agac();
      a.position.set(px, 0, rnd(25, 31));
      sabitler.add(a);
      if (Math.random() < 0.6) {
        const a2 = agac();
        a2.scale.setScalar(rnd(0.7, 0.9));
        a2.position.set(px + rnd(3, 5), 0, rnd(31, 38));
        sabitler.add(a2);
      }
      // çiçek tarhı
      const tx = px + rnd(-2, 2);
      const tarh = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.3, 1.1), toprak);
      tarh.position.set(tx, KALDIRIM_Y + 0.15, 16.9);
      sabitler.add(tarh);
      kalabalik.engelEkle(tx, 16.9, 3.2, 1.1);
      const renk = tarhRenk[Math.floor(Math.random() * tarhRenk.length)];
      const cicekMat = new THREE.MeshStandardMaterial({ color: renk, roughness: 0.9, flatShading: false });
      for (let i = 0; i < 6; i++) {
        const px=tx-1.3+i*.52,pz=16.9+rnd(-.18,.18);
        const yesil=new THREE.Mesh(new THREE.IcosahedronGeometry(.14,1),cali);yesil.position.set(px,KALDIRIM_Y+.35,pz);yesil.scale.y=.55;sabitler.add(yesil);
        if(i%2) {
          for(let j=0;j<5;j++) {const aci=j*Math.PI*2/5;const petal=new THREE.Mesh(new THREE.SphereGeometry(.06,6,4),cicekMat);petal.scale.set(1,.5,.65);petal.position.set(px+Math.cos(aci)*.067,KALDIRIM_Y+.47,pz+Math.sin(aci)*.067);sabitler.add(petal);}
          const merkez=new THREE.Mesh(new THREE.SphereGeometry(.025,6,4),cicekMat);merkez.position.set(px,KALDIRIM_Y+.48,pz);sabitler.add(merkez);
        }
      }
      if (Math.random() < 0.35) {
        const b = bank();
        b.position.set(px + 1.5, KALDIRIM_Y, 20.9);
        b.rotation.y = Math.PI;
        sabitler.add(b);
      }
    }

    // hareket etmeyen her şey malzemesine göre birleşir: yüzlerce çizim birkaç taneye iner
    // hücreli birleştirme: sokakta yalnızca görünen kısım (ve gölge alanı) çizilir
    birlestir(sabitler, { hucre: 48 });

    sokakEtiketi('anaCadde', 'Cumhuriyet Caddesi', 0, A_Z);
    sokakEtiketi('arkaSokak', 'İstiklal Sokak', 0, B_Z);
    sokakEtiketi('batiSokak', 'Atatürk Bulvarı', XB, -20);
    sokakEtiketi('doguSokak', 'Lale Sokak', XD, -20);
    sokakEtiketi('meydan', 'Meydan', meydanX, -30);
    // 0.30: yağmurda asfaltta su birikintileri (yol kenarlarına yakın, çukurlarda); kuruyunca kaybolur
    for (let i = 0; i < 46; i++) {
      const arka = i % 4 === 3;
      const zm = arka ? B_Z : A_Z;
      const kenar = (Math.random() < 0.5 ? -1 : 1) * ((arka ? B_YARI - 1.1 : 3.1) + (Math.random() - 0.5) * 1.0);
      havaEf.birikintiEkle(XB + 4 + Math.random() * (XD - XB - 8), 0.034, zm + kenar, 0.8 + Math.random() * 2.2, 0.45 + Math.random() * 0.8);
    }

    trafikKur();
    yayaKur();
    copcuKur();
    if (semsiyeAcik) { semsiyeAcik = false; semsiyeleriAyarla(true); }
    if (sokakAdlari) caddeGuncelle([], sokakAdlari);
  }

  function sokakEtiketi(anahtar, ad, x, z) {
    const e = document.createElement('div');
    e.className = 'etiket gizli';
    e.innerHTML = `<button class="sokak-adi">${esc(ad)}</button>`;
    etiketKutusu.appendChild(e);
    e.querySelector('button').addEventListener('click', () => ucusYap(x, z, 34));
    // etiket sokağın görünen bir noktasına konur: sokak boyunca birkaç aday nokta, binaların ardında kalanlar elenir
    const adaylar = anahtar === 'anaCadde' || anahtar === 'arkaSokak'
      ? [-60, -30, 0, 30, 60].map((dx) => [x + dx, z])
      : anahtar === 'meydan' ? [[x, z]] : [-110, -95, -80, -65, -50, -35, -20, -5, 10].map((zz) => [x, zz]);
    sokakEtiketleri.push({ e, x, z, anahtar, adaylar, gx: x, gz: z, gorunur: false, sonBakis: 0 });
  }
  // Görüş denetimi: kameradan noktaya giden ışın bir binayı (dükkân sıraları ya da semtin binaları) kesiyor mu?
  const gorusIsini = new THREE.Ray();
  const gorusYon = new THREE.Vector3();
  const gorusNokta = new THREE.Vector3();
  function noktaGorunur(x, y, z) {
    gorusYon.set(x, y, z).sub(kamera.position);
    const boy = gorusYon.length();
    gorusIsini.set(kamera.position, gorusYon.normalize());
    for (const d of dukkanlar.values()) {
      if (!d.kutu || d.engel) continue; // kesit alınmış (saydamlaşmış) bina görüşü kapatmaz
      const k = gorusIsini.intersectBox(d.kutu, gorusNokta);
      if (k && kamera.position.distanceTo(gorusNokta) < boy - 1) return false;
    }
    const kl = sehir && sehir.binaKutulari;
    if (kl) {
      for (const b of kl) {
        const k = gorusIsini.intersectBox(b, gorusNokta);
        if (k && kamera.position.distanceTo(gorusNokta) < boy - 1) return false;
      }
    }
    return true;
  }
  function sokakEtiketiKonumla(s) {
    const t = performance.now();
    if (t - s.sonBakis < 220) return s.gorunur;
    s.sonBakis = t;
    // bakılan yere en yakın görünen aday seçilir
    const sirali = s.adaylar.slice().sort((a, b) => Math.hypot(a[0] - hedefX, a[1] - hedefZ) - Math.hypot(b[0] - hedefX, b[1] - hedefZ));
    // 0.30: etiket yazısı birkaç metre yer kaplar; yalnızca noktası değil, yazının üst kenarı ve iki yanı da açıkta
    // olmalı (yoksa ad binaların arkasından yarım yamalak görünüyordu)
    const px = (mesafe * 1.15) / Math.max(320, window.innerHeight); // bir ekran pikselinin metre karşılığı
    const w = s.e.offsetWidth ? s.e.offsetWidth / 2 : 70;
    const sagX = Math.cos(aci) * w * px, sagZ = -Math.sin(aci) * w * px;
    const ust = 30 * px;
    const tamGorunur = (ax, az) => noktaGorunur(ax, 0.6, az) && noktaGorunur(ax, ust, az)
      && noktaGorunur(ax + sagX, 0.6, az + sagZ) && noktaGorunur(ax - sagX, 0.6, az - sagZ);
    const bulunan = sirali.find(([ax, az]) => tamGorunur(ax, az));
    s.gorunur = !!bulunan;
    if (bulunan) { s.gx = bulunan[0]; s.gz = bulunan[1]; }
    return s.gorunur;
  }

  // ------------------------------------------------ Dükkânlar (3 sıra)
  const dukkanlar = new Map(); // no -> { grup, veri, anahtar, etiket, isabet, merkezX, sira }
  const etiketKutusu = document.getElementById('etiketler');

  function dukkanAnahtari(y) {
    const i = y.isletme;
    return i ? `${i.tur}|${i.ad}|${i.durum}` : 'kiralik';
  }

  let ilkCaddeHazirlik = null;
  function binayiUret(y) {
    const i = y.isletme;
    return apartman({ genislik:y.genislik, kat:y.kat, derinlik:9, rng:tohumluRastgele(y.tohum),
      dukkan:i ? {ad:i.ad,tur:i.tur,durum:i.durum,simge:i.simge} : {durum:'kiralik'} });
  }
  async function caddeHazirla(yerler, isimler) {
    if (ilkCaddeHazirlik) { await ilkCaddeHazirlik; return caddeGuncelle(yerler, isimler); }
    if (dukkanlar.size) return caddeGuncelle(yerler, isimler);
    const hazir = new Map();
    ilkCaddeHazirlik = (async () => {
      const siralar = [0,1,2].map(k => yerler.filter(y => (y.sira || 0) === k).sort((a,b) => a.no-b.no));
      const genislikler = siralar.map(l => l.reduce((a,y) => a+y.genislik+.25,0));
      if (!kuruldu) mahalleKur(genislikler);
      const liste = siralar.flatMap((l,k) => {
        const sigdir = Math.min(1,(XD-XB-8.5)/Math.max(1,genislikler[k]));
        return l.map(y => sigdir < 1 ? {...y,genislik:Math.round(y.genislik*sigdir*10)/10} : y);
      });
      let i = 0;
      await parcaliIs(() => { if (i >= liste.length) return false; const y = liste[i++]; hazir.set(y.no,binayiUret(y)); return true; });
      caddeGuncelle(yerler, isimler, false, hazir);
    })();
    try { await ilkCaddeHazirlik; }
    finally { ilkCaddeHazirlik = null; for (const g of hazir.values()) bellektenSil(g); }
  }

  function caddeGuncelle(yerler, isimler, zorla = false, hazirBinalar = null) {
    // başka ilçeyi gezerken kendi caddemizin yenilenen verisi saklanır, ekrana basılmaz
    if (!ziyaret || !zorla) kendiCadde = { yerler, isimler: isimler || (kendiCadde && kendiCadde.isimler) };
    if (ziyaret && !zorla) return;
    if (isimler) {
      for (const s2 of sokakEtiketleri) {
        const b = s2.e.querySelector('button');
        if (b && isimler[s2.anahtar] && b.textContent !== isimler[s2.anahtar]) b.textContent = isimler[s2.anahtar];
      }
      sokakAdlari = isimler;
    }
    const siralar = [0, 1, 2].map((k) => yerler.filter((y) => (y.sira || 0) === k).sort((a, b) => a.no - b.no));
    const genislikler = siralar.map((l) => l.reduce((a, y) => a + y.genislik + 0.25, 0));
    if (!kuruldu) mahalleKur(genislikler);
    siralar.forEach((liste, k) => {
      const S = SIRA[k];
      // başka bir ilçenin (ya da sonradan genişleyen) dükkân sırası ara sokaklara taşmasın: gerekirse sıkıştırılır
      const sigdir = Math.min(1, (XD - XB - 8.5) / Math.max(1, genislikler[k]));
      let bx = (-genislikler[k] / 2) * sigdir;
      for (const y0 of liste) {
        const y = sigdir < 1 ? { ...y0, genislik: Math.round(y0.genislik * sigdir * 10) / 10 } : y0;
        const merkezX = bx + y.genislik / 2;
        bx += y.genislik + 0.25 * sigdir;
        let d = dukkanlar.get(y.no);
        const anahtar = dukkanAnahtari(y);
        if (!d) {
          const etiket = document.createElement('div');
          etiket.className = 'etiket gizli';
          etiketKutusu.appendChild(etiket);
          // tıklama alanı binanın tamamı: cephe, üst katlar ve çatı (kuş bakışında da dokunulabilsin)
          const yukseklik = 4 + (y.kat || 2) * 3.1;
          const isabet = new THREE.Mesh(new THREE.BoxGeometry(y.genislik * 0.96, yukseklik, 9.4), new THREE.MeshBasicMaterial({ visible: false }));
          isabet.position.set(merkezX, yukseklik / 2, S.on - S.yon * 4.3);
          isabet.userData.dukkan = y.no;
          sahne.add(isabet);
          d = { etiket, isabet };
          dukkanlar.set(y.no, d);
        }
        Object.assign(d, { veri: y, merkezX, sira: k, onZ: S.on, yon: S.yon, seritZ: S.serit });
        if (d.anahtar !== anahtar) {
          if (d.grup) {
            sahne.remove(d.grup);
            saydamlikUygula(d, 1); // saydam kopyalar silinir, asıl malzemeler geri takılır
            bellektenSil(d.grup);
          }
          if (d.uzak) { sahne.remove(d.uzak); bellektenSil(d.uzak); d.uzak = null; }
          topluBinalariSil();
          d.saydamlik = 1;
          d.golgeVar = true;
          const i = y.isletme;
          d.grup = hazirBinalar?.get(y.no) || binayiUret(y);
          hazirBinalar?.delete(y.no);
          d.grup.position.set(merkezX, KALDIRIM_Y, S.on - S.yon * 4.5);
          d.grup.rotation.y = S.yon > 0 ? 0 : Math.PI;
          sahne.add(d.grup);
          d.kutu = new THREE.Box3().setFromObject(d.grup);
          geceIsiklariniTopla(d.grup);
          d.uzakAyar = { genislik: y.genislik, kat: y.kat, tohum: y.tohum, dukkan: i ? { ad: i.ad, tur: i.tur, durum: i.durum, simge: i.simge } : { durum: 'kiralik' }, x: merkezX, z: S.on - S.yon * 4.5, ry: S.yon > 0 ? 0 : Math.PI };
          d.uzakta = false;
          d.anahtar = anahtar;
          d.etiketDurum = '';
        }
        dukkanEtiketi(d);
      }
    });
    topluBinalarIste();
  }

  // Dükkânların üstünde yazı balonu yok: ad tabelada, kapalıysa kepenkte "🌙 KAPALI" yazar.
  // Yalnızca kendi dükkânının önünde, tezgâhtaki "+" çerçevesi gibi yavaşça yanıp sönen bir dokunma işareti durur.
  // ------------------------------------------------ Reklam panoları
  function panoCiz() {
    panolar.forEach((p, i) => {
      const r = reklamlar.length ? reklamlar[(panoSira + i) % reklamlar.length] : null;
      p.gosterilen = r;
      if (!r) {
        p.g.userData.ciz({ baslik: i ? 'Mahallenin yıldızı sen ol' : 'Burada reklamın olabilir', alt: 'Dükkânına reklam ver', simge: '📣', sira: i + 3, sistem: true });
        return;
      }
      const d = [...dukkanlar.values()].find((x) => x.veri && x.veri.no === r.yerNo);
      const simge = d && d.veri.isletme ? d.veri.isletme.simge : '🏪';
      p.g.userData.ciz({ baslik: r.ad, alt: ['Hemen yanı başında!', 'Mahallenin gözdesi', 'Kaliteli ve uygun', 'Bekliyoruz!'][(panoSira + i) % 4], simge, sira: panoSira + i });
    });
  }
  function reklamlariAyarla(l) {
    const anahtar = JSON.stringify(l || []);
    if (anahtar === JSON.stringify(reklamlar)) return;
    reklamlar = l || [];
    panoCiz();
  }
  function panoGuncelle(t) {
    for (const p of panolar) p.g.userData.yuz.emissiveIntensity = 0.22 + gecePayi * 0.95;
    if (reklamlar.length > 1 && t - sonPano > 7) { sonPano = t; panoSira++; panoCiz(); }
  }

  function dukkanEtiketi(d) {
    const i = d.veri.isletme;
    let html = '';
    if (i && i.benim) {
      const kasa = i.kasa > 0 && i.durum !== 'ruhsat';
      const ad = `${esc(i.ad)}${i.durum === 'ruhsat' ? ' (ruhsat bekliyor)' : ''}${kasa ? `, kasada ${sade(i.kasa)} ₺` : ''}`;
      html = `<button class="dukkan-isaret${kasa ? ' kasa' : ''}${i.durum === 'ruhsat' ? ' bekliyor' : ''}" data-dukkan="${d.veri.no}" aria-label="${ad}"><i></i></button>`;
    }
    if (!i || i.durum === 'kiralik') html = `<button class="dukkan-isaret kiralik" data-dukkan="${d.veri.no}" aria-label="${npcMetni('Kiralık dükkânı incele')}"><i></i></button>`;
    if (d.etiketDurum !== html) { d.etiket.innerHTML = html; d.etiketDurum = html; }
  }

  // Günün saatine göre sokak yoğunluğu: işe gidiş, öğle ve iş çıkışı en kalabalık saatler
  const YOGUNLUK = [0.2, 0.15, 0.1, 0.1, 0.12, 0.25, 0.55, 1, 1, 0.75, 0.6, 0.65, 0.95, 0.9, 0.65, 0.6, 0.7, 1, 1, 0.95, 0.7, 0.5, 0.4, 0.3];
  function yogunluk() {
    const s = oyunSaati();
    const a = Math.floor(s) % 24;
    const b = (a + 1) % 24;
    const k = s - Math.floor(s);
    return YOGUNLUK[a] * (1 - k) + YOGUNLUK[b] * k;
  }

  // ------------------------------------------------ Trafik ışıkları
  // x yönündeki (doğu-batı) ve z yönündeki (kuzey-güney) trafik sırayla yeşil yanar
  // her yeşilden sonra kısa bir "hepsi kırmızı" süresi: kavşakta kalan araba çıkmadan öbür yön kalkmaz
  const DONGU = [['x-yesil', 20], ['x-sari', 3], ['kirmizi', 2], ['z-yesil', 14], ['z-sari', 3], ['kirmizi', 2]];
  let isikEvre = 0;
  let isikSure = rnd(0, 15);
  function isikAdi() { return DONGU[isikEvre][0]; }
  function yesilMi(eksen) { return isikAdi() === eksen + '-yesil'; }
  function sariMi(eksen) { return isikAdi() === eksen + '-sari'; }

  function isikGuncelle(dt) {
    isikSure += dt;
    if (isikSure > DONGU[isikEvre][1]) { isikSure = 0; isikEvre = (isikEvre + 1) % DONGU.length; }
    for (const { grup, eksen } of isiklar) {
      const { lambalar: l, yaya } = grup.userData.lamba;
      const acik = { kirmizi: !yesilMi(eksen) && !sariMi(eksen), sari: sariMi(eksen), yesil: yesilMi(eksen) };
      for (const k of ['kirmizi', 'sari', 'yesil']) {
        l[k].m.emissiveIntensity = acik[k] ? 3 : 0;
        l[k].h.material.opacity = acik[k] ? 0.5 + gecePayi * 0.5 : 0;
      }
      // yayalar, o yöndeki araç trafiği kırmızıyken geçer
      const gec = eksen === 'x' ? yesilMi('z') : yesilMi('x');
      yaya.gec.emissiveIntensity = gec ? 3 : 0;
      yaya.dur.emissiveIntensity = gec ? 0 : 3;
    }
  }

  // ------------------------------------------------ Trafik
  // Şeritler yalnızca asfaltın olduğu yerlerde uzanır. Ana cadde ve ara sokakların kuzey ucu çevre ızgaranın caddelerine
  // bağlanır (sisin içinde, uzakta); arabalar yola orada girer ve orada çıkar. Ara sokakların güney ucu ve arka sokağın
  // iki ucu kavşakta biter: arabalar oraya gelince sağa ya da sola döner (yolun olmadığı bina aralarından ya da parktan
  // araç çıkmaz). Ana caddedekiler de ara sıra ara sokaklara döner.
  const arabalar = [];
  let SERITLER = [];
  let KAVSAKLAR = [];
  const donenler = [];      // kavşakta dönen arabalar (şeritten çıkmış, eğri üstünde)
  const disEngeller = new Set(); // şerit dışında yolda duran/yanaşan görev araçları
  const UZAK = 170;         // ana caddenin iki yanda, ara sokakların kuzeyde uzandığı mesafe (sisin içi)
  // Türkiye sokaklarındaki araç karışımı: sedan ve hatchback çoğunlukta, SUV, hafif ticari (Doblo tipi), sarı taksi ve dolmuş
  const TURLER = ['sedan', 'hatchback', 'sedan', 'taksi', 'suv', 'kombi', 'sedan', 'hatchback', 'dolmus', 'taksi', 'suv', 'sedan', 'kombi', 'hatchback'];

  function seritKonum(s, p) {
    return s.eksen === 'x' ? [p, s.sabit] : [s.sabit, p];
  }
  function seritAcisi(s) {
    return s.eksen === 'x' ? (s.yon > 0 ? 0 : Math.PI) : (s.yon > 0 ? -Math.PI / 2 : Math.PI / 2);
  }
  // Dönüş eğrisi: kaynak şeritten hedef şeride, iki şeridin kesiştiği köşe (C) kontrol noktası olan ikinci derece Bezier.
  // r: köşeden ne kadar önce dönmeye başlanır (sağa dönüş dar, sola dönüş geniş)
  function donus(kaynak, hedef, r) {
    const C = kaynak.eksen === 'x' ? [hedef.sabit, kaynak.sabit] : [kaynak.sabit, hedef.sabit];
    const kose = kaynak.eksen === 'x' ? hedef.sabit : hedef.sabit; // kaynak ekseninde köşenin konumu
    const pA = kose - kaynak.yon * r;
    const pB = (kaynak.eksen === 'x' ? kaynak.sabit : kaynak.sabit) + hedef.yon * r;
    const A = seritKonum(kaynak, pA);
    const B = seritKonum(hedef, pB);
    // yay uzunluğu (örnekleyerek)
    let uz = 0;
    let [px, pz] = A;
    for (let i = 1; i <= 12; i++) {
      const [x, z] = bezier(A, C, B, i / 12);
      uz += Math.hypot(x - px, z - pz);
      px = x; pz = z;
    }
    // sağa mı sola mı: gidiş yönleri arasındaki dönüşün işareti (x doğu, z güney; +z sağ taraf)
    const kv = kaynak.eksen === 'x' ? [kaynak.yon, 0] : [0, kaynak.yon];
    const hv = hedef.eksen === 'x' ? [hedef.yon, 0] : [0, hedef.yon];
    const taraf = kv[0] * hv[1] - kv[1] * hv[0] > 0 ? 'sag' : 'sol';
    return { kaynak, hedef, r, A, B, C, pA, pB, uz, taraf, hiz: 2.2 + r * 1.1 };
  }
  function bezier(A, C, B, t) {
    const u = 1 - t;
    return [u * u * A[0] + 2 * u * t * C[0] + t * t * B[0], u * u * A[1] + 2 * u * t * C[1] + t * t * B[1]];
  }
  function bezierTurev(A, C, B, t) {
    return [2 * (1 - t) * (C[0] - A[0]) + 2 * t * (B[0] - C[0]), 2 * (1 - t) * (C[1] - A[1]) + 2 * t * (B[1] - C[1])];
  }

  function trafikKur() {
    const L1 = XB - UZAK;
    const L2 = XD + UZAK;
    const KZ = -75 - UZAK;
    const anaDogu = { eksen: 'x', sabit: 5.3, yon: 1, min: L1, max: L2, dur: [XB - 4.7, GECIT_X - 2.8, XD - 4.7], bas: 'uzak', son: 'uzak' };
    const anaBati = { eksen: 'x', sabit: 2.4, yon: -1, min: L1, max: L2, dur: [XD + 4.7, GECIT_X + 2.8, XB + 4.7], bas: 'uzak', son: 'uzak' };
    const arkaDogu = { eksen: 'x', sabit: B_Z + 1.7, yon: 1, min: XB - 3.5, max: XD + 3.5, dur: [XD - 4.7], bas: 'donus', son: 'donus' };
    const arkaBati = { eksen: 'x', sabit: B_Z - 1.7, yon: -1, min: XB - 3.5, max: XD + 3.5, dur: [XB + 4.7], bas: 'donus', son: 'donus' };
    SERITLER = [anaDogu, anaBati, arkaDogu, arkaBati];
    const ara = {};
    for (const X of [XB, XD]) {
      const guneye = { eksen: 'z', sabit: X - 1.7, yon: 1, min: KZ, max: 8.4, dur: [B_Z - B_YARI - 1, -0.8], bas: 'uzak', son: 'donus' };
      const kuzeye = { eksen: 'z', sabit: X + 1.7, yon: -1, min: KZ, max: 8.4, dur: [B_Z + B_YARI + 1], bas: 'donus', son: 'uzak' };
      SERITLER.push(guneye, kuzeye);
      ara[X] = { guneye, kuzeye };
    }
    for (const s of SERITLER) s.cikislar = [];
    const SAG = 2.0, SOL = 3.4;
    const cikis = (s, secenekler, olasilik) => s.cikislar.push({ secenekler, olasilik, zorunlu: olasilik >= 1, p: Math.min(...secenekler.map((d) => d.pA * s.yon)) * s.yon });
    for (const X of [XB, XD]) {
      const { guneye, kuzeye } = ara[X];
      // ana caddeden ara sokağa (kuzeye) dönüş
      cikis(anaDogu, [donus(anaDogu, kuzeye, SOL)], 0.16);
      cikis(anaBati, [donus(anaBati, kuzeye, SAG)], 0.16);
      // ara sokağın güney ucu ana caddede biter: sağa (batıya) ya da sola (doğuya)
      cikis(guneye, [donus(guneye, anaBati, SAG), donus(guneye, anaDogu, SOL)], 1);
    }
    // ara sokaklardan arka sokağa
    cikis(ara[XB].guneye, [donus(ara[XB].guneye, arkaDogu, SOL)], 0.3);
    cikis(ara[XD].guneye, [donus(ara[XD].guneye, arkaBati, SAG)], 0.3);
    cikis(ara[XB].kuzeye, [donus(ara[XB].kuzeye, arkaDogu, SAG)], 0.3);
    cikis(ara[XD].kuzeye, [donus(ara[XD].kuzeye, arkaBati, SOL)], 0.3);
    // arka sokağın uçları: kavşakta sağa ya da sola
    cikis(arkaDogu, [donus(arkaDogu, ara[XD].guneye, SAG), donus(arkaDogu, ara[XD].kuzeye, SOL)], 1);
    cikis(arkaBati, [donus(arkaBati, ara[XB].kuzeye, SAG), donus(arkaBati, ara[XB].guneye, SOL)], 1);
    for (const s of SERITLER) s.cikislar.sort((a, b) => (a.p - b.p) * s.yon);

    // kavşak kutuları: içinde öbür yönden bir araba varken kavşağa girilmez
    KAVSAKLAR = [];
    for (const X of [XB, XD]) {
      KAVSAKLAR.push({ x1: X - 3.6, x2: X + 3.6, z1: 0.1, z2: 8.7, dolu: { x: false, z: false } });
      KAVSAKLAR.push({ x1: X - 3.6, x2: X + 3.6, z1: B_Z - B_YARI - 0.1, z2: B_Z + B_YARI + 0.1, dolu: { x: false, z: false } });
    }
    // arabalar yalnızca uzak uçtan başlayan şeritlere dağıtılır (arka sokağa ve kuzeye giden şeride dönerek girilir)
    const baslangic = SERITLER.filter((s) => s.bas === 'uzak');
    const adet = Math.max(Math.round(K.araba * 1.7) + 4, 10);
    for (let i = 0; i < adet; i++) {
      const s = baslangic[i % baslangic.length];
      const tur = TURLER[i % TURLER.length];
      const a = araba(tur);
      // görünür kısma yakın başlasınlar: şeridin ilk 3/4'ünde, birbirinden aralıklı
      const ilk = s.cikislar.find((c) => c.zorunlu);
      const son = ilk ? ilk.p - s.yon * 12 : (s.yon > 0 ? s.max : s.min);
      const bas = s.yon > 0 ? s.min : s.max;
      const p = bas + (son - bas) * (0.08 + ((i * 0.37) % 1) * 0.84);
      const [x, z] = seritKonum(s, p);
      a.position.set(x, 0.02, z);
      a.rotation.y = seritAcisi(s);
      Object.assign(a.userData, { serit: s, p, hiz: rnd(5, 8), azami: s.eksen === 'x' && s.sabit > 0 ? rnd(8, 11) : rnd(6, 8), tur });
      a.userData.araba.haleler.forEach((h) => gecelik.haleler.add(h));
      sahne.add(a);
      arabalar.push(a);
    }
    // şeritte üst üste başlayanlar ayrılır
    for (const s of SERITLER) {
      const l = arabalar.filter((a) => a.userData.serit === s).sort((a, b) => (a.userData.p - b.userData.p) * s.yon);
      for (let i = 1; i < l.length; i++) if ((l[i].userData.p - l[i - 1].userData.p) * s.yon < 9) l[i].visible = false;
    }
    // park yerleri: bir kısmı dolu başlar
    for (let px = XB + 10; px < XD - 8; px += rnd(9, 14)) {
      // yaya geçidi ve otobüs durağının önüne park edilmez
      if (Math.abs(px - GECIT_X) < 7 || Math.abs(px - Math.min(55, XD - 12)) < 9) continue;
      // konteynerlerin önüne de park edilmez (çöp kamyonu yanaşır)
      if (konteynerler.some((k) => k.yolZ > 7 && k.yolZ < 8 && Math.abs(px - k.x) < 5.5)) continue;
      const yer = { x: px, araba: null, sure: 0 };
      if (Math.random() < 0.6) {
        const a = araba(['sedan', 'hatchback', 'sedan', 'suv', 'kombi', 'hatchback'][Math.floor(Math.random() * 6)]);
        a.position.set(px, 0.02, 7.25);
        farlar(a, false);
        lambaAyarla(a, 0);
        sahne.add(a);
        Object.assign(a.userData, { durum: 'park', hiz: 0, azami: rnd(6, 8), tur: 'sedan' });
        yer.araba = a;
        yer.sure = rnd(20, 200);
      }
      parkYerleri.push(yer);
    }
  }

  // Ön tekerlekler direksiyonla döner (dönüşte ve park ederken)
  function direksiyon(a, aci, dt) {
    const u = a.userData;
    u.direksiyon = (u.direksiyon || 0) + (Math.max(-0.55, Math.min(0.55, aci)) - (u.direksiyon || 0)) * Math.min(1, dt * 6);
    for (const t of u.araba.tekerler) if (t.position.x > 0) t.rotation.y = u.direksiyon;
  }
  function tekerDondur(a, yol) {
    const d = yol / a.userData.araba.r;
    for (const t of a.userData.araba.tekerler) t.rotation.z -= d;
  }
  // Yol üstündeki aracın bir eksen boyunca yarı boyu (yan duran araç şeritte daha az yer kaplar)
  function eksenYarisi(a, eksen) {
    const au = a.userData.araba;
    const c = Math.abs(eksen === 'x' ? Math.cos(a.rotation.y) : Math.sin(a.rotation.y));
    return (au.uzunluk / 2) * c + ((au.en || 1.8) / 2) * (1 - c);
  }

  // Uzak uca varan araba (görünmeden) başka bir yoldan yeniden gelir: sokağın yoğunluğuna göre görünür ya da görünmez
  function yenidenDagit(a) {
    const u = a.userData;
    const adaylar = SERITLER.filter((s) => s.bas === 'uzak' && !(s.kapaliBitis > performance.now()));
    const s = adaylar.length ? adaylar[Math.floor(Math.random() * adaylar.length)] : u.serit;
    const bas = s.yon > 0 ? s.min : s.max;
    const dolu = arabalar.some((b) => b !== a && b.userData.serit === s && b.visible && Math.abs(b.userData.p - bas) < 11);
    Object.assign(u, { serit: s, p: bas, hiz: u.azami * 0.8, cikis: null, karar: null, bekleme: 0 });
    a.visible = !dolu && !(s.kapaliBitis > performance.now()) && Math.random() < yogunluk();
    const [x, z] = seritKonum(s, bas);
    a.position.set(x, 0.02, z);
    a.rotation.y = seritAcisi(s);
    direksiyon(a, 0, 1);
  }

  const parkYerleri = [];
  const parkEdenler = [];   // park etmeye ya da çıkmaya çalışan arabalar
  let sonParkGelis = 0;
  // Park eden arabanın farları söner. Haleler yalnızca hava kararınca çizilir (gündüz boşuna çizilmesin).
  let isikAcikPayi = 0;
  function farlar(a, acik) {
    for (const h of a.userData.araba.haleler) { h.userData.kapali = !acik; h.visible = acik && isikAcikPayi > 0.01; }
  }
  const yumusak = (k) => { k = Math.max(0, Math.min(1, k)); return k * k * (3 - 2 * k); };
  const yumusakTurev = (k) => (k <= 0 || k >= 1 ? 0 : 6 * k * (1 - k));
  const PARK_YOL = 9;       // şeritten park yerine S çizerek geçilen mesafe
  const PARK_Z = 7.25;
  const SERIT_Z = 5.3;

  function parkGuncelle(dt, t) {
    const ana = SERITLER[0];
    // süresi dolan park eden araba çıkar
    for (const yer of parkYerleri) {
      if (!yer.araba || yer.araba.userData.durum !== 'park') continue;
      yer.sure -= dt;
      if (yer.sure > 0) continue;
      // arkadan gelen araba yoksa çık (önce sinyal verip bekler)
      const arkada = arabalar.some((b) => b.userData.serit === ana && b.visible && yer.x - b.userData.p > -2 && yer.x - b.userData.p < 16 + b.userData.hiz * 1.5);
      if (arkada) { yer.sure = 1.5; continue; }
      const a = yer.araba;
      yer.araba = null;
      Object.assign(a.userData, { durum: 'cikis', hiz: 0, basX: a.position.x, bekle: 0.9 });
      farlar(a, true);
      parkEdenler.push(a);
    }
    // ara sıra yoldan geçen bir araba boş yere park eder
    if (t - sonParkGelis > rnd(25, 70)) {
      sonParkGelis = t;
      const bos = parkYerleri.filter((y) => !y.araba);
      for (const yer of bos) {
        // önündeki park yeri de boşsa girer (ileri park için yer lazım)
        const aday = arabalar.find((b) => b.userData.serit === ana && b.visible && !b.userData.olay && !b.userData.cikis && yer.x - b.userData.p > PARK_YOL + 10 && yer.x - b.userData.p < 45);
        if (aday) {
          const i = arabalar.indexOf(aday);
          arabalar.splice(i, 1);
          aday.userData.serit = null;
          Object.assign(aday.userData, { durum: 'giris', hedefYer: yer });
          yer.araba = aday;
          parkEdenler.push(aday);
          break;
        }
      }
    }
    for (let i = parkEdenler.length - 1; i >= 0; i--) {
      const a = parkEdenler[i];
      const u = a.userData;
      if (u.durum === 'giris') {
        // yavaşlayarak yaklaşır, park yerinin önünde S çizerek kaldırıma yanaşır ve durur
        const hedefX = u.hedefYer.x;
        const kalan = hedefX - a.position.x;
        let sinir = Math.min(u.azami, Math.sqrt(0.25 + 2 * 1.6 * Math.max(0, kalan)));
        // şeritteyken önündeki arabayı ve geçitteki yayayı gözetir
        if (a.position.z < 6.4) {
          for (const b of arabalar) {
            if (b.userData.serit !== ana || !b.visible) continue;
            const on = b.userData.p - a.position.x - (u.araba.uzunluk + b.userData.araba.uzunluk) / 2;
            if (on > -1) sinir = Math.min(sinir, Math.max(0, (on - 2) * 1.1));
          }
          for (const y of yoldakiler) if (Math.abs(y.z - SERIT_Z) < 1.8 && y.x - a.position.x > 0 && y.x - a.position.x < 14) sinir = Math.min(sinir, Math.max(0, (y.x - a.position.x - 3) * 1.1));
        }
        u.fren = sinir < u.hiz - 0.3 || u.hiz < 0.3;
        u.sinyal = 'sag';
        u.hiz = Math.max(0, u.hiz + Math.max(-7 * dt, Math.min(2.2 * dt, sinir - u.hiz)));
        const adim = Math.min(kalan, u.hiz * dt);
        a.position.x += adim;
        const k = 1 - (hedefX - a.position.x) / PARK_YOL;
        a.position.z = SERIT_Z + (PARK_Z - SERIT_Z) * yumusak(k);
        const egim = ((PARK_Z - SERIT_Z) * yumusakTurev(k)) / PARK_YOL;
        const aci = -Math.atan(egim);
        direksiyon(a, (aci - a.rotation.y) * 6, dt);
        a.rotation.y = aci;
        tekerDondur(a, adim);
        if (kalan < 0.03) {
          u.durum = 'park';
          u.hiz = 0;
          a.position.set(hedefX, 0.02, PARK_Z);
          a.rotation.y = 0;
          direksiyon(a, 0, 1);
          u.hedefYer.sure = rnd(60, 240);
          u.fren = false;
          u.sinyal = null;
          lambaAyarla(a, 0);
          farlar(a, false);
          parkEdenler.splice(i, 1);
        }
      } else if (u.durum === 'cikis') {
        u.sinyal = 'sol';
        u.fren = u.bekle > 0;
        if (u.bekle > 0) { u.bekle -= dt; direksiyon(a, -0.45, dt); continue; }
        u.hiz = Math.min(6.5, u.hiz + dt * 2.2);
        const adim = u.hiz * dt;
        a.position.x += adim;
        const k = (a.position.x - u.basX) / PARK_YOL;
        a.position.z = PARK_Z - (PARK_Z - SERIT_Z) * yumusak(k);
        const egim = (-(PARK_Z - SERIT_Z) * yumusakTurev(k)) / PARK_YOL;
        const aci = -Math.atan(egim);
        direksiyon(a, (aci - a.rotation.y) * 6, dt);
        a.rotation.y = aci;
        tekerDondur(a, adim);
        if (k >= 1) {
          // ana caddedeki trafiğe katılır
          a.rotation.y = 0;
          a.position.z = SERIT_Z;
          Object.assign(u, { durum: 'yol', serit: ana, p: a.position.x, cikis: null, karar: null, sinyal: null });
          arabalar.push(a);
          parkEdenler.splice(i, 1);
        }
      }
    }
  }

  // Yolun üstündeki yayalar (geçitten geçenler ve sokak olaylarındaki insanlar): arabalar önlerinde durur
  let yoldakiler = [];
  function yoldakileriTopla() {
    yoldakiler = [];
    for (const y of gecenler) if (y.userData.gecis && y.position.z > 0.1 && y.position.z < 8.5) yoldakiler.push({ x: y.position.x, z: y.position.z });
    if (olaylar) for (const k of olaylar.insanlar()) if (k.g.position.z > 0.1 && k.g.position.z < 8.5) yoldakiler.push({ x: k.g.position.x, z: k.g.position.z });
  }
  // Yürüyenler birbirinin içinden geçmesin: hafifçe itişirler
  const itisListesi = [];
  function itisme(dt) {
    // park etmiş arabalar da yürüyenler için engeldir
    for (const yer of parkYerleri) {
      const dolu = !!(yer.araba && yer.araba.userData.durum === 'park');
      if (dolu && !yer.engel) yer.engel = kalabalik.engelEkle(yer.x, 7.25, 4.5, 1.9);
      else if (!dolu && yer.engel) { kalabalik.engelSil(yer.engel); yer.engel = null; }
    }
    itisListesi.length = 0;
    for (const y of yayalar) if (y.visible) itisListesi.push({ p: y.position, itZ: (dz) => { y.userData.kay = Math.max(-1.4, Math.min(1.4, (y.userData.kay || 0) + dz)); } });
    for (const m of musteriler) if (m.visible) itisListesi.push({ p: m.position, agir: m.userData.durum === 'bekle' });
    for (const y of gecenler) itisListesi.push({ p: y.position, agir: !y.userData.gecis });
    for (const y of yerler.values()) if (y.insan) itisListesi.push({ p: y.insan.getWorldPosition(new THREE.Vector3()), sabit: true });
    if (olaylar) for (const k of olaylar.insanlar()) itisListesi.push({ p: k.g.position, agir: !k.yuruyor, sabit: !!k.sabit });
    for (const c of copculer) if (c.g.visible) itisListesi.push({ p: c.g.position, agir: true });
    kalabalik.itis(itisListesi, dt);
  }

  // Şerit dışındaki yol engelleri (dönen, park eden, kaldırıma yanaşan araçlar): arkalarından gelen onlara çarpmaz
  const yolEngelleri = [];
  function yolEngelleriniTopla() {
    yolEngelleri.length = 0;
    for (const d of donenler) yolEngelleri.push(d.a);
    for (const a of parkEdenler) if (a.userData.durum !== 'park') yolEngelleri.push(a);
    for (const a of disEngeller) if (a.parent) yolEngelleri.push(a);
  }
  // Hedef şeride dönmek için yer var mı: yaklaşan araba yakınsa ya da dönüş noktasının hemen önü doluysa beklenir
  function donusBosMu(d, a) {
    const h = d.hedef;
    if (h.kapaliBitis > performance.now()) return false;
    for (const b of arabalar) {
      if (b === a || b.userData.serit !== h || !b.visible) continue;
      const fark = (d.pB - b.userData.p) * h.yon; // pozitif: araba dönüş noktasının gerisinde (geliyor)
      if (fark > -7 && fark < 0) return false;
      if (fark >= 0 && fark < 4 + b.userData.hiz * 1.6) return false;
    }
    for (const o of donenler) if (o.d.hedef === h && o.t < 0.85) return false;
    return true;
  }
  function donusBaslat(a, d) {
    const u = a.userData;
    arabalar.splice(arabalar.indexOf(a), 1);
    u.serit = null;
    donenler.push({ a, d, t: 0, hiz: Math.max(1.5, u.hiz) });
  }
  function donenleriGuncelle(dt) {
    for (let i = donenler.length - 1; i >= 0; i--) {
      const o = donenler[i];
      const { a, d } = o;
      const u = a.userData;
      // dönüşte yavaş, çıkışta hızlanır; önüne (hedef şeritte) araba çıkarsa durur
      let hedefHiz = d.hiz + o.t * 2;
      for (const b of arabalar) {
        if (b.userData.serit !== d.hedef || !b.visible) continue;
        const on = (b.userData.p - d.pB) * d.hedef.yon;
        if (on > -1 && on < 7 && o.t > 0.5) hedefHiz = Math.min(hedefHiz, Math.max(0, (on - 4.5) * 1.2));
      }
      u.fren = hedefHiz < o.hiz - 0.6;
      u.sinyal = o.t < 0.75 ? d.taraf : null;
      o.hiz += Math.max(-8 * dt, Math.min(2.5 * dt, hedefHiz - o.hiz));
      o.hiz = Math.max(0, o.hiz);
      const [tx, tz] = bezierTurev(d.A, d.C, d.B, o.t);
      const turevBoy = Math.hypot(tx, tz) || 1;
      o.t = Math.min(1, o.t + (o.hiz * dt) / turevBoy);
      const [x, z] = bezier(d.A, d.C, d.B, o.t);
      const yol = Math.hypot(x - a.position.x, z - a.position.z);
      a.position.x = x;
      a.position.z = z;
      const [vx, vz] = bezierTurev(d.A, d.C, d.B, Math.min(0.999, o.t));
      const aci = Math.atan2(-vz, vx);
      let fark = aci - a.rotation.y;
      while (fark > Math.PI) fark -= Math.PI * 2;
      while (fark < -Math.PI) fark += Math.PI * 2;
      a.rotation.y += fark;
      direksiyon(a, yol > 1e-4 ? (fark / yol) * 2.6 : u.direksiyon || 0, dt);
      tekerDondur(a, yol);
      if (o.t >= 1) {
        donenler.splice(i, 1);
        Object.assign(u, { serit: d.hedef, p: d.pB, hiz: o.hiz, cikis: null, karar: null, bekleme: 0 });
        a.rotation.y = seritAcisi(d.hedef);
        arabalar.push(a);
      }
    }
  }

  // Stop lambaları ve sinyaller (yakındaki araçlarda; malzeme yalnızca durum değişince güncellenir)
  function lambaAyarla(a, stop, sol = 0, sag = 0) {
    const L = a.userData.araba;
    if (!L || !L.stopMat) return;
    const u = a.userData;
    const anahtar = stop * 100 + sol * 10 + sag;
    if (u.lambaAnahtar === anahtar) return;
    u.lambaAnahtar = anahtar;
    L.stopMat.emissiveIntensity = stop === 2 ? 3.2 : stop === 1 ? 0.5 : 0.15;

    // sinyal yanınca köşelerdeki turuncu hale de parlar (gündüz de uzaktan seçilir)
    if (L.sinyalHale) {
      for (const h of L.sinyalHale.sol) { h.visible = !!sol; h.material.opacity = 0.95; }
      for (const h of L.sinyalHale.sag) { h.visible = !!sag; h.material.opacity = 0.95; }
    }
  }
  function lambalariGuncelle(t) {
    const yanik = Math.floor(t * 2.8) % 2 === 0;
    const isle = (a) => {
      if (!a.visible || !a.userData.araba || !a.userData.araba.stopMat) return;
      const u = a.userData;
      if (u.durum === 'park') { lambaAyarla(a, 0); return; }
      if (!yakinMi(a.position.x, a.position.z, 50)) return;
      const sn = u.sinyal;
      lambaAyarla(a, u.fren ? 2 : 1, yanik && (sn === 'sol' || sn === 'dortlu') ? 1 : 0, yanik && (sn === 'sag' || sn === 'dortlu') ? 1 : 0);
    };
    for (const a of arabalar) isle(a);
    for (const d of donenler) isle(d.a);
    for (const a of parkEdenler) isle(a);
    for (const a of disEngeller) isle(a);
  }

  function trafikGuncelle(dt) {
    yolEngelleriniTopla();
    donenleriGuncelle(dt);
    // kavşaklarda hangi yönden araba var (dönen araba iki yönü de tutar)
    for (const k of KAVSAKLAR) { k.dolu.x = false; k.dolu.z = false; }
    for (const a of arabalar) {
      if (!a.visible || !a.userData.serit) continue;
      const yari = (a.userData.araba.uzunluk || 4) / 2;
      const ex = a.userData.serit.eksen;
      for (const k of KAVSAKLAR) {
        const icinde = ex === 'x'
          ? a.position.z > k.z1 && a.position.z < k.z2 && a.position.x + yari > k.x1 && a.position.x - yari < k.x2
          : a.position.x > k.x1 && a.position.x < k.x2 && a.position.z + yari > k.z1 && a.position.z - yari < k.z2;
        if (icinde) k.dolu[ex] = true;
      }
    }
    for (const o of donenler) {
      if (o.t <= 0.02) continue;
      for (const k of KAVSAKLAR) {
        if (o.a.position.x > k.x1 - 1.5 && o.a.position.x < k.x2 + 1.5 && o.a.position.z > k.z1 - 1.5 && o.a.position.z < k.z2 + 1.5) { k.dolu.x = true; k.dolu.z = true; }
      }
    }
    const simdiMs = performance.now();
    for (const s of SERITLER) {
      const liste = arabalar.filter((a) => a.userData.serit === s && a.visible);
      const gizli = arabalar.filter((a) => a.userData.serit === s && !a.visible);
      const zorunlu = s.cikislar.find((c) => c.zorunlu);
      for (const a of gizli) {
        a.userData.p += a.userData.azami * s.yon * dt;
        const p = a.userData.p;
        const bitti = zorunlu ? (p - zorunlu.p) * s.yon > 0 : p > s.max || p < s.min;
        if (bitti) yenidenDagit(a);
      }
      const durmali = !yesilMi(s.eksen);
      liste.sort((a, b) => (a.userData.p - b.userData.p) * s.yon);
      for (let j = 0; j < liste.length; j++) {
        const a = liste[j];
        const u = a.userData;
        const yari = u.araba.uzunluk / 2;
        const ondeki = liste[j + 1];
        let bosluk = ondeki ? (ondeki.userData.p - u.p) * s.yon - (yari + ondeki.userData.araba.uzunluk / 2) : Infinity;
        let hizSiniri = u.azami;
        // şerit dışındaki yol engelleri (dönen, park eden, yanaşan araçlar)
        for (const e of yolEngelleri) {
          const yan = s.eksen === 'x' ? e.position.z : e.position.x;
          if (Math.abs(yan - s.sabit) > 1.55) continue;
          const on = ((s.eksen === 'x' ? e.position.x : e.position.z) - u.p) * s.yon;
          if (on <= 0) continue;
          bosluk = Math.min(bosluk, on - yari - eksenYarisi(e, s.eksen));
        }
        // kavşağın içinde öbür yönden araba varsa girmeden bekler (acil araçlar da)
        const obur = s.eksen === 'x' ? 'z' : 'x';
        for (const k of KAVSAKLAR) {
          if (!k.dolu[obur]) continue;
          const serittenGecer = s.eksen === 'x' ? s.sabit > k.z1 && s.sabit < k.z2 : s.sabit > k.x1 && s.sabit < k.x2;
          if (!serittenGecer) continue;
          const giris = s.eksen === 'x' ? (s.yon > 0 ? k.x1 : k.x2) : (s.yon > 0 ? k.z1 : k.z2);
          const kalan = (giris - (u.p + s.yon * yari)) * s.yon;
          if (kalan > -0.3 && kalan < 14) bosluk = Math.min(bosluk, kalan + 1.6);
        }
        // yolda yaya varsa (geçitte ya da olay yerinde) araç önünde durur; acil araçlar da ezmez
        if (s.eksen === 'x' && s.sabit < 9) {
          for (const y of yoldakiler) {
            if (Math.abs(y.z - s.sabit) > 1.75) continue;
            const on = (y.x - u.p) * s.yon - yari;
            if (on > -0.8 && on < 16) bosluk = Math.min(bosluk, on - 0.4);
          }
        }
        // görev aracı (zabıta, polis, ambulans…) hedef noktasında durur ya da (yanaşacaksa) o noktaya yavaşlayarak gelir
        if (u.durHedef != null) {
          const kalan = (u.durHedef - u.p) * s.yon;
          if (u.durHiz) hizSiniri = Math.min(hizSiniri, Math.sqrt(u.durHiz * u.durHiz + 2 * 3 * Math.max(0, kalan)));
          else bosluk = Math.min(bosluk, kalan + 2.3);
        }
        // kırmızı ışıkta durur (acil durum araçları beklemez)
        if (durmali && !u.acil) {
          for (const cizgiP of s.dur) {
            const kalan = (cizgiP - (u.p + s.yon * yari)) * s.yon;
            if (kalan > -0.5 && kalan < 30 && !(sariMi(s.eksen) && kalan < 3)) bosluk = Math.min(bosluk, kalan + 2.3);
          }
        }
        // kavşakta dönüş: yaklaşırken karar verilir, dönüşe uygun hıza yavaşlanır, yol boşsa dönülür
        if (!u.olay && u.durHedef == null) {
          const c = s.cikislar.find((x) => (x.p - u.p) * s.yon > -0.5 && (x.p - u.p) * s.yon < 40);
          if (c && u.karar !== c) {
            u.karar = c;
            u.cikis = null;
            if (c.zorunlu || Math.random() < c.olasilik) {
              const uygun = c.secenekler.filter((d) => !(d.hedef.kapaliBitis > simdiMs));
              u.cikis = (uygun.length ? uygun : c.secenekler)[Math.floor(Math.random() * (uygun.length || c.secenekler.length))];
              u.cikisBekleme = 0;
            }
          }
          if (u.cikis) {
            const d = u.cikis;
            const kalan = (d.pA - u.p) * s.yon;
            hizSiniri = Math.min(hizSiniri, Math.sqrt(d.hiz * d.hiz + 2 * 2.6 * Math.max(0, kalan)));
            if (kalan <= 0.05 || (kalan < 0.6 && u.hiz < 0.5)) {
              if (donusBosMu(d, a)) { donusBaslat(a, d); continue; }
              // yol açılana kadar dönüş noktasında bekler; isteğe bağlı dönüşten uzun beklerse vazgeçip düz devam eder
              u.cikisBekleme = (u.cikisBekleme || 0) + dt;
              if (!(u.karar && u.karar.zorunlu) && u.cikisBekleme > 8) u.cikis = null;
              if (u.cikis) bosluk = Math.min(bosluk, Math.max(0, kalan) + 2.3);
            } else if (kalan < 6) {
              // dönüş noktasına gelirken dolu şeride dalmamak için önceden yavaşlar
              if (!donusBosMu(d, a)) bosluk = Math.min(bosluk, kalan + 2.3);
            }
          }
        }
        // saygı duruşu: bütün araçlar olduğu yerde yavaşça durur (acil araçlar hariç), dörtlüler yanar
        if (durus && !u.acil) { hizSiniri = 0; if (!u.olay) u.sinyal = 'dortlu'; }
        const hedefHiz = Math.max(0, Math.min(hizSiniri, (bosluk - 2.3) * 1.1));
        // stop lambası: yavaşlarken ve dururken yanar; dönüşe yaklaşırken sinyal verilir
        u.fren = u.hiz > 0.4 ? hedefHiz < u.hiz - 0.6 : true;
        if (!u.olay) u.sinyal = u.cikis && (u.cikis.pA - u.p) * s.yon < 32 ? u.cikis.taraf : null;
        u.hiz += Math.max(-9 * dt, Math.min(3 * dt, hedefHiz - u.hiz));
        u.hiz = Math.max(0, u.hiz);
        u.p += u.hiz * s.yon * dt;
        const asim = u.p > s.max ? u.p - s.max : u.p < s.min ? s.min - u.p : 0;
        if (asim > 0 && asim < 140 && ekrandaMi(a.position, 3.5)) {
          // yolun ucu ekranın içinde: araba ekrandan çıkana kadar düz devam eder (birden kaybolmaz)
          const [x2, z2] = seritKonum(s, u.p);
          a.position.x = x2; a.position.z = z2;
          tekerDondur(a, u.hiz * dt);
          continue;
        }
        if (u.olay && (u.p > s.max || u.p < s.min)) {
          // görev aracı sokağın sonuna gelince sahneden çıkar
          arabalar.splice(arabalar.indexOf(a), 1);
          if (u.bitince) u.bitince();
          continue;
        }
        if (u.p > s.max || u.p < s.min || (zorunlu && !u.cikis && (u.p - zorunlu.p) * s.yon > 1)) {
          // yolun uzak ucuna varan araba başka bir yoldan yeniden gelir
          yenidenDagit(a);
          continue;
        }
        const [x, z] = seritKonum(s, u.p);
        const onceX = a.position.x - hedefX;
        a.position.x = x;
        a.position.z = z;
        a.rotation.y = seritAcisi(s);
        if (u.direksiyon) direksiyon(a, 0, dt);
        tekerDondur(a, u.hiz * dt);
        // kameranın önünden geçen araba sesi (yalnızca yakındaki ana cadde trafiği)
        if (aktifMi && s.eksen === 'x' && mesafe < 60 && Math.abs(z - hedefZ) < 20) {
          const sonra = x - hedefX;
          if (Math.sign(onceX) !== Math.sign(sonra) && Math.abs(sonra) < 2 && u.hiz > 2) ses.arabaGecti(s.yon, u.hiz);
        }
        u.bekleme = u.hiz < 0.3 ? (u.bekleme || 0) + dt : 0;
        if (!u.olay && u.bekleme > 6 && yesilMi(s.eksen) && Math.random() < dt * 0.2 && mesafe < 80) {
          ses.korna(Math.max(-1, Math.min(1, (x - hedefX) / 15)), u.tur === 'dolmus');
          u.bekleme = 0;
        }
      }
    }
  }

  // ------------------------------------------------ Özel günler: bayrak, pankart, ışık zinciri ve saygı duruşu
  // Millî bayramlarda binalara Türk bayrakları asılır, caddeye pankart gerilir; dinî bayramlarda ve yılbaşında
  // renkli ampul zincirleri yanar. 10 Kasım 09.05'te bir dakikalık saygı duruşu: trafik durur, yürüyenler durur.
  let susleme = null;   // { kod, grup, zincirler: [] }
  let durus = false;
  function ozelGunAyarla(o) {
    const kod = o && o.susleme ? o.kod + ':' + o.susleme : '';
    if ((susleme ? susleme.kod : '') === kod) return;
    if (susleme) { sahne.remove(susleme.grup); bellektenSil(susleme.grup); susleme = null; }
    if (!kod || !kuruldu) return;
    const grup = new THREE.Group();
    const zincirler = [];
    if (o.susleme === 'bayrak') {
      // cephelerden sarkan bayraklar: her binaya bir tane (bir atlayarak)
      let i = 0;
      for (const d of dukkanlar.values()) {
        if (i++ % 2) continue;
        const b = asiliBayrak(1.6, 2.4);
        b.position.set(d.merkezX + 2.6, 6.2, d.onZ + d.yon * 0.32);
        b.rotation.y = d.yon > 0 ? 0 : Math.PI;
        grup.add(b);
      }
      // lamba direklerine küçük bayraklar
      for (const l of lambalar) {
        const b = asiliBayrak(0.55, 0.85);
        b.position.set(l.position.x + 0.3, 3.3, l.position.z);
        grup.add(b);
      }
    }
    if (o.susleme === 'yilbasi' || o.susleme === 'bayram') {
      // cadde boyunca ve caddenin üstünden sarkan ampul zincirleri
      const renkler = o.susleme === 'yilbasi' ? ['#FF3B3B', '#FFD23F', '#3DDC97', '#4DA3FF', '#FFFFFF'] : ['#FFD23F', '#FF8A3D', '#FF4D8D', '#8AE0FF', '#B38CFF'];
      const nokta = [];
      for (let x = XB + 8; x <= XD - 8; x += 11) nokta.push([x, 5.4, x % 2 ? -0.6 : 9.1]);
      const z = isikZinciri(nokta.map((n, k) => [n[0], n[1], k % 2 ? -0.6 : 9.1]), renkler);
      grup.add(z);
      zincirler.push(z);
      const z2 = isikZinciri([[XB + 6, 4.6, 9.4], [XD - 6, 4.6, 9.4]], renkler);
      grup.add(z2);
      zincirler.push(z2);
    }
    // caddeye gerilen pankart(lar)
    const metin = {
      '23nisan': '23 NİSAN ULUSAL EGEMENLİK VE ÇOCUK BAYRAMI KUTLU OLSUN',
      '19mayis': '19 MAYIS GENÇLİK VE SPOR BAYRAMI KUTLU OLSUN',
      '30agustos': '30 AĞUSTOS ZAFER BAYRAMI KUTLU OLSUN',
      '29ekim': '29 EKİM CUMHURİYET BAYRAMIMIZ KUTLU OLSUN',
      '15temmuz': '15 TEMMUZ DEMOKRASİ VE MİLLÎ BİRLİK GÜNÜ',
      '10kasim': 'ATAMIZI SAYGI VE ÖZLEMLE ANIYORUZ',
      canakkale: 'ÇANAKKALE GEÇİLMEZ',
      yilbasi: 'MUTLU YILLAR', yilbasi_arife: 'MUTLU YILLAR',
    }[o.kod] || (o.tur === 'dini' ? 'BAYRAMINIZ MÜBAREK OLSUN' : null);
    if (metin) {
      const anma = o.tur === 'anma';
      for (const px of [XB + 22, GECIT_X - 12]) {
        const p = pankart(metin, { zemin: anma ? '#15171A' : o.tur === 'dini' ? '#1F6F54' : o.susleme === 'yilbasi' ? '#0F3D7A' : '#C8102E', renk: '#FFFFFF' });
        p.position.set(px, KALDIRIM_Y, 9.75);
        grup.add(p);
      }
    }
    sahne.add(grup);
    susleme = { kod, grup, zincirler };
  }
  function suslemeGuncelle(t) {
    if (!susleme) return;
    // ampuller sırayla göz kırpar (gece daha parlak)
    const faz = Math.floor(t * 1.5);
    for (const z of susleme.zincirler) {
      const m = z.userData.ampuller.material;
      m.color.setScalar(0.55 + isikAcikPayi * 0.9 + (faz % 2) * 0.25);
    }
    for (const b of susleme.grup.children) if (b.userData.dalga) b.rotation.z = Math.sin(t * 1.3 + b.position.x) * 0.03;
  }
  function sayginDurus(aktif) { durus = !!aktif; }

  // ------------------------------------------------ Çöpçüler
  // Gündüz belediyenin temizlik görevlileri el arabalarını iterek kaldırımları süpürür: birkaç adımda bir durur,
  // arabayı bırakır, süpürgeyle yeri süpürür, çöpü arabaya atar ve yoluna devam eder. Konteynerlerin önünü de toplar.
  const copculer = [];
  function copcuKur() {
    const hatlar = [
      { z: 11.75, x1: XB + 6, x2: XD - 6 },   // güney gezinti yolu
      { z: -1.75, x1: XB + 6, x2: XD - 6 },   // kuzey kaldırımı (tezgâhların önü)
    ];
    for (let i = 0; i < Math.min(2, Math.max(1, Math.round(K.yaya / 8))); i++) {
      const h = hatlar[i % hatlar.length];
      const g = insanUret('temizlik');
      const sp = supurge();
      sp.position.set(-0.28, 1.02, 0.28);
      g.add(sp);
      const araba = copArabasi();
      const x = rnd(h.x1, h.x2);
      g.position.set(x, KALDIRIM_Y, h.z);
      araba.position.set(x + 1, KALDIRIM_Y, h.z);
      sahne.add(g, araba);
      copculer.push({ g, sp, araba, hat: h, yon: Math.random() < 0.5 ? 1 : -1, durum: 'yuru', sayac: rnd(4, 9), t: 0, hedef: null });
    }
  }
  function copcuGuncelle(dt, animDt) {
    const saat = oyunSaati() % 24;
    const mesai = saat >= 6 && saat < 19.5;
    for (const c of copculer) {
      const { g, araba, hat } = c;
      const ins = g.userData.insan;
      // mesai dışında görünmezler (arabayla birlikte)
      const gor = mesai;
      if (g.visible !== gor) { g.visible = gor; araba.visible = gor; }
      if (!gor) continue;
      c.t += dt;
      if (durus) { ins.oynat('Idle_Loop', 0.4); }
      else if (c.durum === 'yuru') {
        // arabayı önünde iterek yürür
        const hiz = 0.75;
        const hx = c.yon > 0 ? hat.x2 : hat.x1;
        const aci = kalabalik.yuru(g.position, hx, hat.z, hiz * dt);
        if (aci !== null) yonel(g, aci, dt);
        if (Math.abs(g.position.x - hx) < 0.4) c.yon = -c.yon;
        araba.position.set(g.position.x + Math.sin(g.rotation.y) * 1.05, KALDIRIM_Y, g.position.z + Math.cos(g.rotation.y) * 1.05);
        araba.rotation.y = g.rotation.y + Math.PI / 2; // sapı kişiye dönük
        for (const o of araba.children) if (o.geometry && o.geometry.type === 'CylinderGeometry' && o.rotation.x) o.rotation.y += hiz * dt / 0.2;
        c.sp.rotation.y = 0;
        ins.oynat('Walk_Loop', 0.3, 0.62);
        c.sayac -= hiz * dt;
        if (c.sayac <= 0) {
          // süpürülecek yer: yolun kenarına doğru ya da tezgâhların önü
          c.durum = 'supur';
          c.t = 0;
          c.sure = rnd(4, 7);
          c.merkez = [g.position.x + rnd(-0.6, 0.6), hat.z + rnd(-0.7, 0.7)];
        }
      } else if (c.durum === 'supur') {
        // süpürge sağa sola, ufak adımlarla yer değiştirerek
        const [mx, mz] = c.merkez;
        const hx = mx + Math.sin(c.t * 0.9) * 0.5;
        if (Math.abs(g.position.x - hx) > 0.05) kalabalik.yuru(g.position, hx, mz, 0.35 * dt);
        yonel(g, c.yon > 0 ? Math.PI / 2 : -Math.PI / 2, dt);
        c.sp.rotation.y = Math.sin(c.t * 5.5) * 0.55;
        c.sp.position.x = -0.28 + Math.sin(c.t * 5.5) * 0.08;
        ins.oynat('Idle_Loop', 0.3);
        if (c.t > c.sure) {
          c.durum = 'bosalt';
          c.t = 0;
        }
      } else if (c.durum === 'bosalt') {
        // çöpü el arabasının kovasına atar
        yonel(g, Math.atan2(araba.position.x - g.position.x, araba.position.z - g.position.z), dt);
        c.sp.rotation.y *= 0.9;
        ins.oynat('Interact', 0.25);
        if (c.t > 1.4) { c.durum = 'yuru'; c.sayac = rnd(5, 11); }
      }
      g.position.y = KALDIRIM_Y;
      if (animDt && yakinMi(g.position.x, g.position.z)) insanGuncelle(g, animDt);
    }
  }

  // ------------------------------------------------ Yayalar ve karşıya geçenler
  const yayalar = [];
  const gecenler = [];
  const banklar = [];
  let YAYA_SERITLERI = [];

  function yayaKur() {
    const x1 = XB + 5;
    const x2 = XD - 5;
    YAYA_SERITLERI = [
      { z: -6.9, yon: 1 }, { z: -6.2, yon: -1 }, { z: -0.95, yon: 1 }, { z: -0.35, yon: -1 },
      { z: 10.1, yon: 1 }, { z: 15.85, yon: -1 },
      { z: -35.9, yon: 1 }, { z: -36.9, yon: -1 }, { z: -48.1, yon: 1 }, { z: -47.1, yon: -1 },
    ].map((s) => ({ ...s, min: x1, max: x2 }));
    const adet = K.yaya + 4;
    for (let i = 0; i < adet; i++) {
      const s = YAYA_SERITLERI[i % YAYA_SERITLERI.length];
      const y = insanUret('yaya');
      y.position.set(rnd(x1, x2), KALDIRIM_Y, s.z + rnd(-0.1, 0.1));
      y.rotation.y = s.yon > 0 ? Math.PI / 2 : -Math.PI / 2;
      Object.assign(y.userData, { serit: s, hiz: rnd(1.05, 1.4) * hizCarpani(y) });
      y.userData.azami = y.userData.hiz;
      sahne.add(y);
      yayalar.push(y);
    }
    for (let i = 0; i < Math.min(4, Math.ceil(K.yaya / 4)); i++) {
      const y = insanUret('yaya');
      const karsi = i % 2 === 0;
      y.position.set(GECIT_X + rnd(-1.2, 1.2), KALDIRIM_Y, karsi ? 9.3 : -0.4);
      y.userData.hedefZ = karsi ? -0.4 : 9.3;
      y.userData.gecis = false;
      sahne.add(y);
      gecenler.push(y);
    }
  }

  function yonel(y, hedefAci, dt) {
    let f = hedefAci - y.rotation.y;
    while (f > Math.PI) f -= Math.PI * 2;
    while (f < -Math.PI) f += Math.PI * 2;
    y.rotation.y += f * Math.min(1, dt * 8);
  }

  function yakinMi(x, z, sinir = 60) {
    return Math.abs(x - hedefX) < sinir + mesafe * 0.6 && Math.abs(z - hedefZ) < sinir + mesafe * 0.6;
  }

  // Bankta dinlenme: kaldırımdaki yaya yakındaki boş bankta 15–40 sn oturur, sonra yoluna devam eder
  function bankaYonel(y, s) {
    if (Math.abs(s.z - 10.1) > 0.5) return false;
    const b = banklar.find((b) => b.oturan.length < 2 && (b.x - y.position.x) * s.yon > 0.5 && (b.x - y.position.x) * s.yon < 4);
    if (!b) return false;
    const yer = b.oturan.length ? (b.oturan[0].userData.oturma.dx > 0 ? -0.45 : 0.45) : (Math.random() < 0.5 ? -0.45 : 0.45);
    b.oturan.push(y);
    y.userData.oturma = { b, dx: yer, faz: 'git', t: 0, sure: 15 + Math.random() * 25 };
    return true;
  }
  function oturmaGuncelle(y, s, dt, animDt) {
    const u = y.userData, o = u.oturma, ins = u.insan;
    const hx = o.b.x + o.dx, hz = o.b.z + 0.02;
    if (o.faz === 'git') {
      const dx = hx - y.position.x, dz = hz - y.position.z, d = Math.hypot(dx, dz);
      if (d < 0.08) { o.faz = 'otur'; y.rotation.y = Math.PI; }
      else { const v = Math.min(d, 1.1 * dt); y.position.x += dx / d * v; y.position.z += dz / d * v; yonel(y, Math.atan2(dx, dz), dt); ins.oynat('Walk_Loop', 0.3, 0.9); }
    } else if (o.faz === 'otur') {
      o.t += dt;
      y.position.y += ((KALDIRIM_Y + 0.05) - y.position.y) * Math.min(1, dt * 6);
      ins.oynat('Sitting_Idle_Loop', 0.5);
      if (o.t > o.sure || durus === 'kalk') o.faz = 'kalk';
    } else {
      y.position.y += (KALDIRIM_Y - y.position.y) * Math.min(1, dt * 6);
      const dz = s.z - y.position.z;
      if (Math.abs(dz) < 0.05) {
        o.b.oturan = o.b.oturan.filter((x) => x !== y);
        u.oturma = null; u.kay = 0; u.kayHedef = 0; y.position.y = KALDIRIM_Y;
      } else { y.position.z += Math.sign(dz) * Math.min(Math.abs(dz), 1.1 * dt); yonel(y, s.yon > 0 ? Math.PI / 2 : -Math.PI / 2, dt); ins.oynat('Walk_Loop', 0.3, 0.9); }
    }
    if (animDt && yakinMi(y.position.x, y.position.z)) insanGuncelle(y, animDt);
  }
  function yayaGuncelle(dt, animDt) {
    for (const s of YAYA_SERITLERI) {
      const liste = yayalar.filter((y) => y.userData.serit === s && y.visible);
      const boy = s.max - s.min;
      for (const y of liste) {
        const u = y.userData;
        if (u.kay === undefined) { u.kay = 0; u.kayHedef = 0; }
        if (u.oturma || (!durus && banklar.length && Math.random() < dt * 0.012 && bankaYonel(y, s))) { oturmaGuncelle(y, s, dt, animDt); continue; }
        // yalnızca aynı hizada yürüyen biri önü keser
        let enYakin = Infinity;
        let ondeki = null;
        for (const b of liste) {
          if (b === y || b.userData.oturma || Math.abs((b.userData.kay || 0) - u.kay) > 0.35) continue;
          let fark = (b.position.x - y.position.x) * s.yon;
          if (fark <= 0) fark += boy;
          if (fark < enYakin) { enYakin = fark; ondeki = b; }
        }
        let hedefHiz = durus ? 0 : u.azami; // saygı duruşunda herkes olduğu yerde durur
        // önünde tezgâh, ağaç, bank gibi bir engel varsa yanından dolaşır
        const engelZ = kalabalik.seritEngeli(y.position.x, s.z + u.kay, s.yon, 2.6);
        if (engelZ !== null) {
          u.kayHedef = Math.max(-1.4, Math.min(1.4, engelZ - s.z));
          u.engelde = 1.2;
        } else if (u.engelde > 0) u.engelde -= dt;
        if (u.engelde > 0) {
          // engelin yanından geçerken şerit sollama kuralı uygulanmaz
        } else if (ondeki && enYakin < 1.8) {
          // öndeki yavaşsa yana kayıp sollar
          if (ondeki.userData.hiz < u.azami - 0.05) u.kayHedef = (ondeki.userData.kay || 0) >= 0 ? -0.42 : 0.42;
          hedefHiz = Math.min(u.azami, Math.max(0, (enYakin - 0.7) * 1.6));
        } else if (!ondeki || enYakin > 3) {
          u.kayHedef = 0;
        }
        if (ondeki && enYakin < 1.8 && u.engelde > 0) hedefHiz = Math.min(u.azami, Math.max(0, (enYakin - 0.7) * 1.6));
        u.kay += (u.kayHedef - u.kay) * Math.min(1, dt * (u.engelde > 0 ? 4 : 2.5));
        if (durus) hedefHiz = 0;
        u.hiz += Math.max(-4 * dt, Math.min(2 * dt, hedefHiz - u.hiz));
        y.position.x += u.hiz * s.yon * dt;
        y.position.z = s.z + u.kay;
        const tasti = y.position.x > s.max || y.position.x < s.min;
        const asimY = y.position.x > s.max ? y.position.x - s.max : s.min - y.position.x;
        // kaldırımın ucu ekrandaysa yaya ekrandan çıkana kadar yürür; ekran dışında karşı uca alınır
        if (tasti && (asimY > 45 || !ekrandaMi(y.position, 1.2))) {
          y.position.x = y.position.x > s.max ? s.min : s.max;
          if (Math.random() > yogunluk() + 0.15) y.visible = false;
        }
        // başlangıç ucu ekrandaysa yavaşça belirir (birden ortaya çıkmasın)
        {
          const kalan = s.yon > 0 ? s.max - y.position.x : y.position.x - s.min;
          const gecen = boy - kalan;
          insanSaydamlik(y, Math.max(0, Math.min(1, gecen / 3.5)));
        }
        yonel(y, s.yon > 0 ? Math.PI / 2 : -Math.PI / 2, dt);
        if (animDt) {
          const ins = u.insan;
          if (u.hiz < 0.15) ins.oynat('Idle_Loop', 0.3);
          else ins.oynat('Walk_Loop', 0.3, u.hiz / 1.2);
          // uzaktaki insanların animasyonu atlanır (hız için)
          if (yakinMi(y.position.x, y.position.z)) insanGuncelle(y, animDt);
        }
      }
      // kalabalık saatlerde gizli yayalar sokağa geri döner
      if (animDt) {
        for (const y of yayalar) {
          if (y.userData.serit === s && !y.visible && Math.random() < animDt * 0.05 * yogunluk()) {
            y.position.x = s.yon > 0 ? s.min : s.max;
            y.visible = true;
          }
        }
      }
    }
    const gec = yesilMi('z');
    for (const y of gecenler) {
      const u = y.userData;
      const f = u.hedefZ - y.position.z;
      // karşıya geçmeye yalnızca yeşilin başında başlanır (yolun ortasında kırmızıya yakalanmasın)
      if ((gec && isikSure > 0.8 && isikSure < DONGU[isikEvre][1] - 8) || u.gecis) {
        u.gecis = Math.abs(f) > 0.05;
        if (u.gecis) {
          y.position.z += Math.sign(f) * Math.min(Math.abs(f), 1.35 * dt);
          y.position.y = (y.position.z > 0.25 && y.position.z < 8.4) ? 0.02 : KALDIRIM_Y;
          yonel(y, f > 0 ? 0 : Math.PI, dt);
          u.insan.oynat('Walk_Loop', 0.25, 1.1);
        } else {
          u.hedefZ = u.hedefZ > 4 ? -0.4 : 9.3;
          y.position.x = GECIT_X + rnd(-1.2, 1.2);
        }
      } else {
        yonel(y, f > 0 ? 0 : Math.PI, dt);
        u.insan.oynat('Idle_Loop', 0.4);
      }
      if (animDt && yakinMi(y.position.x, y.position.z)) insanGuncelle(y, animDt);
    }
  }

  // ------------------------------------------------ Müşteriler (tezgâh ve dükkânlara gelip gidenler)
  const musteriler = [];
  for (let i = 0; i < K.musteri + 4; i++) {
    const m = insanUret('musteri');
    m.visible = false;
    m.userData.durum = 'havuz';
    sahne.add(m);
    musteriler.push(m);
  }
  function bosMusteri() { return musteriler.find((m) => m.userData.durum === 'havuz'); }

  function tezgahaGonder(yer) {
    const m = bosMusteri();
    if (!m) return;
    const tx = yer.grup.position.x;
    const soldan = Math.random() < 0.5 ? -1 : 1;
    const tz = yer.grup.position.z;
    const serit = yer.guney ? MUSTERI_SERIDI_G : MUSTERI_SERIDI;
    const nokta = new THREE.Vector3(tx + rnd(-0.8, 0.8), KALDIRIM_Y, tz + 1.55 + rnd(0, 0.25));
    m.position.set(tx + soldan * rnd(9, 13), KALDIRIM_Y, serit + rnd(-0.1, 0.1));
    m.visible = true;
    insanSaydamlik(m, 0);
    Object.assign(m.userData, {
      belir: 0,
      durum: 'yol', hedefYer: yer, bekleme: rnd(4, 9), sonra: 'bekle', bakis: Math.PI,
      yol: [new THREE.Vector3(nokta.x, KALDIRIM_Y, serit), nokta],
      donus: [new THREE.Vector3(nokta.x, KALDIRIM_Y, serit), new THREE.Vector3(tx - soldan * rnd(11, 15), KALDIRIM_Y, serit)],
    });
    yer.musteri = (yer.musteri || 0) + 1;
  }

  // Dükkân şu an çalışıyor mu (ruhsatlı + çalışma saatleri içinde). Kapalıyken müşteri girmez, kepenk iner.
  function dukkanAcikMi(d) {
    const i = d.veri && d.veri.isletme;
    if (!i || i.durum !== 'acik') return false;
    const h = oyunSaati();
    const [a, b] = i.saat || [8, 21];
    const hs = Math.floor(h);
    return (hs >= a && hs < b) || (b > 24 && hs < b - 24);
  }
  function kepenkleriGuncelle() {
    for (const d of dukkanlar.values()) {
      const k = d.grup && d.grup.userData.kepenk;
      if (!k) continue;
      const i = d.veri && d.veri.isletme;
      const kapali = !!i && i.durum !== 'ruhsat' && !dukkanAcikMi(d);
      d.kapali = kapali;
      if (k.visible !== kapali) k.visible = kapali;
    }
  }
  function dukkanaGonder(d) {
    const m = bosMusteri();
    if (!m) return;
    const soldan = Math.random() < 0.5 ? -1 : 1;
    const kapi = new THREE.Vector3(d.merkezX + rnd(-0.6, 0.6), KALDIRIM_Y, d.onZ + d.yon * 0.25);
    m.position.set(d.merkezX + soldan * rnd(10, 14), KALDIRIM_Y, d.seritZ + rnd(-0.1, 0.1));
    m.visible = true;
    insanSaydamlik(m, 0);
    Object.assign(m.userData, {
      belir: 0,
      durum: 'yol', hedefDukkan: d, bekleme: rnd(4, 10), sonra: 'iceri',
      yol: [new THREE.Vector3(kapi.x, KALDIRIM_Y, d.seritZ), kapi],
      donus: [new THREE.Vector3(kapi.x, KALDIRIM_Y, d.seritZ), new THREE.Vector3(d.merkezX - soldan * rnd(11, 15), KALDIRIM_Y, d.seritZ)],
    });
    d.musteri = (d.musteri || 0) + 1;
  }

  // Sipariş balonu: oyuncu dokunursa bizzat servis yapmış olur (ek kazanç ve bahşiş)
  let sonrakiSiparisBalonu = 0;
  const sonSiparisMetni = new Map();
  function siparisVer(m, yer) {
    const an = performance.now();
    if (an < sonrakiSiparisBalonu || musteriler.some((k) => k.userData.siparis)) return;
    sonrakiSiparisBalonu = an + rnd(12000, 20000);
    const liste = SIPARISLER[yer.veri.kod] || ['Bir tane!'];
    const e = document.createElement('div');
    e.className = 'etiket gizli';
    const uygun = liste.filter((metin) => metin !== sonSiparisMetni.get(yer.veri.kod));
    const secim = (uygun.length ? uygun : liste);
    const metin = secim[Math.floor(Math.random() * secim.length)];
    sonSiparisMetni.set(yer.veri.kod, metin);
    const gorunen=yer.veri.kod==='simit'?dilMetni('dialog.simit'+(liste.indexOf(metin)+1)):npcMetni(metin);
    e.innerHTML = `<button class="siparis">${esc(gorunen)}</button>`;
    etiketKutusu.appendChild(e);
    m.userData.siparis = e;
    m.userData.bekleme = Math.max(m.userData.bekleme, 6);
    e.querySelector('button').addEventListener('click', (ev) => {
      ev.stopPropagation();
      const rect = e.getBoundingClientRect();
      siparisKaldir(m);
      m.userData.insan.oynat('Interact', 0.2);
      m.userData.bekleme = 1.4;
      servisTik(yer.veri.kod, rect);
    });
  }
  function siparisKaldir(m) {
    if (m.userData.siparis) { m.userData.siparis.remove(); m.userData.siparis = null; }
  }

  let sonTezgahMusterisi = 0;
  let sonDukkanMusterisi = 0;
  let sonKepenk = -99;
  function musteriGuncelle(dt, t, animDt) {
    if (t - sonKepenk > 2) { sonKepenk = t; kepenkleriGuncelle(); }
    if (animDt && t - sonTezgahMusterisi > rnd(1.5, 3.5)) {
      sonTezgahMusterisi = t;
      const calisan = [...yerler.values(), ...[...komsular.values()].filter((k) => !k.sehir && k.model)].filter((y) => y.grup.visible && y.aktif && y.aktif.bitis > simdi() && (y.musteri || 0) < 2 && yakinMi(y.grup.position.x, y.grup.position.z, 10));
      if (calisan.length) tezgahaGonder(calisan[Math.floor(Math.random() * calisan.length)]);
    }
    if (animDt && t - sonDukkanMusterisi > rnd(1.2, 3.5) * (1.4 - yogunluk() * 0.6)) {
      sonDukkanMusterisi = t;
      const acik = [...dukkanlar.values()].filter((d) => dukkanAcikMi(d) && (d.musteri || 0) < 2 && yakinMi(d.merkezX, d.onZ, 10));
      if (acik.length) dukkanaGonder(acik[Math.floor(Math.random() * acik.length)]);
    }
    for (const m of musteriler) {
      const u = m.userData;
      if (u.durum === 'havuz') continue;
      const ins = u.insan;
      // belirme / solma: gelişte yavaşça belirir; ayrılırken son iki metrede, dükkâna girerken kapıda solar
      if (u.belir < 1) u.belir = Math.min(1, u.belir + dt * 1.2);
      let solma = 1;
      if ((u.durum === 'gidis' && u.yol.length === 1) || (u.durum === 'yol' && u.sonra === 'iceri' && u.yol.length === 1)) {
        const son = u.yol[0];
        solma = Math.min(1, Math.hypot(son.x - m.position.x, son.z - m.position.z) / (u.durum === 'gidis' ? 2.2 : 0.9));
      }
      insanSaydamlik(m, Math.min(u.belir, solma));
      if (u.durum === 'yol' || u.durum === 'gidis') {
        const hedef = u.yol[0];
        const f = new THREE.Vector3().subVectors(hedef, m.position);
        f.y = 0;
        const uzaklik = f.length();
        if (uzaklik < 0.06) {
          u.yolSure = 0;
          u.yol.shift();
          if (!u.yol.length) {
            if (u.durum === 'gidis') {
              u.durum = 'havuz';
              m.visible = false;
            } else if (u.sonra === 'iceri' && u.hedefDukkan && !dukkanAcikMi(u.hedefDukkan)) {
              // vardığında dükkân kapanmışsa içeri girmez, yoluna devam eder
              u.hedefDukkan.musteri = Math.max(0, (u.hedefDukkan.musteri || 1) - 1);
              u.hedefDukkan = null;
              u.durum = 'gidis';
              u.yol = u.donus;
            } else if (u.sonra === 'iceri') {
              u.durum = 'iceride';
              m.visible = false;
            } else {
              u.durum = 'bekle';
              if (u.hedefYer && !u.hedefYer.komsu && Math.random() < 0.85) siparisVer(m, u.hedefYer);
            }
          }
        } else {
          // engellerin (tezgâh, bank…) etrafından dolaşarak yürür; çok uzun takılırsa hedefe atlar
          const aci = kalabalik.yuru(m.position, hedef.x, hedef.z, 1.2 * dt);
          if (aci !== null) yonel(m, aci, dt);
          ins.oynat('Walk_Loop', 0.25, 1);
          u.yolSure = (u.yolSure || 0) + dt;
          if (u.yolSure > 25) { m.position.x = hedef.x; m.position.z = hedef.z; u.yolSure = 0; }
        }
      } else if (u.durum === 'bekle') {
        yonel(m, Math.PI, dt);
        if (!u.siparis && u.bekleme < 1.5) ins.oynat('Interact', 0.3);
        else ins.oynat('Idle_Talking_Loop', 0.35);
        u.bekleme -= dt;
        const hala = u.hedefYer && u.hedefYer.aktif && u.hedefYer.aktif.bitis > simdi();
        if (u.bekleme <= 0 || !hala) {
          siparisKaldir(m);
          if (u.hedefYer) u.hedefYer.musteri = Math.max(0, (u.hedefYer.musteri || 1) - 1);
          u.hedefYer = null;
          u.durum = 'gidis';
          u.yol = u.donus;
        }
      } else if (u.durum === 'iceride') {
        u.bekleme -= dt;
        if (u.bekleme <= 0) {
          if (u.hedefDukkan) u.hedefDukkan.musteri = Math.max(0, (u.hedefDukkan.musteri || 1) - 1);
          const d = u.hedefDukkan;
          u.hedefDukkan = null;
          m.visible = true;
          u.belir = 0;
          m.rotation.y = d && d.yon > 0 ? 0 : Math.PI;
          u.durum = 'gidis';
          u.yol = u.donus;
        }
      }
      if (m.visible && animDt) insanGuncelle(m, animDt);
    }
  }

  // ------------------------------------------------ Komşu tezgâhları ve başka ilçeyi gezme
  // Aynı ilçedeki diğer oyuncuların açık tezgâhları caddenin ara sokaklardan sonraki uzantısında durur.
  // Başka bir ilçe gezilirken o ilçenin dükkânları kurulur, oradaki oyuncuların tezgâhları ana sıralara dizilir,
  // kendi tezgâhlarımız gizlenir; dönünce her şey eski hâline gelir.
  const komsular = new Map();
  let ziyaret = null;
  let kendiCadde = null;
  // Semtin caddelerinde komşu tezgâhlar için yerler: caddelerin iki kenarı boyunca, kavşaklardan uzak,
  // mahalleye en yakından başlayarak (ilk gelen oyuncular hemen yanı başında, kalabalık ilçelerde semt boyunca)
  let sehirYerleri = null;
  function sehirYerleriniHazirla() {
    if (sehirYerleri || !sehir || !sehir.yollar) return sehirYerleri || [];
    const { yatay, dikey, orta, Y2, cekirdek: c } = sehir.yollar;
    const l = [];
    const tumDikey = [...dikey, ...orta];
    const cekirdekte = (x, z) => x > c.x1 - 4 && x < c.x2 + 4 && z > c.zK - 4 && z < c.zG + 4;
    const kavsakta = (d, liste) => liste.some((v) => Math.abs(v - d) < Y2 + 7);
    const R = Math.min(SEHIR_YARICAP * 0.8, 700);
    for (const z0 of yatay) {
      for (let x = -R; x <= R; x += 17) {
        if (kavsakta(x, tumDikey)) continue;
        for (const yan of [-1, 1]) {
          const z = z0 + yan * (Y2 - 1.1);
          if (cekirdekte(x, z) || Math.hypot(x, z - ORTA_Z) > R) continue;
          l.push({ x, z, ry: yan < 0 ? 0 : Math.PI, sehir: true });
        }
      }
    }
    for (const x0 of dikey) {
      for (let z = -R; z <= R * 0.75; z += 17) {
        if (kavsakta(z, yatay)) continue;
        for (const yan of [-1, 1]) {
          const x = x0 + yan * (Y2 - 1.1);
          if (cekirdekte(x, z) || Math.hypot(x, z - ORTA_Z) > R) continue;
          l.push({ x, z, ry: yan < 0 ? Math.PI / 2 : -Math.PI / 2, sehir: true });
        }
      }
    }
    // mahalleye yakın olanlar önce; aynı uzaklıktakiler karışık (hep aynı caddeye yığılmasın)
    l.sort((a, b) => Math.hypot(a.x, a.z - ORTA_Z) - Math.hypot(b.x, b.z - ORTA_Z));
    sehirYerleri = l;
    return l;
  }
  function komsuKonumlari(adet, mod) {
    const l = [];
    if (mod === 'sehir') {
      // önce caddenin uzantısındaki (ara sokakların dışındaki) yerler, sonra semtin caddeleri
      const kenar = komsuKonumlari(Math.min(adet, 8), 'kenar');
      return [...kenar, ...sehirYerleriniHazirla().slice(0, Math.max(0, adet - kenar.length))];
    }
    if (mod === 'ana') {
      const n = Math.max(adet, isler.length || 12);
      for (let i = 0; i < adet; i++) l.push(yerKonumu(i, n));
      return l;
    }
    const sutun = Math.max(1, Math.floor((70 - 16) / ARALIK) + 1);
    for (let j = 0; j < sutun && l.length < adet; j++) {
      for (const [x, guney] of [[XD + 12 + j * ARALIK, true], [XB - 12 - j * ARALIK, true], [XD + 12 + j * ARALIK + 1.8, false], [XB - 12 - j * ARALIK - 1.8, false]]) {
        if (l.length < adet) l.push({ x, z: guney ? GUNEY_TEZGAH_Z : TEZGAH_Z, guney });
      }
    }
    return l;
  }
  // Komşu tezgâh önce yalnızca etiket (kuş bakışında iğne) ve dokunma alanıyla kurulur; kamera yaklaşınca tezgâhın
  // kendisi, satıcısı ve ışıkları yüklenir, uzaklaşınca kaldırılır (60 tezgâh ve satıcı birden çizilmez).
  function komsuKur(x, p) {
    const grup = new THREE.Group();
    // semtin caddelerinde tezgâh yol kenarında (asfaltta), satıcı arkasında kaldırımda durur
    grup.position.set(p.x, p.sehir ? 0.02 : KALDIRIM_Y, p.z);
    grup.rotation.y = p.ry || 0;
    const govde = new THREE.Group();
    govde.scale.setScalar(OLCEK);
    grup.add(govde);
    const isabet = new THREE.Mesh(new THREE.BoxGeometry(3.8, 4.2, 3.6), new THREE.MeshBasicMaterial({ visible: false }));
    isabet.position.y = 1.9;
    isabet.userData.komsu = x.id;
    grup.add(isabet);
    sahne.add(grup);
    const etiket = document.createElement('div');
    etiket.className = 'etiket gizli';
    etiketKutusu.appendChild(etiket);
    etiket.addEventListener('click', (e) => { e.stopPropagation(); const k = komsular.get(x.id); if (k) komsuTiklandi(k.veri); });
    const dik = Math.abs(Math.sin(p.ry || 0)) > 0.5;
    const engel = kalabalik.engelEkle(p.x, p.z, dik ? 2.4 : 5.0, dik ? 5.0 : 2.4);
    const k = { grup, govde, model: null, insan: null, isabet, etiket, ampul: null, isik: null, engel, guney: p.guney, sehir: !!p.sehir, p, isKodu: x.isKodu, calisan: x.calisan, komsu: true, buyume: 1, musteri: 0 };
    return k;
  }
  function komsuDetay(k, gerekli) {
    if (gerekli && !k.model) {
      k.model = tezgahModeli(k.isKodu);
      k.model.traverse((o) => { if (o.userData.acikta) o.visible = true; });
      k.model.scale.setScalar(0.01);
      k.buyume = 0;
      k.govde.add(k.model);
      k.insan = insanUret(k.calisan === 'cirak' ? 'cirak' : 'ben');
      k.insan.position.set(0.2, k.p.sehir ? 0.16 : 0, -1.3);
      k.insan.userData.insan.oynat('Idle_Talking_Loop', 0);
      k.grup.add(k.insan);
      k.ampul = hale('#FFD28A', 2.6);
      k.ampul.position.set(0, 2.6, 0.2);
      k.isik = isikLekesi('#FFC878', 5);
      k.isik.position.y = 0.03;
      k.grup.add(k.ampul, k.isik);
      gecelik.haleler.add(k.ampul).add(k.isik);
    } else if (!gerekli && k.model) {
      gecelik.haleler.delete(k.ampul); gecelik.haleler.delete(k.isik);
      k.govde.remove(k.model);
      k.grup.remove(k.insan, k.ampul, k.isik);
      bellektenSil(k.model);
      bellektenSil(k.insan, { geometri: false });
      bellektenSil(k.ampul); bellektenSil(k.isik);
      k.model = k.insan = k.ampul = k.isik = null;
    }
  }
  function komsuDetaylariAyarla() {
    for (const k of komsular.values()) {
      const u = Math.hypot(k.grup.position.x - hedefX, k.grup.position.z - hedefZ);
      // yakındaysa yükle; kaldırmak için biraz daha uzaklaşmak gerekir (sınırda gidip gelmesin)
      if (!k.model && u < 150 && mesafe < 230) komsuDetay(k, true);
      else if (k.model && (u > 230 || mesafe > 320)) komsuDetay(k, false);
    }
  }
  function komsuSil(k) {
    komsuDetay(k, false);
    kalabalik.engelSil(k.engel);
    sahne.remove(k.grup);
    bellektenSil(k.grup, { geometri: false });
    k.etiket.remove();
  }
  function komsuEtiketi(k) {
    const x = k.veri;
    const html = `<button class="balon komsu-balon"><span class="kb-simge">${x.simge}</span><span><b>${esc(x.ad)}</b><small>${esc(x.isAdi)} · ${x.seviye}. sv</small></span></button>`;
    if (k.etiket._html !== html) { k.etiket.innerHTML = html; k.etiket._html = html; }
  }
  function komsulariAyarla(liste, mod = 'kenar') {
    if (!kuruldu) return;
    const gelen = new Set(liste.map((x) => x.id));
    for (const [id, k] of komsular) if (!gelen.has(id) || k.mod !== mod) { komsuSil(k); komsular.delete(id); }
    const yerlesim = komsuKonumlari(liste.length, mod);
    liste.forEach((x, i) => {
      const p = yerlesim[i];
      if (!p) return;
      let k = komsular.get(x.id);
      if (!k) { k = komsuKur(x, p); k.mod = mod; komsular.set(x.id, k); }
      k.veri = x;
      k.aktif = { bitis: x.bitis };
      komsuEtiketi(k);
    });
  }
  function kendiTezgahlariGizle(gizle) {
    for (const y of yerler.values()) {
      y.grup.visible = !gizle;
      if (gizle) {
        y.etiket.classList.add('gizli');
        if (y.engel) { kalabalik.engelSil(y.engel); y.engel = null; }
      } else if (y.model && !y.engel) {
        y.engel = kalabalik.engelEkle(y.grup.position.x, y.grup.position.z, 5.0, 2.4);
      }
    }
    if (arabam) arabam.g.visible = !gizle;
  }
  function musterileriSal() {
    for (const m of musteriler) {
      if (m.userData.durum === 'havuz') continue;
      siparisKaldir(m);
      m.userData.durum = 'havuz';
      m.userData.hedefYer = null;
      m.userData.hedefDukkan = null;
      m.visible = false;
    }
    for (const y of yerler.values()) y.musteri = 0;
    for (const d of dukkanlar.values()) d.musteri = 0;
  }
  function ziyaretBasla(v) {
    if (!kuruldu) return false;
    ziyaret = { ilce: v.ilce };
    kendiTezgahlariGizle(true);
    musterileriSal();
    caddeGuncelle(v.yerler, v.isimler, true);
    komsulariAyarla(v.tezgahlar || [], 'ana');
    tumunuGoster = { aniden: false };
    if (boyut.ilk) tumunuGosterUygula();
    return true;
  }
  function ziyaretBitir() {
    if (!ziyaret) return;
    ziyaret = null;
    musterileriSal();
    komsulariAyarla([], 'ana');
    kendiTezgahlariGizle(false);
    if (kendiCadde) caddeGuncelle(kendiCadde.yerler, kendiCadde.isimler, true);
    tumunuGoster = { aniden: false };
    if (boyut.ilk) tumunuGosterUygula();
  }

  // ------------------------------------------------ Tezgâh yerleri
  const yerler = new Map();
  let isler = [];
  let aktifler = [];

  function yerKur(liste) {
    liste.forEach((is, sira) => {
      if (yerler.has(is.kod)) return;
      const grup = new THREE.Group();
      const k = yerKonumu(sira, liste.length);
      grup.position.set(k.x, KALDIRIM_Y, k.z);
      const govde = new THREE.Group();
      govde.scale.setScalar(OLCEK);
      grup.add(govde);
      const isabet = new THREE.Mesh(new THREE.BoxGeometry(3.8, 4.2, 3.6), new THREE.MeshBasicMaterial({ visible: false }));
      isabet.position.y = 1.9;
      isabet.userData.kod = is.kod;
      grup.add(isabet);
      const ampul = hale('#FFD28A', 2.6);
      ampul.position.set(0, 2.6, 0.2);
      const isik = isikLekesi('#FFC878', 5);
      isik.position.y = 0.03;
      ampul.visible = isik.visible = false;
      grup.add(ampul, isik);
      gecelik.haleler.add(ampul).add(isik);
      sahne.add(grup);
      const etiket = document.createElement('div');
      etiket.className = 'etiket gizli';
      etiketKutusu.appendChild(etiket);
      yerler.set(is.kod, { grup, govde, model: null, isabet, etiket, insan: null, durum: '', veri: is, ampul, isik, guney: k.guney });
    });
  }

  // Tezgâhın yanında biriken para: satış ilerledikçe ve bahşiş geldikçe büyür
  function birikim(a) {
    if (!a) return 0;
    const oran = Math.max(0, Math.min(1, (simdi() - a.baslangic) / (a.bitis - a.baslangic)));
    return Math.round((a.ciro || 0) * oran + (a.bonus || 0));
  }
  const sikkeGeo = new THREE.CylinderGeometry(0.11, 0.11, 0.035, 18);
  const sikkeMat = new THREE.MeshStandardMaterial({ color: '#E8B923', metalness: 0.9, roughness: 0.25, emissive: '#5A3F00', emissiveIntensity: 0.2 });
  const kasaMat = new THREE.MeshStandardMaterial({ color: '#6B4B2E', roughness: 0.7 });
  function paraYiginiKur(yer) {
    const g = new THREE.Group();
    const kasa = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.32, 0.36), kasaMat);
    kasa.position.y = 0.16;
    kasa.castShadow = true;
    g.add(kasa);
    const sikkeler = [];
    for (let i = 0; i < 20; i++) {
      const m = new THREE.Mesh(sikkeGeo, sikkeMat);
      const sutun = i % 2;
      m.position.set(-0.1 + sutun * 0.22 + (Math.random() - 0.5) * 0.02, 0.34 + Math.floor(i / 2) * 0.037, (Math.random() - 0.5) * 0.03);
      m.visible = false;
      g.add(m);
      sikkeler.push(m);
    }
    g.userData.sikkeler = sikkeler;
    g.position.set(1.95, 0, 0.45);
    yer.grup.add(g);
    yer.para = g;
  }
  let sonPara = 0;
  function paraGuncelle() {
    const t = performance.now();
    if (t - sonPara < 400) return;
    sonPara = t;
    for (const yer of yerler.values()) {
      const a = yer.aktif;
      if (!a) { if (yer.para) yer.para.visible = false; continue; }
      if (!yer.para) paraYiginiKur(yer);
      yer.para.visible = true;
      const tl = birikim(a) / 100;
      const n = Math.min(20, Math.ceil(Math.log2(1 + tl / 150) * 2.2));
      yer.para.userData.sikkeler.forEach((m, i) => { m.visible = i < n; });
    }
  }

  function durumAnahtari(is, a) {
    if (a) return a.bitis <= simdi() ? 'bitti' : 'suruyor-' + a.calisan;
    if (is.sahip) return 'bos';
    if (is.kilitli) return 'kilit';
    return 'satin';
  }

  function durumGuncelle(veri) {
    isler = veri.isler;
    aktifler = veri.aktifler;
    yerKur(isler);
    for (const is of isler) {
      const y = yerler.get(is.kod);
      y.veri = is;
      const a = aktifler.find((z) => z.isKodu === is.kod) || null;
      y.aktif = a;
      if (is.sahip && !y.model) {
        // tezgâh yürüyenler için engeldir (içinden geçilmez)
        y.engel = kalabalik.engelEkle(y.grup.position.x, y.grup.position.z, 5.0, 2.4); // tezgâh, halı, tabela ve kasalar
        y.model = tezgahModeli(is.kod);
        // örtü (branda) tezgâhın gövdesinin ölçüsünde, tabanı yerde
        const { boy, merkez } = y.model.userData.govdeKutu;
        y.ortu = ortu(boy, is.kod);
        y.ortu.position.set(merkez.x, merkez.y - boy.y / 2, merkez.z);
        y.acikta = [];
        y.model.traverse((o) => { if (o.userData.acikta) y.acikta.push(o); });
        y.govde.add(y.model, y.ortu);
        y.model.scale.setScalar(0.01);
        y.buyume = 0;
        if (is.kod === 'ayakkabi') {
          y.tabure = tabure();
          y.tabure.position.set(-0.85, 0, -0.25);
          y.grup.add(y.tabure);
        }
      } else if (!is.sahip && y.model) {
        kalabalik.engelSil(y.engel);
        y.engel = null;
        y.govde.remove(y.model, y.ortu);
        bellektenSil(y.model); bellektenSil(y.ortu);
        if (y.tabure) { y.grup.remove(y.tabure); bellektenSil(y.tabure); }
        y.model = y.ortu = y.tabure = null;
      }
      if (y.ortu) y.ortu.visible = !a;
      if (y.acikta) for (const o of y.acikta) o.visible = !!a;
      // yerdeki çerçeve: satın alınabilir yerde "+", kilitli yerde soluk kilit, çalışmayan kendi tezgâhında "▶"
      const bosTur = !is.sahip ? (is.kilitli ? 'kilit' : 'arti') : !a ? 'oynat' : null;
      if (y.bos && y.bos.userData.tur !== bosTur) {
        y.grup.remove(y.bos);
        bellektenSil(y.bos);
        y.bos = null;
      }
      if (bosTur && !y.bos) {
        y.bos = bosYer(bosTur);
        // ▶ çerçevesi tezgâhın önünde (müşterinin durduğu yanda) durur
        if (bosTur === 'oynat') { y.bos.scale.setScalar(0.62); y.bos.position.z = y.guney ? -1.9 : 1.9; }
        y.grup.add(y.bos);
      }
      vitrinGuncelle(y, is);
      y.ampul.visible = y.isik.visible = !!a;
      const kim = a ? a.calisan : null;
      if (y.insanTur !== kim) {
        if (y.insan) { y.grup.remove(y.insan); bellektenSil(y.insan, { geometri: false }); }
        y.insan = null;
        if (kim) {
          y.insan = insanUret(kim);
          if (is.kod === 'ayakkabi') {
            y.insan.position.set(-0.85, 0.02, -0.25);
            y.insan.rotation.y = Math.PI / 2;
            y.insan.userData.insan.oynat('Sitting_Idle_Loop', 0);
          } else {
            y.insan.position.set(0.2, 0, -1.3);
            y.insan.userData.insan.oynat('Idle_Talking_Loop', 0);
          }
          y.grup.add(y.insan);
        }
        y.insanTur = kim;
      }
      y.durum = '';
      etiketCiz(y);
    }
    if (ziyaret) kendiTezgahlariGizle(true);
    if (introDolgu) introDolguUygula();
  }

  // ------------------------------------------------ Tanıtım: dolu sokak ve tezgâh açılışı
  // Tanıtım boyunca sokaktaki bütün tezgâh yerleri açık tezgâhla ve taburesinde oturan satıcıyla doldurulur
  // (sokak boş görünmesin). Oyuncunun kendi tezgâhında küçük bir açılış hazırlığı oynatılır:
  // satıcı gelir, brandayı kaldırıp katlar, mallar tezgâha dizilir, satıcı taburesine oturur.
  // Tanıtım bitince her şey oyunun gerçek durumuna döner.
  let introDolgu = null;
  function introSatici(tur) {
    const ins = insanUret(tur);
    ins.userData.insan.oynat('Sitting_Idle_Loop', 0);
    return ins;
  }
  function introDoldur(acik, anaKod) {
    if (!acik) {
      if (!introDolgu) return;
      for (const [y, d] of introDolgu.yerler) {
        if (d.model) { y.govde.remove(d.model); bellektenSil(d.model); }
        if (d.ortu) { y.govde.remove(d.ortu); bellektenSil(d.ortu); }
        if (d.insan) { y.grup.remove(d.insan); bellektenSil(d.insan, { geometri: false }); }
        if (d.tabure) { y.grup.remove(d.tabure); bellektenSil(d.tabure); }
        if (d.engel) kalabalik.engelSil(d.engel);
        if (y.ortu) { y.ortu.visible = !y.aktif; y.ortu.position.copy(d.ortuYer || y.ortu.position); y.ortu.scale.setScalar(1); y.ortu.rotation.set(0, 0, 0); }
        if (y.acikta) for (const o of y.acikta) { o.visible = !!y.aktif; if (o.userData.introOlcek) { o.scale.copy(o.userData.introOlcek); delete o.userData.introOlcek; } }
        if (y.bos) y.bos.visible = true;
        y.ampul.visible = y.isik.visible = !!y.aktif;
      }
      introDolgu = null;
      return;
    }
    if (introDolgu) return introDolgu.konum;
    introDolgu = { yerler: new Map(), acilis: null };
    const liste = [...yerler.values()];
    const ana = (anaKod && yerler.get(anaKod)) || liste.find((y) => y.veri && y.veri.sahip) || liste[0];
    for (const y of liste) {
      if (y.aktif && y.insan) continue; // zaten çalışan tezgâh
      const d = {};
      if (!y.model) {
        d.model = tezgahModeli(y.veri.kod);
        d.model.traverse((o) => { if (o.userData.acikta) o.visible = true; });
        y.govde.add(d.model);
      }
      d.tabure = tabure();
      d.tabure.position.set(0.95, 0, -1.45);
      y.grup.add(d.tabure);
      d.insan = introSatici(y.veri && y.veri.sahip ? 'ben' : 'yaya');
      d.insan.position.set(0.95, 0.02, -1.45);
      y.grup.add(d.insan);
      if (d.model) d.engel = kalabalik.engelEkle(y.grup.position.x, y.grup.position.z, 5.0, 2.4);
      introDolgu.yerler.set(y, d);
      if (y === ana) {
        // açılış hazırlığı: brandalı başlar, satıcı tezgâhın yanında ayakta bekler
        const model = y.model || d.model;
        if (!y.ortu) {
          const { boy, merkez } = model.userData.govdeKutu;
          d.ortu = ortu(boy, y.veri.kod);
          d.ortu.position.set(merkez.x, merkez.y - boy.y / 2, merkez.z);
          y.govde.add(d.ortu);
        }
        const o = y.ortu || d.ortu;
        d.ortuYer = o.position.clone();
        const acikta = [];
        model.traverse((x) => { if (introCekim ? x.userData.introUrun : x.userData.acikta) acikta.push(x); });
        // Kaldırım tabelası ürün değildir; çekimde branda açılırken ekrana sıçramasın.
        if (introCekim && y.veri.kod === 'simit') model.traverse((x) => { if (x.userData.acikta && x.type === 'Group' && x.position.x < -1.2) x.visible = false; });
        introDolgu.acilis = { y, d, ortu: o, acikta, t: -1 };
        d.insan.position.set(-2.1, 0, -1.65);
        d.insan.rotation.y = Math.PI / 2;
        d.insan.userData.insan.oynat('Idle_Loop', 0);
      }
    }
    introDolguUygula();
    introDolgu.konum = ana ? { x: ana.grup.position.x, z: ana.grup.position.z } : null;
    return introDolgu.konum;
  }
  // durum yenilense de tanıtımdaki görünüm korunur
  function introDolguUygula() {
    for (const [y, d] of introDolgu.yerler) {
      const acilis = introDolgu.acilis && introDolgu.acilis.y === y;
      const once = acilis && introDolgu.acilis.t < 0;
      if (y.ortu && !d.ortu) y.ortu.visible = once;
      if (d.ortu) d.ortu.visible = once;
      if (y.acikta && !d.model) for (const o of y.acikta) o.visible = !once;
      if (acilis && (once || introCekim)) for (const o of introDolgu.acilis.acikta) o.visible = false;
      if (y.bos) y.bos.visible = false;
      if (y.etiket) y.etiket.classList.add('gizli');
    }
  }
  function introAcilisBaslat() { if (introDolgu && introDolgu.acilis) introDolgu.acilis.t = 0; }
  const yumusakK = (k) => { k = Math.max(0, Math.min(1, k)); return k * k * (3 - 2 * k); };
  function introDolguGuncelle(dt) {
    for (const d of introDolgu.yerler.values()) if (d.insan) insanGuncelle(d.insan, dt);
    const a = introDolgu.acilis;
    if (!a || a.t < 0 || a.bitti) return;
    a.t += dt;
    const t = a.t;
    const ins = a.d.insan;
    // 0-0.5 sn: satıcı brandanın yanına yürür
    if (t < 0.5) {
      if (!a.yuruyor) { a.yuruyor = true; ins.userData.insan.oynat('Walk_Loop', 0.2, 1); }
      ins.position.x = -2.1 + yumusakK(t / 0.5) * 0.6;
    }
    // 0.4-1.2 sn: branda kalkar, katlanıp kaybolur
    const kb = yumusakK((t - 0.4) / 0.8);
    if (t > 0.4 && !a.brandaBitti) {
      if (!a.uzaniyor) { a.uzaniyor = true; ins.userData.insan.oynat('Interact', 0.2); }
      a.ortu.visible = kb < 1;
      a.ortu.position.y = a.d.ortuYer.y + kb * 1.4;
      a.ortu.scale.set(1 - kb * 0.55, Math.max(0.02, 1 - kb), 1 - kb * 0.55);
      a.ortu.rotation.z = kb * 0.35;
      if (kb >= 1) a.brandaBitti = true;
    }
    // 0.9-1.9 sn: mallar sırayla tezgâha dizilir
    if (t > 0.9) {
      a.acikta.forEach((o, i) => {
        const k = Math.max(0, Math.min(1, (t - 0.9 - i * (0.9 / Math.max(1, a.acikta.length))) / 0.35));
        if (k <= 0) return;
        if (!o.userData.introOlcek) o.userData.introOlcek = o.scale.clone();
        o.visible = true;
        const s2 = k < 0.7 ? (k / 0.7) * 1.12 : 1.12 - ((k - 0.7) / 0.3) * 0.12;
        o.scale.copy(o.userData.introOlcek).multiplyScalar(Math.max(0.01, s2));
      });
    }
    // 1.5-2.2 sn: taburesine geçip oturur
    if (t > 1.5) {
      const k = yumusakK((t - 1.5) / 0.5);
      if (!a.gidiyor) { a.gidiyor = true; ins.userData.insan.oynat('Walk_Loop', 0.2, 1); }
      ins.position.x = -1.5 + k * (0.95 + 1.5);
      ins.position.z = -1.65 + k * 0.2;
      ins.rotation.y = Math.PI / 2 * (1 - k);
      if (k >= 1 && !a.oturdu) {
        a.oturdu = true;
        ins.position.set(0.95, 0.02, -1.45);
        ins.rotation.y = 0;
        ins.userData.insan.oynat('Sitting_Idle_Loop', 0.25);
        a.y.ampul.visible = a.y.isik.visible = true;
      }
    }
    if (t > 2.4) a.bitti = true;
  }

  // Sahibi olmayan tezgâh yeri: brandası kapalı bir tezgâh ve üstünde adı, fiyatı, "SATIN AL" yazan levha.
  // Yerdeki yanıp sönen "+" çerçevesi de durur. Kilitli yerde levha gri, seviye yazar.
  // Satın alınmamış tezgâhlarda yalnızca yerdeki yanıp sönen "+" çerçevesi durur (0.14'teki brandalı vitrin kaldırıldı)
  function vitrinGuncelle(y) {
    if (y.vitrin) { y.govde.remove(y.vitrin); bellektenSil(y.vitrin); y.vitrin = null; }
    if (y.levha) { y.grup.remove(y.levha); bellektenSil(y.levha); y.levha = null; }
  }

  // Tezgâh bilgisi sade durur: yalnızca ilerleme halkası. Halkaya tıklayınca (dokununca) süre,
  // çırak ve birikim açılır, halkaya yeniden tıklayınca kapanır; kapatılmazsa 30 saniye sonra kendiliğinden kapanır.
  const ACIK_SURE = 30000;
  function etiketAc(y) {
    y.acikBitis = Date.now() + ACIK_SURE;
    etiketCiz(y);
  }
  function etiketDegistir(y) {
    if ((y.acikBitis || 0) > Date.now()) { y.acikBitis = 0; etiketCiz(y); }
    else etiketAc(y);
  }
  function etiketCiz(y) {
    const is = y.veri;
    const a = y.aktif;
    const acik = (y.acikBitis || 0) > Date.now();
    // (0.37.22) ayrıntı balonu açıkken iş biterse kese yine çizilir; önceden 30 sn boyunca hiçbir şey görünmüyordu
    const temel = durumAnahtari(is, a);
    const d = temel + (acik && temel.startsWith('suruyor') ? '-acik' : '');
    if (d === y.durum) {
      if (d.startsWith('suruyor')) {
        const oran = Math.max(0, Math.min(1, (simdi() - a.baslangic) / (a.bitis - a.baslangic)));
        const daire = y.etiket.querySelectorAll('circle')[1];
        if (daire) daire.setAttribute('stroke-dashoffset', String(Number(daire.getAttribute('stroke-dasharray')) * (1 - oran)));
        if (!acik) return;
        const sayac = y.etiket.querySelector('.sayi');
        if (sayac) sayac.textContent = sureMetni(a.bitis - simdi());
        const bir = y.etiket.querySelector('.birikim');
        if (bir) bir.textContent = '💰 ' + sade(birikim(a)) + ' ₺';
      }
      return;
    }
    y.durum = d;
    const e = y.etiket;
    if (d === 'bitti') {
      e.innerHTML = `<button class="kese" data-kese="${is.kod}" aria-label="${esc(npcSablon`${is.ad} kazancını topla`)}">💰</button>`;
    } else if (d.startsWith('suruyor')) {
      const oran = (simdi() - a.baslangic) / (a.bitis - a.baslangic);
      e.innerHTML = acik ? `<button class="balon" data-yer="${is.kod}">
        <span class="halka" data-halka="${is.kod}" title="${esc(dilMetni('common.close'))}">${halkaSvg(oran, 30, 4, '#1FA25A', '#E3E6EE')}<b>${is.simge}</b></span>
        <span><span class="sayi">${sureMetni(a.bitis - simdi())}</span>${a.calisan === 'cirak' ? `<span class="cirak">${esc(npcMetni('Çırak'))}</span>` : ''}<span class="birikim sayi">💰 ${sade(birikim(a))} ₺</span></span></button>`
        : `<button class="balon mini" data-yer="${is.kod}" data-mini aria-label="${esc(is.ad)}"><span class="halka">${halkaSvg(oran, 30, 4, '#1FA25A', '#E3E6EE')}<b>${is.simge}</b></span></button>`;
    } else {
      // boştaki kendi tezgâhında yerde yanıp sönen ▶, satın alınabilir yerde "+" çerçevesi var; balon yok
      // satın alınabilir ve kilitli yerlerde bilgi tezgâhın üstündeki levhada yazar
      e.innerHTML = '';
    }
  }

  // Kese dokunuşu parmak değer değmez işlenir: etiketler her karede ekranda kaydığı ve durum değişince
  // yeniden çizildiği için "click" bazen hiç oluşmuyor, oyuncu 2-3 kez dokunmak zorunda kalıyordu.
  etiketKutusu.addEventListener('pointerdown', (ev) => {
    const kese = ev.target.closest('[data-kese]');
    if (!kese || (ev.button !== undefined && ev.button !== 0)) return;
    ev.preventDefault();
    keseTik(kese.dataset.kese, kese.getBoundingClientRect());
  });
  etiketKutusu.addEventListener('click', (ev) => {
    const kese = ev.target.closest('[data-kese]');
    if (kese) return;
    const yer = ev.target.closest('[data-yer]');
    const halka = ev.target.closest('[data-halka]');
    const mini = yer && yer.hasAttribute('data-mini') ? yer.dataset.yer : null;
    if (halka || mini) { const y = yerler.get(halka ? halka.dataset.halka : mini); if (y) etiketDegistir(y); return; }
    if (yer) return tiklandi(yer.dataset.yer);
    const dk = ev.target.closest('[data-dukkan]');
    if (dk) dukkanTiklandi(Number(dk.dataset.dukkan));
  });

  // ------------------------------------------------ Sokak olayları (zabıta, polis, ambulans…)
  // Park yerleri: görev aracı yanaşacağı yeri ayırır; ayrılan yere başka araba park etmez
  const REZERVE = { userData: { durum: 'rezerve' } };
  function parkAyir(xIstenen) {
    let en = null;
    for (let kay = 0; kay <= 24; kay += 1.5) {
      for (const x of [xIstenen + kay, xIstenen - kay]) {
        if (x < XB + 8 || x > XD - 8 || Math.abs(x - GECIT_X) < 6) continue;
        const dolu = parkYerleri.some((y) => y.araba && Math.abs(y.x - x) < 6.5) || parkEdenler.some((a) => Math.abs(a.position.x - x) < 7);
        if (!dolu) { en = x; break; }
      }
      if (en !== null) break;
    }
    if (en === null) return null;
    const yer = { x: en, araba: REZERVE, sure: 0, gecici: true };
    parkYerleri.push(yer);
    return en;
  }
  // Oyuncunun en değerli arabası caddenin güney kenarına park eder (üstünde küçük "🔑 Senin" etiketi)
  let arabam = null;
  function arabamAyarla(bilgi) {
    const anahtar = bilgi ? bilgi.ad + bilgi.renk : '';
    if (arabam && arabam.anahtar === anahtar) return;
    if (arabam) {
      sahne.remove(arabam.g); bellektenSil(arabam.g);
      if (arabam.x != null) parkBirak(arabam.x);
      arabam.etiket.remove();
      arabam = null;
    }
    if (!bilgi || !kuruldu) return;
    const yer = [...yerler.values()].find((y) => y.veri && y.veri.sahip);
    const px = parkAyir(yer ? yer.grup.position.x + 3 : DURAK_X - 14);
    if (px == null) return;
    const g = araba(bilgi.govde === 'suv' ? 'suv' : bilgi.govde === 'spor' ? 'spor' : 'sedan', bilgi.renk);
    g.position.set(px, 0.02, 7.3);
    sahne.add(g);
    const etiket = document.createElement('div');
    etiket.className = 'etiket gizli';
    etiket.innerHTML = `<div class="olay-balon arabam">🔑 ${esc(bilgi.ad)}</div>`;
    etiketKutusu.appendChild(etiket);
    arabam = { g, x: px, anahtar, etiket };
  }

  function parkBirak(x) {
    const i = parkYerleri.findIndex((y) => y.gecici && y.x === x);
    if (i > -1) parkYerleri.splice(i, 1);
  }
  const olaylar = olayMotoru({
    sahne, etiketKutusu, gecelik, bellektenSil, api,
    etiketGoster: (e, x, y, z) => etiketGoster(e, x, y, z),
    kuruldu: () => kuruldu,
    kamera: () => ({ x: hedefX, z: hedefZ, mesafe }),
    saat: () => oyunSaati(),
    yakin: (x, z, sinir = 60) => yakinMi(x, z, sinir),
    ekrandaMi: (p, r) => ekrandaMi(p, r),
    sinirlar: () => ({ XB, XD }),
    durakX: () => DURAK_X,
    // sokak müzisyenlerinin sabit yeri: güney sırasındaki son tezgâhın sağı
    muzisyenYeri: () => {
      let mx = -Infinity;
      for (const y of yerler.values()) if (y.guney) mx = Math.max(mx, y.grup.position.x);
      if (!Number.isFinite(mx)) return null;
      return { x: Math.min(XD - 6, mx + 6.2), z: GUNEY_TEZGAH_Z - 0.2 };
    },
    dukkanlar: () => [...dukkanlar.values()],
    trafik: {
      ekle(a, no) {
        const sr = SERITLER[no];
        a.userData.serit = sr;
        a.visible = true;
        if (!arabalar.includes(a)) arabalar.push(a);
      },
      // konvoy geçerken şeride sokağın başından sivil araç girmez
      kapat(no, sn) { SERITLER[no].kapaliBitis = performance.now() + sn * 1000; },
      cikar(a) { const i = arabalar.indexOf(a); if (i > -1) arabalar.splice(i, 1); a.userData.serit = null; },
      // şeritte x'in arkasında (gelen trafik yönünde) pay kadar boşluk var mı
      bosMu(no, x, pay) {
        const sr = SERITLER[no];
        return !arabalar.some((b) => b.userData.serit === sr && b.visible && Math.abs(b.position.x - x) < pay)
          && !parkEdenler.some((b) => b.userData.durum !== 'park' && Math.abs(b.position.z - sr.sabit) < 1.6 && Math.abs(b.position.x - x) < pay);
      },
      // şerit dışında yolda duran/yanaşan görev aracı: arkadan gelenler ona çarpmaz
      engel(a, var_) { if (var_) disEngeller.add(a); else disEngeller.delete(a); },
      direksiyon: (a, aci, dt) => direksiyon(a, aci, dt),
    },
    zeminY: (x, z) => zeminY(x, z),
    konteynerler: () => konteynerler,
    park: { ayir: parkAyir, birak: parkBirak },
    katil: (olay, eylem, rect) => olayKatil ? olayKatil(olay, eylem, rect) : Promise.resolve(null),
    zabitaSonucu: (kod, sonuc, z) => zabitaSonucu && zabitaSonucu(kod, sonuc, z),
    haber: (olay, metin, x, z) => { if (olayHaberi && (!aktifMi || !yakinMi(x, z, 45))) olayHaberi(olay, metin, () => ucusYap(x, z + 2, 32)); },
    izinVar: () => (izinVar ? izinVar() : false),
    yerBul: (kod) => { const y = yerler.get(kod); return y ? { kod, x: y.grup.position.x, z: y.grup.position.z, guney: y.guney } : null; },
    zabitaZiyaretleri() {
      const l = [];
      for (const [kod, y] of yerler) {
        if (!y.aktif || !y.aktif.zabita) continue;
        for (const z of y.aktif.zabita) l.push({ ...z, yer: { kod, x: y.grup.position.x, z: y.grup.position.z, guney: y.guney } });
      }
      return l;
    },
    calisanTezgah() {
      const c = [...yerler.entries()].filter(([, y]) => y.aktif && y.aktif.bitis > simdi() && yakinMi(y.grup.position.x, y.grup.position.z, 20));
      if (!c.length) return null;
      const [kod, y] = c[Math.floor(Math.random() * c.length)];
      return { kod, x: y.grup.position.x, z: y.grup.position.z };
    },
    kuyrukOlustur(kod, n) {
      const y = yerler.get(kod);
      if (!y) return;
      for (let i = 0; i < n; i++) setTimeout(() => tezgahaGonder(y), i * 700);
    },
  });

  // ------------------------------------------------ Kamera: sokak seviyesinden kuş bakışına
  // Tek parmak sürükle: kaydır. İki parmak: yakınlaştır ve döndür. Fare tekeri: yakınlaştır, sağ tık: döndür.
  let hedefX = 0;
  let hedefZ = ORTA_Z;
  let aci = 0;                // kameranın bakış yönü (0 = kuzeye bakar)
  let mesafe = 30;
  let istenenMesafe = 30;
  let enYakinMesafe = 18;
  // Semt büyüklüğü: 0.24'teki semtin 2 katı alan (yarıçap 470 → 665 m; zayıf cihazda biraz küçük)
  const SEHIR_YARICAP = 300; // Yakın modellerin kalitesi aynı; yalnızca çevredeki alan daraltılır.
  // 0.30: dört kademe daha uzaklaşılabilir (fare tekerleğinin her kademesi ×1,16): bütün semt ve sokak adları görünür
  const ESKI_UZAK = Math.round(Math.max(300, SEHIR_YARICAP * 1.05));
  const EN_UZAK = Math.round(ESKI_UZAK * 1.8);
  // eski en uzak noktaya kadar eğim eskisi gibi; ötesinde kamera iyice tepeden bakar (sokaklar binaların arasından görünür)
  function egimHesapla(m) {
    if (m <= ESKI_UZAK) return THREE.MathUtils.lerp(0.67, 1.3, Math.max(0, Math.min(1, (m - enYakinMesafe) / (ESKI_UZAK - enYakinMesafe))));
    return THREE.MathUtils.lerp(1.3, 1.48, Math.min(1, (m - ESKI_UZAK) / (EN_UZAK - ESKI_UZAK)));
  }
  let hizX = 0;
  let hizZ = 0;
  let ucus = null;
  const kanvas = document.getElementById('sahne');
  let aktifMi = false;
  const parmaklar = new Map();
  let ikiParmak = null;

  // en uzak noktadayken daha da uzaklaşmak isteyen oyuncu haritaya (ilçesine) çıkar
  let uzaklasmaPayi = 0;
  let sonCikis = 0;
  function uzaklasmaIstegi(kat) {
    if (mesafe < EN_UZAK * 0.97) { uzaklasmaPayi = 0; return; }
    uzaklasmaPayi += kat;
    if (uzaklasmaPayi > 0.35 && performance.now() - sonCikis > 2500) {
      uzaklasmaPayi = 0;
      sonCikis = performance.now();
      uzaklasti();
    }
  }
  function sinir() {
    // yakındayken sokakta kalır; uzaklaştıkça bütün semtte gezilebilir
    const pay = Math.max(0, Math.min(1, (istenenMesafe - 60) / 260));
    const genis = SEHIR_YARICAP - 120;
    hedefX = Math.max(XB - 60 - pay * genis, Math.min(XD + 60 + pay * genis, hedefX));
    hedefZ = Math.max(-80 - pay * genis, Math.min(26 + pay * genis * 0.72, hedefZ));
    istenenMesafe = Math.max(enYakinMesafe, Math.min(EN_UZAK, istenenMesafe));
  }

  function ekranaGoreKaydir(dx, dy) {
    const olcek = (mesafe * 1.15) / window.innerHeight;
    const sag = { x: Math.cos(aci), z: -Math.sin(aci) };
    const ileri = { x: -Math.sin(aci), z: -Math.cos(aci) };
    const mx = -dx * olcek * sag.x + dy * olcek * ileri.x;
    const mz = -dx * olcek * sag.z + dy * olcek * ileri.z;
    hedefX += mx;
    hedefZ += mz;
    return [mx, mz];
  }

  // Yakınlaştırma imlecin (iki parmakta parmakların ortasının) altındaki noktaya doğru olur:
  // o nokta ekranda yerinde kalır, kamera ona doğru yaklaşır/uzaklaşır.
  let zumCapa = null;
  const capaIsin = new THREE.Raycaster();
  const capaNdc = new THREE.Vector2();
  const capaYer = new THREE.Plane(new THREE.Vector3(0, 1, 0), -1.2);
  const capaNokta = new THREE.Vector3();
  function zumCapasi(cx, cy) {
    const r = kanvas.getBoundingClientRect();
    capaNdc.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
    capaIsin.setFromCamera(capaNdc, kamera);
    if (!capaIsin.ray.intersectPlane(capaYer, capaNokta)) { zumCapa = null; return; }
    // ufka çok yakın (çok uzak) noktalara doğru ani sıçrama olmasın
    const uz = Math.hypot(capaNokta.x - hedefX, capaNokta.z - hedefZ);
    const en = mesafe * 2.2;
    if (uz > en) { capaNokta.x = hedefX + ((capaNokta.x - hedefX) / uz) * en; capaNokta.z = hedefZ + ((capaNokta.z - hedefZ) / uz) * en; }
    zumCapa = { x: capaNokta.x, z: capaNokta.z };
  }

  kanvas.addEventListener('pointerdown', (e) => {
    if (!aktifMi) return;
    // birincil dokunuş/tık yeni bir hareketin başıdır: kaçırılmış "bırakma"lardan kalan eski parmaklar silinir
    // (yoksa sürükleme iki parmak sanılıp kamera kilitli gibi kalıyordu)
    if (e.isPrimary) { parmaklar.clear(); ikiParmak = null; }
    sinema = null; // oyuncu dokunduysa sinematik kamera bırakılır
    parmaklar.set(e.pointerId, { x: e.clientX, y: e.clientY, sag: e.button === 2 });
    hizX = hizZ = 0;
    ucus = null;
    if (parmaklar.size === 2) {
      const [a, b] = [...parmaklar.values()];
      ikiParmak = { uzaklik: Math.hypot(a.x - b.x, a.y - b.y), aci: Math.atan2(b.y - a.y, b.x - a.x) };
    }
  });
  window.addEventListener('pointermove', (e) => {
    if (!aktifMi || !parmaklar.has(e.pointerId)) return;
    const p = parmaklar.get(e.pointerId);
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;
    if (parmaklar.size === 2 && ikiParmak) {
      const [a, b] = [...parmaklar.values()];
      const uzaklik = Math.hypot(a.x - b.x, a.y - b.y);
      const yeniAci = Math.atan2(b.y - a.y, b.x - a.x);
      if (ikiParmak.uzaklik > 10) {
        const oran = ikiParmak.uzaklik / Math.max(10, uzaklik);
        zumCapasi((a.x + b.x) / 2, (a.y + b.y) / 2);
        istenenMesafe *= oran;
        if (oran > 1) uzaklasmaIstegi(oran - 1);
      }
      // iki parmak saat yönünde dönünce sahne de parmaklarla birlikte döner
      aci += yeniAci - ikiParmak.aci;
      ikiParmak = { uzaklik, aci: yeniAci };
      sinir();
      return;
    }
    if (p.sag || e.shiftKey) {
      aci -= dx * 0.008;
      return;
    }
    zumCapa = null;
    const [mx, mz] = ekranaGoreKaydir(dx, dy);
    // fareyle sürüklerken bırakınca kayma olmaz (ekran tam istenen yerde durur); parmakla hafif süzülür
    if (e.pointerType === 'touch') { hizX = mx * 40; hizZ = mz * 40; } else { hizX = hizZ = 0; }
    sinir();
  });
  const birak = (e) => {
    parmaklar.delete(e.pointerId);
    if (parmaklar.size < 2) ikiParmak = null;
  };
  window.addEventListener('pointerup', birak);
  window.addEventListener('pointercancel', birak);
  // pencere odağı kaybolunca (başka uygulama, sekme, sistem penceresi) basılı parmaklar unutulur
  const hepsiniBirak = () => { parmaklar.clear(); ikiParmak = null; };
  window.addEventListener('blur', hepsiniBirak);
  document.addEventListener('visibilitychange', () => { if (document.hidden) hepsiniBirak(); });
  kanvas.addEventListener('contextmenu', (e) => e.preventDefault());
  // fare tezgâhın üstündeyken imleç el olur; ayrıntı yalnızca halkaya tıklayınca açılır
  let sonUzerinde = 0;
  const uzerIsin = new THREE.Raycaster();
  kanvas.addEventListener('pointermove', (e) => {
    if (!aktifMi || e.pointerType !== 'mouse' || parmaklar.size || performance.now() - sonUzerinde < 120) return;
    sonUzerinde = performance.now();
    const r = kanvas.getBoundingClientRect();
    uzerIsin.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), kamera);
    const v = uzerIsin.intersectObjects([...yerler.values()].map((y) => y.isabet).concat([...dukkanlar.values()].map(d => d.isabet)), false)[0];
    const y = v && yerler.get(v.object.userData.kod);
    kanvas.style.cursor = v || (y && y.veri) ? 'pointer' : '';
  });
  kanvas.addEventListener('wheel', (e) => {
    if (!aktifMi) return;
    e.preventDefault();
    sinema = null;
    zumCapasi(e.clientX, e.clientY);
    istenenMesafe *= Math.pow(1.0015, e.deltaY);
    if (e.deltaY > 0) uzaklasmaIstegi(Math.min(0.2, e.deltaY / 500));
    ucus = null;
    sinir();
  }, { passive: false });

  function boyut(w, h) {
    kamera.aspect = w / h;
    // telefonda sokak seviyesinde birkaç tezgâh birden görünsün
    const genislik = w < h ? 13 : 30;
    const uygun = genislik / (2 * Math.tan(THREE.MathUtils.degToRad(kamera.fov / 2)) * kamera.aspect);
    enYakinMesafe = Math.max(16, Math.min(uygun * 0.7, 36));
    if (!boyut.ilk) { boyut.ilk = true; mesafe = istenenMesafe = Math.max(24, Math.min(uygun, 52)); }
    kamera.updateProjectionMatrix();
    tumunuGosterUygula();
  }

  // Açılışta tüm tezgâhlar ekrana sığsın (ekran oranı belli olunca uygulanır)
  let tumunuGoster = null;
  function tumunuGosterUygula() {
    if (!tumunuGoster) return;
    // Bitmiş işler de açılış kadrajına dahildir; tek çalışan iş kamerayı kendine çekmesin.
    const hepsi = [...yerler.values()].filter((y) => y.veri && y.veri.sahip);
    const secilen = hepsi;
    let x0, x1, z0, z1;
    if (secilen.length && !ziyaret) {
      x0 = Math.min(...secilen.map((y) => y.grup.position.x)) - 4.5;
      x1 = Math.max(...secilen.map((y) => y.grup.position.x)) + 4.5;
      z0 = Math.min(...secilen.map((y) => y.grup.position.z)) - 3;
      z1 = Math.max(...secilen.map((y) => y.grup.position.z)) + 3;
    } else {
      const g = (Math.ceil((isler.length || 12) / 2) - 1) * ARALIK + 3.6 + 12;
      x0 = -g / 2; x1 = g / 2; z0 = ORTA_Z - 6; z1 = ORTA_Z + 6;
    }
    const tanY = Math.tan(THREE.MathUtils.degToRad(kamera.fov / 2));
    // genişlik yatay görüşe, derinlik (eğik bakışta kısalır) dikey görüşe sığsın; kenarlarda arayüz için pay
    // Tek tezgâhı olan oyuncuda da cadde görünür; dar ekranlarda sabit üst sınır kadrajı kırpmasın.
    const mGen = Math.max(30, x1 - x0) * 1.18 / (2 * tanY * kamera.aspect);
    const mDer = Math.max(18, z1 - z0) * 1.6 / (2 * tanY);
    const uygun = Math.max(enYakinMesafe, Math.min(EN_UZAK, Math.max(mGen, mDer)));
    const cx = (x0 + x1) / 2;
    const cz = (z0 + z1) / 2 + 1;
    aci = 0;
    sinema = null;
    zumCapa = null;
    if (tumunuGoster.aniden) { ucus = null; hizX = hizZ = 0; hedefX = cx; hedefZ = cz; istenenMesafe = mesafe = uygun; } else ucusYap(cx, cz, uygun);
    tumunuGoster = null;
  }

  function ucusYap(x, z, m) {
    zumCapa = null;
    ucus = { t: 0, bx: hedefX, bz: hedefZ, bm: istenenMesafe, sx: x, sz: z, sm: m || istenenMesafe };
    hizX = hizZ = 0;
  }

  const bakis = new THREE.Vector3();
  const hedef = new THREE.Vector3();
  let sonEtiket = 0;
  let sonSes = 0;
  let gecePayi = 0;
  let tavanKariAcik = false;
  let golgeBoyu = 26;
  const sisGunduz = new THREE.Color('#CDE6FA');
  const sisAksam = new THREE.Color('#E6AE84');
  const sisGece = new THREE.Color('#0E1729');
  // her karede yeni renk nesnesi üretilmesin (çöp toplayıcıyı yormasın)
  const sisRengi = new THREE.Color();
  const RENK_AKSAM = new THREE.Color('#FF9A5A');
  const RENK_GECE_GUNES = new THREE.Color('#8EA6D8');
  const RENK_GECE_YARIM = new THREE.Color('#8899B5');
  const GECE_ISIK_YONU = new THREE.Vector3();
  const AY_YONU = new THREE.Vector3(0.3, 1, 0.4).normalize();

  function gunIsigi(dt = 1/60) {
    const saat = oyunSaati();
    const gun = (saat - 6) / 14;
    const yukseklik = Math.sin(gun * Math.PI) * 58 - (gun < 0 || gun > 1 ? 20 : 0);
    const yon = THREE.MathUtils.lerp(-75, 75, THREE.MathUtils.clamp(gun, 0, 1));
    const el = THREE.MathUtils.degToRad(Math.max(-18, yukseklik));
    const az = THREE.MathUtils.degToRad(yon);
    gunesYonu.set(Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el));
    gu.sunPosition.value.copy(gunesYonu);
    const gece = THREE.MathUtils.clamp((4 - yukseklik) / 12, 0, 1);
    gecePayi = gece;
    const alacakaranlik = THREE.MathUtils.clamp(1 - Math.abs(yukseklik - 4) / 14, 0, 1);

    // bulut yavaşça değişir (sayfa açıkken hava değişirse sahne birden kararmasın)
    bulutPayi += (hedefBulut - bulutPayi) * (1-Math.exp(-Math.min(dt,.25)*1.2));
    const guc = THREE.MathUtils.clamp(Math.sin(el) * 2.7, 0, 2.35) * (1 - bulutPayi * 0.6);
    gunes.intensity = guc + gece * 0.28;
    gunes.color.set('#F9F5EC').lerp(RENK_AKSAM, alacakaranlik * 0.8).lerp(RENK_GECE_GUNES, gece);
    const isikYonu = GECE_ISIK_YONU.copy(gunesYonu).lerp(AY_YONU,THREE.MathUtils.smoothstep(gece,.2,.85)).normalize();
    // gölge alanı 4 m'lik ızgarada kayar: kamera her kaydırıldığında gölge haritası yeniden çizilmez
    const gx = Math.round(hedefX / 4) * 4, gz = Math.round(hedefZ / 4) * 4;
    gunes.position.set(gx + isikYonu.x * 60, Math.max(8, isikYonu.y * 60), gz + isikYonu.z * 60);
    gunes.target.position.set(gx, 0, gz);
    golgeYonAnahtari = Math.round(isikYonu.x * 200) + ',' + Math.round(isikYonu.y * 200) + ',' + Math.round(isikYonu.z * 200) + ',' + gx + ',' + gz;
    // kapalı ve yağışlı havada sahne kasvetlenir: gök ışığı ve yansımalar azalır
    const kasvet = bulutPayi * (hava.tur === 'firtina' ? 1 : hava.tur === 'yagmur' || hava.tur === 'kar' ? 0.8 : 0.55);
    yarim.intensity = (0.28 + (1 - gece) * 0.26 + gece * 0.04) * (1 - kasvet * 0.3);
    yarim.color.set('#DCE5EE').lerp(RENK_GECE_YARIM, gece);

    const sis = sisRengi.copy(sisGunduz).lerp(bulutSis, bulutPayi * 0.8).lerp(sisAksam, alacakaranlik * 0.7 * (1 - bulutPayi * 0.6)).lerp(sisGece, gece);
    sahne.fog.color.copy(sis);
    const bulanik = 5 + bulutPayi * 14;
    if (Math.abs(gu.turbidity.value - bulanik) > 0.8) { gu.turbidity.value = bulanik; sonOrtamYuk = -99; }
    // kapalı havada gölgeler silikleşir
    if ('intensity' in gunes.shadow) gunes.shadow.intensity = 1 - bulutPayi * 0.75;
    yildizlar.material.opacity = gece * 0.9;

    if (Math.abs(yukseklik - sonOrtamYuk) > (K.kod === 'dusuk' ? 8 : 3)) {
      sonOrtamYuk = yukseklik;
      if (ortam) ortam.dispose();
      ortam = pmrem.fromScene(gokSahne, 0.02);
      sahne.environment = ortam.texture;
    }
    sahne.environmentIntensity = (0.35 + (1 - gece) * 0.5) * (1 - kasvet * 0.45);

    const isikAcik = aydinlatmaPayi(saat, THREE.MathUtils.clamp((gece + alacakaranlik * 0.5 - 0.25) * 2, 0, 1));
    isikAcikPayi = isikAcik;
    // far huzmeleri havadaki nemde görünür: yağmur, kar ve siste daha belirgin (ortak malzeme)
    const nem = Math.min(1, havaEf.islaklik * 0.8 + (hava && hava.tur === 'sis' ? 1 : hava && hava.tur === 'kar' ? 0.7 : 0));
    farHuzmesiMalzemesi().opacity = isikAcik * (0.07 + nem * 0.13);
    const km = tavanKariMalzemesi();
    const kar = havaEf.karOrtusu;
    if (Math.abs(km.opacity - kar * 0.95) > 0.01) km.opacity = kar * 0.95;
    if ((kar > 0.03) !== !!tavanKariAcik) { tavanKariAcik = kar > 0.03; for (const a of arabalar) { const k = a.userData.araba && a.userData.araba.kar; if (k) k.visible = tavanKariAcik; } }
    for (const h of gecelik.haleler) {
      if (h.userData.huzme) { h.visible = isikAcik > 0.05 && !h.userData.kapali; continue; }
      // ıslak zeminde lamba ve far lekeleri daha parlak (su ışığı yansıtır)
      h.material.opacity = Math.min(1, isikAcik * (h.isSprite ? 0.9 : 0.55 * (h.userData.leke ? 1 + havaEf.islaklik * 0.55 : 1)));
      h.visible = isikAcik > 0.01 && !h.userData.kapali;
    }
    for (const l of lambalar) l.userData.lamba.ampul.material.emissiveIntensity = isikAcik * 3;
    isikliCam().emissiveIntensity = isikAcik * 1.6;
    vitrinIsigi(isikAcik);
    if (sehir) sehir.geceAyarla(isikAcik);
    for (const m of gecelik.tabelalar) m.emissiveIntensity = isikAcik * 1.35;
    pozlama.deger = 0.78 + gece * 0.5 - kasvet * 0.1 * (1 - gece);
  }
  const pozlama = { deger: 0.78 };


  // Sinematik kamera (tanıtım için): iki çekim noktası arasında yumuşak hareket.
  // nokta: { x, z, mesafe, aci, egim (isteğe bağlı: kameranın eğimi, radyan) }
  let sinema = null;
  function sinemaKamera(bas, son, sure) {
    sinema = { bas: { ...bas }, son: { ...son }, sure: Math.max(0.01, sure), t: 0 };
    ucus = null;
    hizX = hizZ = 0;
  }
  function kameraGuncelle(dt) {
    if (sinema) {
      sinema.t = Math.min(1, sinema.t + dt / sinema.sure);
      const k = sinema.t < 0.5 ? 2 * sinema.t * sinema.t : 1 - Math.pow(-2 * sinema.t + 2, 2) / 2; // yumuşak başla, yumuşak dur
      const a = sinema.bas;
      const b = sinema.son;
      const ara = (p, q) => (p ?? q) + ((q ?? p) - (p ?? q)) * k;
      hedefX = ara(a.x, b.x);
      hedefZ = ara(a.z, b.z);
      istenenMesafe = mesafe = ara(a.mesafe, b.mesafe);
      aci = ara(a.aci ?? 0, b.aci ?? 0);
      const egim = a.egim != null || b.egim != null ? ara(a.egim ?? b.egim, b.egim ?? a.egim) : null;
      hedef.set(hedefX, 1.2, hedefZ);
      const e = egim ?? egimHesapla(mesafe);
      kamera.position.set(hedefX + Math.sin(aci) * Math.cos(e) * mesafe, 1.2 + Math.sin(e) * mesafe, hedefZ + Math.cos(aci) * Math.cos(e) * mesafe);
      kamera.lookAt(hedef);
      gok2.position.copy(kamera.position);
      gorusuAc(dt);
      sahne.fog.near = (110 + mesafe * 0.85) * sisCarpani;
      sahne.fog.far = (360 + mesafe) * (0.4 + sisCarpani * 0.6);
      return;
    }
    if (ucus) {
      ucus.t = Math.min(1, ucus.t + dt * 1.3);
      const k = 1 - Math.pow(1 - ucus.t, 3);
      hedefX = ucus.bx + (ucus.sx - ucus.bx) * k;
      hedefZ = ucus.bz + (ucus.sz - ucus.bz) * k;
      istenenMesafe = ucus.bm + (ucus.sm - ucus.bm) * k;
      if (ucus.t >= 1) ucus = null;
    } else if (parmaklar.size === 0 && (Math.abs(hizX) > 0.01 || Math.abs(hizZ) > 0.01)) {
      hedefX += hizX * dt;
      hedefZ += hizZ * dt;
      const sonum = Math.pow(0.04, dt);
      hizX *= sonum;
      hizZ *= sonum;
      sinir();
    }
    const eskiMesafe = mesafe;
    mesafe += (istenenMesafe - mesafe) * Math.min(1, dt * 8);
    if (zumCapa && !ucus && eskiMesafe > 0.1) {
      // kamera çapa noktasına doğru giden doğru üzerinde kalır: çapa ekranda yerinden oynamaz
      const r = mesafe / eskiMesafe;
      hedefX = zumCapa.x + (hedefX - zumCapa.x) * r;
      hedefZ = zumCapa.z + (hedefZ - zumCapa.z) * r;
      sinir();
      if (Math.abs(istenenMesafe - mesafe) < mesafe * 0.002) zumCapa = null;
    }
    // uzaklaştıkça kamera daha dik bakar (kuş bakışı)
    const egim = egimHesapla(mesafe);
    hedef.set(hedefX, 1.2, hedefZ);
    kamera.position.set(
      hedefX + Math.sin(aci) * Math.cos(egim) * mesafe,
      1.2 + Math.sin(egim) * mesafe,
      hedefZ + Math.cos(aci) * Math.cos(egim) * mesafe,
    );
    kamera.lookAt(hedef);
    gok2.position.copy(kamera.position);
    gorusuAc(dt);
    sahne.fog.near = (110 + mesafe * 0.85) * sisCarpani;
    sahne.fog.far = (360 + mesafe) * (0.4 + sisCarpani * 0.6);
    // gölge alanı kameranın gördüğü alana göre büyür
    const istenenGolge = Math.max(26, Math.min(150, mesafe * 1.1));
    if (Math.abs(istenenGolge - golgeBoyu) > 4) {
      golgeBoyu = istenenGolge;
      Object.assign(gunes.shadow.camera, { left: -golgeBoyu, right: golgeBoyu, top: golgeBoyu * 0.85, bottom: -golgeBoyu * 0.85, far: 140 + golgeBoyu * 2 });
      gunes.shadow.camera.updateProjectionMatrix();
    }
  }

  // Kamerayla bakılan yer arasında kalan binalar yumuşakça saydamlaşır (birden kaybolup geri gelmez).
  // Karar için ışın binanın kutusunu keser mi diye bakılır; kısa titreşimler için gecikmeli (histerezisli) karar verilir.
  const isin = new THREE.Ray();
  const yon3 = new THREE.Vector3();
  const kesisim = new THREE.Vector3();
  const SAYDAM_EN_AZ = 0; // kesit: engel olan binada yalnızca zemin kat kalır
  const genisKutu = new THREE.Box3();
  function arayaGiriyor(d) {
    // kamera binanın içinde ya da dibindeyse
    genisKutu.copy(d.kutu).expandByVector(new THREE.Vector3(5, 200, 5));
    if (genisKutu.containsPoint(kamera.position)) return true;
    for (const yukseklik of [1.2, 3.5, 6]) {
      yon3.set(hedefX, yukseklik, hedefZ).sub(kamera.position);
      const boy = yon3.length();
      isin.set(kamera.position, yon3.normalize());
      const k = isin.intersectBox(d.kutu, kesisim);
      if (k && kamera.position.distanceTo(k) < boy - 2.5) return true;
    }
    return false;
  }
  // Kamerayı kapatan bina kaybolmaz, "kesit" alınır: üst katlar yumuşakça aşağı iner, zemin kattaki dükkân,
  // vitrini ve tabelası her zaman görünür kalır (oran 1 = bina tam, 0 = yalnızca zemin kat).
  const KESIT_ALT = KALDIRIM_Y + 4.45;
  function saydamlikUygula(d, oran) {
    if (oran >= 0.999) {
      if (!d.kopyalar) return;
      d.grup.traverse((o) => {
        if (!o.userData.asilMalzeme) return;
        o.material = o.userData.asilMalzeme;
        delete o.userData.asilMalzeme;
      });
      for (const m of d.kopyalar.values()) { gecelik.tabelalar.delete(m); m.dispose(); }
      d.kopyalar = null;
      golgeKirli = true;
      return;
    }
    if (!d.kopyalar) {
      d.kopyalar = new Map();
      d.kesitDuzlemi = new THREE.Plane(new THREE.Vector3(0, -1, 0), 1000);
      d.grup.traverse((o) => {
        if (!(o.isMesh || o.isSprite) || o.userData.asilMalzeme) return;
        const kopyala = (m) => {
          if (!d.kopyalar.has(m)) {
            const k = m.clone();
            k.clippingPlanes = [d.kesitDuzlemi];
            k.clipShadows = true;
            k.side = o.isMesh ? THREE.DoubleSide : k.side; // kesilen yerden içerisi boş görünmesin
            if (m.userData && m.userData.tabela) gecelik.tabelalar.add(k);
            d.kopyalar.set(m, k);
          }
          return d.kopyalar.get(m);
        };
        o.userData.asilMalzeme = o.material;
        o.material = Array.isArray(o.material) ? o.material.map(kopyala) : kopyala(o.material);
      });
    }
    const tepe = d.kutu ? d.kutu.max.y + 0.5 : KESIT_ALT + 30;
    const yeniSabit = KESIT_ALT + (tepe - KESIT_ALT) * Math.max(0, Math.min(1, oran));
    if (Math.abs(yeniSabit - d.kesitDuzlemi.constant) > 0.5) golgeKirli = true;
    d.kesitDuzlemi.constant = yeniSabit;
  }
  function gorusuAc(dt) {
    if (introCekim) return; // çekimde bina kesitinin kamerada yanıp sönmesi engellenir
    // çok uzaktan (kuş bakışı) binalar zaten engel olmaz; eşik yumuşak geçişle uygulanır
    const acik = mesafe < 120;
    for (const d of dukkanlar.values()) {
      if (!d.grup || !d.kutu) continue;
      const engel = acik && arayaGiriyor(d);
      // engel durumu en az 0,2 sn sürmeden karar değişmez (yakınlaştırırken yanıp sönmesin)
      d.engelSure = engel === !!d.engel ? 0 : (d.engelSure || 0) + dt;
      if (d.engelSure > 0.2) { d.engel = engel; d.engelSure = 0; }
      const hedefOran = d.engel ? SAYDAM_EN_AZ : 1;
      const oran = d.saydamlik ?? 1;
      if (Math.abs(oran - hedefOran) < 0.001) continue;
      const yeni = hedefOran < oran ? Math.max(hedefOran, oran - dt * 2.2) : Math.min(hedefOran, oran + dt * 1.6);
      d.saydamlik = yeni;
      saydamlikUygula(d, yeni);

    }
  }

  // Pencere ışıkları (0.38.0): gece çok seyrek, yakındaki bir binada bir pencerenin ışığı yanar ya da söner,
  // bir süre sonra eski hâline döner. Aynı anda en çok üç pencere; her biri tek küçük çizim.
  const pencereOyunlari = [];
  let sonrakiPencere = 6 + Math.random() * 8;
  const pencereKonum = new THREE.Vector3();
  function pencereIsiklari(t, dt) {
    for (let i = pencereOyunlari.length - 1; i >= 0; i--) {
      const p = pencereOyunlari[i];
      p.t += dt;
      const hedef = p.t < p.sure ? 1 : 0;
      p.a += (hedef - p.a) * Math.min(1, dt * (p.yanan ? 3 : 5));
      p.m.material.opacity = p.a * (p.yanan ? 0.92 * isikAcikPayi : 0.96);
      if (p.t > p.sure && p.a < 0.02) { p.m.parent && p.m.parent.remove(p.m); p.m.geometry.dispose(); p.m.material.dispose(); pencereOyunlari.splice(i, 1); }
    }
    if (t < sonrakiPencere) return;
    sonrakiPencere = t + 7 + Math.random() * 14;
    if (isikAcikPayi < 0.6 || pencereOyunlari.length >= 3) return;
    const adaylar = [...dukkanlar.values()].filter((d) => d.grup && d.grup.parent && d.grup.userData.pencereler && d.grup.userData.pencereler.length && Math.abs(d.merkezX - hedefX) < 45 + mesafe * 0.4);
    if (!adaylar.length) return;
    const d = adaylar[Math.floor(Math.random() * adaylar.length)];
    const l = d.grup.userData.pencereler;
    const [x, y, z, w, h, isikli] = l[Math.floor(Math.random() * l.length)];
    if (pencereOyunlari.some((p) => p.d === d && p.x === x && p.y === y)) return;
    // ışıklı pencere söner (karanlık cam), karanlık pencere yanar (sıcak ışık)
    const yanan = !isikli;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.98, h * 0.98), new THREE.MeshBasicMaterial({ color: yanan ? '#FFD49A' : '#2E3B48', transparent: true, opacity: 0, depthWrite: false, toneMapped: !yanan }));
    m.position.set(x, y, z);
    m.renderOrder = 2;
    m.userData.golgeAsil = false;
    d.grup.add(m);
    pencereOyunlari.push({ m, d, x, y, yanan, a: 0, t: 0, sure: 8 + Math.random() * 18 });
  }
  // Kuşlar ve köpekler (0.38.0): gündüz arada bir caddenin üstünden kuş sürüsü geçer; kaldırımda bir sokak köpeği
  // ekranın bir ucundan girip öbür ucundan çıkar (arada durup koklar). Aynı anda en çok bir sürü ve bir köpek.
  let kusSuru = null, kopek = null;
  let sonrakiKus = 25 + Math.random() * 30, sonrakiKopek = 40 + Math.random() * 50;
  function hayvanlar(t, dt) {
    if (kusSuru) {
      kusSuru.t += dt;
      for (const b of kusSuru.kuslar) {
        b.position.x += kusSuru.yon * 9 * dt;
        b.position.y = kusSuru.y + b.userData.dy + Math.sin(kusSuru.t * 1.3 + b.userData.dy * 4) * 0.4;
        kusCirp(b, dt);
      }
      if (kusSuru.t > 22) { for (const b of kusSuru.kuslar) sahne.remove(b); kusSuru = null; }
    } else if (t > sonrakiKus) {
      sonrakiKus = t + 45 + Math.random() * 70;
      if (gecePayi < 0.5 && !introCekim) {
        const yon = Math.random() < 0.5 ? 1 : -1;
        const y = 11 + Math.random() * 7;
        const z = hedefZ + (Math.random() - 0.5) * 20;
        const kuslar = [];
        const n = 5 + Math.floor(Math.random() * 5);
        for (let i = 0; i < n; i++) {
          const b = kusModeli(Math.random() < 0.3 ? '#4A4A52' : '#26262B');
          // V dizilişi
          const sira = Math.ceil(i / 2), yan = i % 2 ? 1 : -1;
          b.position.set(hedefX - yon * (95 + sira * 1.6), y, z + yan * sira * 1.3);
          b.rotation.y = yon > 0 ? 0 : Math.PI;
          b.userData.dy = (Math.random() - 0.5) * 0.8;
          b.traverse((o) => { o.castShadow = false; o.userData.golgeAsil = false; });
          sahne.add(b); kuslar.push(b);
        }
        kusSuru = { kuslar, yon, y, t: 0 };
        if (ses.kusSesi) ses.kusSesi();
      }
    }
    if (kopek) {
      const u = kopek.userData;
      u.t += dt;
      if (u.dur > 0) { u.dur -= dt; u.hiz = Math.max(0, u.hiz - dt * 3); }
      else { u.hiz = Math.min(1.25, u.hiz + dt * 2); if (Math.random() < dt * 0.08) u.dur = 1.5 + Math.random() * 2.5; }
      kopek.position.x += u.yon * u.hiz * dt;
      kopekAdim(kopek, u.hiz, dt);
      if (u.t > 6 && !ekrandaMi(kopek.position, 1) || u.t > 120) { sahne.remove(kopek); kopek = null; }
    } else if (t > sonrakiKopek) {
      sonrakiKopek = t + 60 + Math.random() * 90;
      if (!introCekim && !durus) {
        const yon = Math.random() < 0.5 ? 1 : -1;
        kopek = kopekModeli(['#B07A43', '#E8DCC8', '#3A3027', '#8C8A86'][Math.floor(Math.random() * 4)]);
        const z = Math.random() < 0.6 ? 9.75 : -6.55;
        // görüş alanının hemen dışından girer
        let x = hedefX - yon * 25;
        for (let i = 0; i < 12 && ekrandaMi({ x, y: 0, z }, 1); i++) x -= yon * 8;
        kopek.position.set(x, KALDIRIM_Y, z);
        kopek.rotation.y = yon > 0 ? 0 : Math.PI;
        Object.assign(kopek.userData, { yon, hiz: 0, dur: 0, t: 0 });
        kopek.traverse((o) => { if (o.isMesh) { o.castShadow = !sabitGolge; o.userData.golgeAsil = o.castShadow; } });
        sahne.add(kopek);
      }
    }
  }
  // Selektör (0.38.0): gece arada bir bir araba uzunları iki kez yakıp söndürür
  let sonrakiSelektor = 8 + Math.random() * 10, selektorAraba = null, selektorBas = 0;
  function selektorler(t) {
    if (selektorAraba) {
      const g = t - selektorBas;
      const acik = g < 0.16 || (g > 0.32 && g < 0.48);
      for (const h of selektorAraba.userData.huzmeler || []) {
        if (!h.userData.taban) h.userData.taban = h.scale.clone();
        const b = h.userData.taban;
        h.scale.set(b.x * (acik ? 1.9 : 1), b.y * (acik ? 1.25 : 1), b.z * (acik ? 1.25 : 1));
        h.rotation.z = acik ? -0.025 : -0.07;
      }
      if (g > 0.6) selektorAraba = null;
      return;
    }
    if (t < sonrakiSelektor) return;
    sonrakiSelektor = t + 10 + Math.random() * 18;
    if (isikAcikPayi < 0.3) return;
    const adaylar = arabalar.filter((a) => a.visible && a.userData.huzmeler && a.position.distanceToSquared(kamera.position) < 90 * 90);
    if (!adaylar.length) return;
    selektorAraba = adaylar[Math.floor(Math.random() * adaylar.length)];
    selektorBas = t;
  }
  let uzakSayac = 0;
  // ---- Sabit gölge (0.38.0, telefon ve tablet): gölge haritasını yalnızca binalar, ağaçlar, tezgâhlar gibi duran
  // nesneler çizer ve harita yalnızca ışık yönü, gölge alanı ya da sahne değişince yenilenir (her karede değil).
  // Yürüyen insanlar ve arabalar haritaya girmez; altlarında yumuşak bir zemin gölgesi (tek çizimle) olur.
  // Ekran kartının her karede yaptığı gölge çizimi ortadan kalkar: ısınma ve takılma azalır, görüntü aynı kalır.
  const sabitGolge = !!gunes.castShadow && matchMedia('(pointer: coarse)').matches;
  let golgeYonAnahtari = '', golgeSonAnahtar = null, golgeSonCizim = -99, golgeKirli = true, golgeCocukSayisi = -1;
  function golgeIstegi() {
    const t = performance.now() / 1000;
    if (sahne.children.length !== golgeCocukSayisi) { golgeCocukSayisi = sahne.children.length; golgeKirli = true; }
    const anahtar = golgeYonAnahtari + ',' + golgeBoyu;
    if ((anahtar !== golgeSonAnahtar || golgeKirli) && t - golgeSonCizim > 0.25 || t - golgeSonCizim > 8) {
      golgeSonAnahtar = anahtar; golgeSonCizim = t; golgeKirli = false;
      return true;
    }
    return false;
  }
  const lekeler = sabitGolge ? (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const x = c.getContext('2d'); const g = x.createRadialGradient(32, 32, 2, 32, 32, 31);
    g.addColorStop(0, 'rgba(0,0,0,0.72)'); g.addColorStop(0.5, 'rgba(0,0,0,0.45)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    const doku = new THREE.CanvasTexture(c);
    const m = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: doku, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }), 160);
    m.count = 0; m.frustumCulled = false; m.renderOrder = 1; m.userData.golgeAsil = false;
    sahne.add(m);
    return m;
  })() : null;
  const lekeMat = new THREE.Matrix4(), lekeKonum = new THREE.Vector3(), lekeDon = new THREE.Quaternion(), lekeOlcek = new THREE.Vector3(), lekeEuler = new THREE.Euler();
  function dinamikGolgeleriKapat() {
    if (!sabitGolge) return;
    for (const o of sahne.children) {
      const u = o.userData;
      if (u.golgeDinamik || !(u.insan || u.araba)) continue;
      u.golgeDinamik = true;
      o.traverse((x) => { if (x.isMesh) { x.castShadow = false; x.userData.golgeAsil = false; } });
    }
  }
  function lekeleriGuncelle() {
    if (!lekeler) return;
    let n = 0;
    for (const o of sahne.children) {
      const u = o.userData;
      if (!(u.insan || u.araba) || !o.visible || n >= 160) continue;
      if (u.insan && o.position.y > 0.6) continue;
      o.getWorldPosition(lekeKonum);
      lekeEuler.set(0, o.rotation.y, 0); lekeDon.setFromEuler(lekeEuler);
      if (u.araba) lekeOlcek.set(2.3, 1, 4.9); else lekeOlcek.set(0.8, 1, 0.8);
      lekeKonum.y += 0.018;
      lekeMat.compose(lekeKonum, lekeDon, lekeOlcek);
      lekeler.setMatrixAt(n++, lekeMat);
    }
    lekeler.count = n;
    lekeler.instanceMatrix.needsUpdate = true;
    lekeler.material.opacity = 1 - gecePayi * 0.55;
  }
  // İnsan ayrıntısı 40/50 m histerezisle değişir; görünür gövdeler uzaklık yüzünden yok edilmez.
  const lodKonum = new THREE.Vector3();
  // Gölge ayrıntısı (0.37.22): kamera uzaktayken (kuş bakışı) küçük nesnelerin (çiçek saksısı, levha, ampul, eşya…)
  // gölgesi gölge haritasında bir iki pikseldir, görünmez; bunlar gölge çiziminden çıkarılır. Yaklaşınca geri gelir.
  // Gölge çiziminin yarıdan fazlası bu küçük parçalardı (kuş bakışında 500'ü aşkın ek çizim).
  let golgeUzak = false, golgeTarama = -99;
  const golgeOlcek = new THREE.Vector3();
  function golgeLodu(t) {
    const uzak = mesafe > 110;
    if (uzak === golgeUzak && t - golgeTarama < 3) return;
    golgeUzak = uzak; golgeTarama = t;
    sahne.traverse((o) => {
      if (!o.isMesh || o.isSkinnedMesh || o.isInstancedMesh) return;
      const u = o.userData;
      if (u.golgeAsil === undefined) {
        u.golgeAsil = o.castShadow;
        if (!o.castShadow) return;
        const g = o.geometry;
        if (!g.boundingSphere) g.computeBoundingSphere();
        o.getWorldScale(golgeOlcek);
        u.golgeR = g.boundingSphere.radius * Math.max(golgeOlcek.x, golgeOlcek.y, golgeOlcek.z);
      }
      if (!u.golgeAsil) return;
      o.castShadow = !uzak || u.golgeR >= 1.2;
    });
  }
  const lodKure = new THREE.Sphere();
  const lodGorus = new THREE.Frustum();
  const lodMatris = new THREE.Matrix4();
  function insanLodu(g) {
    if (!g || !g.userData.insan) return;
    g.getWorldPosition(lodKonum);
    const u = lodKonum.distanceTo(kamera.position);
    const onceki = g.userData.insan.lod;
    insanLod(g, u > (onceki === 1 ? 40 : 50) ? 1 : 0);
    // ekranda değilse hareketi seyrek, uzaktaysa iki karede bir güncellenir (görüntü aynı kalır)
    lodKure.center.copy(lodKonum); lodKure.center.y += 0.9; lodKure.radius = 1.6;
    const ekranda = lodGorus.intersectsSphere(lodKure);
    insanAdimAraligi(g, !ekranda ? 6 : u > 45 ? 2 : 1);
  }
  // Binaların uzak kopyası: kameradan 90 m ötedeki binalar balkon, klima, perde gibi küçük ayrıntılar olmadan çizilir
  // (bir binanın çizim sayısı yarıya iner). Kesit alınan (kamerayı kapatan) bina hep asıl haliyle kalır.
  // Kuş bakışında bütün binaların sade kopyaları tek parça olarak (malzeme başına bir çizim) çizilir
  let topluBinalar = null;
  let topluHazirlik = null, topluHazirlikHatasi = false, topluHazirlikIsi = null;
  function topluBinalariSil() {
    topluHazirlik?.abort(); topluHazirlik = null; topluHazirlikIsi = null; topluHazirlikHatasi = false;
    for (const d of dukkanlar.values()) { if (d.grup) d.grup.visible = true; if (d.uzak) d.uzak.visible = false; }
    if (topluBinalar) { sahne.remove(topluBinalar); bellektenSil(topluBinalar); topluBinalar = null; }
  }
  function topluBinalarIste() {
    if (introCekim || topluBinalar || topluHazirlik || topluHazirlikHatasi || !dukkanlar.size) return;
    const kontrol = new AbortController(); topluHazirlik = kontrol;
    const kap = new THREE.Group(), liste = [...dukkanlar.values()]; let i = 0;
    const is = (async () => {
      try {
        const hazir = await parcaliIs(() => {
          if (i >= liste.length) return false;
          const a = liste[i++].uzakAyar;
          if (!a) return true;
          const b = apartman({ genislik: a.genislik, kat: a.kat, derinlik: 9, sade: true, rng: tohumluRastgele(a.tohum), dukkan: a.dukkan });
          b.position.set(a.x, KALDIRIM_Y, a.z); b.rotation.y = a.ry; kap.add(b);
          return true;
        }, {signal:kontrol.signal, bekle:250});
        if (!hazir || !await birlestirParcali(kap, {golge:true, signal:kontrol.signal})) return;
        if (kontrol.signal.aborted) return;
        // Shader hazırlığı görünür modele geçmeden tamamlanır.
        const r = getRenderer();
        if (r?.compileAsync) await r.compileAsync(kap, kamera, sahne);
        if (kontrol.signal.aborted) return;
        kap.visible = false; sahne.add(kap); geceIsiklariniTopla(kap); topluBinalar = kap;
      } catch (e) { if (!kontrol.signal.aborted) { topluHazirlikHatasi = true; console.error('[model hazırlığı]', e); } }
      finally {
        if (topluBinalar !== kap) { sahne.remove(kap); bellektenSil(kap); }
        if (topluHazirlik === kontrol) { topluHazirlik = null; topluHazirlikIsi = null; }
      }
    })();
    topluHazirlikIsi = is;
  }
  function binaLodlari() {
    const toplu = !introCekim && mesafe > 140 && [...dukkanlar.values()].every(d => (d.saydamlik ?? 1) >= 0.999);
    if (toplu && !topluBinalar) topluBinalarIste();
    if (topluBinalar) topluBinalar.visible = toplu;
    const hazir = toplu && !!topluBinalar;
    // Hazırlık bitene kadar mevcut binalar görünür kalır; orta mesafede yeni kopya oluşturulmaz.
    for (const d of dukkanlar.values()) {
      if (d.grup) d.grup.visible = !hazir;
      if (d.uzak) d.uzak.visible = false;
      d.uzakta = false;
    }
  }

  function insanLodlari() {
    kamera.updateMatrixWorld();
    lodGorus.setFromProjectionMatrix(lodMatris.multiplyMatrices(kamera.projectionMatrix, kamera.matrixWorldInverse));
    for (const y of yayalar) insanLodu(y);
    for (const y of gecenler) insanLodu(y);
    for (const m of musteriler) insanLodu(m);
    for (const y of yerler.values()) insanLodu(y.insan);
    for (const k of komsular.values()) insanLodu(k.insan);
    for (const c of copculer) insanLodu(c.g);
    if (olaylar) for (const k of olaylar.insanlar()) insanLodu(k.g);
  }
  // Ekranda mı (0.38.0): yolun ya da kaldırımın ucuna gelen araba ve yaya, ekrandayken birden kaybolmaz; ekranın
  // dışına çıkana kadar yürür/sürer. Ekran boyutu ve yakınlaştırma ne olursa olsun kameranın gerçek görüş alanına bakılır.
  const gorusAlani = new THREE.Frustum(), gorusMat = new THREE.Matrix4(), gorusKure = new THREE.Sphere();
  function gorusGuncelle() { kamera.updateMatrixWorld(); gorusMat.multiplyMatrices(kamera.projectionMatrix, kamera.matrixWorldInverse); gorusAlani.setFromProjectionMatrix(gorusMat); }
  function ekrandaMi(p, r = 2.5) { gorusKure.center.set(p.x, (p.y || 0) + r * 0.5, p.z); gorusKure.radius = r; return gorusAlani.intersectsSphere(gorusKure); }
  function guncelle(dt, t) {
    kameraGuncelle(dt);
    gorusGuncelle();
    // semtin sis ötesinde kalan kareleri (bina, ağaç, lamba) çizme
    // ayrıntı ayarları zamana bağlı (yavaş cihazda da her 0,4 saniyede bir)
    if (t - uzakSayac > 0.4 || t < uzakSayac) { uzakSayac = t; if (sehir && sehir.uzakGizle) sehir.uzakGizle(hedefX, hedefZ, introCekim ? Infinity : sahne.fog.far); komsuDetaylariAyarla(); insanLodlari(); binaLodlari(); golgeLodu(t); dinamikGolgeleriKapat(); }
    lekeleriGuncelle();
    selektorler(t);
    pencereIsiklari(t, dt);
    hayvanlar(t, dt);
    gunIsigi(dt);
    {
      // hava efektleri; şimşek çakınca sahne bir anlığına beyaza keser
      const hv = havaEf.guncelle(dt, t, { x: hedefX, z: hedefZ, gunduz: 1 - gecePayi, bulut: bulutPayi, zeminY, yakinlik: Math.max(0, Math.min(1, 1 - (mesafe - 25) / 90)) });
      if (hv.simsek > 0) {
        yarim.intensity += hv.simsek * 4.5;
        yarim.color.lerp(SIMSEK_RENK, hv.simsek * 0.8);
        sahne.fog.color.lerp(SIMSEK_RENK, hv.simsek * 0.45);
      }
    }
    const adimSayisi = Math.max(1, Math.ceil(dt / 0.05));
    const h = dt / adimSayisi;
    if (kuruldu) yoldakileriTopla();
    for (let i = 0; i < adimSayisi; i++) {
      const son = i === adimSayisi - 1 ? dt : 0;
      if (kuruldu) {
        isikGuncelle(h);
        trafikGuncelle(h);
        parkGuncelle(h, t);
        if (son) lambalariGuncelle(t);
        yayaGuncelle(h, son);
        copcuGuncelle(h, son);
      }
      musteriGuncelle(h, t, son);
    }
    suslemeGuncelle(t);
    paraGuncelle();
    panoGuncelle(t);
    yagisGuncelle(Math.min(dt, 0.1), t);
    if (kuruldu) olaylar.guncelle(Math.min(dt, 0.25), t);
    if (kuruldu) itisme(Math.min(dt, 0.1));

    for (const yer of yerler.values()) {
      if (yer.model) {
        if (yer.buyume < 1) {
          yer.buyume = Math.min(1, yer.buyume + dt * 2.5);
          const k = yer.buyume;
          const o = k < 0.7 ? k / 0.7 * 1.1 : 1.1 - (k - 0.7) / 0.3 * 0.1;
          yer.model.scale.setScalar(o);
          if (yer.ortu) yer.ortu.scale.setScalar(o);
        }
        const calisiyor = yer.aktif && yer.aktif.bitis > simdi();
        // modeldeki hareketli parçalar bir kez bulunur (her karede bütün modeli dolaşmamak için)
        if (!yer.hareketliler || yer.hareketliModel !== yer.model) {
          yer.hareketliModel = yer.model;
          yer.hareketliler = [];
          yer.model.traverse((o) => { const u = o.userData; if (u.don || u.salla !== undefined || u.duman || u.faz !== undefined) yer.hareketliler.push(o); });
        }
        const yakinda = yakinMi(yer.grup.position.x, yer.grup.position.z, 30);
        for (const o of yer.hareketliler) {
          if (o.userData.duman) o.visible = !!calisiyor;
          if (!yakinda) continue;
          if (o.userData.don && calisiyor) o.rotation.x += dt * 2;
          if (o.userData.salla !== undefined) o.position.x += Math.sin(t * 1.5 + o.userData.salla) * 0.002;
          if (o.userData.faz !== undefined && o.parent && o.parent.userData.duman) {
            const f = (t * 0.4 + o.userData.faz) % 1;
            o.position.y = 2.2 + f * 1.4;
            o.material.opacity = 0.5 * (1 - f);
            o.scale.setScalar(0.6 + f);
          }
        }
      }
      if (yer.bos) bosYerOynat(yer.bos, t);
      if (yer.insan && yakinMi(yer.grup.position.x, yer.grup.position.z)) insanGuncelle(yer.insan, dt);
    }
    if (introDolgu) introDolguGuncelle(dt);
    for (const k of komsular.values()) {
      if (k.model && k.buyume < 1) { k.buyume = Math.min(1, k.buyume + dt * 2.2); const o = k.buyume < 0.7 ? (k.buyume / 0.7) * 1.1 : 1.1 - ((k.buyume - 0.7) / 0.3) * 0.1; k.model.scale.setScalar(o); }
      if (k.insan && yakinMi(k.grup.position.x, k.grup.position.z)) insanGuncelle(k.insan, dt);
    }
    if (t - sonEtiket > 0.25) {
      sonEtiket = t;
      for (const yer of yerler.values()) if (yer.veri) etiketCiz(yer);
    }
    if (t - sonSes > 1) {
      sonSes = t;
      const kalabalik = Math.min(1, (yayalar.length + musteriler.filter((m) => m.visible).length) / 16) * Math.max(0.2, 1 - mesafe / 200);
      ses.ortamDurumu({ aktif: aktifMi && !document.hidden, gece: gecePayi, kalabalik });
    }
  }

  // Etiketin gizli/görünür durumu bellekte tutulur: her karede yüzlerce etikete sınıf yazmak (değişmese de)
  // tarayıcıya stil yeniden hesaplatıyordu.
  function etiketGizle(etiket, gizli) {
    // (başka yerlerde doğrudan eklenen 'gizli' sınıfı da hesaba katılır; okumak stil hesaplatmaz)
    if (etiket.classList.contains('gizli') === gizli) return;
    etiket.classList.toggle('gizli', gizli);
  }
  function etiketGoster(etiket, x3, y3, z3, gorunur = true) {
    if (!aktifMi || !gorunur) { etiketGizle(etiket, true); return; }
    bakis.set(x3, y3, z3);
    const k = ekranKonumu(bakis, kamera);
    if (!k || k.x < -80 || k.x > window.innerWidth + 80 || k.y < -40 || k.y > window.innerHeight + 40) {
      etiketGizle(etiket, true);
    } else {
      etiketGizle(etiket, false);
      // yalnızca yer değiştiyse yazılır (her karede stil yazmak tablette yavaşlatıyordu)
      const tr = `translate(${Math.round(k.x)}px, ${Math.round(k.y)}px) translate(-50%, -100%)`;
      if (etiket._tr !== tr) { etiket._tr = tr; etiket.style.transform = tr; }
    }
  }

  function etiketleriGuncelle() {
    if (sinema || introDolgu) return; // tanıtımda etiketler gizli, konumları hesaplanmaz
    const yakin = mesafe < 75;
    const orta = mesafe < 140;
    for (const yer of yerler.values()) {
      // tezgâhlara bakarken (açılıştaki genel görünüm dahil) etiketler açık kalır
      const tezgahBolgesi = mesafe < 320 && Math.abs(hedefZ - ORTA_Z) < 30 && Math.abs(hedefX) < 60;
      // uzaktan bakarken kilitli tezgâhların etiketi gizlenir, kalabalık olmasın
      const gerekli = yer.veri && (yer.aktif || yer.veri.sahip || !yer.veri.kilitli);
      // biten işin kazanç kesesi uzaktan da görünür (toplanmayı bekleyen para kaybolmasın)
      const kese = yer.durum === 'bitti' && mesafe < 260;
      etiketGoster(yer.etiket, yer.grup.position.x, ETIKET_Y + (yer.veri && yer.veri.kod === 'dondurma' ? 0.8 : 0), yer.grup.position.z, yakin || kese || (tezgahBolgesi && gerekli));
    }
    // semtin caddelerindeki komşular kuş bakışında da görünür: uzaktan küçük bir iğne, yakında tam etiket
    for (const k of komsular.values()) {
      const uzak = mesafe > 120;
      if (k.uzakEtiket !== uzak) { k.uzakEtiket = uzak; k.etiket.classList.toggle('uzak-komsu', uzak); }
      etiketGoster(k.etiket, k.grup.position.x, ETIKET_Y - 0.4, k.grup.position.z, k.mod === 'sehir' ? mesafe < 950 : mesafe < 95);
    }
    for (const d of dukkanlar.values()) {
      const i = d.veri.isletme;
      // Kendi dükkânı ve kiralık yerler için dokunma işareti.
      const kiralik = !i || i.durum === 'kiralik';
      etiketGoster(d.etiket, d.merkezX, 1.6, d.onZ + d.yon * 1.2, (kiralik || !!(i && i.benim)) && orta);
    }
    for (const m of musteriler) if (m.userData.siparis) etiketGoster(m.userData.siparis, m.position.x, 2.3, m.position.z, yakin);
    for (const s of sokakEtiketleri) { const g = mesafe > 100 && sokakEtiketiKonumla(s); etiketGoster(s.e, s.gx, 0.5, s.gz, g); }
    if (arabam) etiketGoster(arabam.etiket, arabam.g.position.x, 2.0, arabam.g.position.z, mesafe < 70);
  }

  function tikla(raycaster) {
    const hedefler = [...yerler.values()].filter((y) => y.grup.visible).map((y) => y.isabet)
      .concat([...komsular.values()].map((k) => k.isabet), [...dukkanlar.values()].map((d) => d.isabet), panolar.map((p) => p.isabet));
    const v = raycaster.intersectObjects(hedefler, false)[0];
    if (!v) return;
    if (v.object.userData.komsu) { const k = komsular.get(v.object.userData.komsu); if (k) komsuTiklandi(k.veri); return; }
    if (v.object.userData.pano) {
      // panodaki dükkâna uç; reklam yoksa reklam ekranı açılır
      const p = panolar.find((x) => x.isabet === v.object);
      if (p && p.gosterilen) dukkanaOdakla(p.gosterilen.yerNo);
      else if (reklamTik) reklamTik();
      return;
    }
    if (v.object.userData.kod) {
      tiklandi(v.object.userData.kod);
    }
    else if (v.object.userData.dukkan) dukkanTiklandi(v.object.userData.dukkan);
  }

  function odakla(kod, aniden) {
    const y = yerler.get(kod);
    if (!y) return;
    const m = Math.min(istenenMesafe, 40);
    const oz = y.grup.position.z + 1.2;
    if (aniden) { hedefX = y.grup.position.x; hedefZ = oz; istenenMesafe = mesafe = Math.max(m, enYakinMesafe); aci = 0; }
    else ucusYap(y.grup.position.x, oz, Math.max(m, enYakinMesafe));
  }
  function dukkanaOdakla(no, aniden) {
    const d = dukkanlar.get(no);
    if (!d) return;
    const z = d.onZ + d.yon * 4;
    const m = Math.max(Math.min(istenenMesafe, 40), enYakinMesafe);
    // arka sokaktaki kuzeye bakan dükkânlara güneyden bakılmalı
    if (d.yon < 0) aci = Math.PI; else if (Math.abs(aci) > Math.PI / 2) aci = 0;
    if (aniden) { hedefX = d.merkezX; hedefZ = z; istenenMesafe = mesafe = m; }
    else ucusYap(d.merkezX, z, m);
  }

  function ekranYeri(kod) {
    const y = yerler.get(kod);
    if (!y) return null;
    bakis.set(y.grup.position.x, 2, y.grup.position.z);
    return ekranKonumu(bakis, kamera);
  }
  function dukkanEkranYeri(no) {
    const d = dukkanlar.get(no);
    if (!d) return null;
    bakis.set(d.merkezX, 2.5, d.onZ);
    return ekranKonumu(bakis, kamera);
  }
  function ilkKiralik() {
    const liste = [...dukkanlar.values()].filter((d) => !d.veri.isletme)
      .sort((a, b) => Math.hypot(a.merkezX - hedefX, a.onZ - hedefZ) - Math.hypot(b.merkezX - hedefX, b.onZ - hedefZ));
    return liste[0] ? liste[0].veri.no : null;
  }

  gunIsigi();

  return {
    async hazirla() { gunIsigi(0); while (topluHazirlikIsi) await topluHazirlikIsi; },
    hazirlikDurumu() { return {binaSayisi:dukkanlar.size, toplu:!!topluBinalar, bekliyor:!!topluHazirlik, hata:topluHazirlikHatasi}; },
    baglamYenilendi() { sonOrtamYuk = -99; },
    sahne, kamera, guncelle, boyut, tikla, etiketleriGuncelle, _dukkanlar: dukkanlar,
    durumGuncelle, caddeGuncelle, caddeHazirla, reklamlariAyarla, komsulariAyarla, ziyaretBasla, ziyaretBitir, ziyaretteMi: () => !!ziyaret, arabamAyarla, odakla, dukkanaOdakla, ekranYeri, dukkanEkranYeri, ilkKiralik, havaAyarla, ozelGunAyarla, sayginDurus,
    camiyeOdakla() { aci = 0; ucusYap(XD + 48, -38, Math.max(enYakinMesafe, 30)); },
    get pozlama() { return pozlama.deger; },
    // gölge haritası kaç karede bir yenilenir: yakında her karede, kuş bakışında seyrek (gölgeler zaten küçük görünür)
    get golgeAralik() { return mesafe < 90 ? 1 : mesafe < 230 ? 3 : 8; },
    // telefon ve tablette gölge haritası yalnızca gerektiğinde yenilenir (sabit gölge)
    golgeIstegi: sabitGolge ? golgeIstegi : undefined,
    golgeYenile() { golgeKirli = true; },
    // deneme: kuş, köpek, selektör ve pencere ışığını hemen başlatır
    denemeCanlilar() { sonrakiKus = sonrakiKopek = sonrakiSelektor = sonrakiPencere = 0; for (const y of yayalar) if (Math.abs(y.userData.serit && y.userData.serit.z - 10.1) < 0.5 && !y.userData.oturma) bankaYonel(y, y.userData.serit); },
    // deneme: trafiğin anlık durumu (şerit başına görünen araba, dönen, park eden) ve yol dışına taşan araba var mı
    trafikDurumu() {
      const seritler = SERITLER.map((s, i) => ({ i, eksen: s.eksen, sabit: +s.sabit.toFixed(1), yon: s.yon, gorunen: arabalar.filter((a) => a.userData.serit === s && a.visible).length, gizli: arabalar.filter((a) => a.userData.serit === s && !a.visible).length }));
      const yolDisi = [];
      for (const a of [...arabalar, ...donenler.map((d) => d.a)]) {
        if (!a.visible) continue;
        const { x, z } = a.position;
        const anaCadde = z > 0 && z < 8.6;
        const arka = z > B_Z - B_YARI - 0.3 && z < B_Z + B_YARI + 0.3 && x > XB - 3.8 && x < XD + 3.8;
        const ara = (Math.abs(x - XB) < 3.8 || Math.abs(x - XD) < 3.8) && z < 8.6;
        if (!anaCadde && !arka && !ara) yolDisi.push([+x.toFixed(1), +z.toFixed(1)]);
      }
      return { seritler, donen: donenler.length, parkEden: parkEdenler.length, yolDisi, XB, XD };
    },
    // açılışta tüm tezgâhlar ekrana sığacak şekilde ortalanır
    tezgahlariGoster(aniden) {
      tumunuGoster = { aniden };
      if (boyut.ilk) tumunuGosterUygula();
    },
    // servis kazancı tezgâhın yığınına anında eklensin
    servisEklendi(kod, tutar) {
      const y = yerler.get(kod);
      if (y && y.aktif) y.aktif.bonus = (y.aktif.bonus || 0) + tutar;
    },
    // tanıtım: bütün tezgâh yerleri oturan satıcılarla dolar, oyuncunun tezgâhında açılış hazırlığı oynar
    introDoldur: (acik, kod) => introDoldur(acik, kod),
    introAcilis: () => introAcilisBaslat(),
    // intro için: kamerayı anında mahallenin kuş bakışına getirir
    sinemaKamera,
    sinemaBitir() { sinema = null; },
    // yeni oyuncu rehberi: gösterilecek yerin ekrandaki kutusu (tezgâh, sipariş balonu, kese) ya da null
    // rehberin gösterdiği türden en yakın tezgâhın yeri (ekranda olmasa da)
    rehberYeri(tur) {
      let en = null, enUz = Infinity;
      for (const y of yerler.values()) {
        if (!y.durum || !y.durum.startsWith(tur)) continue;
        const uz = Math.hypot(y.grup.position.x - hedefX, y.grup.position.z - hedefZ);
        if (uz < enUz) { enUz = uz; en = y; }
      }
      return en ? { x: en.grup.position.x, z: en.grup.position.z } : null;
    },
    rehberHedefi(tur) {
      if (!aktifMi || sinema) return null;
      if (tur === 'siparis' || tur === 'kese') {
        const e = document.querySelector(`.etiket:not(.gizli) .${tur}`);
        if (!e) return null;
        const r = e.getBoundingClientRect();
        return r.width ? { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width + 22, h: r.height + 22 } : null;
      }
      let en = null, enUz = Infinity;
      for (const y of yerler.values()) {
        if (!y.durum || !y.durum.startsWith(tur)) continue;
        const uz = Math.hypot(y.grup.position.x - hedefX, y.grup.position.z - hedefZ);
        if (uz < enUz) { enUz = uz; en = y; }
      }
      if (!en) return null;
      const p = en.grup.position;
      const a = ekranKonumu(bakis.set(p.x, 0.2, p.z), kamera);
      const b = ekranKonumu(bakis.set(p.x, 2.6, p.z), kamera);
      const c = ekranKonumu(bakis.set(p.x + 2.1, 1.2, p.z), kamera);
      if (!a || !b || !c) return null;
      const h = Math.max(60, Math.abs(a.y - b.y) + 30);
      const w = Math.max(70, Math.abs(c.x - a.x) * 2 + 30);
      const x = a.x, y = (a.y + b.y) / 2;
      if (x < -w / 2 || x > window.innerWidth + w / 2 || y < -h / 2 || y > window.innerHeight + h / 2) return null;
      return { x, y, w, h, kod: en.veri ? en.veri.kod : null };
    },
    yerKonumu(kod) { const y = kod ? yerler.get(kod) : yerler.values().next().value; return y ? { x: y.grup.position.x, z: y.grup.position.z } : { x: 0, z: TEZGAH_Z }; },
    sinirlar: () => ({ XB, XD, durakX: DURAK_X }),
    // tanıtımda sokakta canlılık: bir sokak olayını hemen başlatır
    olayBaslat(tur) { return olaylar.dene(tur); },
    kusBakisiAniden() {
      aci = 0;
      hedefX = (XB + XD) / 2 + 10;
      hedefZ = -22;
      istenenMesafe = mesafe = 200;
      ucus = null;
    },
    // kuş bakışı üç kademe: sokak → mahalle (190 m) → bütün semt (komşu tezgâhlar etiketleriyle) → sokak
    kusBakisi() {
      if (mesafe > 330) ucusYap((XB + XD) / 2, ORTA_Z, Math.max(30, enYakinMesafe));
      else if (mesafe > 100) { aci = 0; ucusYap(0, -40, Math.min(EN_UZAK * 0.8, 780)); }
      else { aci = 0; ucusYap((XB + XD) / 2 + 10, -22, 190); }
    },
    xOdakla(x0) { hedefX = x0; hizX = hizZ = 0; },
    hata() {
      return {
        musteriler: musteriler.map((m) => [m.userData.durum, Math.round(m.position.x), Math.round(m.position.z * 10) / 10]),
        hedef: [hedefX, hedefZ, mesafe, aci], XB, XD, dukkan: dukkanlar.size,
        kalabalik: kalabalik.denetle(itisListesi),
        yoldakiler: yoldakiler.length,
      };
    },
    // kamerayı bir noktaya uçurur (deneme ve yönlendirme için)
    bak(x, z, m) { ucusYap(x, z, m || istenenMesafe); },
    basla() { aktifMi = true; },
    durdur() {
      aktifMi = false;
      parmaklar.clear();
      ses.ortamDurumu({ aktif: false });
      for (const y of yerler.values()) y.etiket.classList.add('gizli');
      for (const d of dukkanlar.values()) d.etiket.classList.add('gizli');
      for (const m of musteriler) if (m.userData.siparis) m.userData.siparis.classList.add('gizli');
      for (const s of sokakEtiketleri) s.e.classList.add('gizli');
      for (const e of etiketKutusu.children) e.classList.add('gizli');
    },
    olaylar,
  };
}
