// Grafik kalitesi: cihaza göre otomatik seçilir, oyuncu isterse değiştirir.
const AYARLAR = {
  dusuk: { ad: 'Düşük', piksel: 1, golge: false, golgeBoyut: 0, yaya: 6, araba: 4, musteri: 6, bina: 1 },
  orta: { ad: 'Orta', piksel: 1.5, golge: true, golgeBoyut: 1024, yaya: 10, araba: 6, musteri: 10, bina: 1 },
  yuksek: { ad: 'Yüksek', piksel: 2, golge: true, golgeBoyut: 2048, yaya: 16, araba: 8, musteri: 16, bina: 1 },
};

function otomatik() {
  const dokunmatik = matchMedia('(pointer: coarse)').matches;
  const bellek = navigator.deviceMemory || 4;
  const cekirdek = navigator.hardwareConcurrency || 4;
  if (dokunmatik && (bellek <= 3 || cekirdek <= 4)) return 'dusuk';
  if (dokunmatik) return 'orta';
  return cekirdek >= 8 ? 'yuksek' : 'orta';
}

export function kaliteTercihi() {
  try { return localStorage.getItem('tezgah_kalite') || 'otomatik'; } catch (e) { return 'otomatik'; }
}
export function kaliteKaydet(t) {
  try { localStorage.setItem('tezgah_kalite', t); } catch (e) { /* yok say */ }
}
export function kaliteKodu() {
  const t = kaliteTercihi();
  return AYARLAR[t] ? t : otomatik();
}
export function kalite() {
  return { kod: kaliteKodu(), ...AYARLAR[kaliteKodu()] };
}
export const KALITELER = AYARLAR;

// Kare hızı, grafik ayrıntısından bağımsızdır; varsayılan 30 FPS.
export function fpsTercihi() {
  try { return localStorage.getItem('cirak_fps') === '60' ? 60 : 30; }
  catch (_) { return 30; }
}
export function fpsKaydet(deger) {
  const fps = Number(deger) === 60 ? 60 : 30;
  try { localStorage.setItem('cirak_fps', String(fps)); } catch (_) { /* oturumda uygulanır */ }
  return fps;
}
