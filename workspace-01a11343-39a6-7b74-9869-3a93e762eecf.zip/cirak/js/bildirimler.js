import { sistemMetni as _autoMetin, sistemHtml as _autoHtml, sistemSablonu as _autoSablon } from './dil.js?v=0.38.0';
// Telefona / bilgisayara bildirim: izin isteme, abone olma, aboneliği kaldırma.
// Bildirimler oyun kapalıyken gelir (oyun açıkken zaten ekranda gösterilir).

import { api } from './yardimci.js?v=0.38.0';

export function destekleniyor() {
  return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && window.isSecureContext;
}

// iPhone ve iPad'de bildirim yalnızca oyun ana ekrana eklenip oradan açılınca çalışır (iOS 16.4 ve sonrası)
export function iosAnaEkranGerekli() {
  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const anaEkranda = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  return ios && !anaEkranda;
}

let kayitSozu = null;
export function servisCalisaniKaydet() {
  if (!('serviceWorker' in navigator)) return Promise.resolve(null);
  if (!kayitSozu) {
    kayitSozu = navigator.serviceWorker.register('sw.js?v=0.38.0').catch((e) => {
      console.warn('Servis çalışanı kaydedilemedi:', e);
      kayitSozu = null;
      return null;
    });
  }
  return kayitSozu;
}

function anahtarCevir(b64) {
  const dolgu = '='.repeat((4 - (b64.length % 4)) % 4);
  const ham = atob((b64 + dolgu).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(ham, (c) => c.charCodeAt(0));
}

function ayniAnahtar(abone, anahtar) {
  const a = abone.options && abone.options.applicationServerKey;
  if (!a) return true;
  const b = new Uint8Array(a);
  if (b.length !== anahtar.length) return false;
  return b.every((x, i) => x === anahtar[i]);
}

// Şu anki durum: 'desteklenmiyor' | 'ana-ekran' | 'engelli' | 'kapali' | 'acik'
export async function durum() {
  if (iosAnaEkranGerekli()) return 'ana-ekran';
  if (!destekleniyor()) return 'desteklenmiyor';
  if (Notification.permission === 'denied') return 'engelli';
  if (Notification.permission !== 'granted') return 'kapali';
  const kayit = await servisCalisaniKaydet();
  if (!kayit) return 'desteklenmiyor';
  const abone = await kayit.pushManager.getSubscription();
  return abone ? 'acik' : 'kapali';
}

// İzin ister ve abone olur. Başarılıysa true döner.
export async function ac() {
  if (!destekleniyor()) throw new Error(_autoMetin('Bu tarayıcı bildirimleri desteklemiyor.'));
  const izin = await Notification.requestPermission();
  if (izin !== 'granted') throw new Error(izin === 'denied'
    ? _autoMetin('Bildirim izni kapalı. Tarayıcının site ayarlarından bu siteye bildirim izni ver.')
    : 'Bildirim izni verilmedi.');
  const kayit = await servisCalisaniKaydet();
  if (!kayit) throw new Error(_autoMetin('Bildirim hazırlanamadı. Sayfayı yenileyip tekrar dene.'));
  await navigator.serviceWorker.ready;
  const { anahtar } = await api('bildirim');
  const anahtarBayt = anahtarCevir(anahtar);
  let abone = await kayit.pushManager.getSubscription();
  // sunucunun anahtarı değiştiyse eski abonelik geçersizdir
  if (abone && !ayniAnahtar(abone, anahtarBayt)) { await abone.unsubscribe(); abone = null; }
  if (!abone) abone = await kayit.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: anahtarBayt });
  await api('bildirim/abone', { abonelik: abone.toJSON() });
  return true;
}

export async function kapat() {
  const kayit = await servisCalisaniKaydet();
  const abone = kayit && (await kayit.pushManager.getSubscription());
  if (!abone) return;
  try { await api('bildirim/sil', { endpoint: abone.endpoint }); } catch (e) { /* yok say */ }
  await abone.unsubscribe();
}

// Oyuna girişte: izin zaten verilmişse aboneliği bu hesaba bağla (aynı cihazda hesap değişmiş olabilir).
// Oyunun adresi (klasörü) değiştiyse eski adresteki servis çalışanı ve aboneliği kaldırılır, yeni adreste
// sessizce yeniden abone olunur; böylece bildirimler iki kez gelmez.
export async function esitle() {
  try {
    if (!destekleniyor()) return;
    const kayit = await servisCalisaniKaydet();
    if (!kayit) return;
    let tasindi = false;
    for (const r of await navigator.serviceWorker.getRegistrations()) {
      // yalnızca oyunun eski klasörleri (aynı alan adındaki başka sitelere dokunulmaz)
      if (r.scope === kayit.scope || !/\/(tezgah|cirak)\/$/.test(new URL(r.scope).pathname)) continue;
      const eski = await r.pushManager.getSubscription().catch(() => null);
      if (eski) {
        try { await api('bildirim/sil', { endpoint: eski.endpoint }); } catch (e) { /* yok say */ }
        await eski.unsubscribe().catch(() => {});
        tasindi = true;
      }
      await r.unregister().catch(() => {});
    }
    if (Notification.permission !== 'granted') return;
    const abone = await kayit.pushManager.getSubscription();
    if (abone) await api('bildirim/abone', { abonelik: abone.toJSON() });
    else if (tasindi) await ac(); // izin zaten verilmiş: soru sormadan yeni adreste abone olunur
  } catch (e) { /* sessiz */ }
}

// Çıkış yaparken: bu cihaz artık bu hesabın bildirimlerini almasın
export async function cikistaSil() {
  try {
    const kayit = await servisCalisaniKaydet();
    const abone = kayit && (await kayit.pushManager.getSubscription());
    if (abone) await api('bildirim/sil', { endpoint: abone.endpoint });
  } catch (e) { /* sessiz */ }
}
