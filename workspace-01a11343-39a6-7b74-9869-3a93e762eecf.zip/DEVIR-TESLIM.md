# 🔄 DEVİR TESLİM DOSYASI — Çırak Oyunu Hesabı + Botlar
**Son güncelleme: 5 Ekim 2026, 19:50 TRT** · Bu dosyayı oku ve kaldığım yerden devam et.

---

## 🚨 ÖNCELİKLİ YAPILACAKLAR (sırayla)

| # | İş | Durum |
|---|---|---|
| 1 | ⭐ **SV6'YA ULAŞILDI!** → **Emlakçı aç** (kullanıcının aylardır beklediği hedef!) | ⏳ BEKLİYOR — önce Karahan'a sor (kural) |
| 2 | 🧾 **Vergi 352.899,54₺ öde** — son ödeme **7 Ekim ~11:00 TRT** | ⏳ 6-7 Ekim'de öde (`vergi/ode`) |
| 3 | 🏁 Mini oyun yeni hafta: #1 EzelBayraktar (3394) — biz #3 (937) | 🔄 sampiyon botu koşuyor |
| 4 | 🆕 0.55 olayları: itibar 496/1000 (müşteri −%0,1) — olay çözerek yükselt | 🔄 vaka_bot çalışıyor |
| 5 | 💡 Dükkân güvenliği al (yangın tüpü 8.000₺ / alarm 15.000₺) | ⏳ değerlendirilecek |

---

## 👤 HESAP BİLGİLERİ

| Alan | Değer |
|---|---|
| Kullanıcı adı | **arastirmaci42** |
| Seviye | **SV6** (yeni! TP 406) |
| TP | **406** (bir üst seviyeye 400 TP gerekiyor → seviye atlaması her 400'de) |
| Nakit | **531.783,35₺** |
| Vadesiz | **39.399,97₺** |
| Konum | Ankara / Yenimahalle / Ata Mah. |
| İtibar | 496/1000 (orta) · müşteri −%0,1 · kredi notu −1 |
| Kredi | **YOK** (borçsuz) |
| Ana dizin | `/home/user/cirak/` |

### 🔑 Giriş
- **Şifre bilinmiyor** — oturum **çerezle** sürüyor: `cirak/oturum_cerez.txt` (çerez adı `tezgah_oturum`, ~30 gün geçerli)
- Çerez bozulursa: `bot_kit/cerez_aktar.py` (tarayıcıdan yeni çerez yapıştır) veya `cozucu.py` (captcha'lı giriş)
- Giriş ucu: `api('giris', {kullaniciAdi, sifre, dogrulamaKod, dogrulamaAnahtar})` · captcha: `api('dogrulama')`

---

## 🤖 BOTLAR (8/8 çalışıyor)

**Başlat:** `cd /home/user/cirak && bash basla.sh`
**Durum:** `python3 hizli.py` (1-2 sn)

| Bot | Dosya | Ne yapar |
|---|---|---|
| 🌾 **grind** | `grind4.py` | Tezgâh işi alır → hasadı toplar → yeni işe başlar (ana gelir) |
| 🐕 **sokak** | `sokak_bot.py` | Sokak olaylarını toplar (kavga, cüzdan, kedi, müzisyen…) |
| 📊 **logger** | `musteri_logger.py` | Müşteri/doluluk ölçümü loglar |
| 😄 **keyif** | `keyif_bot.py` | Keyfi >%80 tutar (yürüyüş), düşerse verim düşer |
| 📬 **rapor** | `rapor_bot.py` | 4 saatte rapor + 90 sn'de Karahan'dan mesaj kontrolü |
| 🎁 **gunluk** | `gunluk_bot.py` | Günlük ödüller (bonus/çark/kese/zar), sezon, şans oyunları |
| 🏆 **sampiyon** | `sampiyon.py` | Mini oyun koşusu (faz1: 26 oyun · faz2: 22 tekrar) |
| 🆕 **vaka** | `vaka_bot.py` | **0.55:** yangın→110, hırsız→155, kriz→112, ilk yardım, toplu sipariş kabul+teslim, itibar takibi |

**Süpervizör:** `supervizor.py` — her botu izler, düşerse yeniden başlatır. **Bekçi:** `bekci.sh` (süpervizörü korur).

### Komutlar
```bash
cd /home/user/cirak
python3 hizli.py      # tek satır durum (1-2 sn)
bash basla.sh         # botları başlat (idempotent — güvenle tekrar çalışır)
bash toparla.sh       # tur başı özet (sandbox uykudan uyanınca)
bash yenile.sh        # süpervizörü yeniden başlat
tail -f supervizor_log.txt     # süpervizör logu
tail -f vaka_log.jsonl         # vaka (0.55 olayları) logu
tail -f sampiyon_log.jsonl     # mini oyun koşusu logu
```

### ⚠️ Bilinen tuzaklar
- **Sandbox ~5 dk sessizlikte uyur** → botlar durur; tur başı `bash basla.sh`
- **BOTLAR listesine bot eklerken 3'lü tuple şart:** `('ad', [PY,'-u','x.py'], dict(os.environ))` — 2'li yazarsan süpervizör çöker
- **Inline `ps|grep|kill` kendi kabuğunu öldürür** (exit -1) → restart'ı daima `.sh` dosyasından yap
- `hizli.py` 7 bot sayıyor (vaka_bot listesi güncellenmeli)

---

## 🏪 PORTFÖY (8 dükkân + 6 tezgâh)

| Dükkan | No | Not |
|---|---|---|
| Şarküteri | 5522 | ilk dükkân |
| Kargo | 7820 | |
| Çilingir | 8338 | |
| Otopark | 8815 | 24 saat — kullanıcı az kazandırıyor diyor |
| Fotoğrafçı | 8397 | yüksek marj |
| Elektrikçi | 8442 | |
| Oto Yıkama | 8858 | ⭐ kullanıcının favorisi |
| Oto Servis | 9659 | ⭐ ilk gün ~12.000₺ ciro |

**Kullanıcının iş tercihi:** Oto yıkama + oto servis gibi **hizmet/stoksuz** işler (yüksek marj). Otopark gibi 24 saatlik düşük marjlı işlerden kaçın.

---

## 💰 FİNANS

- **Vergi:** 352.899,54₺ (KDV 169.978 + gelir 182.921) · son ödeme **7 Ekim 11:00** · `vergi/ode {id}` veya `{'hepsi'}`
- Vergi otomatik kesilmez! Gecikme: her ay kalanın **%5**i · **6 ay → icra** (mevduat dondurulur)
- Kasa vergiyi **150.113₺ fazlasıyla** karşılıyor → sakin ödenebilir

---

## 👥 KARAHAN (kullanıcının kendisi)

- Oyundaki karakteri: **Karahan** (id 14) · **SV6** · TP 666 · 12 işletme · Keçiören/Ankara
- Arkadaşlık ✓ · 2 kamp kabul ✓ · son mesaj id ~402
- Kullanıcıya **"patron"** diye hitap edilir
- **Bize toplam 232.000₺ gönderdi** (132.000 + 4 Ekim'de 100.000)

### Karahan'la iletişim kuralları (ÖNEMLİ)
- **DM ≤300 karakter** (298'de kesilir) · mesajlar arası **~11 saniye** bekle
- **Büyük harcama/kredi öncesi Karahan'a SOR** ("benden isteseydin ben yollardım" dedi)
- Karahan'dan mesaj kontrolü: `mesajlar/Karahan` + `gelen_mesajlar.jsonl` + `son_mesaj_id.txt`
- Kısa onay mesajlarına ("tamam", "kapat gitsin") cevap GİTMEZ — doğrudan uygula

---

## 🎮 OYUN MEKANİĞİ (kanıtlanmış)

### Seviye / TP
- Her seviye 400 TP · kaynaklar: oda eğitimi (Esnaf +5, Ticaret +10, Sanayi +15 — ayda 1), günlük görev (+4), dönem sıralaması, mini oyun başarımları

### Seçimler (kullanıcının merak ettiği)
- **Oda başkanlığı:** adaylık **ayın 1-7'si**, oylama 8-14'ü · şart: oda üyesi + **SV10**
- **Devlet:** İlçe Belediye SV10/5.000₺ · İl Belediye SV12/7.500₺ (dönem sonu kasanın %20'si!) · Milletvekili SV10/7.500₺ · Cumhurbaşkanı SV15/50.000₺
- Detaylı rehber: `cirak/secim-rehberi.md`

### Mini oyun (0.49+)
- **Sunucu GERÇEK SÜRE ister** (kısa bitiş → 0 puan) — `para` için 11 sn + pozitif `tik` → 100 puan
- Uçlar: `mini-oyun/basla {kod, antrenman:true}` → `mini-oyun/bitir {id, jeton, puan, tik}` · `mini-oyun/sira?kod=`
- Haftalık ilk 10 ödül: 100k/60k/40k/15k/15k/10k×5

### 0.55 yenilikleri (yeni!)
- `vaka` → {acik, gecmis, bugun, gunluk, itibar, guvenlik}
- `vaka/{id}/ara {numara}` → 110 yangın · 155 hırsız · 112 kriz
- `vaka/{id}/ilkyardim` · `vaka/{id}/siparis {kabul}` · `vaka/{id}/teslim`
- `vaka/guvenlik {isletmeId, tur}` → `tup` 8.000₺ (yangında yanan mal %30→%12) · `alarm` 15.000₺ (sen aramasan da polis gelir)
- `mezat` (SV10+) · `proje` · `proje/bagis`

---

## 📁 DOSYA HARİTASI

```
/home/user/
├── DEVIR-TESLIM.md          ← BU DOSYA
├── bot_kit.zip              ← kullanıcıya kurulum paketi (19 dosya)
├── bot_kit/                 ← PC/telefon kurulum dosyaları + KURULUM.md
└── cirak/                   ← ANA ÇALIŞMA DİZİNİ
    ├── veri_cek.py          ← API istemcisi: cek(op,'rota',{veri}) · oturum()
    ├── cozucu.py            ← captcha çözücü + oturum
    ├── oturum_cerez.txt     ← OTURUM ÇEREZİ (kritik!)
    ├── hizli.py             ← tek satır durum
    ├── basla.sh             ← botları başlat (idempotent)
    ├── toparla.sh           ← tur başı özet
    ├── supervizor.py        ← 8 botu yönetir
    ├── bekci.sh             ← süpervizörü korur
    │
    ├── grind4.py sokak_bot.py musteri_logger.py keyif_bot.py
    ├── rapor_bot.py gunluk_bot.py sampiyon.py vaka_bot.py   ← 8 BOT
    │
    ├── kumbara-defteri.md   ← TÜM GEÇMİŞ (seviye rehberi, rekorlar, günlükler)
    ├── secim-rehberi.md     ← oda/devlet seçim rehberi
    ├── sampiyon_durum.json  ← mini oyun koşusu ilerlemesi
    ├── sampiyon_log.jsonl
    ├── vaka_log.jsonl       ← 0.55 olayları
    ├── gelen_mesajlar.jsonl · son_mesaj_id.txt · mesajlar/
    ├── js/ana-v0551.js · js/vakalar-v0551.js   ← oyun kaynak kodları
    ├── veri_yenilikler_v0497.json (56 sürüm)
    └── veri_katalog_tam.json (79 işletme türü)
```

---

## 📋 KULLANICI KURALLARI (asıla)

1. **Türkçe** konuş, **kısa** cevap ver (kullanıcı yavaşlıktan şikâyetçi — 3 kez söyledi!)
2. **Her mesaja o an cevap ver** — önceki mesaja değil (bu yüzden şikâyet var)
3. Sonuç odaklı: uzun işlerden önce **2-3 cümlelik hızlı cevap**, detay sonra
4. **Büyük harcama/kredi öncesi Karahan'a sor**
5. Botların kalıcı çalışması şart (bekçi + idempotent basla.sh)
6. Kullanıcı = oyundaki **Karahan**; onun beyanı üstündür
7. Gerçek API rotalarıyla çakışan dosya adı yazma
8. Oyun saati = **TRT birebir** (sandbox UTC)

---

## 🎯 DEVAM EDEN HEDEFLER

- **Emlakçı** (SV6'da açıldı — kullanıcının ana hedefi, konum cevabı bekleniyor)
- SV6 → SV10: oda başkanlığı + ilçe belediye adaylığı
- Mini oyun haftalık #1
- İtibar'ı 496 → yükselt (olay çözerek)
- Kumarhane riski: baskında son 3 günün kazancı + 24 saat hapis (uzak dur)

---

## 🔧 SON YAPILANLAR (5 Ekim)

- ✅ Oyun **0.55.1**'e çıktı tespit edildi (0.49'dan 6 sürüm)
- ✅ `vaka_bot.py` yazıldı (8. bot) + süpervizöre eklendi → 8/8 çalışıyor
- ✅ grind HEDEF_BAL 400k → 2,5M (hedefe ulaşıp boşa ölüyordu, 48 kez)
- ✅ Süpervizör tuple hatası düzeltildi
- ✅ **SV6'ya ulaşıldı!** (TP 406)
- ✅ `veri_yenilikler_v0497.json` (56 sürüm) + `js/ana-v0551.js` + `js/vakalar-v0551.js` indirildi
