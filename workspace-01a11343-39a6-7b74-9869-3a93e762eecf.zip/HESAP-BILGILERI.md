# 🔑 HESAP BİLGİLERİ — arastirmaci42

**Bu dosyayı Arena AI'ya ver; `DEVIR-TESLIM.md` ile birlikte okusun ve kaldığı yerden devam etsin.**

---

## 📋 GİRİŞ BİLGİLERİ

| Alan | Değer |
|---|---|
| **Kullanıcı adı** | `arastirmaci42` |
| **Şifre** | ⚠️ **BİLİNMİYOR** — hesap bot tarafından açılırken rastgele üretildi, kaydedilmedi |
| **Giriş yöntemi** | **Çerez ile** (`cirak/oturum_cerez.txt` — çerez adı `tezgah_oturum`) |
| **Sunucu** | `https://oyunsitem.com/cirak/` |
| **API kökü** | `https://oyunsitem.com/cirak/api/` |
| **E-posta (kullanıcının)** | `tmrk1623@gmail.com` — 5 Eki 22:10'da oyun desteğine bağlanması için talep gönderildi ✅ |
| **Konum** | Ankara / Yenimahalle / Ata Mah. |
| **Vergi No** | 1064683142 |
| **IBAN** | `TR06 0077 7098 0600 5694 4967 03` |
| **Çalışma dizini** | `/home/user/cirak/` |

---

## ⚠️ ŞİFRE DURUMU — ÖNEMLİ

- Hesapta şifre **var** (`sifreVar: True`) ama değeri kayıtlı değil
- Şifre değiştirmek için **eski şifre** gerekiyor → bilinmiyor
- E-posta bağlı olmadığı için "şifremi unuttum" da çalışmıyor
- **Çözüm:** Hesaba bir e-posta bağlanır (`eposta` ucu) → sonra `sifremi-unuttum` ile şifre sıfırlanır → kalıcı şifre oluşur

### ✅ YAPILDI (5 Eki 22:10)
Oyun desteğine (`iletisim` ucu) talep gönderildi → `{"tamam": true}`
İstenen: **tmrk1623@gmail.com** adresinin hesaba bağlanması + sıfırlama bağlantısı gönderilmesi.
Destek ekibi bağlarsa: "Şifremi unuttum" → mail gelir → kullanıcı sıfırlar → kalıcı şifre oluşur.

### Neden otomatik yapılamadı
- `eposta` ucu → "Şifren yanlış" (eski şifre şart, captcha yetmiyor)
- `sifremi-unuttum` → captcha gerekiyor; **0.56'da captcha değişti** (rakam yok, gürültü çizgileri = görsel bulmaca) → çözücü işe yaramıyor

---

## 🤖 BOTLAR (8/8 çalışıyor)

| Bot | Dosya | İşlevi |
|---|---|---|
| 🌾 grind | `grind4.py` | Tezgâh işi → hasat → yeni iş (ana gelir) |
| 🐕 sokak | `sokak_bot.py` | Sokak olayları |
| 📊 logger | `musteri_logger.py` | Müşteri/doluluk ölçümü |
| 😄 keyif | `keyif_bot.py` | Keyfi >%80 tutar |
| 📬 rapor | `rapor_bot.py` | 4 saatte rapor + Karahan mesaj kontrolü |
| 🎁 gunluk | `gunluk_bot.py` | Günlük ödüller, sezon, şans oyunları |
| 🏆 sampiyon | `sampiyon.py` | Mini oyun koşusu (haftalık sıralama) |
| 🆕 vaka | `vaka_bot.py` | 0.55: yangın→110, hırsız→155, kriz→112, sipariş, itibar |

**Süpervizör:** `supervizor.py` (botları izler, düşerse kaldırır) · **Bekçi:** `bekci.sh`

### Komutlar
```bash
cd /home/user/cirak
python3 hizli.py     # tek satır durum (1-2 sn)
bash basla.sh        # botları başlat (idempotent)
bash yenile.sh       # süpervizörü yenile
bash toparla.sh      # tur başı özet
```

---

## 💰 GÜNCEL DURUM (5 Ekim 2026, ~20:40 TRT)

| | |
|---|---|
| Seviye | **SV6** · TP 416 |
| Kasa | **578.741₺** (nakit + vadesiz) |
| Vergi | 352.899,54₺ → **hazır (+186.441₺)** · son ödeme 7 Ekim 11:00 |
| Kredi | Yok (borçsuz) |
| İtibar | 496/1000 (orta) |
| Mini oyun | #3 (1037 puan) |
| Portföy | 8 dükkân + 6 tezgâh |

### Portföy
Şarküteri 5522 · Kargo 7820 · Çilingir 8338 · Otopark 8815 · Fotoğrafçı 8397 · Elektrikçi 8442 · Oto Yıkama 8858 · Oto Servis 9659

---

## 📁 DEVRİN TAMAMLANMASI İÇİN

1. ✅ `/home/user/DEVIR-TESLIM.md` — tüm mekanikler, API uçları, kurallar, tuzaklar
2. ✅ `/home/user/HESAP-BILGILERI.md` — bu dosya
3. ✅ `/home/user/cirak/oturum_cerez.txt` — oturum çerezi (~30 gün geçerli)
4. ✅ `/home/user/cirak/kumbara-defteri.md` — tüm geçmiş, seviye rehberi, rekorlar
5. ✅ `/home/user/bot_kit.zip` — PC/telefon kurulum paketi

**Arena AI'ya şöyle de:**
> "DEVIR-TESLIM.md ve HESAP-BILGILERI.md dosyalarını oku, `/home/user/cirak` dizininde çalış, kaldığı yerden devam et. Öncelik: (1) Emlakçı aç (SV6 geldi, önce Karahan'a sor) (2) Vergiyi 6-7 Ekim'de öde (3) 8 botu ayakta tut."

---

## 🔒 GÜVENLİK NOTU

- Bu dosya **hesap erişim bilgisi içerir** (çerez dosyasıyla birlikte) — paylaşırken dikkatli olun
- Çerez ~30 gün sonra ölür → o tarihe kadar e-posta bağlanıp kalıcı şifre alınmalı
- Otomasyonun riski kullanıcıya aittir (bugüne kadar sorun yaşanmadı)
